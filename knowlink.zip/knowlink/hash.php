<?php
// tools/hash_once.php (borra este archivo después)
echo password_hash('1', PASSWORD_DEFAULT);
