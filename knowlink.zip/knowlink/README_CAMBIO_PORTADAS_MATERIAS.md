# Cambio: portadas visuales para materias

Se agregó una mejora para que las tarjetas de materias en el módulo de estudiante ya no muestren únicamente la clave dentro del recuadro superior.

## Archivos modificados/agregados

- `public/estudiantes/index.php`
- `public/estudiantes/buscar_recurso.php`
- `public/materia_portada.php`
- `src/materia_images.php`
- `public/cache/.htaccess`

## Funcionamiento

1. La tarjeta solicita la portada a `public/materia_portada.php`.
2. Ese endpoint intenta buscar una imagen relacionada con la materia usando Wikimedia Commons.
3. Si encuentra imagen, redirige a esa imagen.
4. Si no encuentra imagen o no hay internet, genera una portada SVG local con el nombre de la materia.
5. Las imágenes encontradas se guardan en caché dentro de `public/cache/materia_images.json`.

## Ventajas

- No requiere API key.
- No modifica la base de datos.
- Si no existe imagen relacionada, no se rompe la tarjeta.
- Funciona como fallback mostrando el nombre de la materia y, si no hay nombre, la clave.

