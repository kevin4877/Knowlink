# KnowLink UI Perfect

Versión visual final con:

- Modo oscuro conservando la interfaz actual, pero con correcciones de contraste para textos, tarjetas, formularios, panel probabilístico, botones y tablas.
- Modo claro rediseñado con identidad propia, conectado al estilo premium del login: tarjetas blancas, acentos azul/dorado, sombras suaves, barra superior y menú lateral nuevos.
- Transiciones animadas al cambiar entre modo claro y oscuro, con soporte para View Transitions cuando el navegador lo permite.
- Ventanas “Próximamente” para Grupos y Cursos en estudiante y docente, con modal Bootstrap, ilustración integrada y textos en español.
- Eliminación de “¿Olvidaste tu contraseña?” del login, porque no existe esa función en el proyecto.
- Uso de Bootstrap 5.3.8 y capa visual global para formularios, tablas, botones, cards, modales y diseño responsive.

Archivos principales modificados:

- public/assets/css/knowlink-modern.css
- public/assets/js/knowlink-theme.js
- css/estilosLogin.css
- public/login.php
- public/estudiantes/grupos.php
- public/estudiantes/cursos.php
- public/docentes/grupos.php
- public/docentes/cursos.php
