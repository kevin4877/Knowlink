# Banco de preguntas Ingeniería Industrial 4° semestre

Archivo incluido:

- `banco_preguntas_iind_4to_sin_inc1005_200.sql`

Incluye 200 preguntas para las materias de 4° semestre de Ingeniería Industrial, excepto `INC-1005 Algoritmos y Lenguajes de Programación`, porque esa materia ya cuenta con su propio banco.

Materias incluidas:

- `INC-1023` Procesos de Fabricación
- `INC-1009` Electricidad y Electrónica Industrial
- `INC-1018` Investigación de Operaciones I
- `AEF-1025` Estadística Inferencial II
- `INJ-1012` Estudio del Trabajo II
- `INF-1016` Higiene y Seguridad Industrial

El SQL no borra preguntas anteriores. Usa `ON DUPLICATE KEY UPDATE` para actualizar preguntas si ya existían con el mismo código.
