<?php
// Prueba rápida de Ollama para KnowLink.
// Abre en navegador: http://localhost/knowlink/test_ollama.php
// o ejecútalo en consola: php test_ollama.php

declare(strict_types=1);
require_once __DIR__ . '/config/config.php';

function out($label, $value) {
  if (PHP_SAPI === 'cli') {
    echo "\n=== {$label} ===\n";
    echo is_string($value) ? $value : json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    echo "\n";
    return;
  }
  echo "<h3>" . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . "</h3><pre>" . htmlspecialchars(is_string($value) ? $value : json_encode($value, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES), ENT_QUOTES, 'UTF-8') . "</pre>";
}

function call_ollama(string $url, array $payload, int $timeout = 180): array {
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => $timeout,
  ]);
  $t0 = microtime(true);
  $res = curl_exec($ch);
  $ms = (int)round((microtime(true) - $t0) * 1000);
  $err = curl_error($ch);
  $code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
  curl_close($ch);
  return ['http' => $code, 'ms' => $ms, 'curl_error' => $err, 'raw' => $res, 'decoded' => json_decode((string)$res, true)];
}

$base = defined('OLLAMA_BASE_URL') ? rtrim((string)OLLAMA_BASE_URL, '/') : 'http://127.0.0.1:11434/api';
$model = defined('OLLAMA_MODEL') ? (string)OLLAMA_MODEL : 'llama3.2:latest';

if (PHP_SAPI !== 'cli') echo '<!doctype html><meta charset="utf-8"><title>Test Ollama KnowLink</title><style>body{font-family:system-ui;background:#0f172a;color:#e5e7eb;padding:24px}pre{background:#111827;border:1px solid #334155;border-radius:12px;padding:14px;white-space:pre-wrap}h3{color:#38bdf8}</style>';
echo PHP_SAPI === 'cli' ? "KnowLink - Test Ollama\n" : '<h1>KnowLink - Test Ollama</h1>';
out('Configuración', ['OLLAMA_BASE_URL' => $base, 'OLLAMA_MODEL' => $model]);

$ch = curl_init($base . '/tags');
curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 3, CURLOPT_TIMEOUT => 10]);
$res = curl_exec($ch);
$err = curl_error($ch);
$code = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
curl_close($ch);

if ($res === false || $code < 200 || $code >= 300) {
  out('Error consultando /api/tags', $err !== '' ? $err : ('HTTP ' . $code . ' ' . (string)$res));
  exit;
}
out('Modelos instalados', json_decode($res, true) ?: $res);

$system = 'Eres un profesor. Responde solo JSON válido.';
$user = 'Genera 2 preguntas de opción múltiple sobre lógica algorítmica. Devuelve exactamente {"questions":[{"pregunta":"...","opciones":["...","...","...","..."],"respuesta":"A","respuesta_texto":"...","explicacion":"..."}]}';

$payloadChat = [
  'model' => $model,
  'messages' => [
    ['role' => 'system', 'content' => $system],
    ['role' => 'user', 'content' => $user],
  ],
  'stream' => false,
  'format' => 'json',
  'options' => ['temperature' => 0.18, 'num_predict' => 1600],
];
out('Prueba /api/chat', call_ollama($base . '/chat', $payloadChat, 180));

$payloadGenerate = [
  'model' => $model,
  'prompt' => "INSTRUCCIONES DEL SISTEMA:\n{$system}\n\nSOLICITUD:\n{$user}\n\nResponde solo JSON válido.",
  'stream' => false,
  'format' => 'json',
  'options' => ['temperature' => 0.18, 'num_predict' => 1600],
];
out('Prueba /api/generate', call_ollama($base . '/generate', $payloadGenerate, 180));
