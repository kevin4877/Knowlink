-- =============================================================================
--  ESQUEMA BASE: KnowLink
--  MySQL 8+ / MariaDB 10.4+ (ajusta collation si tu versión difiere)
-- =============================================================================

CREATE DATABASE IF NOT EXISTS KnowLink
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE KnowLink;

-- -------------------------
-- USUARIOS Y ROLES
-- -------------------------
CREATE TABLE usuarios (
  id              BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  nombre          VARCHAR(100)       NOT NULL,
  apellidos       VARCHAR(150)       NOT NULL,
  email           VARCHAR(150)       NOT NULL,
  username        VARCHAR(60)        NOT NULL,
  password_hash   VARCHAR(255)       NOT NULL,
  rol             ENUM('estudiante','docente','administrador') NOT NULL,
  foto_url        VARCHAR(255)       NULL,
  activo          TINYINT(1)         NOT NULL DEFAULT 1,
  creado_en       TIMESTAMP          NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en  TIMESTAMP          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY ux_usuarios_email (email),
  UNIQUE KEY ux_usuarios_username (username),
  KEY ix_usuarios_rol (rol)
) ENGINE=InnoDB;

-- Estudiantes y Docentes (datos extra por rol)
CREATE TABLE estudiantes (
  usuario_id      BIGINT UNSIGNED PRIMARY KEY,
  no_control      VARCHAR(30) NOT NULL,
  reticula_id     BIGINT UNSIGNED NULL,
  carrera_id      BIGINT UNSIGNED NULL,
  semestre_actual TINYINT UNSIGNED NULL,
  extra_json      JSON NULL,
  UNIQUE KEY ux_estudiantes_no_control (no_control),
  CONSTRAINT fk_estudiantes_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE docentes (
  usuario_id  BIGINT UNSIGNED PRIMARY KEY,
  extra_json  JSON NULL,
  CONSTRAINT fk_docentes_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- ESTRUCTURA ACADÉMICA
-- -------------------------
CREATE TABLE carreras (
  id         BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  clave      VARCHAR(30)  NOT NULL,  -- ej. ICI, IEM, ISC...
  nombre     VARCHAR(200) NOT NULL,
  UNIQUE KEY ux_carreras_clave (clave)
) ENGINE=InnoDB;

CREATE TABLE reticulas (
  id              BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  carrera_id      BIGINT UNSIGNED NOT NULL,
  clave           VARCHAR(50) NOT NULL, -- p.ej. R2019-ICI
  nombre          VARCHAR(200) NOT NULL,
  vigente_desde   DATE NOT NULL,
  vigente_hasta   DATE NULL,
  UNIQUE KEY ux_reticulas_clave (clave),
  KEY ix_reticulas_carrera (carrera_id),
  CONSTRAINT fk_reticulas_carrera
    FOREIGN KEY (carrera_id) REFERENCES carreras(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Materia canónica por CLAVE (compartible entre carreras/retículas)
CREATE TABLE materias (
  clave        VARCHAR(20) PRIMARY KEY, -- ej. ACF0901
  nombre       VARCHAR(200) NOT NULL,
  descripcion  TEXT NULL
) ENGINE=InnoDB;

-- Inclusión de materia por retícula y semestre
CREATE TABLE reticula_materias (
  id               BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  reticula_id      BIGINT UNSIGNED NOT NULL,
  materia_clave    VARCHAR(20)     NOT NULL,
  semestre         TINYINT UNSIGNED NOT NULL,
  horas_teoria     TINYINT UNSIGNED NULL,
  horas_practica   TINYINT UNSIGNED NULL,
  UNIQUE KEY ux_reticula_materia (reticula_id, materia_clave),
  KEY ix_rm_semestre (reticula_id, semestre),
  CONSTRAINT fk_rm_reticula
    FOREIGN KEY (reticula_id) REFERENCES reticulas(id) ON DELETE CASCADE,
  CONSTRAINT fk_rm_materia
    FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- UNIDADES Y TEMAS
-- -------------------------
CREATE TABLE unidades (
  id             BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  materia_clave  VARCHAR(20) NOT NULL,
  numero         TINYINT UNSIGNED NOT NULL,
  titulo         VARCHAR(200) NOT NULL,
  descripcion    TEXT NULL,
  UNIQUE KEY ux_unidades (materia_clave, numero),
  KEY ix_unidades_materia (materia_clave),
  CONSTRAINT fk_unidades_materia
    FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE
) ENGINE=InnoDB;

-- Overrides por retícula (si difieren las unidades)
CREATE TABLE reticula_unidades (
  id                   BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  reticula_materia_id  BIGINT UNSIGNED NOT NULL,
  numero               TINYINT UNSIGNED NOT NULL,
  titulo               VARCHAR(200) NOT NULL,
  descripcion          TEXT NULL,
  unidad_canonica_id   BIGINT UNSIGNED NULL,
  UNIQUE KEY ux_reticula_unidad (reticula_materia_id, numero),
  KEY ix_ru_unidad_canonica (unidad_canonica_id),
  CONSTRAINT fk_ru_rm
    FOREIGN KEY (reticula_materia_id) REFERENCES reticula_materias(id) ON DELETE CASCADE,
  CONSTRAINT fk_ru_uc
    FOREIGN KEY (unidad_canonica_id) REFERENCES unidades(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE temas (
  id           BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  unidad_id    BIGINT UNSIGNED NOT NULL,
  titulo       VARCHAR(250) NOT NULL,
  descripcion  TEXT NULL,
  UNIQUE KEY ux_temas (unidad_id, titulo),
  KEY ix_temas_unidad (unidad_id),
  CONSTRAINT fk_temas_unidad
    FOREIGN KEY (unidad_id) REFERENCES unidades(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- PERMISOS DEL DOCENTE POR MATERIA (por CLAVE)
-- -------------------------
CREATE TABLE docente_permisos_materia (
  id             BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  docente_id     BIGINT UNSIGNED NOT NULL,     -- = usuarios.id del docente
  materia_clave  VARCHAR(20)     NOT NULL,
  creado_en      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_doc_perm (docente_id, materia_clave),
  KEY ix_docente (docente_id),
  CONSTRAINT fk_dpm_docente
    FOREIGN KEY (docente_id) REFERENCES docentes(usuario_id) ON DELETE CASCADE,
  CONSTRAINT fk_dpm_materia
    FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- CONTENIDOS (APUNTES) Y ACTIVOS
-- -------------------------
CREATE TABLE contenidos (
  id             BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  tema_id        BIGINT UNSIGNED NOT NULL,
  docente_id     BIGINT UNSIGNED NOT NULL,
  visibilidad    ENUM('publico','solo_estudiantes','privado') NOT NULL DEFAULT 'publico',
  titulo         VARCHAR(250) NOT NULL,
  descripcion    TEXT NULL,
  creado_en      TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY ix_contenidos_tema (tema_id),
  KEY ix_contenidos_docente (docente_id),
  KEY ix_contenidos_vis (visibilidad),
  CONSTRAINT fk_contenidos_tema
    FOREIGN KEY (tema_id) REFERENCES temas(id) ON DELETE CASCADE,
  CONSTRAINT fk_contenidos_docente
    FOREIGN KEY (docente_id) REFERENCES docentes(usuario_id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE contenido_activos (
  id            BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  contenido_id  BIGINT UNSIGNED NOT NULL,
  tipo          ENUM('pdf','word','imagen','texto','enlace','video','powerpoint','excel','otro') NOT NULL,
  titulo        VARCHAR(250) NULL,
  url           VARCHAR(500) NULL,
  texto_largo   LONGTEXT NULL,
  metadata      JSON NULL,
  orden         INT UNSIGNED NOT NULL DEFAULT 1,
  creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY ix_activos_contenido (contenido_id),
  KEY ix_activos_tipo (tipo),
  CONSTRAINT fk_activos_contenido
    FOREIGN KEY (contenido_id) REFERENCES contenidos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- RECOMENDACIONES (likes)
-- -------------------------
CREATE TABLE recomendaciones (
  usuario_id    BIGINT UNSIGNED NOT NULL,
  contenido_id  BIGINT UNSIGNED NOT NULL,
  creado_en     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (usuario_id, contenido_id),
  KEY ix_reco_contenido (contenido_id),
  CONSTRAINT fk_reco_usuario
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
  CONSTRAINT fk_reco_contenido
    FOREIGN KEY (contenido_id) REFERENCES contenidos(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- -------------------------
-- VISTAS DE APOYO (opcionales)
-- -------------------------
CREATE OR REPLACE VIEW vw_reticula_materias AS
SELECT
  rm.id                   AS reticula_materia_id,
  r.id                    AS reticula_id,
  r.clave                 AS reticula_clave,
  c.nombre                AS carrera,
  rm.semestre,
  m.clave                 AS materia_clave,
  m.nombre                AS materia_nombre
FROM reticula_materias rm
JOIN reticulas r   ON r.id = rm.reticula_id
JOIN carreras c    ON c.id = r.carrera_id
JOIN materias m    ON m.clave = rm.materia_clave;

CREATE OR REPLACE VIEW vw_unidades_efectivas AS
SELECT
  rm.id                           AS reticula_materia_id,
  COALESCE(ru.numero, u.numero)   AS numero,
  COALESCE(ru.titulo, u.titulo)   AS titulo,
  COALESCE(ru.descripcion, u.descripcion) AS descripcion,
  u.id  AS unidad_canonica_id,
  ru.id AS reticula_unidad_id
FROM reticula_materias rm
JOIN materias m ON m.clave = rm.materia_clave
LEFT JOIN unidades u ON u.materia_clave = m.clave
LEFT JOIN reticula_unidades ru
       ON ru.reticula_materia_id = rm.id
      AND (ru.unidad_canonica_id = u.id OR ru.numero = u.numero);

-- -------------------------
-- DATOS DE EJEMPLO MÍNIMOS
-- -------------------------
INSERT INTO carreras (clave, nombre) VALUES
  ('ICI', 'Ingeniería Civil'),
  ('IEM', 'Ingeniería Electromecánica');

INSERT INTO reticulas (carrera_id, clave, nombre, vigente_desde) VALUES
  ((SELECT id FROM carreras WHERE clave='ICI'), 'R2019-ICI', 'Retícula 2019 ICI', '2019-08-01'),
  ((SELECT id FROM carreras WHERE clave='IEM'), 'R2021-IEM', 'Retícula 2021 IEM', '2021-08-01');

INSERT INTO materias (clave, nombre, descripcion) VALUES
  ('ACF0901', 'Cálculo Diferencial', 'Límites, derivadas, aplicaciones');

INSERT INTO reticula_materias (reticula_id, materia_clave, semestre)
SELECT r.id, 'ACF0901', 1 FROM reticulas r WHERE r.clave='R2019-ICI';
INSERT INTO reticula_materias (reticula_id, materia_clave, semestre)
SELECT r.id, 'ACF0901', 3 FROM reticulas r WHERE r.clave='R2021-IEM';

INSERT INTO unidades (materia_clave, numero, titulo) VALUES
 ('ACF0901', 1, 'Límites y continuidad'),
 ('ACF0901', 2, 'Derivadas'),
 ('ACF0901', 3, 'Aplicaciones de la derivada');

INSERT INTO temas (unidad_id, titulo, descripcion)
VALUES ((SELECT id FROM unidades WHERE materia_clave='ACF0901' AND numero=1),
        'Concepto de límite', 'Definiciones y ejemplos');

-- Usuario docente (sin número de empleado) + alta en docentes + permiso en ACF0901
INSERT INTO usuarios (nombre, apellidos, email, username, password_hash, rol)
VALUES ('Ana', 'López', 'ana@uni.edu', 'analopez', '$2y$10$hashDeEjemplo', 'docente');

INSERT INTO docentes (usuario_id)
VALUES (LAST_INSERT_ID());

INSERT INTO docente_permisos_materia (docente_id, materia_clave)
VALUES ((SELECT usuario_id FROM docentes ORDER BY usuario_id DESC LIMIT 1), 'ACF0901');

-- Contenido de ejemplo
INSERT INTO contenidos (tema_id, docente_id, visibilidad, titulo, descripcion)
VALUES (
  (SELECT id FROM temas WHERE titulo='Concepto de límite' LIMIT 1),
  (SELECT usuario_id FROM docentes ORDER BY usuario_id DESC LIMIT 1),
  'publico',
  'Notas introductorias de límites',
  'Apuntes con ejercicios'
);

INSERT INTO contenido_activos (contenido_id, tipo, titulo, url)
VALUES (
  (SELECT id FROM contenidos WHERE titulo='Notas introductorias de límites' LIMIT 1),
  'pdf',
  'Apuntes PDF',
  '/uploads/limites_intro.pdf'
);
USE KnowLink;

CREATE TABLE IF NOT EXISTS remember_tokens (
  id BIGINT UNSIGNED PRIMARY KEY AUTO_INCREMENT,
  usuario_id BIGINT UNSIGNED NOT NULL,
  selector CHAR(18) NOT NULL,
  hashed_validator CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY ux_selector (selector),
  KEY ix_usuario (usuario_id),
  CONSTRAINT fk_rt_usuario FOREIGN KEY (usuario_id)
    REFERENCES usuarios(id) ON DELETE CASCADE
);


-- =========================================================
-- EXTENSIÓN: Ingesta de archivos, chunks y exámenes predictivos
-- =========================================================

-- Migración para ingesta de archivos + chunks + exámenes predictivos
-- Ejecuta este archivo sobre una base KnowLink ya existente.

CREATE TABLE IF NOT EXISTS activo_texto_extraido (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  activo_id BIGINT(20) UNSIGNED NOT NULL,
  contenido_id BIGINT(20) UNSIGNED NOT NULL,
  tema_id BIGINT(20) UNSIGNED NOT NULL,
  unidad_id BIGINT(20) UNSIGNED NOT NULL,
  materia_clave VARCHAR(20) NOT NULL,
  docente_id BIGINT(20) UNSIGNED NOT NULL,
  fuente_tipo ENUM('pdf','word','imagen','texto','enlace','video','powerpoint','excel','otro') NOT NULL,
  ruta_origen VARCHAR(500) DEFAULT NULL,
  nombre_archivo VARCHAR(250) DEFAULT NULL,
  hash_archivo CHAR(64) DEFAULT NULL,
  idioma VARCHAR(10) DEFAULT 'es',
  texto_crudo LONGTEXT DEFAULT NULL,
  texto_limpio LONGTEXT DEFAULT NULL,
  paginas_total INT(10) UNSIGNED DEFAULT NULL,
  caracteres_total INT(10) UNSIGNED DEFAULT NULL,
  estado ENUM('pendiente','procesando','listo','error') NOT NULL DEFAULT 'pendiente',
  error_detalle TEXT DEFAULT NULL,
  extraido_en TIMESTAMP NULL DEFAULT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  actualizado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_activo_texto_activo (activo_id),
  KEY ix_ate_contenido (contenido_id),
  KEY ix_ate_tema (tema_id),
  KEY ix_ate_unidad (unidad_id),
  KEY ix_ate_materia (materia_clave),
  KEY ix_ate_docente (docente_id),
  KEY ix_ate_estado (estado),
  CONSTRAINT fk_ate_activo FOREIGN KEY (activo_id) REFERENCES contenido_activos(id) ON DELETE CASCADE,
  CONSTRAINT fk_ate_contenido FOREIGN KEY (contenido_id) REFERENCES contenidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_ate_tema FOREIGN KEY (tema_id) REFERENCES temas(id) ON DELETE CASCADE,
  CONSTRAINT fk_ate_unidad FOREIGN KEY (unidad_id) REFERENCES unidades(id) ON DELETE CASCADE,
  CONSTRAINT fk_ate_materia FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE,
  CONSTRAINT fk_ate_docente FOREIGN KEY (docente_id) REFERENCES docentes(usuario_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS activo_chunks (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  activo_texto_id BIGINT(20) UNSIGNED NOT NULL,
  activo_id BIGINT(20) UNSIGNED NOT NULL,
  contenido_id BIGINT(20) UNSIGNED NOT NULL,
  tema_id BIGINT(20) UNSIGNED NOT NULL,
  unidad_id BIGINT(20) UNSIGNED NOT NULL,
  materia_clave VARCHAR(20) NOT NULL,
  docente_id BIGINT(20) UNSIGNED NOT NULL,
  chunk_index INT(10) UNSIGNED NOT NULL,
  texto_chunk MEDIUMTEXT NOT NULL,
  caracteres_chunk INT(10) UNSIGNED NOT NULL DEFAULT 0,
  pagina_inicio INT(10) UNSIGNED DEFAULT NULL,
  pagina_fin INT(10) UNSIGNED DEFAULT NULL,
  embedding_provider VARCHAR(50) DEFAULT NULL,
  embedding_model VARCHAR(100) DEFAULT NULL,
  embedding_status ENUM('pendiente','listo','error') NOT NULL DEFAULT 'pendiente',
  embedding_ref VARCHAR(255) DEFAULT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_chunk_unico (activo_texto_id, chunk_index),
  KEY ix_ac_activo_texto (activo_texto_id),
  KEY ix_ac_activo (activo_id),
  KEY ix_ac_contenido (contenido_id),
  KEY ix_ac_tema (tema_id),
  KEY ix_ac_unidad (unidad_id),
  KEY ix_ac_materia (materia_clave),
  KEY ix_ac_docente (docente_id),
  KEY ix_ac_embedding_status (embedding_status),
  CONSTRAINT fk_ac_activo_texto FOREIGN KEY (activo_texto_id) REFERENCES activo_texto_extraido(id) ON DELETE CASCADE,
  CONSTRAINT fk_ac_activo FOREIGN KEY (activo_id) REFERENCES contenido_activos(id) ON DELETE CASCADE,
  CONSTRAINT fk_ac_contenido FOREIGN KEY (contenido_id) REFERENCES contenidos(id) ON DELETE CASCADE,
  CONSTRAINT fk_ac_tema FOREIGN KEY (tema_id) REFERENCES temas(id) ON DELETE CASCADE,
  CONSTRAINT fk_ac_unidad FOREIGN KEY (unidad_id) REFERENCES unidades(id) ON DELETE CASCADE,
  CONSTRAINT fk_ac_materia FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE,
  CONSTRAINT fk_ac_docente FOREIGN KEY (docente_id) REFERENCES docentes(usuario_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS cola_ingesta_activos (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  activo_id BIGINT(20) UNSIGNED NOT NULL,
  prioridad TINYINT(3) UNSIGNED NOT NULL DEFAULT 5,
  estado ENUM('pendiente','procesando','listo','error') NOT NULL DEFAULT 'pendiente',
  intentos TINYINT(3) UNSIGNED NOT NULL DEFAULT 0,
  disponible_desde TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  tomado_en TIMESTAMP NULL DEFAULT NULL,
  finalizado_en TIMESTAMP NULL DEFAULT NULL,
  error_detalle TEXT DEFAULT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ux_cola_activo_pendiente (activo_id, estado),
  KEY ix_cola_activo (activo_id),
  KEY ix_cola_estado (estado, prioridad, disponible_desde),
  CONSTRAINT fk_cola_activo FOREIGN KEY (activo_id) REFERENCES contenido_activos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS examenes_predictivos (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  unidad_id BIGINT(20) UNSIGNED NOT NULL,
  materia_clave VARCHAR(20) NOT NULL,
  estudiante_id BIGINT(20) UNSIGNED DEFAULT NULL,
  titulo VARCHAR(255) NOT NULL,
  estilo ENUM('teorico','practico','mixto') NOT NULL DEFAULT 'mixto',
  proveedor_llm VARCHAR(50) DEFAULT NULL,
  modelo_llm VARCHAR(100) DEFAULT NULL,
  total_preguntas INT(10) UNSIGNED NOT NULL DEFAULT 0,
  contexto_usado MEDIUMTEXT DEFAULT NULL,
  creado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ix_ep_unidad (unidad_id),
  KEY ix_ep_materia (materia_clave),
  KEY ix_ep_estudiante (estudiante_id),
  CONSTRAINT fk_ep_unidad FOREIGN KEY (unidad_id) REFERENCES unidades(id) ON DELETE CASCADE,
  CONSTRAINT fk_ep_materia FOREIGN KEY (materia_clave) REFERENCES materias(clave) ON DELETE CASCADE,
  CONSTRAINT fk_ep_estudiante FOREIGN KEY (estudiante_id) REFERENCES estudiantes(usuario_id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS examen_preguntas (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  examen_id BIGINT(20) UNSIGNED NOT NULL,
  orden_pregunta INT(10) UNSIGNED NOT NULL,
  pregunta TEXT NOT NULL,
  opcion_a TEXT NOT NULL,
  opcion_b TEXT NOT NULL,
  opcion_c TEXT NOT NULL,
  opcion_d TEXT NOT NULL,
  respuesta_correcta CHAR(1) NOT NULL,
  explicacion TEXT DEFAULT NULL,
  chunk_ids_json LONGTEXT DEFAULT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY ux_examen_orden (examen_id, orden_pregunta),
  KEY ix_epg_examen (examen_id),
  CONSTRAINT fk_epg_examen FOREIGN KEY (examen_id) REFERENCES examenes_predictivos(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

CREATE TABLE IF NOT EXISTS examen_intentos (
  id BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  examen_id BIGINT(20) UNSIGNED NOT NULL,
  estudiante_id BIGINT(20) UNSIGNED NOT NULL,
  aciertos INT(10) UNSIGNED NOT NULL DEFAULT 0,
  errores INT(10) UNSIGNED NOT NULL DEFAULT 0,
  porcentaje DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  iniciado_en TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  finalizado_en TIMESTAMP NULL DEFAULT NULL,
  PRIMARY KEY (id),
  KEY ix_ei_examen (examen_id),
  KEY ix_ei_estudiante (estudiante_id),
  CONSTRAINT fk_ei_examen FOREIGN KEY (examen_id) REFERENCES examenes_predictivos(id) ON DELETE CASCADE,
  CONSTRAINT fk_ei_estudiante FOREIGN KEY (estudiante_id) REFERENCES estudiantes(usuario_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

