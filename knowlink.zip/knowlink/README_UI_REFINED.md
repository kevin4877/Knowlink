# KnowLink UI Refined

Ajustes aplicados:

- Menú lateral con el mismo tamaño, separación y altura en modo claro y oscuro.
- Topbar y contenido con medidas uniformes entre temas.
- El cambio de tema conserva estructura y solo cambia colores.
- Login estabilizado: los mensajes dinámicos ya no empujan el formulario ni mueven los campos mientras el usuario escribe.
- Mensajes del login pausados mientras el usuario interactúa con usuario o contraseña.
- Mejoras de contraste y limpieza visual para experiencia premium.

No se modificó la lógica de autenticación ni la base de datos.
