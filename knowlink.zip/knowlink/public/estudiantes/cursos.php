<?php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo || ($yo['rol'] ?? '') !== 'estudiante') {
  redirect(base_url('login.php'));
  exit;
}

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

$active = 'cursos';
$title = 'KnowLink · Estudiante · Cursos';
require __DIR__ . '/partials/header.php';
?>

<section class="kl-soon-stage" aria-label="Sección próximamente">
  <article class="kl-soon-card">
    <div class="kl-soon-content">
      <div class="kl-soon-illustration" aria-hidden="true">
        <svg viewBox="0 0 520 380" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Personas colaborando en una sección en desarrollo">
  <defs>
    <linearGradient id="gA" x1="70" y1="40" x2="470" y2="330" gradientUnits="userSpaceOnUse"><stop stop-color="#eaf2ff"/><stop offset="1" stop-color="#f8fbff"/></linearGradient>
    <linearGradient id="gB" x1="115" y1="125" x2="220" y2="280" gradientUnits="userSpaceOnUse"><stop stop-color="#2563eb"/><stop offset="1" stop-color="#0ea5e9"/></linearGradient>
    <linearGradient id="gC" x1="300" y1="130" x2="420" y2="285" gradientUnits="userSpaceOnUse"><stop stop-color="#fbbf24"/><stop offset="1" stop-color="#f59e0b"/></linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="18" stdDeviation="18" flood-color="#1e3a8a" flood-opacity=".13"/></filter>
  </defs>
  <circle cx="260" cy="190" r="155" fill="url(#gA)"/>
  <circle cx="92" cy="156" r="13" fill="#dbeafe"/><circle cx="430" cy="92" r="10" fill="#fef3c7"/><circle cx="444" cy="250" r="8" fill="#dbeafe"/>
  <rect x="310" y="70" width="92" height="72" rx="18" fill="#fff" stroke="#dbeafe" stroke-width="3" filter="url(#shadow)"/>
  <path d="M330 94h48M330 116h48" stroke="#93c5fd" stroke-width="8" stroke-linecap="round"/><circle cx="320" cy="94" r="8" fill="#2563eb"/><path d="M316 94l3 3 6-7" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="320" cy="116" r="8" fill="#2563eb"/><path d="M316 116l3 3 6-7" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="148" y="74" width="86" height="48" rx="22" fill="#2563eb"/><circle cx="178" cy="98" r="4" fill="#fff"/><circle cx="193" cy="98" r="4" fill="#fff"/><circle cx="208" cy="98" r="4" fill="#fff"/>
  <path d="M271 67c0-15 12-27 27-27s27 12 27 27c0 10-5 18-13 23v18h-28V90c-8-5-13-13-13-23z" fill="#fbbf24" stroke="#f59e0b" stroke-width="3"/><path d="M284 120h28" stroke="#92400e" stroke-width="8" stroke-linecap="round"/><path d="M298 20v-13M338 38l10-10M258 38l-10-10" stroke="#f59e0b" stroke-width="5" stroke-linecap="round"/>
  <g filter="url(#shadow)">
    <path d="M130 191c0-45 31-81 70-81s70 36 70 81v73H130v-73z" fill="url(#gB)"/>
    <circle cx="200" cy="122" r="34" fill="#ffd2b8"/><path d="M165 119c6-37 61-43 75-9 5 12 2 26-5 35-14-18-41-15-70-26z" fill="#111827"/>
    <path d="M100 272c12-55 49-82 100-82s88 27 100 82" fill="#1d4ed8"/>
    <path d="M175 286h94l15-78H160l15 78z" fill="#cbd5e1"/><rect x="150" y="278" width="144" height="18" rx="9" fill="#94a3b8"/>
    <circle cx="222" cy="242" r="8" fill="#f8fafc"/>
  </g>
  <g filter="url(#shadow)">
    <path d="M325 214c-10-38 10-70 45-77 35-6 66 18 75 57l16 71-120 26-16-77z" fill="url(#gC)"/>
    <circle cx="385" cy="132" r="30" fill="#ffd2b8"/><path d="M356 131c2-26 25-45 52-34 17 7 23 22 22 39-16-11-36-10-74-5z" fill="#111827"/>
    <circle cx="376" cy="137" r="9" fill="none" stroke="#111827" stroke-width="4"/><circle cx="407" cy="137" r="9" fill="none" stroke="#111827" stroke-width="4"/><path d="M385 137h13" stroke="#111827" stroke-width="4"/>
    <rect x="351" y="210" width="78" height="92" rx="14" fill="#1e3a8a"/><rect x="365" y="226" width="50" height="8" rx="4" fill="#93c5fd"/>
    <path d="M441 168c-4-26-2-47 7-65" stroke="#ffd2b8" stroke-width="16" stroke-linecap="round"/><path d="M449 101l7 16" stroke="#ffd2b8" stroke-width="11" stroke-linecap="round"/>
  </g>
  <g filter="url(#shadow)">
    <path d="M81 221c9-37 38-59 72-50 34 9 53 44 44 81l-12 52-116-29 12-54z" fill="#60a5fa"/>
    <circle cx="143" cy="154" r="29" fill="#ffd2b8"/><path d="M112 154c7-32 53-48 76-16-18 7-38 13-76 16z" fill="#111827"/>
  </g>
</svg>
      </div>
      <div>
        <span class="kl-soon-kicker"><i class="fas fa-screwdriver-wrench" aria-hidden="true"></i> En desarrollo</span>
        <h1 class="kl-soon-title">Próximamente</h1>
        <p class="kl-soon-lead">Estamos preparando esta sección para ti.</p>
        <p class="kl-soon-text">Muy pronto podrás consultar y organizar cursos desde esta sección dentro de KnowLink.</p>
        <div class="kl-soon-actions">
          <button class="btn btn-primary" type="button" data-bs-toggle="modal" data-bs-target="#soonModal"><i class="fas fa-chalkboard" aria-hidden="true"></i> Ver aviso</button>
          <a class="kl-soon-link" href="<?= esc(base_url('estudiantes/index.php')) ?>"><i class="fas fa-arrow-left me-2" aria-hidden="true"></i> Volver al panel</a>
        </div>
      </div>
    </div>
  </article>
</section>

<div class="modal fade kl-soon-modal" id="soonModal" tabindex="-1" aria-labelledby="soonModalTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
      <div class="modal-body">
        <div class="kl-modal-ill" aria-hidden="true"><svg viewBox="0 0 520 380" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="Personas colaborando en una sección en desarrollo">
  <defs>
    <linearGradient id="gA" x1="70" y1="40" x2="470" y2="330" gradientUnits="userSpaceOnUse"><stop stop-color="#eaf2ff"/><stop offset="1" stop-color="#f8fbff"/></linearGradient>
    <linearGradient id="gB" x1="115" y1="125" x2="220" y2="280" gradientUnits="userSpaceOnUse"><stop stop-color="#2563eb"/><stop offset="1" stop-color="#0ea5e9"/></linearGradient>
    <linearGradient id="gC" x1="300" y1="130" x2="420" y2="285" gradientUnits="userSpaceOnUse"><stop stop-color="#fbbf24"/><stop offset="1" stop-color="#f59e0b"/></linearGradient>
    <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%"><feDropShadow dx="0" dy="18" stdDeviation="18" flood-color="#1e3a8a" flood-opacity=".13"/></filter>
  </defs>
  <circle cx="260" cy="190" r="155" fill="url(#gA)"/>
  <circle cx="92" cy="156" r="13" fill="#dbeafe"/><circle cx="430" cy="92" r="10" fill="#fef3c7"/><circle cx="444" cy="250" r="8" fill="#dbeafe"/>
  <rect x="310" y="70" width="92" height="72" rx="18" fill="#fff" stroke="#dbeafe" stroke-width="3" filter="url(#shadow)"/>
  <path d="M330 94h48M330 116h48" stroke="#93c5fd" stroke-width="8" stroke-linecap="round"/><circle cx="320" cy="94" r="8" fill="#2563eb"/><path d="M316 94l3 3 6-7" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/><circle cx="320" cy="116" r="8" fill="#2563eb"/><path d="M316 116l3 3 6-7" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
  <rect x="148" y="74" width="86" height="48" rx="22" fill="#2563eb"/><circle cx="178" cy="98" r="4" fill="#fff"/><circle cx="193" cy="98" r="4" fill="#fff"/><circle cx="208" cy="98" r="4" fill="#fff"/>
  <path d="M271 67c0-15 12-27 27-27s27 12 27 27c0 10-5 18-13 23v18h-28V90c-8-5-13-13-13-23z" fill="#fbbf24" stroke="#f59e0b" stroke-width="3"/><path d="M284 120h28" stroke="#92400e" stroke-width="8" stroke-linecap="round"/><path d="M298 20v-13M338 38l10-10M258 38l-10-10" stroke="#f59e0b" stroke-width="5" stroke-linecap="round"/>
  <g filter="url(#shadow)">
    <path d="M130 191c0-45 31-81 70-81s70 36 70 81v73H130v-73z" fill="url(#gB)"/>
    <circle cx="200" cy="122" r="34" fill="#ffd2b8"/><path d="M165 119c6-37 61-43 75-9 5 12 2 26-5 35-14-18-41-15-70-26z" fill="#111827"/>
    <path d="M100 272c12-55 49-82 100-82s88 27 100 82" fill="#1d4ed8"/>
    <path d="M175 286h94l15-78H160l15 78z" fill="#cbd5e1"/><rect x="150" y="278" width="144" height="18" rx="9" fill="#94a3b8"/>
    <circle cx="222" cy="242" r="8" fill="#f8fafc"/>
  </g>
  <g filter="url(#shadow)">
    <path d="M325 214c-10-38 10-70 45-77 35-6 66 18 75 57l16 71-120 26-16-77z" fill="url(#gC)"/>
    <circle cx="385" cy="132" r="30" fill="#ffd2b8"/><path d="M356 131c2-26 25-45 52-34 17 7 23 22 22 39-16-11-36-10-74-5z" fill="#111827"/>
    <circle cx="376" cy="137" r="9" fill="none" stroke="#111827" stroke-width="4"/><circle cx="407" cy="137" r="9" fill="none" stroke="#111827" stroke-width="4"/><path d="M385 137h13" stroke="#111827" stroke-width="4"/>
    <rect x="351" y="210" width="78" height="92" rx="14" fill="#1e3a8a"/><rect x="365" y="226" width="50" height="8" rx="4" fill="#93c5fd"/>
    <path d="M441 168c-4-26-2-47 7-65" stroke="#ffd2b8" stroke-width="16" stroke-linecap="round"/><path d="M449 101l7 16" stroke="#ffd2b8" stroke-width="11" stroke-linecap="round"/>
  </g>
  <g filter="url(#shadow)">
    <path d="M81 221c9-37 38-59 72-50 34 9 53 44 44 81l-12 52-116-29 12-54z" fill="#60a5fa"/>
    <circle cx="143" cy="154" r="29" fill="#ffd2b8"/><path d="M112 154c7-32 53-48 76-16-18 7-38 13-76 16z" fill="#111827"/>
  </g>
</svg></div>
        <h2 id="soonModalTitle">Próximamente</h2>
        <span class="kl-dev-badge"><i class="fas fa-screwdriver-wrench" aria-hidden="true"></i> En desarrollo</span>
        <p class="lead">Estamos preparando esta sección para ti.</p>
        <p>Muy pronto podrás consultar y organizar cursos desde esta sección dentro de KnowLink.</p>
        <div class="d-grid gap-2 col-10 mx-auto">
          <button type="button" class="btn btn-primary" data-bs-dismiss="modal">Entendido</button>
          <a class="kl-soon-link" href="<?= esc(base_url('estudiantes/index.php')) ?>">Volver al panel</a>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function(){
  var modalEl = document.getElementById('soonModal');
  if(!modalEl) return;
  setTimeout(function(){
    if(window.bootstrap && window.bootstrap.Modal){
      var modal = new window.bootstrap.Modal(modalEl, {backdrop:true, keyboard:true});
      modal.show();
    }
  }, 120);
});
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
