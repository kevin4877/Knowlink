<?php
// public/estudiantes/ver_materia.php

declare(strict_types=1);

// Permite que Ollama tenga tiempo suficiente para responder sin que PHP corte la petición.
@ini_set('max_execution_time', '180');
@set_time_limit(180);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';
if (is_file(__DIR__ . '/../../vendor/autoload.php')) {
  require_once __DIR__ . '/../../vendor/autoload.php';
}

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'estudiante') { http_response_code(403); echo "Acceso denegado"; exit; }

$pdo = db();
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

/* ========= Helpers ========= */
function escx($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function json_out(array $arr, int $code = 200): void {
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}
function recortar_texto(string $s, int $max): string {
  $s = trim((string)(preg_replace('/\s+/u', ' ', $s) ?? $s));
  return mb_strlen($s, 'UTF-8') > $max ? mb_substr($s, 0, $max, 'UTF-8') : $s;
}
function limpiar_texto_salida(string $txt): string {
  $txt = str_replace(
    ['\\u201c','\\u201d','\\u2018','\\u2019','\\u00bf','\\u00a1','\\n','\\r','\\t'],
    ['','','','','','',' ',' ',' '],
    $txt
  );
  $txt = html_entity_decode($txt, ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $txt = preg_replace('/\s+/u', ' ', $txt) ?? $txt;
  return trim($txt);
}
function limpiar_opciones(array $choices): array {
  $out = [];
  foreach ($choices as $c) {
    $c = limpiar_texto_salida((string)$c);
    if ($c !== '') $out[] = $c;
  }
  return array_values($out);
}
function letra_a_indice(string $letter): int {
  $m = ['A' => 0, 'B' => 1, 'C' => 2, 'D' => 3];
  $L = strtoupper(trim($letter));
  return $m[$L] ?? 0;
}
function indice_a_letra(int $i): string {
  return ['A', 'B', 'C', 'D'][$i] ?? 'A';
}
function norm_basic(string $s): string {
  $s = mb_strtolower(trim($s), 'UTF-8');
  $s = (string)preg_replace('/\s+/u', ' ', $s);
  $s = (string)preg_replace('/[\p{P}\p{S}]+/u', '', $s);
  $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
  return trim($t !== false ? $t : $s);
}
function array_get_string(array $row, string $key, string $default = ''): string {
  return isset($row[$key]) ? (string)$row[$key] : $default;
}
function norm_choice_key(string $s): string {
  $s = html_entity_decode(trim($s), ENT_QUOTES | ENT_HTML5, 'UTF-8');
  $s = str_replace(['≤','≥','²','³'], ['<=','>=','^2','^3'], $s);
  $s = mb_strtolower($s, 'UTF-8');
  $s = (string)preg_replace('/\s+/u', ' ', $s);
  $t = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
  return trim($t !== false ? $t : $s);
}
if (!function_exists('find_correct_index')) {
  function find_correct_index(array $choices, string $respuesta = '', string $respuesta_texto = ''): int {
    $respuesta = strtoupper(trim($respuesta));
    if (in_array($respuesta, ['A', 'B', 'C', 'D'], true)) {
      return letra_a_indice($respuesta);
    }
    $needle = norm_basic($respuesta_texto);
    if ($needle !== '') {
      foreach ($choices as $i => $c) {
        if (norm_basic((string)$c) === $needle) return (int)$i;
      }
    }
    return 0;
  }
}
function kl_normalize_numeric_text(string $s): string {
  $s = trim($s);
  $s = str_replace([',', ' '], ['', ''], $s);
  return $s;
}
function kl_answer_text_from_question_obj(array $obj): string {
  $ops = $obj['opciones'] ?? [];
  if (!is_array($ops)) return '';
  $idx = letra_a_indice((string)($obj['respuesta'] ?? 'A'));
  return isset($ops[$idx]) ? trim((string)$ops[$idx]) : '';
}
function kl_simple_calculation_expected(string $question): ?string {
  $q = str_replace(['×','x','X'], '*', $question);
  $q = str_replace(['−','–','—'], '-', $q);
  $q = html_entity_decode($q, ENT_QUOTES | ENT_HTML5, 'UTF-8');

  // Casos del tipo: "¿Cuánto es 1 + 1?", "Si 8 + 6 = ?"
  if (preg_match('/(?:cu[aá]nto\s+es|resultado\s+de|si)?\s*(-?\d+)\s*([+\-*\/])\s*(-?\d+)\s*(?:=\s*\?|\?)/iu', $q, $m)) {
    $a = (int)$m[1];
    $op = $m[2];
    $b = (int)$m[3];
    if ($op === '+') return (string)($a + $b);
    if ($op === '-') return (string)($a - $b);
    if ($op === '*') return (string)($a * $b);
    if ($op === '/' && $b !== 0) {
      $r = $a / $b;
      return (abs($r - round($r)) < 0.000001) ? (string)(int)round($r) : rtrim(rtrim(number_format($r, 4, '.', ''), '0'), '.');
    }
  }

  // Casos del tipo: "Si 3x = 12, entonces x ="
  if (preg_match('/si\s*(-?\d+)\s*\*?\s*x\s*=\s*(-?\d+).*x\s*=/iu', $q, $m)) {
    $a = (int)$m[1];
    $b = (int)$m[2];
    if ($a !== 0 && $b % $a === 0) return (string)($b / $a);
  }

  // Casos del tipo: "Si 3x + 2 = 14, entonces x ="
  if (preg_match('/si\s*(-?\d+)\s*\*?\s*x\s*([+\-])\s*(\d+)\s*=\s*(-?\d+).*x\s*=/iu', $q, $m)) {
    $a = (int)$m[1];
    $sign = $m[2];
    $c = (int)$m[3];
    $rhs = (int)$m[4];
    if ($a !== 0) {
      $num = ($sign === '+') ? ($rhs - $c) : ($rhs + $c);
      if ($num % $a === 0) return (string)($num / $a);
    }
  }

  return null;
}
function kl_question_answer_coherent(array $obj): bool {
  $question = (string)($obj['pregunta'] ?? '');
  $answerText = kl_answer_text_from_question_obj($obj);
  $expected = kl_simple_calculation_expected($question);
  if ($expected === null) return true;

  $answerNorm = kl_normalize_numeric_text($answerText);
  $expectedNorm = kl_normalize_numeric_text($expected);
  if ($answerNorm === $expectedNorm) return true;

  // Permite respuestas como "2 unidades" siempre que inicien con el número correcto.
  return preg_match('/^' . preg_quote($expectedNorm, '/') . '(\D|$)/u', $answerNorm) === 1;
}

function quality_ok(array $obj, array &$seen): bool {
  $q = trim((string)($obj['pregunta'] ?? ''));
  $ops = $obj['opciones'] ?? null;
  $ans = (string)($obj['respuesta'] ?? 'A');

  if ($q === '' || !is_array($ops) || count($ops) < 4) return false;
  $ops = array_values(array_slice($ops, 0, 4));

  $opsNorm = array_map(fn($x) => norm_choice_key((string)$x), $ops);
  if (count(array_unique($opsNorm)) < 4) return false;
  foreach ($ops as $o) {
    $len = mb_strlen(trim((string)$o), 'UTF-8');
    if ($len < 1 || $len > 100) return false;
  }

  $bad = '/todas las anteriores|ninguna de las anteriores|todas son correctas|ninguna/i';
  foreach ($ops as $o) { if (preg_match($bad, (string)$o)) return false; }

  $qlen = mb_strlen($q, 'UTF-8');
  if ($qlen < 8 || $qlen > 220) return false;
  if (preg_match('/(elige|selecciona|marca|verdadero|falso|completa)/i', $q)) return false;

  $h = norm_basic($q);
  if (isset($seen[$h])) return false;
  $seen[$h] = true;

  $idx = letra_a_indice($ans);
  if ($idx < 0 || $idx > 3) return false;

  if (!kl_question_answer_coherent([
    'pregunta' => $q,
    'opciones' => $ops,
    'respuesta' => $ans,
  ])) return false;

  return true;
}
function validar_preguntas_generadas(array $questions): array {
  $out = [];
  $seen = [];
  foreach ($questions as $q) {
    $q['question'] = limpiar_texto_salida((string)($q['question'] ?? ''));
    $q['explanation'] = limpiar_texto_salida((string)($q['explanation'] ?? ''));
    $q['choices'] = limpiar_opciones($q['choices'] ?? []);
    if (count($q['choices']) < 4) continue;
    $q['choices'] = array_values(array_slice($q['choices'], 0, 4));

    $ans = (int)($q['answer'] ?? 0);
    if ($ans < 0 || $ans > 3) $ans = 0;
    $q['answer'] = $ans;

    if (!quality_ok([
      'pregunta' => $q['question'],
      'opciones' => $q['choices'],
      'respuesta' => indice_a_letra($q['answer']),
    ], $seen)) {
      continue;
    }

    $out[] = $q;
  }
  return $out;
}

function random_pick(array $items, int $count): array {
  $items = array_values($items);
  if ($count >= count($items)) {
    shuffle($items);
    return $items;
  }
  shuffle($items);
  return array_slice($items, 0, $count);
}
function random_item(array $items) {
  if (!$items) return null;
  return $items[array_rand($items)];
}
function random_nonzero_int(int $min, int $max): int {
  do {
    $n = random_int($min, $max);
  } while ($n === 0);
  return $n;
}
function get_recent_exam_signatures(int $unidadId): array {
  $all = $_SESSION['exam_recent_signatures'] ?? [];
  return is_array($all) ? array_values(array_filter($all[$unidadId] ?? [], 'is_string')) : [];
}
function remember_exam_signatures(int $unidadId, array $questions): void {
  if (!isset($_SESSION['exam_recent_signatures']) || !is_array($_SESSION['exam_recent_signatures'])) {
    $_SESSION['exam_recent_signatures'] = [];
  }
  $recent = get_recent_exam_signatures($unidadId);
  foreach ($questions as $q) {
    $sig = norm_basic((string)($q['question'] ?? ''));
    if ($sig !== '') $recent[] = $sig;
  }
  $recent = array_values(array_unique($recent));
  if (count($recent) > 24) {
    $recent = array_slice($recent, -24);
  }
  $_SESSION['exam_recent_signatures'][$unidadId] = $recent;
}
function select_questions_with_rotation(array $candidates, int $n, array &$seen, int $unidadId): array {
  $recent = array_flip(get_recent_exam_signatures($unidadId));
  shuffle($candidates);
  $fresh = [];
  $repeat = [];
  foreach ($candidates as $q) {
    $sig = norm_basic((string)($q['question'] ?? ''));
    if ($sig !== '' && isset($recent[$sig])) $repeat[] = $q;
    else $fresh[] = $q;
  }
  $ordered = array_merge($fresh, $repeat);
  $out = [];
  foreach ($ordered as $q) {
    if (count($out) >= $n) break;
    if (quality_ok([
      'pregunta' => $q['question'],
      'opciones' => $q['choices'],
      'respuesta' => indice_a_letra((int)$q['answer']),
    ], $seen)) {
      $out[] = $q;
    }
  }
  remember_exam_signatures($unidadId, $out);
  return $out;
}

function clamp_float_value(float $value, float $min, float $max): float {
  return max($min, min($max, $value));
}

function bayes_categoria_porcentaje(float $porcentaje): string {
  if ($porcentaje >= 85.0) return 'alto';
  if ($porcentaje >= 70.0) return 'aprobatorio';
  if ($porcentaje >= 55.0) return 'regular';
  return 'bajo';
}

function bayes_categoria_tendencia(array $porcentajes): string {
  $n = count($porcentajes);
  if ($n < 2) return 'sin_tendencia';
  $ultimo = (float)$porcentajes[0];
  $anteriores = array_slice($porcentajes, 1, min(3, $n - 1));
  $promAnterior = array_sum($anteriores) / max(1, count($anteriores));
  $dif = $ultimo - $promAnterior;
  if ($dif >= 8.0) return 'mejora';
  if ($dif <= -8.0) return 'baja';
  return 'estable';
}

function bayes_likelihoods(string $variable, string $valor): array {
  // Probabilidades condicionales estimadas para P(E|Aprueba) y P(E|No aprueba).
  // El modelo usa Naive Bayes: inicia con una probabilidad previa y la actualiza con evidencias observadas.
  $tabla = [
    'promedio' => [
      'alto'        => [0.82, 0.14],
      'aprobatorio' => [0.68, 0.26],
      'regular'     => [0.33, 0.46],
      'bajo'        => [0.12, 0.74],
    ],
    'ultimo' => [
      'alto'        => [0.78, 0.16],
      'aprobatorio' => [0.62, 0.29],
      'regular'     => [0.36, 0.45],
      'bajo'        => [0.16, 0.69],
    ],
    'tendencia' => [
      'mejora'        => [0.58, 0.22],
      'estable'       => [0.48, 0.38],
      'baja'          => [0.20, 0.56],
      'sin_tendencia' => [0.42, 0.42],
    ],
    'experiencia' => [
      'alta'  => [0.55, 0.32],
      'media' => [0.45, 0.38],
      'baja'  => [0.34, 0.45],
    ],
  ];
  $vals = $tabla[$variable][$valor] ?? [0.50, 0.50];
  // Evita divisiones entre cero y probabilidades absolutas.
  return [clamp_float_value((float)$vals[0], 0.02, 0.98), clamp_float_value((float)$vals[1], 0.02, 0.98)];
}

function calcular_prior_aprobacion_materia(PDO $pdo, string $materiaClave): array {
  $materiaClave = trim($materiaClave);
  $priorDefault = 0.62;
  $total = 0;
  $aprobados = 0;

  try {
    $st = $pdo->prepare("\n      SELECT ei.porcentaje\n      FROM examen_intentos ei\n      JOIN examenes_predictivos ep ON ep.id = ei.examen_id\n      WHERE LOWER(ep.materia_clave) = LOWER(:materia)\n      ORDER BY COALESCE(ei.finalizado_en, ei.iniciado_en) DESC, ei.id DESC\n      LIMIT 300\n    ");
    $st->execute([':materia' => $materiaClave]);
    $rows = $st->fetchAll(PDO::FETCH_COLUMN) ?: [];
    foreach ($rows as $p) {
      $total++;
      if ((float)$p >= 70.0) $aprobados++;
    }
  } catch (Throwable $e) {
    $rows = [];
  }

  // Suavizado bayesiano: si hay pocos intentos, se conserva una base razonable.
  $fuerzaPrevia = 8.0;
  $prior = (($priorDefault * $fuerzaPrevia) + $aprobados) / ($fuerzaPrevia + max(0, $total));
  $prior = clamp_float_value($prior, 0.10, 0.90);

  return [
    'prior' => $prior,
    'total_muestra' => $total,
    'aprobados_muestra' => $aprobados,
  ];
}

function calcular_probabilidad_aprobacion(PDO $pdo, int $studentId, string $materiaClave): array {
  $materiaClave = trim($materiaClave);
  if ($studentId <= 0 || $materiaClave === '') {
    return [
      'hay_historial' => false,
      'probabilidad' => null,
      'nivel' => 'Sin historial',
      'mensaje' => 'Aún no hay datos suficientes para estimar la probabilidad.',
      'intentos_usados' => 0,
      'promedio' => null,
      'aprobados' => 0,
      'ultimo_porcentaje' => null,
      'modelo' => 'Teorema de Bayes',
      'metodo' => 'bayes',
      'prior' => null,
      'evidencias' => [],
    ];
  }

  $priorInfo = calcular_prior_aprobacion_materia($pdo, $materiaClave);

  $st = $pdo->prepare("\n    SELECT ei.porcentaje, ei.iniciado_en, ei.finalizado_en\n    FROM examen_intentos ei\n    JOIN examenes_predictivos ep ON ep.id = ei.examen_id\n    WHERE ei.estudiante_id = :student\n      AND LOWER(ep.materia_clave) = LOWER(:materia)\n    ORDER BY COALESCE(ei.finalizado_en, ei.iniciado_en) DESC, ei.id DESC\n    LIMIT 10\n  ");
  $st->execute([':student' => $studentId, ':materia' => $materiaClave]);
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

  if (!$rows) {
    return [
      'hay_historial' => false,
      'probabilidad' => null,
      'nivel' => 'Sin historial',
      'mensaje' => 'Realiza al menos un examen predictivo de esta materia para calcular una probabilidad bayesiana personalizada.',
      'intentos_usados' => 0,
      'promedio' => null,
      'aprobados' => 0,
      'ultimo_porcentaje' => null,
      'modelo' => 'Teorema de Bayes',
      'metodo' => 'bayes',
      'prior' => (int)round($priorInfo['prior'] * 100),
      'evidencias' => [],
      'muestra_materia' => $priorInfo['total_muestra'],
    ];
  }

  $pesoTotal = 0.0;
  $promedioPonderado = 0.0;
  $aprobados = 0;
  $suma = 0.0;
  $porcentajes = [];

  foreach ($rows as $i => $row) {
    $porcentaje = clamp_float_value((float)($row['porcentaje'] ?? 0), 0.0, 100.0);
    $peso = pow(0.90, (float)$i); // los intentos recientes tienen un poco más de peso
    $pesoTotal += $peso;
    $promedioPonderado += $porcentaje * $peso;
    $suma += $porcentaje;
    $porcentajes[] = $porcentaje;
    if ($porcentaje >= 70.0) $aprobados++;
  }

  $intentos = count($rows);
  $promedioPonderado = $pesoTotal > 0 ? ($promedioPonderado / $pesoTotal) : 0.0;
  $promedio = round($suma / max(1, $intentos), 2);
  $ultimo = round($porcentajes[0] ?? 0.0, 2);

  $catPromedio = bayes_categoria_porcentaje($promedioPonderado);
  $catUltimo = bayes_categoria_porcentaje($ultimo);
  $catTendencia = bayes_categoria_tendencia($porcentajes);
  $catExperiencia = $intentos >= 6 ? 'alta' : ($intentos >= 3 ? 'media' : 'baja');

  $prior = clamp_float_value((float)$priorInfo['prior'], 0.05, 0.95);
  $odds = $prior / max(0.0001, (1.0 - $prior));

  $evidencias = [
    ['variable' => 'promedio', 'valor' => $catPromedio, 'texto' => 'Promedio ponderado: ' . round($promedioPonderado, 2) . '%'],
    ['variable' => 'ultimo', 'valor' => $catUltimo, 'texto' => 'Último intento: ' . $ultimo . '%'],
    ['variable' => 'tendencia', 'valor' => $catTendencia, 'texto' => 'Tendencia reciente: ' . str_replace('_', ' ', $catTendencia)],
    ['variable' => 'experiencia', 'valor' => $catExperiencia, 'texto' => 'Intentos registrados: ' . $intentos],
  ];

  $detalleBayes = [];
  foreach ($evidencias as $ev) {
    [$pEA, $pENoA] = bayes_likelihoods($ev['variable'], $ev['valor']);
    $lr = $pEA / max(0.0001, $pENoA);
    $odds *= $lr;
    $detalleBayes[] = [
      'evidencia' => $ev['texto'],
      'valor' => $ev['valor'],
      'p_e_dado_aprueba' => round($pEA, 3),
      'p_e_dado_no_aprueba' => round($pENoA, 3),
      'razon_verosimilitud' => round($lr, 3),
    ];
  }

  $posterior = $odds / (1.0 + $odds);
  $probPct = (int)round(clamp_float_value($posterior, 0.0, 1.0) * 100);

  if ($probPct >= 80) {
    $nivel = 'Alta';
    $mensaje = 'La evidencia de tus intentos anteriores actualiza la probabilidad a un nivel alto. Mantén el repaso para conservar este rendimiento.';
  } elseif ($probPct >= 60) {
    $nivel = 'Media';
    $mensaje = 'La probabilidad bayesiana es favorable, pero conviene reforzar los temas donde fallaste.';
  } elseif ($probPct >= 40) {
    $nivel = 'Baja';
    $mensaje = 'La evidencia muestra riesgo moderado. Repasa antes de generar otro examen para mejorar la probabilidad posterior.';
  } else {
    $nivel = 'Crítica';
    $mensaje = 'La probabilidad posterior es baja. Revisa el material y practica antes del siguiente intento.';
  }

  return [
    'hay_historial' => true,
    'probabilidad' => $probPct,
    'nivel' => $nivel,
    'mensaje' => $mensaje,
    'intentos_usados' => $intentos,
    'promedio' => $promedio,
    'aprobados' => $aprobados,
    'ultimo_porcentaje' => $ultimo,
    'modelo' => 'Teorema de Bayes',
    'metodo' => 'bayes',
    'prior' => (int)round($prior * 100),
    'posterior' => $probPct,
    'muestra_materia' => $priorInfo['total_muestra'],
    'evidencias' => $detalleBayes,
  ];
}

function build_topics_text(array $temas): string {
  $topicsText = '';
  foreach ($temas as $t) {
    $topicsText .= '- ' . ($t['titulo'] ?? '');
    if (!empty($t['descripcion'])) $topicsText .= ': ' . $t['descripcion'];
    $topicsText .= "\n";
  }
  return trim($topicsText);
}
function cfg_value(string $envName, string $constName, ?string $default = null): string {
  $env = getenv($envName);
  if ($env !== false && trim((string)$env) !== '') return trim((string)$env);
  if (defined($constName)) {
    $v = constant($constName);
    if ($v !== null && trim((string)$v) !== '') return trim((string)$v);
  }
  return $default !== null ? $default : '';
}
function llm_provider(): string {
  $p = strtolower(cfg_value('LLM_PROVIDER', 'LLM_PROVIDER', 'openai'));
  return in_array($p, ['ollama', 'openai'], true) ? $p : 'openai';
}
function llm_fallback_provider(): string {
  $p = strtolower(cfg_value('LLM_FALLBACK_PROVIDER', 'LLM_FALLBACK_PROVIDER', 'none'));
  return in_array($p, ['none', 'ollama', 'openai'], true) ? $p : 'none';
}
function provider_enabled(string $provider): bool {
  if ($provider === 'ollama') {
    return ollama_base_url() !== '' && ollama_model() !== '';
  }
  if ($provider === 'openai') {
    return openai_api_key() !== '';
  }
  return false;
}
function provider_order(): array {
  $first = llm_provider();
  $fallback = llm_fallback_provider();
  $order = [$first];
  if ($fallback !== 'none' && $fallback !== $first) $order[] = $fallback;
  return $order;
}
function decode_json_from_text(string $txt): ?array {
  $data = json_decode($txt, true);
  if (is_array($data)) return $data;
  $start = strpos($txt, '{');
  $end = strrpos($txt, '}');
  if ($start !== false && $end !== false && $end > $start) {
    $frag = substr($txt, $start, $end - $start + 1);
    $data = json_decode($frag, true);
    if (is_array($data)) return $data;
  }
  return null;
}
function openai_base_url(): string {
  return rtrim(cfg_value('OPENAI_BASE_URL', 'OPENAI_BASE_URL', 'https://api.openai.com/v1'), '/');
}
function openai_api_key(): string {
  return trim(cfg_value('OPENAI_API_KEY', 'OPENAI_API_KEY', ''));
}
function openai_model(): string {
  return trim(cfg_value('OPENAI_MODEL', 'OPENAI_MODEL', 'gpt-4o-mini'));
}
function openai_timeout(): int {
  // Mantiene la IA ágil: si la API tarda demasiado, se usa respaldo local.
  $v = (int)cfg_value('OPENAI_TIMEOUT', 'OPENAI_TIMEOUT', '24');
  return max(10, min(45, $v));
}
function ollama_base_url(): string {
  return rtrim(cfg_value('OLLAMA_BASE_URL', 'OLLAMA_BASE_URL', 'http://127.0.0.1:11434/api'), '/');
}
function ollama_model(): string {
  return trim(cfg_value('OLLAMA_MODEL', 'OLLAMA_MODEL', 'llama3.2:latest'));
}
function ollama_timeout(): int {
  // Evita que Ollama deje esperando al alumno demasiado tiempo.
  $v = (int)cfg_value('OLLAMA_TIMEOUT', 'OLLAMA_TIMEOUT', '90');
  return max(20, min(180, $v));
}

function ollama_available_models(): array {
  static $cache = null;
  if (is_array($cache)) return $cache;

  $cache = [];
  $url = ollama_base_url() . '/tags';
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 2,
    CURLOPT_TIMEOUT => 4,
  ]);
  $res = curl_exec($ch);
  $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
  curl_close($ch);

  if ($res === false || $status < 200 || $status >= 300) return $cache;
  $j = json_decode((string)$res, true);
  if (!is_array($j) || empty($j['models']) || !is_array($j['models'])) return $cache;

  foreach ($j['models'] as $m) {
    $name = trim((string)($m['name'] ?? $m['model'] ?? ''));
    if ($name !== '' && !in_array($name, $cache, true)) $cache[] = $name;
  }
  return $cache;
}
function ollama_model_candidates(): array {
  $preferred = ollama_model();
  $candidates = [];
  $add = function(string $m) use (&$candidates) {
    $m = trim($m);
    if ($m !== '' && !in_array($m, $candidates, true)) $candidates[] = $m;
  };

  $add($preferred);
  // Si alguien configura "llama3.2" sin etiqueta, Ollama normalmente lo resuelve a latest,
  // pero lo agregamos explícitamente para evitar errores de modelo no encontrado.
  if ($preferred !== '' && strpos($preferred, ':') === false) $add($preferred . ':latest');

  foreach (ollama_available_models() as $m) {
    // Preferir primero los modelos ligeros o el mismo family de llama3.2 si están disponibles.
    if (stripos($m, 'llama3.2') !== false) $add($m);
  }
  foreach (ollama_available_models() as $m) $add($m);

  return $candidates;
}
function openai_chat_json(string $system, string $user, int $timeout = 75): array {
  $key = openai_api_key();
  if ($key === '') {
    return ['ok' => false, 'err' => 'OPENAI_API_KEY_no_configurada', 'text' => '', 'data' => null, 'provider' => 'openai', 'model' => openai_model()];
  }

  $payload = [
    'model' => openai_model(),
    'messages' => [
      ['role' => 'system', 'content' => $system],
      ['role' => 'user', 'content' => $user],
    ],
    'temperature' => 0.2,
    'max_tokens' => 1800,
    'response_format' => ['type' => 'json_object'],
  ];

  $ch = curl_init(openai_base_url() . '/chat/completions');
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_HTTPHEADER => [
      'Content-Type: application/json',
      'Authorization: Bearer ' . $key,
    ],
    CURLOPT_POSTFIELDS => json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 8,
    CURLOPT_TIMEOUT => max(10, min($timeout, openai_timeout())),
  ]);
  $res = curl_exec($ch);
  if ($res === false) {
    $err = curl_error($ch);
    curl_close($ch);
    return ['ok' => false, 'err' => 'curl: ' . $err, 'text' => '', 'data' => null, 'provider' => 'openai', 'model' => openai_model()];
  }
  $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
  curl_close($ch);

  $j = json_decode($res, true);
  if ($status < 200 || $status >= 300) {
    $msg = '';
    if (is_array($j)) {
      $msg = (string)($j['error']['message'] ?? '');
      $code = (string)($j['error']['code'] ?? '');
      if ($code !== '') $msg = trim($code . ' ' . $msg);
    }
    return ['ok' => false, 'err' => 'HTTP ' . $status . ($msg !== '' ? ' - ' . $msg : ''), 'text' => '', 'data' => null, 'provider' => 'openai', 'model' => openai_model()];
  }

  $txt = '';
  if (is_array($j)) {
    $txt = (string)($j['choices'][0]['message']['content'] ?? '');
  }
  if ($txt === '') {
    return ['ok' => false, 'err' => 'Respuesta vacía de OpenAI', 'text' => '', 'data' => null, 'provider' => 'openai', 'model' => openai_model()];
  }

  $data = decode_json_from_text($txt);
  if (!is_array($data)) {
    return ['ok' => false, 'err' => 'JSON inválido devuelto por OpenAI', 'text' => $txt, 'data' => null, 'provider' => 'openai', 'model' => openai_model()];
  }

  return ['ok' => true, 'err' => null, 'text' => $txt, 'data' => $data, 'provider' => 'openai', 'model' => openai_model()];
}
function ollama_chat_json(string $system, string $user, int $timeout = 75): array {
  $lastError = 'OLLAMA_MODEL_no_configurado';
  $lastModel = '';
  $tried = [];

  // La versión antigua del proyecto trabajaba mejor con /api/chat + format=json.
  // Se mantiene ese flujo como principal y se deja /api/generate solo como segundo intento.
  $effectiveTimeout = max(60, min(240, max($timeout, ollama_timeout())));

  $numPredict = 2200;
  if (preg_match('/Genera\s+(\d+)\s+preguntas/iu', $user, $m)) {
    $n = max(1, min(30, (int)$m[1]));
    $numPredict = max(1600, min(8200, 620 * $n));
  }
  if (stripos($user, 'explicación más profunda') !== false || stripos($user, 'explicacion mas profunda') !== false) {
    $numPredict = 1500;
  }

  foreach (ollama_model_candidates() as $model) {
    $model = trim($model);
    if ($model === '' || in_array($model, $tried, true)) continue;
    $tried[] = $model;
    $lastModel = $model;

    $payloadChat = [
      'model' => $model,
      'messages' => [
        ['role' => 'system', 'content' => $system . "\nResponde únicamente JSON válido, sin markdown ni texto fuera del JSON."],
        ['role' => 'user', 'content' => $user],
      ],
      'stream' => false,
      'format' => 'json',
      'options' => [
        'temperature' => 0.18,
        'top_p' => 0.9,
        'num_predict' => $numPredict,
      ],
    ];

    $ch = curl_init(ollama_base_url() . '/chat');
    curl_setopt_array($ch, [
      CURLOPT_POST => true,
      CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
      CURLOPT_POSTFIELDS => json_encode($payloadChat, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CONNECTTIMEOUT => 8,
      CURLOPT_TIMEOUT => $effectiveTimeout,
    ]);
    $res = curl_exec($ch);
    if ($res !== false) {
      $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
      curl_close($ch);
      if ($status >= 200 && $status < 300) {
        $j = json_decode($res, true);
        $txt = is_array($j) ? (string)($j['message']['content'] ?? '') : '';
        if ($txt !== '') {
          $data = decode_json_from_text($txt);
          if (is_array($data)) {
            return ['ok' => true, 'err' => null, 'text' => $txt, 'data' => $data, 'provider' => 'ollama', 'model' => $model];
          }
          $lastError = 'JSON inválido devuelto por Ollama /chat (modelo: ' . $model . ')';
        } else {
          $lastError = 'Respuesta vacía de Ollama /chat (modelo: ' . $model . ')';
        }
      } else {
        $lastError = 'HTTP ' . $status . ' en /chat - ' . trim((string)$res) . ' (modelo: ' . $model . ')';
        if (stripos((string)$res, 'not found') !== false || stripos((string)$res, 'model') !== false) continue;
      }
    } else {
      $err = curl_error($ch);
      curl_close($ch);
      $lastError = 'curl /chat: ' . $err . ' (modelo: ' . $model . ', timeout: ' . $effectiveTimeout . 's)';
      if (stripos($err, 'timed out') !== false || stripos($err, 'timeout') !== false) {
        return ['ok' => false, 'err' => $lastError, 'text' => '', 'data' => null, 'provider' => 'ollama', 'model' => $model];
      }
    }

    // Segundo intento compatible con la prueba manual por CMD: /api/generate.
    $prompt =
      "INSTRUCCIONES DEL SISTEMA:\n" . $system .
      "\n\nSOLICITUD:\n" . $user .
      "\n\nRESPONDE ÚNICAMENTE CON JSON VÁLIDO. No agregues markdown, explicaciones fuera del JSON ni texto adicional.";

    $payloadGenerate = [
      'model' => $model,
      'prompt' => $prompt,
      'stream' => false,
      'format' => 'json',
      'options' => [
        'temperature' => 0.18,
        'top_p' => 0.9,
        'num_predict' => $numPredict,
      ],
    ];

    $ch = curl_init(ollama_base_url() . '/generate');
    curl_setopt_array($ch, [
      CURLOPT_POST => true,
      CURLOPT_HTTPHEADER => ['Content-Type: application/json'],
      CURLOPT_POSTFIELDS => json_encode($payloadGenerate, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES),
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_CONNECTTIMEOUT => 8,
      CURLOPT_TIMEOUT => $effectiveTimeout,
    ]);
    $res = curl_exec($ch);
    if ($res === false) {
      $err = curl_error($ch);
      curl_close($ch);
      $lastError = 'curl /generate: ' . $err . ' (modelo: ' . $model . ', timeout: ' . $effectiveTimeout . 's)';
      if (stripos($err, 'timed out') !== false || stripos($err, 'timeout') !== false) break;
      continue;
    }
    $status = (int)curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
    curl_close($ch);

    if ($status < 200 || $status >= 300) {
      $lastError = 'HTTP ' . $status . ' en /generate - ' . trim((string)$res) . ' (modelo: ' . $model . ')';
      if (stripos((string)$res, 'not found') !== false || stripos((string)$res, 'model') !== false) continue;
      break;
    }

    $j = json_decode($res, true);
    $txt = is_array($j) ? (string)($j['response'] ?? '') : '';
    if ($txt === '' && is_array($j) && isset($j['message']['content'])) $txt = (string)$j['message']['content'];
    if ($txt === '') {
      $lastError = 'Respuesta vacía de Ollama /generate (modelo: ' . $model . ')';
      continue;
    }

    $data = decode_json_from_text($txt);
    if (!is_array($data)) {
      $lastError = 'JSON inválido devuelto por Ollama /generate (modelo: ' . $model . ')';
      continue;
    }

    return ['ok' => true, 'err' => null, 'text' => $txt, 'data' => $data, 'provider' => 'ollama', 'model' => $model];
  }

  return ['ok' => false, 'err' => $lastError, 'text' => '', 'data' => null, 'provider' => 'ollama', 'model' => $lastModel];
}

function llm_chat_json(string $system, string $user, int $timeout = 75): array {
  $errors = [];
  foreach (provider_order() as $provider) {
    if (!provider_enabled($provider)) {
      $errors[] = strtoupper($provider) . '_no_disponible';
      continue;
    }

    $r = ($provider === 'ollama') ? ollama_chat_json($system, $user, $timeout) : openai_chat_json($system, $user, $timeout);
    if (!empty($r['ok'])) return $r;
    $errors[] = strtoupper($provider) . ': ' . (string)($r['err'] ?? 'Sin detalle');
  }

  return ['ok' => false, 'err' => implode(' | ', $errors), 'text' => '', 'data' => null, 'provider' => llm_provider(), 'model' => ''];
}
function is_math_context(array $unit): bool {
  $hay = norm_basic(array_get_string($unit, 'materia_nombre') . ' ' . array_get_string($unit, 'materia_clave') . ' ' . array_get_string($unit, 'unidad_titulo'));
  foreach ([
    'matemat', 'calculo', 'algebra', 'geometr', 'trigonom', 'derivada', 'integral',
    'ecuacion', 'inecuacion', 'desigualdad', 'factorizacion', 'aritmet', 'funcion', 'estadistica'
  ] as $kw) {
    if (str_contains($hay, $kw)) return true;
  }
  return false;
}
function make_mcq(string $question, string $correct, array $wrongs, string $explanation = '', array $chunkIds = []): array {
  $question = limpiar_texto_salida($question);
  $correct = limpiar_texto_salida($correct);
  $explanation = limpiar_texto_salida($explanation);

  $pool = [];
  $add = function(string $v) use (&$pool) {
    $v = limpiar_texto_salida($v);
    if ($v === '') return;
    $key = norm_choice_key($v);
    if (!isset($pool[$key])) $pool[$key] = $v;
  };

  $add($correct);
  foreach ($wrongs as $w) $add((string)$w);

  if (count($pool) < 4) {
    foreach ([
      'Ninguna relación directa',
      'Un contenido distinto',
      'Un procedimiento no relacionado',
      'Una opción incorrecta'
    ] as $f) {
      $add($f);
      if (count($pool) >= 4) break;
    }
  }

  $choices = array_values(array_slice($pool, 0, 4));
  shuffle($choices);

  $answer = array_search($correct, $choices, true);
  if ($answer === false) {
    $choices[0] = $correct;
    $answer = 0;
  }

  return [
    'question' => $question,
    'choices' => $choices,
    'answer' => (int)$answer,
    'explanation' => $explanation !== '' ? $explanation : null,
    'chunk_ids' => $chunkIds,
  ];
}

function normalize_exam_difficulty(string $difficulty): string {
  $difficulty = mb_strtolower(trim($difficulty), 'UTF-8');
  $map = [
    'basica' => 'basico',
    'básico' => 'basico',
    'básica' => 'basico',
    'basic' => 'basico',
    'intermediate' => 'intermedio',
    'medio' => 'intermedio',
    'avanzada' => 'avanzado',
    'advanced' => 'avanzado',
  ];
  if (isset($map[$difficulty])) return $map[$difficulty];
  return in_array($difficulty, ['basico','intermedio','avanzado'], true) ? $difficulty : 'intermedio';
}
function exam_difficulty_label(string $difficulty): string {
  $difficulty = normalize_exam_difficulty($difficulty);
  if ($difficulty === 'basico') return 'Básico';
  if ($difficulty === 'avanzado') return 'Avanzado';
  return 'Intermedio';
}
function exam_difficulty_hint(string $difficulty): string {
  $difficulty = normalize_exam_difficulty($difficulty);
  if ($difficulty === 'basico') {
    return 'Dificultad BÁSICA: redacta preguntas directas, de reconocimiento de conceptos, definiciones, símbolos, pasos iniciales y ejemplos sencillos. Evita operaciones largas y casos con muchas condiciones.';
  }
  if ($difficulty === 'avanzado') {
    return 'Dificultad AVANZADA: redacta preguntas de análisis, aplicación en contexto, comparación de procedimientos, interpretación de resultados y casos con mayor razonamiento. Evita preguntas triviales.';
  }
  return 'Dificultad INTERMEDIA: redacta preguntas de comprensión y aplicación moderada, con ejercicios de uno o dos pasos, relaciones entre conceptos y casos breves.';
}
function question_matches_difficulty(array $q, string $difficulty): bool {
  $difficulty = normalize_exam_difficulty($difficulty);
  $question = norm_basic((string)($q['question'] ?? ''));
  $choices = norm_basic(implode(' ', array_map('strval', $q['choices'] ?? [])));
  $text = trim($question . ' ' . $choices);

  // La dificultad no debe aparecer como tema de la pregunta. Solo debe cambiar la complejidad.
  if (preg_match('/\b(basico|basica|intermedio|avanzado|avanzada|dificultad|nivel)\b/u', $question)) {
    return false;
  }

  $tooBasicForAdvanced = [
    'que representa el simbolo', 'cual de estos valores satisface', 'objetivo principal',
    'idea principal', 'que significa', 'antes de resolver', 'conviene hacer antes',
    'terminos basicos', 'conceptos basicos', 'reconocer los conceptos', 'pasos iniciales'
  ];
  if ($difficulty === 'avanzado') {
    foreach ($tooBasicForAdvanced as $bad) {
      if (str_contains($text, $bad)) return false;
    }
  }

  $tooAdvancedForBasic = [
    'valor absoluto', 'cuadratica', 'parabola', 'intervalo de validez', 'parametro',
    'sistema', 'justificar el procedimiento', 'analizar', 'comparar procedimientos',
    'inecuacion doble', 'producto de factores', 'verificar condiciones'
  ];
  if ($difficulty === 'basico') {
    foreach ($tooAdvancedForBasic as $bad) {
      if (str_contains($text, $bad)) return false;
    }
  }

  return true;
}
function filtrar_preguntas_por_dificultad(array $questions, string $difficulty): array {
  $out = [];
  foreach ($questions as $q) {
    if (is_array($q) && question_matches_difficulty($q, $difficulty)) $out[] = $q;
  }
  return $out;
}
function clamp_exam_question_count(int $n): int {
  return max(1, min(50, $n));
}


function alp_temario_para_prompt(array $unit): string {
  if (!is_algorithm_programming_context($unit)) return '';
  $num = (int)($unit['numero'] ?? 0);
  $unidad = norm_basic((string)($unit['unidad_titulo'] ?? ''));

  if ($num === 1 || str_contains($unidad, 'computacion') || str_contains($unidad, 'hoja de calculo') || str_contains($unidad, 'excel')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 1:\n" .
      "1.1 Introducción a la computación. 1.2 Sistemas operativos. 1.3 Elementos de Excel. " .
      "1.4 Fórmulas y funciones. 1.5 Macros. 1.6 Aplicaciones.";
  }
  if ($num === 2 || str_contains($unidad, 'logica') || str_contains($unidad, 'algoritm')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 2:\n" .
      "Metodología para solución de problemas; diseño Top Down, Bottom Up, modular y programación estructurada; " .
      "lenguajes algorítmicos; diagramas de flujo; pseudocódigo; algoritmos secuenciales, selectivos y repetitivos; pruebas y depuración.";
  }
  if ($num === 3 || str_contains($unidad, 'lenguaje estructurado') || str_contains($unidad, 'python') || str_contains($unidad, 'programacion')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 3:\n" .
      "Entorno de programación en Python/Colab; estructura básica de un programa; tipos de datos; identificadores; memoria; asignación; " .
      "operadores, operandos y expresiones; prioridad de operadores; elaboración de programas; pruebas y depuración.";
  }
  if ($num === 4 || str_contains($unidad, 'selectiv') || str_contains($unidad, 'repeticion') || str_contains($unidad, 'ciclo')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 4:\n" .
      "Estructuras selectivas simple, doble, anidada y múltiple; ciclos mientras, hasta y desde; elaboración de programas con decisiones y repeticiones.";
  }
  if ($num === 5 || str_contains($unidad, 'arreglo') || str_contains($unidad, 'archivo')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 5:\n" .
      "Arreglos unidimensionales, bidimensionales y multidimensionales; apertura, entrada-salida de datos y cierre de archivos; programas con colecciones y persistencia.";
  }
  if ($num === 6 || str_contains($unidad, 'funcion')) {
    return "Temario de referencia para Algoritmos y Lenguajes de Programación - Unidad 6:\n" .
      "Funciones estándar; entrada y salida de datos; funciones definidas por el usuario; paso por valor; paso por referencia; programas modulares.";
  }
  return "Temario de referencia para Algoritmos y Lenguajes de Programación: lógica algorítmica, pseudocódigo, diagramas de flujo, programación estructurada, Python, estructuras de control, arreglos, archivos y funciones.";
}

function build_prompt_exam_from_names(array $unit, string $topicsText, string $style, int $nq, string $difficulty): array {
  $styleHint = 'mezcla preguntas teóricas y prácticas';
  if ($style === 'practico') $styleHint = 'prioriza preguntas prácticas, ejercicios cortos y aplicación';
  if ($style === 'teorico') $styleHint = 'prioriza preguntas conceptuales, definiciones y comprensión';
  $difficulty = normalize_exam_difficulty($difficulty);
  $difficultyHint = exam_difficulty_hint($difficulty);
  $difficultyLabel = exam_difficulty_label($difficulty);

  $materia = trim((string)($unit['materia_nombre'] ?? ''));
  $unidad = trim((string)($unit['unidad_titulo'] ?? ''));
  $numero = (int)($unit['numero'] ?? 0);

  $system = 'Eres un profesor que diseña exámenes predictivos. Responde únicamente JSON válido, sin markdown, sin comentarios externos.';

  $user =
    "Genera {$nq} preguntas de opción múltiple usando SOLO estos dos datos académicos:\n" .
    "Materia: {$materia}\n" .
    "Unidad {$numero}: {$unidad}\n\n" .
    "No uses temas registrados, archivos, apuntes, chunks, textos extraídos ni contenido adicional de la plataforma. " .
    "Debes inferir preguntas coherentes únicamente a partir del nombre de la materia y el nombre de la unidad.\n\n" .
    "Reglas obligatorias:\n" .
    "- Todo en español.\n" .
    "- Cada pregunta debe tener exactamente 4 opciones claras.\n" .
    "- Solo una opción debe ser correcta.\n" .
    "- No uses 'todas las anteriores' ni 'ninguna de las anteriores'.\n" .
    "- La respuesta debe ser A, B, C o D.\n" .
    "- respuesta_texto debe coincidir exactamente con una de las cuatro opciones.\n" .
    "- Antes de responder, verifica internamente que la respuesta correcta sea realmente correcta.\n" .
    "- Si haces una operación, ecuación o ejemplo numérico, calcula el resultado y asegúrate de que la opción correcta coincida. Por ejemplo, 1+1 debe tener como correcta 2.\n" .
    "- No inventes datos administrativos, fechas, autores o detalles que no se deduzcan del nombre de la materia y unidad.\n" .
    "- {$styleHint}.\n" .
    "- {$difficultyHint}\n" .
    "- La dificultad solo debe cambiar la complejidad de la pregunta; no menciones las palabras básico, intermedio, avanzado, nivel o dificultad dentro de las preguntas.\n" .
    "- En dificultad {$difficultyLabel}, respeta el nivel: básico = reconocimiento; intermedio = aplicación corta; avanzado = análisis o caso con más razonamiento.\n\n" .
    "Devuelve SOLO este JSON exacto:\n" .
    "{\n" .
    '  "questions": [' .
    '{"pregunta":"...","opciones":["...","...","...","..."],"respuesta":"A","respuesta_texto":"...","explicacion":"..."}' .
    "]\n" .
    "}";

  return [$system, $user];
}

function build_generic_name_based_questions(array $unit, array $temas, int $n, array &$seen, string $difficulty = 'intermedio'): array {
  $difficulty = normalize_exam_difficulty($difficulty);
  $materia = trim((string)$unit['materia_nombre']);
  $unidad = trim((string)$unit['unidad_titulo']);
  $num = (int)$unit['numero'];
  $unidadId = (int)($unit['unidad_id'] ?? 0);
  // No se usan temas registrados: el examen se basa solo en materia y unidad.
  $topicNames = [];
  $principalTema = $unidad;

  $candidates = [];
  $addCandidate = function(string $question, string $correct, array $wrongs, string $explanation) use (&$candidates) {
    $candidates[] = make_mcq($question, $correct, $wrongs, $explanation);
  };

  $wrongBase = [
    'Trabajar contenidos ajenos a la materia',
    'Memorizar trámites administrativos sin relación con la unidad',
    'Evitar ejemplos, razonamiento y aplicación del tema',
    'Sustituir el estudio por respuestas al azar',
  ];

  if ($difficulty === 'basico') {
    $addCandidate(
      "¿Cuál es la idea principal de la Unidad {$num}: {$unidad} en {$materia}?",
      "Comprender los conceptos esenciales de {$unidad}",
      array_slice($wrongBase, 0, 3),
      "Se busca reconocer el tema central y sus conceptos principales."
    );
    $addCandidate(
      "¿Qué debe identificar primero un estudiante al iniciar la unidad {$unidad}?",
      "Los conceptos y términos básicos del tema",
      ['Los datos administrativos del curso', 'Temas que no pertenecen a la materia', 'Respuestas sin leer la pregunta'],
      "Antes de resolver casos complejos conviene identificar conceptos y términos básicos."
    );
    $addCandidate(
      "¿Qué opción representa una forma básica de estudiar {$unidad}?",
      "Leer definiciones, reconocer ejemplos y repasar ideas clave",
      ['Resolver casos avanzados sin bases', 'Ignorar la teoría del tema', 'Elegir respuestas al azar'],
      "El estudio básico inicia con definiciones, ejemplos sencillos e ideas clave."
    );
    if ($topicNames) {
      $topicA = (string)random_item($topicNames);
      $wrongs = array_slice(array_merge(array_values(array_filter($topicNames, fn($x) => norm_basic($x) !== norm_basic($topicA))), ['Un trámite escolar', 'Una actividad no académica', 'Un tema ajeno a la unidad']), 0, 3);
      $addCandidate(
        "¿Cuál de los siguientes temas pertenece a la unidad {$unidad}?",
        $topicA,
        $wrongs,
        "{$topicA} aparece como tema registrado dentro de esta unidad."
      );
    }
  } elseif ($difficulty === 'avanzado') {
    $addCandidate(
      "Si un estudiante domina la unidad {$unidad}, ¿qué debería poder hacer en un caso nuevo?",
      "Analizar la situación, elegir un procedimiento adecuado y justificar la respuesta",
      ['Repetir una definición sin aplicarla', 'Ignorar las condiciones del problema', 'Responder sin comparar opciones'],
      "Esta pregunta exige transferir lo aprendido a situaciones nuevas y justificar decisiones."
    );
    $addCandidate(
      "¿Qué evidencia demuestra un dominio avanzado de {$unidad}?",
      "Comparar conceptos, detectar errores y explicar por qué una solución es válida",
      ['Memorizar únicamente el título de la unidad', 'Evitar la revisión de procedimientos', 'Copiar una respuesta sin razonamiento'],
      "Esta pregunta evalúa análisis, comparación y argumentación."
    );
    $addCandidate(
      "Al resolver un problema complejo relacionado con {$unidad}, ¿cuál es la mejor estrategia?",
      "Identificar datos, seleccionar criterios, aplicar el método y verificar el resultado",
      ['Contestar antes de leer el caso completo', 'Usar cualquier método aunque no corresponda', 'Omitir la comprobación final'],
      "Los casos complejos requieren un proceso ordenado y verificación."
    );
    if ($topicNames) {
      $topicA = (string)random_item($topicNames);
      $addCandidate(
        "¿Cómo se debería usar el tema {$topicA} dentro de un análisis avanzado de {$unidad}?",
        "Relacionándolo con otros conceptos para justificar una solución o conclusión",
        ['Tratándolo como un dato aislado sin relación', 'Usándolo solo para memorizar una palabra', 'Ignorando su aplicación dentro de la unidad'],
        "Un análisis avanzado relaciona el tema con otros conceptos y aplicaciones."
      );
    }
  } else {
    $addCandidate(
      "Al terminar la Unidad {$num}: {$unidad}, ¿qué se espera que el estudiante pueda hacer?",
      "Identificar, explicar y aplicar contenidos de {$unidad}",
      ['Solo repetir el nombre de la unidad sin comprenderlo', 'Trabajar contenidos de una asignatura distinta', 'Evitar ejemplos y aplicaciones del tema'],
      "Esta pregunta combina comprensión y aplicación moderada del tema."
    );
    $addCandidate(
      "¿Qué tipo de actividad se relaciona mejor con la unidad {$unidad}?",
      "Analizar conceptos y resolver casos breves relacionados con {$unidad}",
      ['Completar únicamente tareas administrativas', 'Memorizar fechas sin relación con la materia', 'Evitar cualquier práctica o ejercicio'],
      "Una unidad académica suele incluir teoría, análisis y ejercicios."
    );
    $addCandidate(
      "Dentro de {$materia}, la unidad {$unidad} se estudia principalmente para:",
      "Desarrollar comprensión y criterio sobre {$unidad}",
      ['Sustituir por completo el resto de la asignatura', 'Eliminar la necesidad de practicar o razonar', 'Trabajar únicamente asuntos administrativos'],
      "El propósito normal es desarrollar comprensión del tema y capacidad de aplicación."
    );
    if ($topicNames) {
      $topicA = (string)random_item($topicNames);
      $wrongs = array_slice(array_merge(array_values(array_filter($topicNames, fn($x) => norm_basic($x) !== norm_basic($topicA))), ['Un tema no relacionado', 'Un trámite administrativo', 'Una actividad extracurricular']), 0, 3);
      $addCandidate(
        "Si tuvieras que relacionar un tema con la unidad {$unidad}, ¿cuál sería el más adecuado?",
        $topicA,
        $wrongs,
        "{$topicA} se relaciona con los temas registrados de la unidad."
      );
    }
  }

  $verbs = $difficulty === 'basico'
    ? ['reconocer', 'identificar', 'definir', 'distinguir']
    : ($difficulty === 'avanzado'
      ? ['analizar', 'evaluar', 'justificar', 'comparar']
      : ['explicar', 'aplicar', 'relacionar', 'resolver']);
  $contexts = $topicNames ?: [$unidad, $materia, 'el tema central de la unidad'];
  $targetPool = max($n * 3, 12);
  $attempt = 0;
  while (count($candidates) < $targetPool && $attempt < $targetPool * 4) {
    $attempt++;
    $verb = (string)random_item($verbs);
    $ctx = (string)random_item($contexts);
    $suffix = $attempt;
    if ($difficulty === 'basico') {
      $addCandidate(
        "¿Qué significa {$verb} {$ctx} dentro de {$unidad}?",
        "Comprender su significado principal y reconocerlo en ejemplos sencillos",
        ['Aplicarlo sin conocer su definición', 'Usarlo como trámite administrativo', 'Ignorarlo porque no aporta al tema'],
        "Este tipo de pregunta se centra en reconocer significados y ejemplos sencillos."
      );
    } elseif ($difficulty === 'avanzado') {
      $addCandidate(
        "En una situación nueva sobre {$ctx}, ¿qué acción demuestra mayor dominio de {$unidad}?",
        "Justificar la decisión relacionando conceptos, condiciones y resultado",
        ['Elegir una opción sin revisar el contexto', 'Copiar una definición sin aplicarla', 'Omitir la comprobación del resultado'],
        "Esta pregunta evalúa razonamiento, relación de conceptos y justificación."
      );
    } else {
      $addCandidate(
        "En un ejercicio sobre {$ctx}, ¿qué debe hacer primero el estudiante?",
        "Identificar el concepto aplicable y después resolver el caso",
        ['Responder sin leer las condiciones', 'Cambiar de tema sin justificarlo', 'Memorizar el título sin aplicarlo'],
        "Esta pregunta requiere comprender el concepto y aplicarlo en un caso breve."
      );
    }
  }

  return select_questions_with_rotation($candidates, $n, $seen, $unidadId);
}


function is_algorithm_programming_context(array $unit): bool {
  $materia = norm_basic(array_get_string($unit, 'materia_nombre') . ' ' . array_get_string($unit, 'materia_clave'));
  $unidad = norm_basic(array_get_string($unit, 'unidad_titulo') . ' ' . array_get_string($unit, 'unidad_desc'));

  // Optimización pensada para Algoritmos y Lenguajes de Programación / Fundamentos de Programación.
  // Evita confundirse con materias diferentes como Programación Web o materias matemáticas de funciones.
  foreach (['algoritmos y lenguajes de programacion', 'fundamentos de programacion', 'logica algoritmica'] as $kw) {
    if (str_contains($materia, $kw)) return true;
  }

  foreach (['logica algoritmica', 'pseudocodigo', 'diagrama de flujo', 'programacion estructurada', 'lenguaje estructurado', 'google colaboratory', 'colab', 'python'] as $kw) {
    if (str_contains($unidad, $kw)) return true;
  }

  return false;
}

function add_mcq_candidate(array &$candidates, string $question, string $correct, array $wrongs, string $explanation, string $kind = 'mixto'): void {
  $q = make_mcq($question, $correct, $wrongs, $explanation);
  $q['_kind'] = $kind;
  $candidates[] = $q;
}

function filter_by_exam_style(array $questions, string $style): array {
  if (!in_array($style, ['mixto','teorico','practico'], true) || $style === 'mixto') return $questions;
  $preferred = [];
  $rest = [];
  foreach ($questions as $q) {
    $kind = (string)($q['_kind'] ?? 'mixto');
    if ($kind === $style || $kind === 'mixto') $preferred[] = $q; else $rest[] = $q;
  }
  return array_merge($preferred, $rest);
}

function strip_internal_question_fields(array $questions): array {
  foreach ($questions as &$q) {
    unset($q['_kind']);
  }
  unset($q);
  return $questions;
}


function materia_clave_norm_for_bank(string $clave): string {
  $clave = strtoupper(trim($clave));
  $clave = str_replace([' ', '_'], ['', ''], $clave);
  return str_replace('-', '', $clave);
}

function banco_preguntas_disponible(PDO $pdo): bool {
  static $ok = null;
  if ($ok !== null) return $ok;
  try {
    $st = $pdo->query("SHOW TABLES LIKE 'banco_preguntas_predictivas'");
    $ok = (bool)$st->fetchColumn();
  } catch (Throwable $e) {
    $ok = false;
  }
  return $ok;
}

function bank_row_to_question(array $row): array {
  $choicesAssoc = [
    'A' => (string)($row['opcion_a'] ?? ''),
    'B' => (string)($row['opcion_b'] ?? ''),
    'C' => (string)($row['opcion_c'] ?? ''),
    'D' => (string)($row['opcion_d'] ?? ''),
  ];
  $letter = strtoupper(trim((string)($row['respuesta_correcta'] ?? 'A')));
  if (!isset($choicesAssoc[$letter])) $letter = 'A';
  $correct = $choicesAssoc[$letter];
  $wrongs = [];
  foreach ($choicesAssoc as $L => $txt) {
    if ($L !== $letter) $wrongs[] = $txt;
  }
  $q = make_mcq(
    (string)($row['pregunta'] ?? ''),
    $correct,
    $wrongs,
    (string)($row['explicacion_breve'] ?? '')
  );
  $q['_kind'] = (string)($row['tipo'] ?? 'mixto');
  $q['chunk_ids'] = [[
    'tipo' => 'banco_preguntas_predictivas',
    'bank_question_id' => (int)($row['id'] ?? 0),
    'codigo' => (string)($row['codigo'] ?? ''),
    'dificultad' => (string)($row['dificultad'] ?? ''),
    'tipo_pregunta' => (string)($row['tipo'] ?? ''),
    'explicacion_profunda' => (string)($row['explicacion_profunda'] ?? ''),
  ]];
  return $q;
}

function banco_fetch_rows(PDO $pdo, string $materiaClave, int $unidadNumero, string $difficulty, ?string $tipo, int $limit): array {
  if (!banco_preguntas_disponible($pdo)) return [];
  $limit = max(1, min(200, $limit));
  $claveNorm = materia_clave_norm_for_bank($materiaClave);
  $whereTipo = '';
  $params = [
    ':clave_norm' => $claveNorm,
    ':difficulty' => normalize_exam_difficulty($difficulty),
    ':unidad' => $unidadNumero,
  ];
  if ($tipo !== null && in_array($tipo, ['teorico','practico'], true)) {
    $whereTipo = ' AND tipo = :tipo ';
    $params[':tipo'] = $tipo;
  }
  $sql = "
    SELECT *
    FROM banco_preguntas_predictivas
    WHERE REPLACE(UPPER(materia_clave), '-', '') = :clave_norm
      AND dificultad = :difficulty
      AND activo = 1
      AND (unidad_numero = :unidad OR unidad_numero IS NULL)
      {$whereTipo}
    ORDER BY CASE WHEN unidad_numero = :unidad THEN 0 ELSE 1 END, RAND()
    LIMIT {$limit}
  ";
  try {
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  } catch (Throwable $e) {
    return [];
  }
}

function cargar_preguntas_banco(PDO $pdo, array $unit, int $nq, string $style, string $difficulty): array {
  if (!banco_preguntas_disponible($pdo)) return [];
  $materiaClave = (string)($unit['materia_clave'] ?? '');
  $unidadNumero = (int)($unit['numero'] ?? 0);
  $nq = clamp_exam_question_count($nq);
  $difficulty = normalize_exam_difficulty($difficulty);
  if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';

  $rows = [];
  if ($style === 'teorico' || $style === 'practico') {
    $rows = banco_fetch_rows($pdo, $materiaClave, $unidadNumero, $difficulty, $style, $nq * 4);
    if (count($rows) < $nq) {
      $extra = banco_fetch_rows($pdo, $materiaClave, $unidadNumero, $difficulty, null, $nq * 4);
      $rows = array_merge($rows, $extra);
    }
  } else {
    $half = (int)ceil($nq / 2);
    $t = banco_fetch_rows($pdo, $materiaClave, $unidadNumero, $difficulty, 'teorico', $half * 3);
    $p = banco_fetch_rows($pdo, $materiaClave, $unidadNumero, $difficulty, 'practico', $half * 3);
    $rows = array_merge(array_slice($t, 0, $half), array_slice($p, 0, max(0, $nq - min($half, count($t)))));
    if (count($rows) < $nq) {
      $rows = array_merge($rows, banco_fetch_rows($pdo, $materiaClave, $unidadNumero, $difficulty, null, $nq * 4));
    }
  }

  $seenCodes = [];
  $questions = [];
  foreach ($rows as $row) {
    $code = (string)($row['codigo'] ?? ('id:' . (int)($row['id'] ?? 0)));
    if (isset($seenCodes[$code])) continue;
    $seenCodes[$code] = true;
    $questions[] = bank_row_to_question($row);
    if (count($questions) >= $nq) break;
  }
  return validar_preguntas_generadas($questions);
}

function infer_materia_orientation(array $unit): string {
  $hay = norm_basic(
    (string)($unit['materia_nombre'] ?? '') . ' ' .
    (string)($unit['materia_clave'] ?? '') . ' ' .
    (string)($unit['unidad_titulo'] ?? '')
  );

  $practicas = [
    'programacion','algoritmo','calculo','algebra','estadistica','fisica','quimica','metodos numericos',
    'base de datos','redes','simulacion','estructuras','hidraulica','topografia','dibujo','diseno',
    'manufactura','procesos','contabilidad financiera','costos','finanzas','presupuestos','operaciones'
  ];
  foreach ($practicas as $kw) {
    if (str_contains($hay, $kw)) return 'practico';
  }

  $teoricas = [
    'etica','cultura','administracion','gestion','derecho','mercadotecnia','desarrollo humano',
    'sustentable','fundamentos de investigacion','investigacion','seminario','epistemologia','historia',
    'analisis critico','urbanismo','calidad','liderazgo'
  ];
  foreach ($teoricas as $kw) {
    if (str_contains($hay, $kw)) return 'teorico';
  }

  return 'mixto';
}

function style_for_local_generation(array $unit, string $requestedStyle): string {
  if (in_array($requestedStyle, ['teorico','practico'], true)) return $requestedStyle;
  $inferred = infer_materia_orientation($unit);
  return in_array($inferred, ['teorico','practico'], true) ? $inferred : 'mixto';
}

function build_adaptive_fill_questions(array $unit, array $temas, int $n, array &$seen, string $difficulty = 'intermedio', string $style = 'mixto'): array {
  $difficulty = normalize_exam_difficulty($difficulty);
  if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';
  $materia = trim((string)($unit['materia_nombre'] ?? 'la materia'));
  $unidad = trim((string)($unit['unidad_titulo'] ?? 'la unidad'));
  $unidadId = (int)($unit['unidad_id'] ?? 0);
  // No se usan temas registrados: el examen se basa solo en materia y unidad.
  $topicNames = [];
  $targets = [$unidad, $materia, 'el contenido principal de la unidad'];

  $candidates = [];
  $contexts = [
    'al resolver una actividad de clase', 'al preparar un examen predictivo', 'al estudiar una guía de ejercicios',
    'al revisar un caso práctico', 'al explicar el tema a otro estudiante', 'al comparar procedimientos',
    'al corregir una respuesta', 'al documentar una solución', 'al usar un ejemplo sencillo', 'al revisar el material de apoyo'
  ];
  $actions = $difficulty === 'basico'
    ? ['reconocer la idea principal', 'identificar conceptos básicos', 'distinguir términos clave', 'describir el propósito']
    : ($difficulty === 'avanzado'
      ? ['justificar una decisión', 'detectar errores de razonamiento', 'comparar alternativas', 'validar una solución']
      : ['aplicar el concepto', 'relacionar teoría y práctica', 'resolver un caso breve', 'explicar el procedimiento']);

  $limit = max($n * 4, 24);
  for ($i = 0; $i < $limit; $i++) {
    $target = (string)$targets[$i % count($targets)];
    $ctx = (string)$contexts[$i % count($contexts)];
    $action = (string)$actions[$i % count($actions)];
    if ($difficulty === 'basico') {
      add_mcq_candidate(
        $candidates,
        "En {$materia}, ¿qué conviene hacer {$ctx} sobre {$target}?",
        ucfirst($action) . ' antes de intentar ejercicios más complejos',
        ['Cambiar de unidad sin revisar el tema', 'Contestar al azar sin leer el planteamiento', 'Ignorar definiciones y ejemplos'],
        'En nivel básico se busca reconocer la idea central y comprender términos antes de aplicar procedimientos.',
        'teorico'
      );
    } elseif ($difficulty === 'avanzado') {
      add_mcq_candidate(
        $candidates,
        "Para demostrar dominio de {$target} {$ctx}, ¿qué respuesta muestra mejor razonamiento?",
        ucfirst($action) . ' considerando datos, condiciones y resultado',
        ['Repetir una definición sin aplicarla', 'Elegir una opción sin comprobarla', 'Omitir la relación con la unidad'],
        'En nivel avanzado se espera analizar, comparar y justificar la solución, no solo memorizar conceptos.',
        'practico'
      );
    } else {
      add_mcq_candidate(
        $candidates,
        "Al trabajar {$target} {$ctx}, ¿cuál es la estrategia más adecuada?",
        ucfirst($action) . ' mediante pasos ordenados y ejemplos relacionados',
        ['Memorizar solo el título del tema', 'Evitar practicar con ejemplos', 'Usar información ajena a la unidad'],
        'En nivel intermedio se combina comprensión con aplicación en casos breves.',
        'mixto'
      );
    }
  }

  $candidates = filter_by_exam_style($candidates, $style);
  $selected = select_questions_with_rotation($candidates, $n, $seen, $unidadId);
  return strip_internal_question_fields(validar_preguntas_generadas($selected));
}

function build_alp_name_based_questions(array $unit, array $temas, int $n, array &$seen, string $difficulty = 'intermedio', string $style = 'mixto'): array {
  $difficulty = normalize_exam_difficulty($difficulty);
  if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';
  $unidad = norm_basic((string)($unit['unidad_titulo'] ?? ''));
  $num = (int)($unit['numero'] ?? 0);
  $unidadId = (int)($unit['unidad_id'] ?? 0);
  $candidates = [];

  $isU1 = $num === 1 || str_contains($unidad, 'computacion') || str_contains($unidad, 'hoja de calculo') || str_contains($unidad, 'excel');
  $isU2 = $num === 2 || str_contains($unidad, 'logica') || str_contains($unidad, 'algoritmica') || str_contains($unidad, 'algoritmo');
  $isU3 = $num === 3 || str_contains($unidad, 'lenguaje estructurado') || str_contains($unidad, 'python') || str_contains($unidad, 'programacion');
  $isU4 = $num === 4 || str_contains($unidad, 'selectiva') || str_contains($unidad, 'repeticion') || str_contains($unidad, 'ciclo');
  $isU5 = $num === 5 || str_contains($unidad, 'arreglo') || str_contains($unidad, 'archivo');
  $isU6 = $num === 6 || str_contains($unidad, 'funcion');

  $add = function(string $question, string $correct, array $wrongs, string $explanation, string $kind = 'mixto') use (&$candidates) {
    add_mcq_candidate($candidates, $question, $correct, $wrongs, $explanation, $kind);
  };

  if ($isU1) {
    $add('¿Cuál es la función principal de un sistema operativo?', 'Administrar recursos del equipo y permitir la interacción con programas', ['Diseñar únicamente hojas de cálculo', 'Crear fórmulas de Excel sin intervención del usuario', 'Reemplazar por completo al hardware'], 'El sistema operativo administra memoria, archivos, dispositivos y ejecución de programas.', 'teorico');
    $add('En una hoja de cálculo, ¿para qué sirve una fórmula?', 'Para calcular resultados a partir de valores, referencias y operadores', ['Para guardar imágenes sin datos', 'Para bloquear el sistema operativo', 'Para cambiar el nombre del archivo únicamente'], 'Las fórmulas permiten realizar cálculos automáticos en celdas.', 'practico');
    $add('¿Qué ventaja tiene usar funciones en Excel?', 'Automatizan operaciones comunes como suma, promedio o conteo', ['Evitan que se puedan editar celdas', 'Eliminan la necesidad de guardar archivos', 'Desactivan el uso de fórmulas'], 'Las funciones simplifican cálculos repetitivos y reducen errores.', 'teorico');
    $add('Si un estudiante necesita calcular el promedio de varias calificaciones, ¿qué herramienta es más adecuada?', 'Una función de promedio en la hoja de cálculo', ['Un cambio de fondo de pantalla', 'Un acceso directo del sistema operativo', 'Una carpeta vacía sin datos'], 'Las hojas de cálculo permiten analizar datos numéricos mediante funciones.', 'practico');
    $add('¿Qué describe mejor una macro en una hoja de cálculo?', 'Una secuencia automatizada de acciones repetitivas', ['Una celda que no acepta datos', 'Un tipo de sistema operativo', 'Un error obligatorio del programa'], 'Las macros automatizan tareas frecuentes dentro de la hoja de cálculo.', 'teorico');
    $add('En un caso de inventarios, ¿cómo ayuda una hoja de cálculo?', 'Organiza datos, aplica fórmulas y facilita el análisis de cantidades', ['Impide registrar productos', 'Solo permite escribir texto decorativo', 'Sustituye la revisión de datos por azar'], 'La hoja de cálculo apoya el control y análisis de información.', 'practico');
  }

  if ($isU2) {
    $add('¿Qué es un algoritmo?', 'Un conjunto finito y ordenado de pasos para resolver un problema', ['Una lista sin orden ni final', 'Un archivo que solo guarda imágenes', 'Una respuesta elegida al azar'], 'Un algoritmo debe ser claro, finito y orientado a una solución.', 'teorico');
    $add('¿Qué característica indica que cada paso del algoritmo no debe tener ambigüedad?', 'Ser definido', ['Ser decorativo', 'Ser infinito', 'Ser improvisado'], 'Un algoritmo definido indica exactamente qué acción realizar en cada paso.', 'teorico');
    $add('¿Cuál herramienta representa gráficamente los pasos de un algoritmo?', 'Diagrama de flujo', ['Hoja de asistencia', 'Tabla de colores sin símbolos', 'Archivo comprimido'], 'El diagrama de flujo usa símbolos y flechas para mostrar el proceso.', 'teorico');
    $add('¿Qué representa el pseudocódigo?', 'Una descripción estructurada de los pasos usando lenguaje cercano al humano', ['Un lenguaje máquina binario obligatorio', 'Un dibujo sin instrucciones', 'Una contraseña del sistema'], 'El pseudocódigo permite planear la solución antes de programarla.', 'teorico');
    $add('En la metodología Top Down, ¿cómo se aborda el problema?', 'Se divide desde una visión general hacia partes más pequeñas', ['Se resuelve sin analizar entradas', 'Se comienza por detalles aislados sin integrar', 'Se evita dividir el problema'], 'Top Down descompone el problema de mayor a menor nivel.', 'teorico');
    $add('Si un algoritmo primero lee dos números, luego los suma y al final muestra el resultado, ¿qué estructura predomina?', 'Secuencial', ['Selectiva múltiple', 'Repetitiva infinita', 'Recursiva obligatoria'], 'Las instrucciones se ejecutan una después de otra en orden.', 'practico');
    $add('¿Qué actividad corresponde a la depuración de un algoritmo?', 'Encontrar y corregir errores en la lógica o en los pasos', ['Borrar todo sin revisar', 'Cambiar el tema de la unidad', 'Ignorar pruebas con datos'], 'Depurar implica localizar fallos y corregirlos.', 'practico');
    $add('Si una solución debe decidir entre aprobar o reprobar según una calificación, ¿qué estructura algorítmica se necesita?', 'Selectiva', ['Solo secuencial sin condición', 'Archivo de texto', 'Macro de formato visual'], 'Una condición permite tomar diferentes caminos según el caso.', 'practico');
  }

  if ($isU3) {
    $add('¿Qué significa que Python sea interpretado?', 'Que ejecuta instrucciones sin requerir una compilación manual previa', ['Que solo funciona sin variables', 'Que no permite imprimir resultados', 'Que siempre necesita diagramas físicos'], 'Python ejecuta el código mediante un intérprete.', 'teorico');
    $add('¿Para qué sirve Google Colaboratory en esta unidad?', 'Para escribir y ejecutar código Python desde el navegador', ['Para instalar físicamente memoria RAM', 'Para bloquear archivos de Excel', 'Para sustituir todas las pruebas'], 'Colab facilita programar en Python sin configuración local compleja.', 'teorico');
    $add('¿Cuál es un identificador válido en Python?', 'promedio_final', ['1promedio', 'nota-final', 'if'], 'Un identificador no inicia con número, no usa guion medio y no debe ser palabra reservada.', 'practico');
    $add('Si edad = 21, ¿qué tipo de dato representa normalmente en Python?', 'Entero', ['Cadena de texto', 'Booleano', 'Archivo'], 'Un número sin decimales se maneja como entero.', 'teorico');
    $add('¿Qué hace la instrucción print()?', 'Muestra información en pantalla o salida de la celda', ['Lee archivos automáticamente', 'Declara una función por referencia', 'Cierra Google Colab'], 'print() permite visualizar resultados.', 'teorico');
    $add('En Python, ¿qué símbolo se usa para asignar un valor a una variable?', '=', ['==', '!=', '>='], 'El símbolo = asigna; == compara igualdad.', 'practico');
    $add('Si nota1 = 8 y nota2 = 10, ¿qué expresión calcula el promedio?', '(nota1 + nota2) / 2', ['nota1 + nota2 / nota1', 'nota1 = nota2', 'nota1 * nota2 + 2'], 'El promedio de dos datos se obtiene sumándolos y dividiendo entre dos.', 'practico');
    $add('¿Por qué conviene usar paréntesis en una expresión?', 'Para indicar claramente el orden de evaluación deseado', ['Para impedir que el programa se ejecute', 'Para cambiar variables por archivos', 'Para eliminar todos los operadores'], 'Los paréntesis evitan confusiones con la prioridad de operadores.', 'teorico');
  }

  if ($isU4) {
    $add('¿Qué permite una estructura selectiva simple?', 'Ejecutar instrucciones solo si una condición se cumple', ['Repetir siempre sin condición', 'Guardar datos en un archivo', 'Crear una lista de valores'], 'La selectiva simple evalúa una condición antes de ejecutar acciones.', 'teorico');
    $add('¿Cuál estructura permite elegir entre dos alternativas?', 'Selectiva doble', ['Asignación simple', 'Comentario de código', 'Arreglo bidimensional'], 'La selectiva doble usa un camino para verdadero y otro para falso.', 'teorico');
    $add('Si se evalúa primero la edad y luego el promedio dentro de otra condición, ¿qué estructura aparece?', 'Selectiva anidada', ['Ciclo desde', 'Archivo secuencial', 'Función estándar'], 'Una condición dentro de otra produce una selectiva anidada.', 'practico');
    $add('¿Cuándo conviene usar una estructura repetitiva?', 'Cuando un bloque de instrucciones debe ejecutarse varias veces', ['Cuando solo se imprime una línea sin condición', 'Cuando no hay proceso que repetir', 'Cuando se desea borrar el algoritmo'], 'Los ciclos evitan escribir repetidamente las mismas instrucciones.', 'teorico');
    $add('¿Qué ciclo se usa normalmente cuando se conoce el número exacto de repeticiones?', 'Repetir desde o ciclo para', ['Selectiva simple', 'Asignación de texto', 'Comentario final'], 'El ciclo para usa un contador con inicio y fin definidos.', 'practico');
    $add('¿Qué riesgo existe si una condición de ciclo nunca cambia?', 'El programa puede entrar en un ciclo infinito', ['El programa se convierte en Excel', 'La variable desaparece de memoria', 'La condición se vuelve comentario'], 'El ciclo necesita una actualización que permita terminar.', 'practico');
    $add('En una validación de datos, ¿por qué puede servir repetir hasta?', 'Porque permite solicitar datos hasta cumplir una condición válida', ['Porque elimina la necesidad de condiciones', 'Porque solo ejecuta instrucciones visuales', 'Porque impide leer entradas'], 'Repetir hasta es útil cuando se necesita al menos una lectura y validación.', 'practico');
  }

  if ($isU5) {
    $add('¿Qué es un arreglo unidimensional?', 'Una colección de datos del mismo tipo organizada en una sola dimensión', ['Una condición lógica', 'Un archivo sin datos', 'Una función sin parámetros'], 'Un vector almacena varios elementos usando índices.', 'teorico');
    $add('¿Qué representa el índice en un arreglo?', 'La posición de un elemento dentro de la estructura', ['El nombre del sistema operativo', 'La contraseña del archivo', 'El tipo de impresora'], 'El índice permite acceder a un elemento específico.', 'teorico');
    $add('¿Qué estructura se asocia con un arreglo bidimensional?', 'Matriz', ['Variable simple', 'Ciclo infinito', 'Comentario'], 'Una matriz organiza datos en filas y columnas.', 'teorico');
    $add('Si se desean guardar 10 calificaciones bajo un mismo nombre, ¿qué estructura conviene usar?', 'Un arreglo o vector', ['Diez programas separados', 'Una condición sin datos', 'Una sola constante'], 'El arreglo permite manejar varios datos relacionados.', 'practico');
    $add('¿Cuál es una operación común al trabajar con archivos?', 'Abrir, leer o escribir datos y cerrar el archivo', ['Cambiar el procesador físico', 'Eliminar todos los operadores', 'Usar únicamente comentarios'], 'El manejo de archivos sigue una secuencia de apertura, operación y cierre.', 'teorico');
    $add('¿Por qué es importante cerrar un archivo después de usarlo?', 'Para liberar recursos y asegurar que los datos se guarden correctamente', ['Para borrar el programa completo', 'Para cambiar el tipo de variable', 'Para convertirlo en arreglo'], 'Cerrar archivos evita pérdida de datos y recursos ocupados.', 'practico');
  }

  if ($isU6) {
    $add('¿Para qué sirve una función en programación?', 'Para organizar y reutilizar código en tareas específicas', ['Para impedir el uso de variables', 'Para reemplazar todos los algoritmos por texto', 'Para eliminar las entradas del programa'], 'Las funciones dividen el programa en partes reutilizables.', 'teorico');
    $add('¿Qué es una función definida por el usuario?', 'Una función creada por el programador para resolver una tarea concreta', ['Una instrucción secreta del sistema operativo', 'Una celda de Excel bloqueada', 'Un archivo sin nombre'], 'El usuario puede crear funciones según las necesidades del problema.', 'teorico');
    $add('¿Qué representa un parámetro en una función?', 'Un dato que la función recibe para trabajar', ['El color del editor', 'El nombre del disco duro', 'Una opción de impresión'], 'Los parámetros permiten enviar información a una función.', 'teorico');
    $add('¿Qué sucede generalmente en el paso por valor?', 'La función trabaja con una copia del dato recibido', ['La variable original siempre se modifica', 'El programa deja de usar memoria', 'El parámetro se convierte en archivo'], 'En paso por valor no se modifica directamente el dato original.', 'teorico');
    $add('¿Qué caracteriza el paso por referencia?', 'La función puede modificar directamente el valor original', ['La función nunca recibe datos', 'El código se ejecuta sin instrucciones', 'El resultado siempre es cero'], 'En paso por referencia se trabaja con el dato original.', 'teorico');
    $add('Si una operación se repite varias veces en un programa, ¿qué conviene hacer?', 'Crear una función para reutilizar esa lógica', ['Copiar muchas veces el mismo bloque sin revisar', 'Eliminar variables importantes', 'Evitar cualquier modularidad'], 'Las funciones reducen repetición y facilitan mantenimiento.', 'practico');
    $add('¿Qué ventaja tiene probar una función por separado?', 'Permite detectar errores en una parte específica del programa', ['Impide volver a usar la función', 'Borra las variables globales siempre', 'Evita que existan salidas'], 'Probar funciones por separado facilita la depuración.', 'practico');
  }

  if (!$candidates) {
    $candidates = build_adaptive_fill_questions($unit, $temas, max($n, 8), $seen, $difficulty, $style);
  }

  // Generador de variaciones específicas para completar exámenes largos sin depender de internet.
  $conceptos = [
    'algoritmo' => 'un conjunto ordenado de pasos para resolver un problema',
    'pseudocódigo' => 'una forma textual y estructurada de representar una solución',
    'diagrama de flujo' => 'una representación gráfica del algoritmo',
    'variable' => 'un espacio identificado que almacena un valor durante la ejecución',
    'constante' => 'un valor que permanece fijo durante el programa',
    'operador lógico' => 'un operador que combina o niega condiciones',
    'ciclo' => 'una estructura que repite instrucciones bajo una condición',
    'arreglo' => 'una estructura que almacena varios datos relacionados',
    'función' => 'un bloque reutilizable de instrucciones'
  ];
  $i = 0;
  while (count($candidates) < max($n * 3, 60) && $i < 120) {
    $keys = array_keys($conceptos);
    $concept = (string)$keys[$i % count($keys)];
    $def = (string)$conceptos[$concept];
    if ($difficulty === 'basico') {
      add_mcq_candidate($candidates, "En programación, ¿qué describe mejor el concepto de {$concept}?", ucfirst($def), ['Un dato sin relación con el problema', 'Un elemento decorativo de la interfaz', 'Una respuesta elegida sin análisis'], "El concepto de {$concept} se usa como base para construir soluciones programables.", 'teorico');
    } elseif ($difficulty === 'avanzado') {
      add_mcq_candidate($candidates, "En un programa con errores, ¿cómo ayudaría revisar el uso de {$concept}?", 'Permitiría comprobar si la solución sigue una lógica coherente y mantenible', ['Solo cambiaría el color del código', 'Eliminaría la necesidad de probar el programa', 'Garantizaría respuestas correctas sin analizar datos'], "En nivel avanzado se revisa cómo cada concepto afecta la lógica, pruebas y mantenimiento del programa.", 'practico');
    } else {
      add_mcq_candidate($candidates, "¿Cómo se aplica {$concept} en un programa básico?", 'Como parte de una solución ordenada que procesa datos o controla instrucciones', ['Como un adorno sin efecto en la solución', 'Como sustituto de todas las pruebas', 'Como una regla ajena al algoritmo'], "El concepto debe conectarse con la construcción de programas y solución de problemas.", 'mixto');
    }
    $i++;
  }

  $candidates = filter_by_exam_style($candidates, $style);
  $selected = select_questions_with_rotation($candidates, $n, $seen, $unidadId);
  $selected = filtrar_preguntas_por_dificultad(validar_preguntas_generadas($selected), $difficulty);

  if (count($selected) < $n) {
    $extra = build_adaptive_fill_questions($unit, $temas, $n - count($selected), $seen, $difficulty, $style);
    foreach ($extra as $q) {
      if (count($selected) >= $n) break;
      $selected[] = $q;
    }
  }

  return array_slice(strip_internal_question_fields($selected), 0, $n);
}

function build_math_name_based_questions(array $unit, array $temas, int $n, array &$seen, string $difficulty = 'intermedio', string $style = 'mixto'): array {
  $materia = trim((string)$unit['materia_nombre']);
  $unidad = trim((string)$unit['unidad_titulo']);
  $uNorm = norm_basic($unidad);
  $unidadId = (int)($unit['unidad_id'] ?? 0);
  $difficulty = normalize_exam_difficulty($difficulty);
  if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';

  $wantTheory = ($style === 'mixto' || $style === 'teorico');
  $wantPractice = ($style === 'mixto' || $style === 'practico');
  $candidates = [];

  $add = function(string $question, string $correct, array $wrongs, string $explanation) use (&$candidates, $difficulty) {
    $q = make_mcq($question, $correct, $wrongs, $explanation);
    if (question_matches_difficulty($q, $difficulty)) $candidates[] = $q;
  };
  $fmt = function(int $n): string { return (string)$n; };

  $isIneq = str_contains($uNorm, 'desigualdad') || str_contains($uNorm, 'inecuacion');
  $isFactor = str_contains($uNorm, 'factor');
  $isDeriv = str_contains($uNorm, 'derivada');
  $isIntegral = str_contains($uNorm, 'integral');
  $targetPool = max($n * 5, 24);
  $guard = 0;

  while (count($candidates) < $targetPool && $guard < $targetPool * 8) {
    $guard++;

    if ($isIneq) {
      if ($difficulty === 'basico') {
        if ($wantTheory) {
          $simbolos = [
            ['>', 'Mayor que', ['Menor que', 'Igual que', 'Diferente de']],
            ['<', 'Menor que', ['Mayor que', 'Igual que', 'Diferente de']],
            ['≥', 'Mayor o igual que', ['Menor o igual que', 'Mayor que', 'Diferente de']],
            ['≤', 'Menor o igual que', ['Mayor o igual que', 'Menor que', 'Diferente de']],
          ];
          $sim = random_item($simbolos);
          $add('¿Qué representa el símbolo ' . $sim[0] . ' en una desigualdad?', $sim[1], $sim[2], 'El símbolo ' . $sim[0] . ' se interpreta como ' . mb_strtolower($sim[1], 'UTF-8') . '.');
          $add('¿Cuál es el objetivo principal al resolver una inecuación?', 'Encontrar los valores que hacen verdadera la desigualdad', ['Hallar siempre un único número', 'Convertir toda desigualdad en ecuación', 'Eliminar la variable sin interpretar el resultado'], 'Resolver una inecuación consiste en determinar los valores que cumplen la condición.');
          $limTeo = random_int(2, 12);
          $add("¿Qué significa la expresión x ≤ {$limTeo}?", "x puede valer {$limTeo} o cualquier número menor", ["x solo puede valer {$limTeo}", "x debe ser mayor que {$limTeo}", "x no puede tomar el valor {$limTeo}"], 'El símbolo ≤ incluye el límite y los valores menores.');
          $limTeo2 = random_int(2, 12);
          $add("En una recta numérica, ¿qué indica el punto cerrado en x ≥ {$limTeo2}?", "Que {$limTeo2} también pertenece a la solución", ["Que {$limTeo2} se excluye", "Que solo se permite el cero", "Que la desigualdad no tiene solución"], 'Un punto cerrado indica que el valor límite está incluido.');
        }
        if ($wantPractice) {
          $b = random_int(2, 9);
          $sol = random_int(2, 12);
          $rhs = $sol + $b;
          $add("Si x + {$b} < {$rhs}, ¿cuál es la solución correcta?", 'x < ' . $sol, ['x > ' . $sol, 'x = ' . $sol, 'x ≤ ' . $rhs], "Al restar {$b} en ambos lados, queda x < {$sol}.");

          $a = random_int(2, 6);
          $sol2 = random_int(2, 9);
          $rhs2 = $a * $sol2;
          $add("Si {$a}x ≤ {$rhs2}, ¿cuál es la solución correcta?", 'x ≤ ' . $sol2, ['x ≥ ' . $sol2, 'x = ' . $sol2, 'x < ' . $rhs2], "Al dividir entre {$a}, queda x ≤ {$sol2}.");

          $lim = random_int(3, 10);
          $ok = random_int(-2, $lim);
          $add("¿Cuál de estos valores satisface la desigualdad x ≤ {$lim}?", (string)$ok, [(string)($lim + 1), (string)($lim + 2), (string)($lim + 3)], "Todo valor menor o igual que {$lim} satisface la desigualdad.");
        }
      } elseif ($difficulty === 'avanzado') {
        if ($wantTheory) {
          $add('Al multiplicar una inecuación por un número negativo, ¿qué condición debe cuidarse?', 'Invertir el sentido de la desigualdad', ['Mantener siempre el mismo signo', 'Eliminar la variable principal', 'Convertir automáticamente la relación en igualdad'], 'Multiplicar o dividir por un número negativo invierte el sentido de la desigualdad.');
          $r1 = random_int(1, 5);
          $r2 = random_int($r1 + 3, $r1 + 10);
          $add("Para (x - {$r1})(x - {$r2}) ≤ 0, ¿qué intervalo describe el conjunto solución?", "{$r1} ≤ x ≤ {$r2}", ["x ≤ {$r1} o x ≥ {$r2}", "x < {$r1} y x > {$r2}", "x = {$r1} únicamente"], 'El producto es menor o igual que cero entre las raíces, incluyendo los extremos.');
        }
        if ($wantPractice) {
          $m = random_int(2, 6);
          if (random_int(0, 1) === 1) $m *= -1;
          $sol = random_int(-5, 8);
          $b = random_int(1, 10);
          $rhs = $m * $sol + $b;
          $sign = $m > 0 ? '≤' : '≥';
          $wrongSign = $m > 0 ? '≥' : '≤';
          $add("Al resolver {$m}x + {$b} ≤ {$rhs}, ¿qué resultado se obtiene?", "x {$sign} {$sol}", ["x {$wrongSign} {$sol}", "x = {$sol}", "x {$sign} " . ($sol + 2)], "Primero se resta {$b}; después se divide entre {$m}. Si el divisor es negativo, el signo cambia.");

          $a = random_int(2, 5);
          $low = random_int(-5, 1);
          $high = random_int($low + 3, $low + 9);
          $b2 = random_int(1, 6);
          $left = $a * $low + $b2;
          $right = $a * $high + $b2;
          $add("Si {$left} < {$a}x + {$b2} ≤ {$right}, ¿cuál es el conjunto solución?", "{$low} < x ≤ {$high}", ["{$low} ≤ x < {$high}", "x < {$low} o x > {$high}", "{$left} < x ≤ {$right}"], "Se resta {$b2} en los tres miembros y luego se divide entre {$a}.");

          $h = random_int(1, 6);
          $rad = random_int(2, 6);
          $lo = $h - $rad;
          $hi = $h + $rad;
          $add("¿Qué solución corresponde a |x - {$h}| < {$rad}?", "{$lo} < x < {$hi}", ["x < {$lo} o x > {$hi}", "{$lo} ≤ x ≤ {$hi}", "x = {$h}"], 'Una desigualdad de valor absoluto menor que una cantidad positiva queda entre dos límites.');
        }
      } else {
        if ($wantTheory) {
          $add('¿Qué ocurre con el signo de una desigualdad si se divide entre un número negativo?', 'Se invierte el sentido de la desigualdad', ['Se conserva igual', 'Desaparece la desigualdad', 'La variable se elimina'], 'Dividir por un número negativo invierte el sentido de la desigualdad.');
          $lim = random_int(2, 9);
          $add("¿Cómo se interpreta x ≥ {$lim} en una recta numérica?", "Incluye {$lim} y todos los valores mayores", ["Incluye solo {$lim}", "Incluye valores menores que {$lim}", "Excluye {$lim} y toma los menores"], 'El símbolo ≥ incluye el límite y los valores a su derecha.');
          $limB = random_int(-4, 8);
          $add("¿Qué intervalo representa x < {$limB}?", "(-∞, {$limB})", ["({$limB}, ∞)", "[{$limB}, ∞)", "(-∞, {$limB}]"], 'El símbolo < toma todos los valores menores y no incluye el límite.');
        }
        if ($wantPractice) {
          $a = random_int(2, 6);
          $sol = random_int(-3, 8);
          $b = random_int(1, 8);
          $rhs = $a * $sol + $b;
          $add("Si {$a}x + {$b} < {$rhs}, ¿cuál es la solución correcta?", 'x < ' . $sol, ['x > ' . $sol, 'x = ' . $sol, 'x ≤ ' . $rhs], "Se resta {$b} y después se divide entre {$a}.");

          $neg = -random_int(2, 6);
          $sol2 = random_int(-4, 7);
          $rhs2 = $neg * $sol2;
          $add("Si {$neg}x > {$rhs2}, ¿cuál es la solución correcta?", 'x < ' . $sol2, ['x > ' . $sol2, 'x = ' . $sol2, 'x ≥ ' . $sol2], "Al dividir entre {$neg}, el sentido de la desigualdad se invierte.");
        }
      }
      continue;
    }

    if ($isFactor) {
      if ($difficulty === 'basico') {
        if ($wantTheory) $add('¿Qué busca la factorización de una expresión algebraica?', 'Escribirla como producto de factores más simples', ['Convertirla en una desigualdad', 'Eliminar todos los términos', 'Obtener siempre un número decimal'], 'Factorizar consiste en escribir una expresión como producto.');
        if ($wantPractice) $add('¿Cuál es el factor común de 3x + 6?', '3', ['x', '6', '3x'], 'El número 3 divide a los dos términos.');
      } elseif ($difficulty === 'avanzado') {
        if ($wantPractice) {
          $a = random_int(2, 5); $b = random_int(2, 6); $sum = $a + $b; $prod = $a * $b;
          $add("¿Cuál es la factorización de x² + {$sum}x + {$prod}?", "(x + {$a})(x + {$b})", ["(x + {$sum})(x + 1)", "(x - {$a})(x - {$b})", "x(x + {$sum})"], 'Se buscan dos números que sumen el coeficiente lineal y multipliquen el término independiente.');
        }
        if ($wantTheory) $add('¿Por qué conviene verificar una factorización multiplicando los factores?', 'Porque confirma que el producto recupera la expresión original', ['Porque cambia el grado del polinomio', 'Porque elimina todos los signos negativos', 'Porque convierte el polinomio en fracción'], 'La verificación evita aceptar una factorización incorrecta.');
      } else {
        if ($wantPractice) $add('¿Cuál es la factorización de x² - 9?', '(x - 3)(x + 3)', ['(x - 9)(x + 1)', '(x - 3)²', 'x(x - 9)'], 'x² - 9 es una diferencia de cuadrados.');
        if ($wantTheory) $add('¿Qué indica que un trinomio puede factorizarse con dos binomios?', 'Que existen dos números con suma y producto adecuados', ['Que todos sus términos sean iguales', 'Que no tenga término independiente', 'Que siempre sea una resta'], 'En muchos trinomios se buscan dos números que cumplan suma y producto.');
      }
      continue;
    }

    if ($isDeriv) {
      if ($difficulty === 'basico') {
        if ($wantTheory) $add('En cálculo, la derivada representa principalmente:', 'La razón de cambio instantánea', ['El área acumulada', 'Un promedio sin variable', 'Una constante fija'], 'La derivada mide cómo cambia una función en un punto.');
        if ($wantPractice) $add('¿Cuál es la derivada de 7?', '0', ['1', '7', 'x'], 'La derivada de una constante es 0.');
      } elseif ($difficulty === 'avanzado') {
        $coef = random_int(2, 5); $pow = random_int(3, 6); $c = random_int(1, 6);
        $correct = ($coef * $pow) . 'x^' . ($pow - 1) . ' + ' . $c;
        if ($wantPractice) $add("Si f(x) = {$coef}x^{$pow} + {$c}x - 4, ¿cuál es f'(x)?", $correct, [($coef).'x^'.($pow-1).' + '.$c, ($pow).'x^'.$pow.' + '.$c, ($coef*$pow).'x^'.$pow.' + '.$c], 'Se aplica la regla de la potencia a cada término y la constante desaparece.');
        if ($wantTheory) $add('¿Qué información aporta el signo de la derivada en un intervalo?', 'Indica si la función crece o decrece en ese intervalo', ['Indica siempre el área exacta', 'Elimina la necesidad de evaluar la función', 'Convierte la función en constante'], 'El signo de la derivada permite interpretar crecimiento y decrecimiento.');
      } else {
        $pow = random_int(2, 5); $coef = random_int(2, 6); $correct = ($coef * $pow) . 'x' . ($pow - 1 === 1 ? '' : '^' . ($pow - 1));
        if ($wantPractice) $add("¿Cuál es la derivada de {$coef}x^{$pow}?", $correct, [($coef).'x^'.($pow-1), ($pow).'x^'.$pow, (string)$coef], 'Se aplica la regla de la potencia.');
        if ($wantTheory) $add('¿Qué se necesita identificar para aplicar la regla de la potencia?', 'El coeficiente y el exponente de la variable', ['Solo el signo igual', 'El nombre de la materia', 'La posición de la respuesta'], 'La regla de la potencia usa el coeficiente y el exponente.');
      }
      continue;
    }

    if ($isIntegral) {
      if ($difficulty === 'basico') {
        if ($wantTheory) $add('La integral indefinida se relaciona principalmente con:', 'Antiderivadas', ['Desigualdades lineales', 'Números primos', 'Promedios simples'], 'Una integral indefinida representa una familia de antiderivadas.');
        if ($wantPractice) $add('¿Cuál es una integral indefinida de 1?', 'x + C', ['1 + C', '0', 'x² + C'], 'Una función cuya derivada es 1 es x, más una constante.');
      } elseif ($difficulty === 'avanzado') {
        $coef = random_int(2, 6); $pow = random_int(2, 5); $newPow = $pow + 1; $num = $coef; $den = $newPow;
        if ($wantPractice) $add("¿Cuál es una integral indefinida de {$coef}x^{$pow} + 3?", "({$num}/{$den})x^{$newPow} + 3x + C", ["{$coef}x^{$newPow} + 3 + C", "({$num}/{$den})x^{$den} + C", "{$coef}x^{$pow} + 3x + C"], 'Se aumenta el exponente en uno y se divide entre el nuevo exponente; además se integra la constante.');
        if ($wantTheory) $add('¿Por qué debe agregarse C en una integral indefinida?', 'Porque muchas funciones que difieren por una constante tienen la misma derivada', ['Porque toda integral elimina la variable', 'Porque la constante cambia el exponente', 'Porque obliga a que el resultado sea positivo'], 'La constante representa la familia de antiderivadas.');
      } else {
        $coef = random_int(2, 6); $half = (($coef/2)==(int)($coef/2)?(string)(int)($coef/2):(string)($coef/2));
        if ($wantPractice) $add("¿Cuál es una integral indefinida de {$coef}x?", $half . 'x² + C', [(string)$coef . 'x + C', 'x + C', 'x³ + C'], 'Al integrar ax se obtiene (a/2)x² + C.');
        if ($wantTheory) $add('¿Qué relación tiene una integral indefinida con una derivada?', 'La integral busca una función cuya derivada regrese la expresión inicial', ['La integral siempre elimina la función', 'La derivada y la integral no se relacionan', 'La integral cambia toda variable por cero'], 'Integrar es el proceso inverso de derivar en este contexto.');
      }
      continue;
    }

    // Respaldo matemático general cuando el título de la unidad no permite deducir un tema específico.
    if ($difficulty === 'basico') {
      if ($wantTheory) $add("¿Qué se debe identificar primero al estudiar {$unidad}?", 'Los conceptos y símbolos principales del tema', ['Los datos administrativos del curso', 'Respuestas elegidas al azar', 'Temas de otra materia'], 'Primero se reconocen conceptos y símbolos esenciales.');
      if ($wantPractice) {
        $a = random_int(4, 12); $b = random_int(3, 11);
        $add("Si {$a} + {$b} = ?", (string)($a + $b), [(string)($a + $b - 1), (string)($a + $b + 1), (string)($a + $b + 2)], 'La suma se obtiene agregando ambas cantidades.');
      }
    } elseif ($difficulty === 'avanzado') {
      if ($wantTheory) $add("En un procedimiento de {$unidad}, ¿qué permite detectar un error de razonamiento?", 'Revisar condiciones, operaciones y coherencia del resultado', ['Aceptar la primera respuesta sin comprobar', 'Ignorar las restricciones del problema', 'Cambiar los datos para que coincidan'], 'La revisión completa ayuda a detectar errores y validar el resultado.');
      if ($wantPractice) {
        $m = random_int(2, 6); $x = random_int(2, 9); $b = random_int(1, 8); $prod = $m * $x + $b;
        $add("Si {$m}x + {$b} = {$prod}, entonces x =", (string)$x, [(string)($x-1), (string)($x+1), (string)$m], 'Se resta el término independiente y luego se divide entre el coeficiente.');
      }
    } else {
      if ($wantTheory) $add("¿Qué estrategia ayuda a resolver ejercicios de {$unidad}?", 'Identificar el concepto aplicable y avanzar paso a paso', ['Responder sin leer condiciones', 'Cambiar de tema sin justificación', 'Evitar comprobar el resultado'], 'Un procedimiento ordenado reduce errores.');
      if ($wantPractice) {
        $m = random_int(2, 6); $x = random_int(2, 9); $prod = $m * $x;
        $add("Si {$m}x = {$prod}, entonces x =", (string)$x, [(string)($x-1), (string)($x+1), (string)$m], 'Al dividir entre el coeficiente se obtiene el valor de x.');
      }
    }
  }

  // Si el usuario pide muchas preguntas, completa con respaldo genérico del mismo nivel sin mezclar preguntas fáciles en avanzado.
  if (count($candidates) < $n) {
    $extra = build_generic_name_based_questions($unit, $temas, $n - count($candidates), $seen, $difficulty);
    foreach ($extra as $q) {
      if (question_matches_difficulty($q, $difficulty)) $candidates[] = $q;
    }
  }

  $selected = select_questions_with_rotation($candidates, $n, $seen, $unidadId);
  $selected = filtrar_preguntas_por_dificultad(validar_preguntas_generadas($selected), $difficulty);
  return array_slice($selected, 0, $n);
}

function verify_math_questions_with_llm(array $unit, array $questions): array {
  return validar_preguntas_generadas($questions);
}
function generate_questions_from_chunks(PDO $pdo, array $unit, array $temas, int $nq, string $style, string $difficulty): array {
  // MODO ESTABLE CON BANCO LOCAL + RESPALDO INTELIGENTE:
  // No consulta temas, chunks, apuntes ni archivos. La generación se basa en materia + unidad.
  // Si existe banco_preguntas_predictivas, se usa primero para preguntas más congruentes.
  $temas = [];
  $difficulty = normalize_exam_difficulty($difficulty);
  $nq = clamp_exam_question_count($nq);
  if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';

  $seen = [];
  $qs = cargar_preguntas_banco($pdo, $unit, $nq, $style, $difficulty);
  if (count($qs) >= $nq) {
    $qs = array_slice($qs, 0, $nq);
    return [
      'questions' => $qs,
      'context_text' => 'Preguntas tomadas del banco local por materia y unidad. Dificultad: ' . exam_difficulty_label($difficulty) . '.',
      'chunks' => [],
      'provider' => 'banco_local',
      'model' => 'banco_preguntas_predictivas',
      'used_fallback' => false,
      'llm_error' => null,
    ];
  }

  $localStyle = style_for_local_generation($unit, $style);

  if (is_algorithm_programming_context($unit)) {
    $extraNeeded = max($nq, $nq - count($qs));
    $qs = array_merge($qs, build_alp_name_based_questions($unit, $temas, $extraNeeded + 6, $seen, $difficulty, $localStyle));
  } elseif (is_math_context($unit)) {
    $extraNeeded = max($nq, $nq - count($qs));
    $qs = array_merge($qs, build_math_name_based_questions($unit, $temas, $extraNeeded + 6, $seen, $difficulty, $localStyle));
  } else {
    $extraNeeded = max($nq, $nq - count($qs));
    $qs = array_merge($qs, build_adaptive_fill_questions($unit, $temas, $extraNeeded + 6, $seen, $difficulty, $localStyle));
    if (count($qs) < $nq) {
      $extra = build_generic_name_based_questions($unit, $temas, $nq - count($qs), $seen, $difficulty);
      $qs = array_merge($qs, $extra);
    }
  }

  $qs = filter_by_exam_style($qs, $localStyle);
  $qs = filtrar_preguntas_por_dificultad(validar_preguntas_generadas($qs), $difficulty);

  // Si algún filtro dejó menos preguntas, se completa de forma local sin llamadas externas.
  $guard = 0;
  while (count($qs) < $nq && $guard < 8) {
    $guard++;
    $missing = $nq - count($qs);
    if (is_algorithm_programming_context($unit)) {
      $extra = build_alp_name_based_questions($unit, $temas, $missing + 3, $seen, $difficulty, $localStyle);
    } elseif (is_math_context($unit)) {
      $extra = build_math_name_based_questions($unit, $temas, $missing + 3, $seen, $difficulty, $localStyle);
    } else {
      $extra = build_adaptive_fill_questions($unit, $temas, $missing + 3, $seen, $difficulty, $localStyle);
      $extra = array_merge($extra, build_generic_name_based_questions($unit, $temas, $missing + 3, $seen, $difficulty));
    }
    $extra = filter_by_exam_style($extra, $localStyle);
    $extra = filtrar_preguntas_por_dificultad(validar_preguntas_generadas($extra), $difficulty);
    foreach ($extra as $q) {
      if (count($qs) >= $nq) break;
      $key = norm_basic((string)($q['question'] ?? ''));
      $exists = false;
      foreach ($qs as $old) {
        if (norm_basic((string)($old['question'] ?? '')) === $key) { $exists = true; break; }
      }
      if (!$exists) $qs[] = $q;
    }
  }

  // Respaldo final ultra simple, también local, para garantizar que siempre haya examen.
  while (count($qs) < $nq) {
    $idx = count($qs) + 1;
    $materia = trim((string)($unit['materia_nombre'] ?? 'la materia')) ?: 'la materia';
    $unidad = trim((string)($unit['unidad_titulo'] ?? 'la unidad')) ?: 'la unidad';
    $qs[] = make_mcq(
      "En {$materia}, dentro de {$unidad}, ¿qué acción ayuda más a resolver una actividad correctamente?",
      'Leer el problema, identificar los datos y aplicar el procedimiento adecuado',
      ['Elegir una respuesta sin revisar el planteamiento', 'Ignorar la unidad y contestar al azar', 'Copiar una opción sin comprobarla'],
      'La respuesta correcta se basa en analizar el problema y aplicar un procedimiento coherente con la unidad.'
    );
    if ($idx > $nq + 5) break;
  }

  $qs = array_slice(validar_preguntas_generadas($qs), 0, $nq);

  return [
    'questions' => $qs,
    'context_text' => 'Generado únicamente a partir del nombre de la materia y de la unidad. Dificultad: ' . exam_difficulty_label($difficulty) . '.',
    'chunks' => [],
    'provider' => count($qs) > 0 ? 'local_inteligente' : 'local_rapido',
    'model' => 'banco_local_materia_unidad',
    'used_fallback' => false,
    'llm_error' => null,
  ];
}

function save_exam(PDO $pdo, int $studentId, array $unit, string $style, array $questions, string $contextText, string $provider, string $model): int {
  $title = 'Examen predictivo · Unidad ' . (int)$unit['numero'];

  $pdo->beginTransaction();
  try {
    $st = $pdo->prepare("
      INSERT INTO examenes_predictivos (
        unidad_id, materia_clave, estudiante_id, titulo, estilo, proveedor_llm, modelo_llm, total_preguntas, contexto_usado
      ) VALUES (
        :unidad_id, :materia_clave, :estudiante_id, :titulo, :estilo, :proveedor_llm, :modelo_llm, :total_preguntas, :contexto_usado
      )
    ");
    $st->execute([
      ':unidad_id' => (int)$unit['unidad_id'],
      ':materia_clave' => (string)$unit['materia_clave'],
      ':estudiante_id' => $studentId,
      ':titulo' => $title,
      ':estilo' => $style,
      ':proveedor_llm' => $provider !== '' ? $provider : null,
      ':modelo_llm' => $model !== '' ? $model : null,
      ':total_preguntas' => count($questions),
      ':contexto_usado' => $contextText,
    ]);
    $examId = (int)$pdo->lastInsertId();

    $insQ = $pdo->prepare("
      INSERT INTO examen_preguntas (
        examen_id, orden_pregunta, pregunta, opcion_a, opcion_b, opcion_c, opcion_d, respuesta_correcta, explicacion, chunk_ids_json
      ) VALUES (
        :examen_id, :orden_pregunta, :pregunta, :a, :b, :c, :d, :respuesta_correcta, :explicacion, :chunk_ids_json
      )
    ");

    foreach ($questions as $idx => $q) {
      $choices = array_values($q['choices']);
      $insQ->execute([
        ':examen_id' => $examId,
        ':orden_pregunta' => $idx + 1,
        ':pregunta' => (string)$q['question'],
        ':a' => (string)($choices[0] ?? ''),
        ':b' => (string)($choices[1] ?? ''),
        ':c' => (string)($choices[2] ?? ''),
        ':d' => (string)($choices[3] ?? ''),
        ':respuesta_correcta' => indice_a_letra((int)$q['answer']),
        ':explicacion' => $q['explanation'] ?? null,
        ':chunk_ids_json' => !empty($q['chunk_ids']) ? json_encode(array_values($q['chunk_ids']), JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) : null,
      ]);
    }

    $pdo->commit();
    return $examId;
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    throw $e;
  }
}
function load_exam_for_student(PDO $pdo, int $examId, int $studentId): ?array {
  $st = $pdo->prepare("
    SELECT ep.id, ep.unidad_id, ep.materia_clave, ep.estudiante_id, ep.titulo, ep.estilo, ep.total_preguntas,
           u.numero AS unidad_numero, u.titulo AS unidad_titulo, m.nombre AS materia_nombre
    FROM examenes_predictivos ep
    JOIN unidades u ON u.id = ep.unidad_id
    JOIN materias m ON LOWER(m.clave) = LOWER(ep.materia_clave)
    WHERE ep.id = :id AND ep.estudiante_id = :student
    LIMIT 1
  ");
  $st->execute([':id' => $examId, ':student' => $studentId]);
  $exam = $st->fetch(PDO::FETCH_ASSOC);
  if (!$exam) return null;

  $stQ = $pdo->prepare("SELECT id, orden_pregunta, pregunta, opcion_a, opcion_b, opcion_c, opcion_d, respuesta_correcta, explicacion, chunk_ids_json FROM examen_preguntas WHERE examen_id=:e ORDER BY orden_pregunta ASC");
  $stQ->execute([':e' => $examId]);
  $exam['questions'] = $stQ->fetchAll(PDO::FETCH_ASSOC) ?: [];
  return $exam;
}
function submit_exam_attempt(PDO $pdo, int $examId, int $studentId, array $answers): array {
  $exam = load_exam_for_student($pdo, $examId, $studentId);
  if (!$exam) throw new RuntimeException('No se encontró el examen.');

  $aciertos = 0;
  $errores = 0;
  $detail = [];

  foreach ($exam['questions'] as $q) {
    $qid = (int)$q['id'];
    $selected = strtoupper(trim((string)($answers[$qid] ?? '')));
    if (!in_array($selected, ['A', 'B', 'C', 'D'], true)) {
      $selected = '';
    }
    $correct = strtoupper(trim((string)$q['respuesta_correcta']));
    $ok = ($selected !== '' && $selected === $correct);
    if ($ok) $aciertos++; else $errores++;

    $detail[] = [
      'question_id' => $qid,
      'orden' => (int)$q['orden_pregunta'],
      'question' => limpiar_texto_salida((string)$q['pregunta']),
      'choices' => [
        limpiar_texto_salida((string)$q['opcion_a']),
        limpiar_texto_salida((string)$q['opcion_b']),
        limpiar_texto_salida((string)$q['opcion_c']),
        limpiar_texto_salida((string)$q['opcion_d']),
      ],
      'selected' => $selected,
      'correct' => $correct,
      'explanation' => limpiar_texto_salida((string)($q['explicacion'] ?? '')),
      'chunk_ids' => $q['chunk_ids_json'] ? (json_decode((string)$q['chunk_ids_json'], true) ?: []) : [],
    ];
  }

  $total = max(1, count($detail));
  $porcentaje = round(($aciertos * 100) / $total, 2);

  $ins = $pdo->prepare("
    INSERT INTO examen_intentos (examen_id, estudiante_id, aciertos, errores, porcentaje, iniciado_en, finalizado_en)
    VALUES (:e, :u, :a, :er, :p, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
  ");
  $ins->execute([
    ':e' => $examId,
    ':u' => $studentId,
    ':a' => $aciertos,
    ':er' => $errores,
    ':p' => $porcentaje,
  ]);

  return [
    'exam' => $exam,
    'aciertos' => $aciertos,
    'errores' => $errores,
    'porcentaje' => $porcentaje,
    'details' => $detail,
  ];
}
function opcion_texto_por_letra(array $q, string $letter): string {
  $letter = strtoupper(trim($letter));
  $map = [
    'A' => 'opcion_a',
    'B' => 'opcion_b',
    'C' => 'opcion_c',
    'D' => 'opcion_d',
  ];
  if (!isset($map[$letter])) return '';
  return limpiar_texto_salida((string)($q[$map[$letter]] ?? ''));
}
function explicacion_local_profunda(array $exam, array $q, string $selected): string {
  $correct = strtoupper(trim((string)($q['respuesta_correcta'] ?? '')));
  $selected = strtoupper(trim($selected));
  $selectedText = opcion_texto_por_letra($q, $selected);
  $correctText = opcion_texto_por_letra($q, $correct);
  $base = limpiar_texto_salida((string)($q['explicacion'] ?? ''));
  if ($base === '') {
    $base = 'La clave está en identificar el concepto central de la pregunta y comparar cada opción con ese concepto.';
  }

  $deepFromBank = '';
  if (!empty($q['chunk_ids_json'])) {
    $meta = json_decode((string)$q['chunk_ids_json'], true);
    if (is_array($meta)) {
      foreach ($meta as $item) {
        if (is_array($item) && !empty($item['explicacion_profunda'])) {
          $deepFromBank = limpiar_texto_salida((string)$item['explicacion_profunda']);
          break;
        }
      }
    }
  }

  $msg = 'Explicación detallada: ' . ($deepFromBank !== '' ? $deepFromBank : $base);
  if ($selected !== '' && $selected !== $correct) {
    $msg .= ' Tu respuesta fue ' . $selected . ($selectedText !== '' ? ' (' . $selectedText . ')' : '') . ', pero la correcta es ' . $correct . ($correctText !== '' ? ' (' . $correctText . ')' : '') . '. ';
    $msg .= 'Para estudiar este punto, revisa primero la definición del tema, después resuelve un ejemplo corto y al final comprueba por qué las demás opciones no cumplen la condición de la pregunta.';
  } else {
    $msg .= ' Tu respuesta coincide con la opción correcta. Para reforzar, intenta explicar el procedimiento con tus propias palabras y resolver un ejemplo parecido sin ver las opciones.';
  }
  return limpiar_texto_salida($msg);
}
function generar_explicacion_profunda(PDO $pdo, int $examId, int $studentId, int $questionId, string $selected): array {
  // Explicación rápida local: no llama a Ollama para evitar que Apache se bloquee.
  $exam = load_exam_for_student($pdo, $examId, $studentId);
  if (!$exam) throw new RuntimeException('No se encontró el examen.');

  $q = null;
  foreach (($exam['questions'] ?? []) as $row) {
    if ((int)$row['id'] === $questionId) { $q = $row; break; }
  }
  if (!$q) throw new RuntimeException('No se encontró la pregunta.');

  return [
    'explanation' => explicacion_local_profunda($exam, $q, $selected),
    'provider' => 'local_rapido',
    'model' => 'explicacion_sin_ollama',
    'used_fallback' => false,
    'err' => null,
  ];
}
if (!function_exists('mint_contenido_view_token')) {
  function mint_contenido_view_token(int $contenido_id, array $back = []): string {
    if (!isset($_SESSION['contenido_view_tokens'])) {
      $_SESSION['contenido_view_tokens'] = [];
    }

    $allowedOrigins = ['en_curso','buscar','grupos','cursos'];
    $origin = (string)($back['origin'] ?? ($_SESSION['student_last_menu'] ?? 'en_curso'));
    if (!in_array($origin, $allowedOrigins, true)) $origin = 'en_curso';

    $mode = (string)($back['mode'] ?? 'materia');
    if (!in_array($mode, ['rm','materia'], true)) $mode = 'materia';

    $safeBack = [
      'origin' => $origin,
      'mode' => $mode,
      'materia_clave' => (string)($back['materia_clave'] ?? ''),
      'reticula_materia_id' => (int)($back['reticula_materia_id'] ?? 0),
      'unidad_id' => (int)($back['unidad_id'] ?? 0),
    ];

    $t = bin2hex(random_bytes(16));
    $_SESSION['contenido_view_tokens'][$t] = [
      'contenido_id' => $contenido_id,
      'back' => $safeBack,
      'exp' => time() + 300,
    ];
    return $t;
  }
}

/* ========= Menú activo ========= */
$origin  = (string)($_POST['origin'] ?? ($_SESSION['student_last_menu'] ?? 'en_curso'));
$allowed = ['en_curso','buscar','grupos','cursos'];
if (!in_array($origin, $allowed, true)) $origin = 'en_curso';
$_SESSION['student_last_menu'] = $origin;

/* ========= AJAX ========= */
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');
$isJsonPost = ($method === 'POST' && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false);
if (isset($_GET['ajax']) || ($method === 'POST' && (isset($_POST['ajax']) || $isJsonPost))) {
  $ajax = $_GET['ajax'] ?? ($_POST['ajax'] ?? '');
  $in = [];

  if ($isJsonPost) {
    $raw = file_get_contents('php://input');
    $in = json_decode($raw, true) ?: [];
    $ajax = $in['ajax'] ?? $ajax;
  }

  $csrf = $in['csrf'] ?? ($_POST['csrf'] ?? $_GET['csrf'] ?? '');
  if (!hash_equals($_SESSION['csrf'] ?? '', (string)$csrf)) json_out(['ok' => false, 'err' => 'csrf'], 400);

  try {
    if ($ajax === 'toggle_like') {
      $cid = (int)($in['contenido_id'] ?? 0);
      if ($cid <= 0) json_out(['ok' => false, 'err' => 'param'], 400);

      $s = $pdo->prepare("SELECT visibilidad FROM contenidos WHERE id=:c LIMIT 1");
      $s->execute([':c' => $cid]);
      $vis = (string)($s->fetchColumn() ?: '');
      if (!in_array($vis, ['publico', 'solo_estudiantes'], true)) json_out(['ok' => false, 'err' => 'no_visible'], 403);

      $params = [':c' => $cid, ':u' => (int)$yo['id']];
      $chk = $pdo->prepare("SELECT 1 FROM recomendaciones WHERE contenido_id=:c AND usuario_id=:u");
      $chk->execute($params);
      $liked = (bool)$chk->fetchColumn();

      if ($liked) {
        $pdo->prepare("DELETE FROM recomendaciones WHERE contenido_id=:c AND usuario_id=:u")->execute($params);
        $liked = false;
      } else {
        $pdo->prepare("INSERT IGNORE INTO recomendaciones (contenido_id, usuario_id) VALUES (:c, :u)")->execute($params);
        $liked = true;
      }

      $cnt = $pdo->prepare("SELECT COUNT(*) FROM recomendaciones WHERE contenido_id=:c");
      $cnt->execute([':c' => $cid]);
      $likes = (int)$cnt->fetchColumn();

      json_out(['ok' => true, 'liked' => $liked, 'likes' => $likes]);
    }

    if ($ajax === 'gen_exam') {
      $unidadId = (int)($in['unidad_id'] ?? 0);
      $nq = clamp_exam_question_count((int)($in['n'] ?? 5));
      $style = (string)($in['style'] ?? 'mixto');
      if (!in_array($style, ['mixto','teorico','practico'], true)) $style = 'mixto';
      $difficulty = normalize_exam_difficulty((string)($in['difficulty'] ?? 'intermedio'));
      if ($unidadId <= 0) json_out(['ok' => false, 'err' => 'param'], 400);

      $st = $pdo->prepare("
        SELECT u.id AS unidad_id, u.numero, u.titulo AS unidad_titulo, u.descripcion AS unidad_desc,
               m.clave AS materia_clave, m.nombre AS materia_nombre
        FROM unidades u
        JOIN materias m ON LOWER(m.clave) = LOWER(u.materia_clave)
        WHERE u.id = :u
        LIMIT 1
      ");
      $st->execute([':u' => $unidadId]);
      $unit = $st->fetch(PDO::FETCH_ASSOC);
      if (!$unit) json_out(['ok' => false, 'err' => 'no_unidad'], 404);

      // No se consultan temas para generar el examen. Solo se usa materia + unidad.
      $temas = [];

      $probBefore = calcular_probabilidad_aprobacion($pdo, (int)$yo['id'], (string)$unit['materia_clave']);

      $generated = generate_questions_from_chunks($pdo, $unit, $temas, $nq, $style, $difficulty);
      $questions = $generated['questions'] ?? [];
      if (!$questions) {
        json_out([
          'ok' => false,
          'err' => 'no_questions',
          'detail' => $generated['llm_error'] ?? 'No hay preguntas disponibles',
        ], 200);
      }

      $examId = save_exam(
        $pdo,
        (int)$yo['id'],
        $unit,
        $style,
        $questions,
        (string)$generated['context_text'],
        (string)($generated['provider'] ?? ''),
        (string)($generated['model'] ?? '')
      );

      $safeQuestions = [];
      $stQ = $pdo->prepare("SELECT id, orden_pregunta, pregunta, opcion_a, opcion_b, opcion_c, opcion_d FROM examen_preguntas WHERE examen_id=:e ORDER BY orden_pregunta ASC");
      $stQ->execute([':e' => $examId]);
      foreach (($stQ->fetchAll(PDO::FETCH_ASSOC) ?: []) as $q) {
        $safeQuestions[] = [
          'id' => (int)$q['id'],
          'orden' => (int)$q['orden_pregunta'],
          'question' => limpiar_texto_salida((string)$q['pregunta']),
          'choices' => [
            limpiar_texto_salida((string)$q['opcion_a']),
            limpiar_texto_salida((string)$q['opcion_b']),
            limpiar_texto_salida((string)$q['opcion_c']),
            limpiar_texto_salida((string)$q['opcion_d'])
          ],
        ];
      }

      json_out([
        'ok' => true,
        'exam' => [
          'id' => $examId,
          'title' => 'Examen predictivo · Unidad ' . (int)$unit['numero'],
          'unit' => [
            'numero' => (int)$unit['numero'],
            'titulo' => (string)$unit['unidad_titulo'],
            'materia' => ['clave' => (string)$unit['materia_clave'], 'nombre' => (string)$unit['materia_nombre']],
          ],
          'questions' => $safeQuestions,
          'style' => $style,
          'difficulty' => $difficulty,
          'difficulty_label' => exam_difficulty_label($difficulty),
        ],
        'meta' => [
          'provider' => (string)($generated['provider'] ?? ''),
          'model' => (string)($generated['model'] ?? ''),
          'used_fallback' => false,
          'chunks_used' => count($generated['chunks'] ?? []),
          'llm_error' => null,
        ],
        'probability_before' => $probBefore
      ]);
    }

    if ($ajax === 'submit_exam') {
      $examId = (int)($in['exam_id'] ?? 0);
      $answers = $in['answers'] ?? [];
      if ($examId <= 0 || !is_array($answers)) json_out(['ok' => false, 'err' => 'param'], 400);

      $result = submit_exam_attempt($pdo, $examId, (int)$yo['id'], $answers);
      $materiaResultado = (string)($result['exam']['materia_clave'] ?? '');
      $nextProbability = calcular_probabilidad_aprobacion($pdo, (int)$yo['id'], $materiaResultado);
      json_out([
        'ok' => true,
        'aciertos' => (int)$result['aciertos'],
        'errores' => (int)$result['errores'],
        'porcentaje' => (float)$result['porcentaje'],
        'details' => $result['details'],
        'next_probability' => $nextProbability,
      ]);
    }

    if ($ajax === 'deep_explain') {
      $examId = (int)($in['exam_id'] ?? 0);
      $questionId = (int)($in['question_id'] ?? 0);
      $selected = (string)($in['selected'] ?? '');
      if ($examId <= 0 || $questionId <= 0) json_out(['ok' => false, 'err' => 'param'], 400);

      $exp = generar_explicacion_profunda($pdo, $examId, (int)$yo['id'], $questionId, $selected);
      json_out(['ok' => true] + $exp);
    }

    json_out(['ok' => false, 'err' => 'accion'], 400);
  } catch (Throwable $e) {
    json_out(['ok' => false, 'err' => 'server', 'detail' => $e->getMessage()], 200);
  }
}

/* ========= token de materia desde POST ========= */
$token = (string)($_POST['token'] ?? '');
if ($token === '') { http_response_code(400); echo 'No se encontró la materia seleccionada.'; exit; }

/* ========= Determinar modo ========= */
$mode = null;
$ctx  = null;

if (isset($_SESSION['rm_view_tokens'][$token])) {
  $t = $_SESSION['rm_view_tokens'][$token];
  if (!isset($t['exp']) || $t['exp'] < time()) { unset($_SESSION['rm_view_tokens'][$token]); http_response_code(400); echo 'Enlace expirado.'; exit; }
  $rm_id = (int)$t['rm_id'];
  if ($rm_id <= 0) { http_response_code(400); echo 'Enlace inválido.'; exit; }

  $st = $pdo->prepare("
    SELECT rm.id AS reticula_materia_id, rm.reticula_id,
           r.clave AS reticula_clave, r.nombre AS reticula_nombre,
           m.clave AS materia_clave, m.nombre AS materia_nombre
    FROM reticula_materias rm
    JOIN reticulas r ON r.id = rm.reticula_id
    JOIN materias  m ON LOWER(m.clave) = LOWER(rm.materia_clave)
    WHERE rm.id = :rm LIMIT 1
  ");
  $st->execute([':rm' => $rm_id]);
  $ctx = $st->fetch(PDO::FETCH_ASSOC);
  if (!$ctx) { echo 'No se encontró la materia seleccionada.'; exit; }
  $mode = 'rm';
} elseif (isset($_SESSION['materia_view_tokens'][$token])) {
  $t = $_SESSION['materia_view_tokens'][$token];
  if (!isset($t['exp']) || $t['exp'] < time()) { unset($_SESSION['materia_view_tokens'][$token]); http_response_code(400); echo 'Enlace expirado.'; exit; }
  $clave = (string)($t['materia_clave'] ?? '');
  if ($clave === '') { http_response_code(400); echo 'Enlace inválido.'; exit; }

  $claveCanonica = resolve_materia_clave($pdo, $clave);
  if (!$claveCanonica) { echo 'No se encontró la materia seleccionada.'; exit; }
  $st = $pdo->prepare("SELECT clave AS materia_clave, nombre AS materia_nombre FROM materias WHERE clave=:c LIMIT 1");
  $st->execute([':c' => $claveCanonica]);
  $ctx = $st->fetch(PDO::FETCH_ASSOC);
  if (!$ctx) { echo 'No se encontró la materia seleccionada.'; exit; }
  $mode = 'materia';
} else {
  http_response_code(400);
  echo 'No se encontró la materia seleccionada.';
  exit;
}

/* ========= Probabilidad de aprobación por materia ========= */
$probAprobacionMateria = calcular_probabilidad_aprobacion($pdo, (int)$yo['id'], (string)($ctx['materia_clave'] ?? ''));

/* ========= Unidades ========= */
$unidades = [];
if ($mode === 'rm') {
  $st = $pdo->prepare("
    SELECT
      COALESCE(ru.numero, u.numero) AS numero,
      COALESCE(ru.titulo, u.titulo) AS titulo,
      COALESCE(ru.descripcion, u.descripcion) AS descripcion,
      u.id AS unidad_id
    FROM reticula_materias rm
    JOIN materias m ON LOWER(m.clave) = LOWER(rm.materia_clave)
    LEFT JOIN unidades u ON LOWER(u.materia_clave) = LOWER(m.clave)
    LEFT JOIN reticula_unidades ru
      ON ru.reticula_materia_id = rm.id
     AND (ru.unidad_canonica_id = u.id OR ru.numero = u.numero)
    WHERE rm.id = :rm AND u.id IS NOT NULL
    ORDER BY COALESCE(ru.numero, u.numero) ASC, u.id ASC
  ");
  $st->execute([':rm' => (int)$ctx['reticula_materia_id']]);
  $unidades = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} else {
  $st = $pdo->prepare("
    SELECT u.numero, u.titulo, u.descripcion, u.id AS unidad_id
    FROM unidades u
    WHERE LOWER(u.materia_clave) = LOWER(:c)
    ORDER BY u.numero ASC
  ");
  $st->execute([':c' => $ctx['materia_clave']]);
  $unidades = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

/* ========= Temas por unidad ========= */
$temasByUnidad = [];
$rowsTemas = [];
if ($unidades) {
  $ids = array_map(fn($u) => (int)$u['unidad_id'], $unidades);
  $ph = []; $params = [];
  foreach ($ids as $i => $id) { $ph[] = ':u' . $i; $params[':u' . $i] = $id; }
  $in = implode(',', $ph);

  $st = $pdo->prepare("SELECT t.id, t.unidad_id, t.titulo, t.descripcion FROM temas t WHERE t.unidad_id IN ($in) ORDER BY t.id ASC");
  $st->execute($params);
  $rowsTemas = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rowsTemas as $r) { $temasByUnidad[(int)$r['unidad_id']][] = $r; }
}

/* ========= Contenidos por tema ========= */
$recByTema = [];
$chunkStatsByUnit = [];
if (!empty($rowsTemas)) {
  $temaIds = array_map(fn($r) => (int)$r['id'], $rowsTemas);
  $ph = [];
  $params = [':uid' => (int)$yo['id']];
  foreach ($temaIds as $i => $id) { $ph[] = ':t' . $i; $params[':t' . $i] = $id; }
  $in2 = implode(',', $ph);

  $sqlRec = "
    SELECT c.tema_id,
           c.id AS contenido_id,
           u.nombre AS docente_nombre, u.apellidos AS docente_apellidos,
           COALESCE(rl.likes,0)  AS likes,
           EXISTS(
             SELECT 1 FROM recomendaciones r2
             WHERE r2.contenido_id=c.id AND r2.usuario_id=:uid
           ) AS me_like,
           c.creado_en
    FROM contenidos c
    JOIN docentes d ON d.usuario_id = c.docente_id
    JOIN usuarios u ON u.id = d.usuario_id
    LEFT JOIN (
      SELECT contenido_id, COUNT(*) AS likes
      FROM recomendaciones
      GROUP BY contenido_id
    ) rl ON rl.contenido_id = c.id
    WHERE c.tema_id IN ($in2) AND c.visibilidad IN ('publico','solo_estudiantes')
    ORDER BY COALESCE(rl.likes,0) DESC, c.creado_en DESC
  ";
  $st = $pdo->prepare($sqlRec);
  $st->execute($params);
  $rws = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
  foreach ($rws as $r) { $tid = (int)$r['tema_id']; $recByTema[$tid][] = $r; }

  $sqlStats = "
    SELECT ac.unidad_id, COUNT(*) AS total_chunks
    FROM activo_chunks ac
    JOIN contenidos c ON c.id = ac.contenido_id
    JOIN activo_texto_extraido ate ON ate.id = ac.activo_texto_id
    WHERE ac.tema_id IN ($in2)
      AND c.visibilidad IN ('publico','solo_estudiantes')
      AND ate.estado = 'listo'
    GROUP BY ac.unidad_id
  ";
  $stS = $pdo->prepare($sqlStats);
  $stS->execute(array_diff_key($params, [':uid' => true]));
  foreach (($stS->fetchAll(PDO::FETCH_ASSOC) ?: []) as $row) {
    $chunkStatsByUnit[(int)$row['unidad_id']] = (int)$row['total_chunks'];
  }
}

$focusUnidadId = (int)($_POST['focus_unidad_id'] ?? ($_POST['unidad_id'] ?? 0));
if ($unidades) {
  $validUnidadIds = array_map(fn($u) => (int)($u['unidad_id'] ?? 0), $unidades);
  if ($focusUnidadId <= 0 || !in_array($focusUnidadId, $validUnidadIds, true)) {
    $focusUnidadId = (int)($unidades[0]['unidad_id'] ?? 0);
  }
}

$title = 'Ver materia · ' . ($ctx['materia_nombre'] ?? '');
require __DIR__ . '/partials/header.php';
?>
<style>
*{box-sizing:border-box}
.tabs-wrap{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
.tab-btn{--ring:0 0 0 0 rgba(255,255,255,0);appearance:none;border:1px solid #e6eef2;background:#fff;color:#0b2545;padding:10px 14px;border-radius:14px;font-weight:800;cursor:pointer;transition:transform .06s, box-shadow .15s, background .15s, color .15s, border-color .15s;box-shadow:var(--ring)}
.tab-btn:hover{transform:translateY(-1px);border-color:#d9e4f1}
.tab-btn:focus-visible{outline:0;box-shadow:0 0 0 3px rgba(0,85,212,.18)}
.tab-btn.is-active,.tab-btn[aria-selected="true"]{color:#fff;border-color:transparent;background:linear-gradient(135deg,#0b2545,#0fb5bf);box-shadow:inset 0 0 0 3px rgba(255,255,255,.75),0 8px 22px rgba(2,6,23,.16)}
.sel-chip{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;font-weight:700;font-size:13px;color:#0b2545;background:#eef5ff;border:1px solid #dfe9ff;border-radius:999px}
.unit-pane{display:none}.unit-pane.show{display:block}
.topic{border:1px solid #eef2f6;border-radius:12px;padding:12px;background:#fff}
.topic-title{color:#0f172a}
html[data-theme="dark"] .topic-title{color:#f8fafc!important}
.inline{display:inline-block}
.btn{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;cursor:pointer;font-weight:900;color:#0b2545}
.btn:hover{background:#f5f8ff;color:#0055d4;transform:translateY(-1px)}
.btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);border:0;color:#fff}
.btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
.btn.like{display:inline-flex;align-items:center;gap:8px;border:1px solid #e6eef2;background:#fff;color:#0b2545}
.btn.like .count{font-weight:800;font-size:13px;padding:2px 8px;border-radius:999px;background:#eef5ff;border:1px solid #dbeafe}
.btn.like.liked{background:#eef6ff;border-color:#cfe1ff;color:#0b2545}
.btn.like.liked .count{background:#eaf0ff;border-color:#cfe1ff}
.meta{font-size:13px;color:#475569}.badge{background:#eef5ff;border:1px solid #dbeafe;color:#0b2545;font-size:12px;padding:2px 8px;border-radius:999px;font-weight:800}
.kv{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.select{padding:10px 12px;border:1px solid #e6eef2;border-radius:10px;background:#fff;color:#0b2545}
/* Panel compacto para configurar el examen */
.exam-setup-panel{margin-top:4px;display:grid;grid-template-columns:minmax(260px,1fr) auto;gap:18px;align-items:center;border:1px solid #dbeafe;border-radius:20px;padding:14px 16px;background:linear-gradient(135deg,#f8fbff 0%,#eef8ff 55%,#ecfeff 100%);box-shadow:0 14px 36px rgba(15,23,42,.07)}
.exam-unit-info{min-width:0}.exam-unit-title{display:flex;align-items:center;gap:8px;flex-wrap:wrap;font-size:18px;font-weight:950;color:#0f172a;letter-spacing:-.02em}.exam-unit-title i{color:#0284c7}.exam-unit-desc{margin-top:4px;color:#475569;font-size:13px;line-height:1.35}.exam-chunks-pill{margin-top:8px;display:inline-flex;align-items:center;gap:7px;border:1px solid #bae6fd;background:#e0f2fe;color:#075985;border-radius:999px;padding:6px 10px;font-size:12px;font-weight:900}.exam-chunks-pill strong{color:#0f172a}.exam-controls-grid{display:grid;grid-template-columns:112px 148px 158px auto;gap:10px;align-items:end}.exam-field{display:flex;flex-direction:column;gap:5px}.exam-field label{font-size:11px;text-transform:uppercase;letter-spacing:.06em;font-weight:950;color:#334155;margin:0}.exam-field .select{width:100%;height:42px;min-width:0;font-weight:850}.exam-number-input{font-weight:950;text-align:center}.difficulty-sel,.style-sel{min-width:0}.exam-gen-actions .btn{height:42px;display:inline-flex;align-items:center;justify-content:center;gap:8px;padding-inline:16px;white-space:nowrap;border-radius:12px}.exam-helper{grid-column:1/-1;display:flex;align-items:center;gap:8px;margin-top:1px;color:#64748b;font-size:12px;font-weight:750}.exam-helper i{color:#0ea5e9}
.exam-probability-card{margin-top:10px;display:flex;gap:10px;align-items:flex-start;border:1px solid #dbeafe;background:linear-gradient(135deg,#eff6ff,#f8fafc);border-radius:16px;padding:12px 13px;box-shadow:0 10px 24px rgba(15,23,42,.06)}.prob-icon{width:38px;height:38px;border-radius:13px;display:grid;place-items:center;background:#dbeafe;color:#1d4ed8;flex:0 0 auto}.prob-content{min-width:0}.prob-label{font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:950;color:#2563eb}.prob-main{margin-top:2px;color:#0f172a;font-weight:900;line-height:1.28}.prob-value{font-size:24px;color:#0f766e}.prob-detail{margin-top:5px;color:#64748b;font-size:12px;line-height:1.35}.prob-badge{display:inline-flex;align-items:center;gap:6px;margin-top:7px;border-radius:999px;padding:5px 9px;font-size:11px;font-weight:950;background:#ecfeff;color:#0f766e;border:1px solid #a5f3fc}.exam-probability-card[data-risk="alta"] .prob-value{color:#15803d}.exam-probability-card[data-risk="media"] .prob-value{color:#0369a1}.exam-probability-card[data-risk="baja"] .prob-value{color:#b45309}.exam-probability-card[data-risk="critica"] .prob-value{color:#b91c1c}.exam-probability-card[data-risk="sin"] .prob-value{font-size:16px;color:#64748b}
html[data-theme="dark"] .exam-setup-panel{background:linear-gradient(135deg,#0f172a 0%,#111827 58%,#0b2532 100%)!important;border-color:var(--kl-border)!important;box-shadow:0 16px 42px rgba(0,0,0,.34)!important}html[data-theme="dark"] .exam-unit-title{color:#f8fafc!important}html[data-theme="dark"] .exam-unit-title i{color:#67e8f9!important}html[data-theme="dark"] .exam-unit-desc,html[data-theme="dark"] .exam-helper{color:#cbd5e1!important}html[data-theme="dark"] .exam-chunks-pill{background:rgba(14,165,233,.14)!important;border-color:rgba(103,232,249,.32)!important;color:#bae6fd!important}html[data-theme="dark"] .exam-chunks-pill strong{color:#fff!important}html[data-theme="dark"] .exam-field label{color:#dbeafe!important}html[data-theme="dark"] .exam-field .select{background:#0b1220!important;color:#e5eefb!important;border-color:#2b3b52!important}
@media(max-width:1120px){.exam-setup-panel{grid-template-columns:1fr}.exam-controls-grid{grid-template-columns:112px minmax(145px,1fr) minmax(150px,1fr) auto}}
@media(max-width:760px){.exam-controls-grid{grid-template-columns:1fr 1fr}.exam-gen-actions{grid-column:1/-1}.exam-gen-actions .btn{width:100%}.exam-helper{align-items:flex-start}.exam-setup-panel{padding:13px}}
@media(max-width:520px){.exam-controls-grid{grid-template-columns:1fr}.exam-unit-title{font-size:16px}}

/* Controles interactivos del examen */
.exam-controls-interactive{display:grid!important;grid-template-columns:minmax(172px,210px) minmax(235px,1fr) minmax(245px,1fr) auto!important;gap:12px!important;align-items:stretch!important}
.exam-control-card{position:relative;display:flex!important;flex-direction:column!important;gap:10px!important;padding:12px!important;border:1px solid #dbeafe!important;border-radius:18px!important;background:rgba(255,255,255,.78)!important;box-shadow:0 12px 30px rgba(15,23,42,.07)!important;transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease,background .18s ease!important;overflow:hidden!important}
.exam-control-card::before{content:"";position:absolute;inset:0 0 auto;height:3px;background:linear-gradient(90deg,#0b2545,#0fb5bf,#f59e0b);opacity:.88}
.exam-control-card:hover,.exam-control-card:focus-within{transform:translateY(-2px);border-color:#93c5fd!important;box-shadow:0 18px 38px rgba(15,23,42,.11)!important;background:#fff!important}
.exam-control-card label{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;font-size:11px!important;text-transform:uppercase!important;letter-spacing:.07em!important;font-weight:950!important;color:#334155!important;margin:0!important}
.field-hint{font-size:10px!important;text-transform:none!important;letter-spacing:0!important;color:#64748b!important;background:#f1f5f9!important;border:1px solid #e2e8f0!important;border-radius:999px!important;padding:2px 7px!important;white-space:nowrap!important}
.question-stepper{display:grid!important;grid-template-columns:42px minmax(0,1fr) 42px!important;gap:7px!important;align-items:center!important}
.exam-step-btn{height:42px;border:1px solid #dbeafe;border-radius:14px;background:#f8fbff;color:#0b2545;font-weight:950;cursor:pointer;display:grid;place-items:center;transition:transform .15s ease,background .15s ease,border-color .15s ease,box-shadow .15s ease,color .15s ease}
.exam-step-btn:hover,.exam-step-btn:focus-visible{background:#e0f2fe;border-color:#7dd3fc;color:#0369a1;transform:translateY(-1px);box-shadow:0 10px 22px rgba(14,165,233,.14);outline:0}
.exam-control-card .exam-number-input{height:42px!important;border-radius:14px!important;font-size:18px!important;font-weight:950!important;text-align:center!important;padding:8px!important}
.exam-quick-buttons{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px}
.exam-quick-btn{height:32px;border:1px solid #e2e8f0;border-radius:12px;background:#fff;color:#334155;font-weight:950;cursor:pointer;transition:transform .15s ease,background .15s ease,color .15s ease,border-color .15s ease,box-shadow .15s ease}
.exam-quick-btn:hover,.exam-quick-btn:focus-visible{transform:translateY(-1px);background:#f8fafc;border-color:#bae6fd;outline:0}
.exam-quick-btn.is-active{background:linear-gradient(135deg,#0b2545,#0fb5bf);color:#fff;border-color:transparent;box-shadow:0 10px 20px rgba(14,181,191,.18)}
.exam-native-select{position:absolute!important;width:1px!important;height:1px!important;padding:0!important;margin:-1px!important;overflow:hidden!important;clip:rect(0 0 0 0)!important;white-space:nowrap!important;border:0!important;opacity:0!important;pointer-events:none!important}
.exam-option-row{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:7px;min-width:0}
.exam-option-btn{min-width:0;min-height:62px;border:1px solid #dbeafe;border-radius:16px;background:#f8fbff;color:#0b2545;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;font-weight:950;cursor:pointer;line-height:1.05;transition:transform .16s ease,background .16s ease,border-color .16s ease,box-shadow .16s ease,color .16s ease}
.exam-option-btn i{font-size:17px;color:#0284c7;transition:color .16s ease,transform .16s ease}.exam-option-btn span{font-size:12px;max-width:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.exam-option-btn:hover,.exam-option-btn:focus-visible{transform:translateY(-2px);border-color:#7dd3fc;background:#ecfeff;box-shadow:0 12px 24px rgba(14,165,233,.12);outline:0}.exam-option-btn:hover i,.exam-option-btn:focus-visible i{transform:scale(1.08)}
.exam-option-btn.is-active{background:linear-gradient(135deg,#0b2545,#0fb5bf)!important;color:#fff!important;border-color:transparent!important;box-shadow:0 14px 28px rgba(14,181,191,.20)!important}.exam-option-btn.is-active i{color:#fff!important}
.difficulty-options .exam-option-btn[data-exam-option="basico"].is-active{background:linear-gradient(135deg,#16a34a,#22c55e)!important}.difficulty-options .exam-option-btn[data-exam-option="intermedio"].is-active{background:linear-gradient(135deg,#0b2545,#0fb5bf)!important}.difficulty-options .exam-option-btn[data-exam-option="avanzado"].is-active{background:linear-gradient(135deg,#b45309,#f97316)!important}
.exam-controls-interactive .exam-gen-actions{display:flex!important;align-items:stretch!important}.exam-controls-interactive .exam-gen-actions .gen-btn{height:100%!important;min-height:104px!important;border-radius:18px!important;padding-inline:18px!important;box-shadow:0 18px 34px rgba(14,181,191,.20)!important;transition:transform .18s ease,box-shadow .18s ease,filter .18s ease!important}.exam-controls-interactive .exam-gen-actions .gen-btn:hover{transform:translateY(-2px) scale(1.01)!important;filter:saturate(1.08)!important;box-shadow:0 24px 42px rgba(14,181,191,.26)!important}.exam-controls-interactive .exam-helper{grid-column:1/-1!important;border:1px dashed #bae6fd!important;background:rgba(240,249,255,.82)!important;border-radius:14px!important;padding:9px 11px!important;font-size:12px!important;font-weight:800!important;color:#475569!important}
.modal-close-x{width:42px!important;height:42px!important;min-width:42px!important;padding:0!important;display:inline-grid!important;place-items:center!important;border-radius:999px!important;margin-left:8px!important;flex:0 0 auto!important}.modal-close-x i{font-size:18px!important;line-height:1!important}#examMeta{min-width:0;max-width:46%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
html[data-theme="dark"] .exam-control-card{background:rgba(15,23,42,.72)!important;border-color:#263546!important;box-shadow:0 14px 34px rgba(0,0,0,.28)!important}html[data-theme="dark"] .exam-control-card:hover,html[data-theme="dark"] .exam-control-card:focus-within{background:#111827!important;border-color:#38bdf8!important}html[data-theme="dark"] .field-hint{background:rgba(148,163,184,.12)!important;border-color:rgba(148,163,184,.20)!important;color:#cbd5e1!important}html[data-theme="dark"] .exam-step-btn,html[data-theme="dark"] .exam-quick-btn,html[data-theme="dark"] .exam-option-btn{background:#0b1220!important;border-color:#2b3b52!important;color:#e5eefb!important}html[data-theme="dark"] .exam-step-btn:hover,html[data-theme="dark"] .exam-quick-btn:hover,html[data-theme="dark"] .exam-option-btn:hover,html[data-theme="dark"] .exam-option-btn:focus-visible{background:#123047!important;border-color:#38bdf8!important;color:#fff!important}html[data-theme="dark"] .exam-option-btn i{color:#67e8f9!important}html[data-theme="dark"] .exam-controls-interactive .exam-helper{background:rgba(14,165,233,.10)!important;border-color:rgba(103,232,249,.30)!important;color:#cbd5e1!important}
@media(max-width:1120px){.exam-controls-interactive{grid-template-columns:1fr!important}.exam-controls-interactive .exam-gen-actions .gen-btn{width:100%!important;min-height:54px!important}.exam-controls-interactive .exam-gen-actions{grid-column:1/-1!important}}
@media(max-width:720px){.exam-controls-interactive{grid-template-columns:1fr!important;gap:10px!important}.exam-control-card{padding:12px!important;border-radius:18px!important}.exam-option-btn{min-height:58px!important}.exam-controls-interactive .exam-helper{align-items:flex-start!important}.modal-close-x{width:40px!important;height:40px!important;min-width:40px!important;margin-left:auto!important}#examBackdrop .exam-modal header{gap:8px!important;padding:10px 12px!important}#examBackdrop .exam-modal header>div:first-child{min-width:0!important;flex:1 1 auto!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}#examMeta{display:none!important}}
@media(max-width:420px){.exam-option-row{gap:6px!important}.exam-option-btn{min-height:54px!important;border-radius:14px!important}.exam-option-btn span{font-size:11px!important}.exam-option-btn i{font-size:16px!important}.question-stepper{grid-template-columns:40px minmax(0,1fr) 40px!important}.exam-step-btn{height:40px!important}.exam-quick-buttons{gap:5px!important}}

.modal-backdrop{position:fixed;inset:0;background:rgba(2,6,23,.42);display:none;align-items:center;justify-content:center;z-index:3000;padding:18px}
#examBackdrop.is-open{display:flex!important}
#examBackdrop .exam-modal{display:block!important;position:relative!important;inset:auto!important;background:#fff;width:min(980px,94vw)!important;height:auto!important;max-height:90vh;overflow:auto;border-radius:18px;box-shadow:0 18px 60px rgba(2,6,23,.28);margin:0!important;opacity:1!important;transform:none!important;pointer-events:auto!important}
#examBackdrop .exam-modal header{position:sticky;top:0;background:#fff;padding:12px 16px;border-bottom:1px dashed #e6eef2;display:flex;align-items:center;gap:12px;z-index:2}
#examBackdrop .exam-modal .body{padding:16px}#examBackdrop .exam-modal .foot{padding:12px 16px;border-top:1px dashed #e6eef2;display:flex;gap:10px;align-items:center;justify-content:space-between;background:#fafcff;position:sticky;bottom:0}
.exam-grid{display:flex;flex-direction:column;gap:14px}
.qcard{border:1px solid #e6eef2;border-radius:12px;padding:14px;background:#fff}
.qtitle{font-weight:800;color:#0b2545;margin-bottom:10px}
.choices{display:flex;flex-direction:column;gap:8px}
.choice-label{display:flex;gap:10px;align-items:flex-start;border:1px solid #e6eef2;border-radius:10px;padding:10px;background:#fbfdff;cursor:pointer}
.choice-label input{margin-top:3px}
.choice-label.correct{border-color:#86efac;background:#f0fdf4}
.choice-label.wrong{border-color:#fecaca;background:#fef2f2}
.result-card{border:1px dashed #dbeafe;border-radius:12px;padding:14px;background:#f8fbff}
.small{font-size:12px;color:#64748b}
.progress{height:8px;background:#eef2f7;border-radius:999px;overflow:hidden;margin-top:8px}
.progress > div{height:100%;width:0%;background:linear-gradient(90deg,#0b2545,#0fb5bf);transition:width .25s ease}
.hidden{display:none!important}
.alert{padding:10px 12px;border-radius:10px;border:1px solid #dbeafe;background:#f8fbff;color:#0b2545}
.alert.error{border-color:#fecaca;background:#fef2f2;color:#991b1b}


/* ===== Flujo nuevo de examen: una pregunta a la vez ===== */
.exam-step-card{border:1px solid #dbeafe;border-radius:20px;padding:18px;background:linear-gradient(180deg,#ffffff,#f8fbff);box-shadow:0 18px 42px rgba(15,23,42,.08)}
.exam-step-head{display:flex;justify-content:space-between;gap:10px;align-items:center;margin-bottom:12px;flex-wrap:wrap}
.exam-step-badge,.exam-step-count{display:inline-flex;align-items:center;gap:8px;border-radius:999px;padding:7px 11px;font-weight:900;font-size:12px;border:1px solid #bae6fd;color:#075985;background:#e0f2fe}
.exam-step-question{font-size:20px;line-height:1.35;font-weight:950;color:#0f172a;margin:8px 0 16px}
.exam-step-choices{display:grid;gap:10px}
.exam-choice-btn{width:100%;display:flex;gap:12px;align-items:flex-start;text-align:left;border:1px solid #dbeafe;border-radius:16px;padding:14px 15px;background:#fff;color:#0f172a;font-weight:800;cursor:pointer;transition:transform .14s ease,box-shadow .14s ease,border-color .14s ease,background .14s ease}
.exam-choice-btn:hover,.exam-choice-btn:focus{border-color:#38bdf8;background:#f0f9ff;box-shadow:0 14px 30px rgba(14,165,233,.14);transform:translateY(-1px);outline:0}
.exam-choice-btn .letter{min-width:34px;height:34px;border-radius:12px;display:inline-flex;align-items:center;justify-content:center;background:linear-gradient(135deg,#0284c7,#0ea5e9);color:#fff;font-weight:950}
.exam-choice-btn.selected{border-color:#0ea5e9;background:#e0f2fe;box-shadow:0 16px 34px rgba(14,165,233,.22)}
.exam-choice-btn:disabled{cursor:not-allowed;opacity:.95}
.exam-step-help{margin-top:12px}
.exam-loading{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;border:1px dashed #bae6fd;border-radius:18px;padding:34px 18px;background:#f8fbff;color:#075985;text-align:center}
.exam-loading i{font-size:28px}.exam-loading span{color:#64748b;font-size:13px}
.exam-score-summary{display:grid;grid-template-columns:auto 1fr;gap:18px;align-items:center;border-radius:24px;padding:22px;border:1px solid #dbeafe;background:linear-gradient(135deg,#ffffff,#f0f9ff);box-shadow:0 20px 50px rgba(15,23,42,.10)}
.score-ring{width:132px;height:132px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(#22c55e var(--score,75%),#e2e8f0 0);box-shadow:inset 0 0 0 12px #fff;border:1px solid #dcfce7}
.exam-score-summary.study .score-ring{background:conic-gradient(#f59e0b var(--score,55%),#e2e8f0 0);border-color:#fde68a}
.score-ring span{font-size:28px;font-weight:950;color:#0f172a}
.score-kicker{text-transform:uppercase;letter-spacing:.08em;font-size:11px;font-weight:950;color:#0284c7}.score-info h3{font-size:28px;margin:4px 0;color:#0f172a}.score-info p{margin:0 0 14px;color:#475569}.score-actions{display:flex;gap:10px;flex-wrap:wrap}
.result-overview{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}.result-question-card{position:relative}.result-question-head{display:flex;justify-content:space-between;gap:12px;align-items:flex-start}.result-status{display:inline-flex;align-items:center;border-radius:999px;padding:5px 10px;font-weight:950;font-size:12px;border:1px solid}.result-status.ok{color:#166534;background:#dcfce7;border-color:#86efac}.result-status.bad{color:#991b1b;background:#fee2e2;border-color:#fecaca}.result-choice{justify-content:space-between}.answer-tags{display:inline-flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.answer-tag{font-size:11px;font-weight:950;border-radius:999px;padding:3px 7px;border:1px solid}.answer-tag.yours{color:#075985;background:#e0f2fe;border-color:#7dd3fc}.answer-tag.correct-tag{color:#166534;background:#dcfce7;border-color:#86efac}.result-answer-line{display:flex;gap:10px;flex-wrap:wrap;margin-top:10px;color:#475569;font-size:13px}.result-explain-box{margin-top:12px;border:1px dashed #bae6fd;background:#f8fbff;border-radius:14px;padding:12px;display:flex;align-items:center;justify-content:space-between;gap:12px;color:#334155}.deep-explain-backdrop{z-index:3600!important}.deep-explain-modal{width:min(760px,94vw)!important;max-height:86vh!important;overflow:auto!important}.deep-explain-modal header{position:sticky;top:0;background:#fff;padding:12px 16px;border-bottom:1px dashed #e6eef2;display:flex;justify-content:space-between;gap:12px;align-items:center;z-index:2}.deep-explain-modal .body{padding:16px}.deep-question{border:1px solid #dbeafe;background:#f8fbff;border-radius:14px;padding:12px;margin-bottom:12px;color:#0f172a}.deep-content{color:#334155;line-height:1.7}.deep-text{white-space:normal;border:1px solid #dbeafe;background:#ffffff;border-radius:16px;padding:16px}.deep-notice{border:1px solid #fde68a;background:#fffbeb;color:#92400e;border-radius:12px;padding:10px 12px;margin-bottom:10px;font-size:13px;font-weight:800}
html[data-theme="dark"] .exam-step-card,html[data-theme="dark"] .exam-score-summary,html[data-theme="dark"] .deep-text{background:linear-gradient(180deg,#111827,#0b1220)!important;border-color:var(--kl-border)!important;color:#e5e7eb!important;box-shadow:0 20px 50px rgba(0,0,0,.36)!important}html[data-theme="dark"] .exam-step-question,html[data-theme="dark"] .score-info h3,html[data-theme="dark"] .score-ring span,html[data-theme="dark"] .deep-question{color:#f8fafc!important}html[data-theme="dark"] .exam-choice-btn{background:#0f172a!important;border-color:var(--kl-border)!important;color:#e5e7eb!important}html[data-theme="dark"] .exam-choice-btn:hover,html[data-theme="dark"] .exam-choice-btn:focus,html[data-theme="dark"] .exam-choice-btn.selected{background:#123047!important;border-color:#38bdf8!important}html[data-theme="dark"] .exam-loading,html[data-theme="dark"] .result-explain-box,html[data-theme="dark"] .deep-question{background:#0f172a!important;border-color:var(--kl-border)!important;color:#cbd5e1!important}html[data-theme="dark"] .exam-loading span,html[data-theme="dark"] .score-info p,html[data-theme="dark"] .result-answer-line,html[data-theme="dark"] .deep-content{color:#cbd5e1!important}html[data-theme="dark"] .deep-explain-modal header{background:#0b1220!important;border-color:var(--kl-border)!important}html[data-theme="dark"] .score-ring{box-shadow:inset 0 0 0 12px #0b1220!important}html[data-theme="dark"] .result-status.ok{color:#bbf7d0;background:rgba(34,197,94,.15);border-color:rgba(34,197,94,.45)}html[data-theme="dark"] .result-status.bad{color:#fecaca;background:rgba(239,68,68,.16);border-color:rgba(239,68,68,.45)}
@media(max-width:720px){.exam-score-summary{grid-template-columns:1fr;text-align:center}.score-ring{margin:auto}.result-explain-box{align-items:flex-start;flex-direction:column}.exam-step-question{font-size:18px}}

html[data-theme="dark"] .exam-number-input, html[data-theme="dark"] .difficulty-sel, html[data-theme="dark"] .style-sel{background:#0f172a;color:#e5eefb;border-color:#2b3b52}
html[data-theme="dark"] .kv .small{color:#cbd5e1}

/* Limpieza visual para estudiante y centrado estable del panel de examen */
.exam-setup-panel{
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
  justify-content:center!important;
  width:min(100%,1120px)!important;
  max-width:1120px!important;
  margin:4px auto 0!important;
  text-align:center!important;
}
.exam-unit-info{
  width:100%!important;
  max-width:920px!important;
  display:flex!important;
  flex-direction:column!important;
  align-items:center!important;
}
.exam-unit-title{
  width:100%!important;
  justify-content:center!important;
  text-align:center!important;
  overflow-wrap:anywhere!important;
}
.exam-unit-desc{
  max-width:760px!important;
  margin-left:auto!important;
  margin-right:auto!important;
}
.exam-probability-card{
  width:min(100%,760px)!important;
  margin:12px auto 0!important;
  text-align:left!important;
}
.exam-controls-interactive{
  width:min(100%,980px)!important;
  margin:16px auto 0!important;
  grid-template-columns:minmax(168px,210px) minmax(225px,1fr) minmax(225px,1fr) minmax(176px,auto)!important;
  justify-content:center!important;
  justify-items:stretch!important;
  align-items:stretch!important;
}
.exam-gen-actions{
  display:flex!important;
  align-items:stretch!important;
  justify-content:center!important;
}
.exam-gen-actions .btn{
  min-width:176px!important;
  width:100%!important;
  min-height:100%!important;
  padding-inline:18px!important;
}
.prob-label{
  font-size:12px!important;
  letter-spacing:.06em!important;
}
@media(max-width:1320px){
  .exam-setup-panel{max-width:980px!important;}
  .exam-controls-interactive{
    max-width:760px!important;
    grid-template-columns:repeat(2,minmax(230px,1fr))!important;
  }
  .exam-gen-actions{grid-column:1/-1!important;}
  .exam-gen-actions .btn{height:48px!important;min-height:48px!important;}
}
@media(max-width:720px){
  .exam-setup-panel{width:100%!important;padding:14px!important;}
  .exam-controls-interactive{grid-template-columns:1fr!important;max-width:100%!important;}
  .exam-probability-card{align-items:flex-start!important;}
  .exam-unit-title{font-size:16px!important;}
}


/* Ventana compacta para configurar el examen */
.exam-config-launch{
  width:min(100%,760px)!important;
  margin:14px auto 0!important;
  display:grid!important;
  grid-template-columns:minmax(0,1fr) auto!important;
  gap:14px!important;
  align-items:center!important;
  text-align:left!important;
  border:1px solid #dbeafe!important;
  border-radius:22px!important;
  padding:16px!important;
  background:linear-gradient(135deg,#ffffff,#f0f9ff 62%,#ecfeff)!important;
  box-shadow:0 16px 38px rgba(15,23,42,.08)!important;
}
.exam-config-kicker{display:flex;align-items:center;gap:7px;font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:950;color:#0284c7;margin-bottom:4px}.exam-config-title{font-size:18px;font-weight:950;color:#0f172a;letter-spacing:-.02em}.exam-config-text{margin-top:4px;color:#64748b;font-size:13px;line-height:1.35}.exam-config-actions{display:flex;flex-direction:column;align-items:flex-end;gap:10px}.exam-config-chips{display:flex;gap:6px;flex-wrap:wrap;justify-content:flex-end}.exam-config-chips span{display:inline-flex;align-items:center;gap:5px;border:1px solid #dbeafe;background:#f8fbff;color:#334155;border-radius:999px;padding:5px 8px;font-size:11px;font-weight:900}.open-exam-config-btn{min-height:46px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:8px!important;border-radius:14px!important;white-space:nowrap!important}
#examSetupBackdrop.is-open{display:flex!important}.exam-config-backdrop{z-index:2950!important}.exam-config-modal{display:block!important;position:relative!important;inset:auto!important;background:#fff;width:min(820px,94vw)!important;height:auto!important;max-height:90vh!important;overflow:auto!important;border-radius:22px!important;box-shadow:0 24px 70px rgba(2,6,23,.32)!important;margin:0!important;opacity:1!important;transform:none!important;pointer-events:auto!important}.exam-config-modal header{position:sticky;top:0;background:#fff;padding:14px 16px;border-bottom:1px dashed #e6eef2;display:flex;align-items:center;justify-content:space-between;gap:12px;z-index:2}.exam-config-modal .body{padding:16px}.exam-config-modal .foot{position:sticky;bottom:0;padding:13px 16px;border-top:1px dashed #e6eef2;background:#fafcff;display:flex;justify-content:space-between;align-items:center;gap:10px}.exam-config-modal-title{font-weight:950;color:#0b2545;font-size:18px}.exam-config-preview{display:flex;align-items:center;gap:12px;border:1px solid #dbeafe;background:linear-gradient(135deg,#f8fbff,#eef8ff);border-radius:18px;padding:12px;margin-bottom:14px}.exam-config-preview-icon{width:42px;height:42px;border-radius:15px;display:grid;place-items:center;background:#dbeafe;color:#1d4ed8;flex:0 0 auto}.exam-config-preview-title{font-weight:950;color:#0f172a;overflow-wrap:anywhere}.exam-modal-controls{width:100%!important;max-width:100%!important;margin:0!important;grid-template-columns:minmax(220px,.8fr) minmax(260px,1fr)!important;align-items:stretch!important}.exam-modal-controls .exam-field-questions{grid-row:span 2}.exam-modal-controls .difficulty-modal-card{grid-column:2}.exam-config-modal .exam-control-card{min-height:0!important}.exam-config-modal .exam-option-btn{min-height:66px!important}.exam-config-modal .exam-number-input{font-size:20px!important}.exam-config-modal .exam-quick-btn{height:36px!important}.exam-config-modal #examSetupGenerate{min-height:46px!important;border-radius:14px!important;display:inline-flex!important;gap:8px!important;align-items:center!important;justify-content:center!important;white-space:nowrap!important}
html[data-theme="dark"] .exam-config-launch,html[data-theme="dark"] .exam-config-preview{background:linear-gradient(135deg,#0f172a,#111827 62%,#0b2532)!important;border-color:var(--kl-border)!important;box-shadow:0 18px 42px rgba(0,0,0,.34)!important}html[data-theme="dark"] .exam-config-title,html[data-theme="dark"] .exam-config-preview-title{color:#f8fafc!important}html[data-theme="dark"] .exam-config-text{color:#cbd5e1!important}html[data-theme="dark"] .exam-config-chips span{background:#0b1220!important;border-color:#2b3b52!important;color:#dbeafe!important}html[data-theme="dark"] .exam-config-modal{background:#0b1220!important;color:#e5e7eb!important}html[data-theme="dark"] .exam-config-modal header,html[data-theme="dark"] .exam-config-modal .foot{background:#0b1220!important;border-color:var(--kl-border)!important}html[data-theme="dark"] .exam-config-modal-title{color:#f8fafc!important}html[data-theme="dark"] .exam-config-preview-icon{background:rgba(14,165,233,.16)!important;color:#67e8f9!important}
@media(max-width:760px){.exam-config-launch{grid-template-columns:1fr!important;text-align:center!important;padding:14px!important}.exam-config-actions{align-items:stretch!important}.exam-config-chips{justify-content:center!important}.open-exam-config-btn{width:100%!important}.exam-config-modal{width:94vw!important;max-height:88vh!important;border-radius:20px!important}.exam-config-modal header{padding:12px!important}.exam-config-modal .body{padding:12px!important}.exam-config-modal .foot{padding:12px!important;flex-direction:column!important;align-items:stretch!important}.exam-config-modal #examSetupGenerate{width:100%!important}.exam-modal-controls{grid-template-columns:1fr!important}.exam-modal-controls .exam-field-questions,.exam-modal-controls .difficulty-modal-card{grid-row:auto!important;grid-column:auto!important}.exam-config-preview{align-items:flex-start!important}.exam-config-modal-title{font-size:16px!important}}
@media(max-width:430px){.exam-config-chips span{font-size:10px;padding:4px 7px}.exam-config-title{font-size:16px}.exam-config-modal .exam-option-row{grid-template-columns:1fr!important}.exam-config-modal .exam-option-btn{min-height:50px!important;flex-direction:row!important;justify-content:flex-start!important;padding-inline:12px!important}.exam-config-modal .question-stepper{grid-template-columns:42px minmax(0,1fr) 42px!important}}


/* Optimización de modales, selección activa y cambio de tema */
html[data-theme="dark"] .exam-option-btn.is-active,
html[data-theme="dark"] .exam-option-btn.is-active:hover,
html[data-theme="dark"] .exam-option-btn.is-active:focus-visible{
  background:linear-gradient(135deg,#0ea5e9,#14b8a6)!important;
  color:#ffffff!important;
  border-color:rgba(125,211,252,.72)!important;
  box-shadow:0 14px 28px rgba(20,184,166,.24),0 0 0 2px rgba(103,232,249,.14)!important;
}
html[data-theme="dark"] .exam-option-btn.is-active i{
  color:#ffffff!important;
}
html[data-theme="dark"] .difficulty-options .exam-option-btn[data-exam-option="basico"].is-active{background:linear-gradient(135deg,#15803d,#22c55e)!important;border-color:rgba(134,239,172,.65)!important;box-shadow:0 14px 28px rgba(34,197,94,.20),0 0 0 2px rgba(134,239,172,.12)!important}
html[data-theme="dark"] .difficulty-options .exam-option-btn[data-exam-option="intermedio"].is-active{background:linear-gradient(135deg,#0ea5e9,#14b8a6)!important;border-color:rgba(125,211,252,.72)!important;box-shadow:0 14px 28px rgba(20,184,166,.24),0 0 0 2px rgba(103,232,249,.14)!important}
html[data-theme="dark"] .difficulty-options .exam-option-btn[data-exam-option="avanzado"].is-active{background:linear-gradient(135deg,#c2410c,#f97316)!important;border-color:rgba(251,146,60,.70)!important;box-shadow:0 14px 28px rgba(249,115,22,.22),0 0 0 2px rgba(251,146,60,.12)!important}
.modal-backdrop,
.exam-config-backdrop,
.deep-explain-backdrop{
  transition:opacity .12s ease!important;
  opacity:0;
  backdrop-filter:none!important;
}
.modal-backdrop.is-visible,
.exam-config-backdrop.is-visible,
.deep-explain-backdrop.is-visible{
  opacity:1;
}
#examBackdrop .exam-modal,
.exam-config-modal,
.deep-explain-modal{
  transform:translate3d(0,8px,0) scale(.985)!important;
  opacity:.96!important;
  will-change:transform,opacity;
  contain:layout paint;
  transition:transform .13s ease,opacity .13s ease!important;
}
#examBackdrop.is-visible .exam-modal,
.exam-config-backdrop.is-visible .exam-config-modal,
.deep-explain-backdrop.is-visible .deep-explain-modal{
  transform:translate3d(0,0,0) scale(1)!important;
  opacity:1!important;
}
.exam-step-card,
.exam-score-summary,
.result-question-card,
.exam-control-card{
  will-change:auto!important;
}
html.kl-theme-changing *,
html.kl-theme-changing *::before,
html.kl-theme-changing *::after{
  transition-duration:.08s!important;
  animation-duration:.08s!important;
}
@media(max-width:760px){
  #examBackdrop,
  #examSetupBackdrop,
  #deepExplainBackdrop{padding:8px!important;}
  #examBackdrop .exam-modal,
  .exam-config-modal,
  .deep-explain-modal{max-height:calc((var(--kl-vh,1vh) * 100) - 16px)!important;}
}

/* Ajustes finales solicitados: indicador de pregunta en modo oscuro y pie de configuración limpio */
html[data-theme="dark"] .exam-step-badge{
  background:linear-gradient(135deg,rgba(14,165,233,.22),rgba(15,23,42,.96))!important;
  border-color:rgba(103,232,249,.45)!important;
  color:#e0f2fe!important;
  box-shadow:0 10px 24px rgba(14,165,233,.16), inset 0 0 0 1px rgba(255,255,255,.04)!important;
}
html[data-theme="dark"] .exam-step-count{
  background:rgba(15,23,42,.92)!important;
  border-color:rgba(148,163,184,.28)!important;
  color:#cbd5e1!important;
}
.exam-config-modal .foot{justify-content:flex-end!important;}
@media(max-width:760px){.exam-config-modal .foot{align-items:stretch!important;}}

</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= escx($ctx['materia_nombre'] ?? 'Materia') ?></div>
    <div class="page-sub">Elige una unidad, revisa tus temas y genera tu examen predictivo.</div>
  </div>
  <div>
    <a class="btn inline" href="<?= escx(base_url($origin==='buscar'?'estudiantes/buscar_recurso.php':'estudiantes/index.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if (!$unidades): ?>
  <section class="card"><div style="color:#64748b;">Aún no hay unidades registradas.</div></section>
<?php else: ?>
  <section class="card" aria-label="Unidades">
    <div class="tabs-wrap" id="tabs" role="tablist">
      <?php foreach ($unidades as $i=>$u): ?>
        <?php
          $isActive = ((int)$u['unidad_id'] === (int)$focusUnidadId);
          $btnId = 'tab-'.(int)$u['unidad_id'];
          $paneId= 'panel-'.(int)$u['unidad_id'];
          $label = 'Unidad '.(int)$u['numero'].' — '.(string)($u['titulo'] ?: '—');
        ?>
        <button
          class="tab-btn<?= $isActive ? ' is-active' : '' ?> unit-tab"
          id="<?= escx($btnId) ?>"
          role="tab"
          aria-controls="<?= escx($paneId) ?>"
          aria-selected="<?= $isActive ? 'true' : 'false' ?>"
          tabindex="<?= $isActive ? '0' : '-1' ?>"
          data-target="<?= escx($paneId) ?>"
          data-label="<?= escx($label) ?>"
        >
          <?= 'Unidad '.(int)$u['numero'] ?>
        </button>
      <?php endforeach; ?>
    </div>
  </section>

  <?php foreach ($unidades as $i=>$u):
    $uid   = (int)$u['unidad_id'];
    $temas = $temasByUnidad[$uid] ?? [];
    $chunkCount = (int)($chunkStatsByUnit[$uid] ?? 0);
  ?>
    <section id="panel-<?= (int)$uid ?>" class="card unit-pane<?= ((int)$uid === (int)$focusUnidadId) ? ' show' : '' ?>" role="tabpanel" aria-labelledby="tab-<?= (int)$uid ?>">
      <div class="exam-setup-panel">
        <div class="exam-unit-info">
          <div class="exam-unit-title"><i class="fas fa-layer-group"></i> Unidad <?= (int)$u['numero'] ?> · <?= escx($u['titulo'] ?? '—') ?></div>
          <?php if (!empty($u['descripcion'])): ?>
            <div class="exam-unit-desc"><?= escx($u['descripcion']) ?></div>
          <?php endif; ?>
          <?php
            $probNivel = mb_strtolower((string)($probAprobacionMateria['nivel'] ?? 'sin'), 'UTF-8');
            $probNivelKey = str_replace(['á','é','í','ó','ú'], ['a','e','i','o','u'], $probNivel);
            if (!in_array($probNivelKey, ['alta','media','baja','critica'], true)) $probNivelKey = 'sin';
          ?>
          <div class="exam-probability-card" data-prob-card data-risk="<?= escx($probNivelKey) ?>">
            <div class="prob-icon"><i class="fas fa-chart-line"></i></div>
            <div class="prob-content">
              <div class="prob-label">Probabilidad de aprobar</div>
              <div class="prob-main">
                <?php if (!empty($probAprobacionMateria['hay_historial'])): ?>
                  Tienes <strong class="prob-value"><?= (int)$probAprobacionMateria['probabilidad'] ?>%</strong> de probabilidad de aprobar el siguiente examen de esta materia.
                <?php else: ?>
                  <strong class="prob-value">Aún no hay historial suficiente</strong> para mostrar una estimación personalizada.
                <?php endif; ?>
              </div>
              <div class="prob-detail">
                <?php if (!empty($probAprobacionMateria['hay_historial'])): ?>
                  Modelo Bayes: se actualiza una probabilidad previa con tus resultados, tendencia e intentos anteriores.
                <?php else: ?>
                  Realiza al menos un examen predictivo para que KnowLink pueda calcular una probabilidad posterior con Bayes.
                <?php endif; ?>
              </div>
            </div>
          </div>
        </div>

        <div class="exam-config-launch" aria-label="Generar examen predictivo">
          <div class="exam-config-copy">
            <div class="exam-config-kicker"><i class="fas fa-wand-magic-sparkles"></i> Examen predictivo</div>
            <div class="exam-config-title">Configura tu examen en una ventana compacta</div>
                      </div>
          <div class="exam-config-actions">
            <div class="exam-config-chips" aria-hidden="true">
              <span><i class="fas fa-list-ol"></i> Preguntas</span>
              <span><i class="fas fa-shuffle"></i> Tipo</span>
              <span><i class="fas fa-gauge-high"></i> Dificultad</span>
            </div>
            <button
              class="btn primary open-exam-config-btn"
              type="button"
              data-unidad="<?= $uid ?>"
              data-chunks="<?= $chunkCount ?>"
              data-unit-title="<?= escx('Unidad '.(int)$u['numero'].' · '.($u['titulo'] ?? '—')) ?>"
            >
              <i class="fas fa-sliders"></i> Configurar examen
            </button>
          </div>
        </div>
      </div>

      <div style="height:8px"></div>

      <?php if (!$temas): ?>
        <div style="color:#64748b;">Sin temas registrados en esta unidad.</div>
      <?php else: ?>
        <div style="display:flex;flex-direction:column;gap:12px;">
          <?php foreach ($temas as $t):
            $list  = $recByTema[(int)$t['id']] ?? [];
          ?>
            <div class="topic">
              <div class="topic-title" style="font-weight:800;margin-bottom:6px;"><?= escx($t['titulo']) ?></div>
              <?php if (!empty($t['descripcion'])): ?>
                <div class="meta" style="margin-bottom:8px;"><?= escx($t['descripcion']) ?></div>
              <?php endif; ?>

              <?php if (!$list): ?>
                <div style="color:#64748b;">No hay recursos publicados para este tema.</div>
              <?php else: ?>
                <ul class="cont-list" style="list-style:none;padding-left:0;display:flex;flex-direction:column;gap:8px;">
                  <?php foreach ($list as $c):
                    $cid    = (int)$c['contenido_id'];
                    $ctok   = mint_contenido_view_token($cid, [
                      'origin' => $origin,
                      'mode' => $mode,
                      'materia_clave' => (string)($ctx['materia_clave'] ?? ''),
                      'reticula_materia_id' => (int)($ctx['reticula_materia_id'] ?? 0),
                      'unidad_id' => $uid,
                    ]);
                    $likes  = (int)$c['likes'];
                    $mine   = ((int)$c['me_like'] === 1);
                    $doc    = trim(($c['docente_nombre'] ?? '').' '.($c['docente_apellidos'] ?? ''));
                    $viewAction = base_url('estudiantes/recurso.php');
                  ?>
                  <li class="cont-item" data-likes="<?= (int)$likes ?>" id="citem-<?= $cid ?>" style="border:1px dashed #e6eef2;border-radius:10px;padding:10px;">
                    <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap;">
                      <div class="meta" style="min-width:220px;">Docente: <strong><?= escx($doc) ?></strong></div>
                      <div style="display:flex;gap:8px;align-items:center;">
                        <button
                          class="btn like<?= $mine ? ' liked':'' ?>"
                          type="button"
                          data-cid="<?= $cid ?>"
                          aria-pressed="<?= $mine ? 'true' : 'false' ?>"
                          title="<?= $mine ? 'Quitar recomendación' : 'Recomendar' ?>"
                        >
                          <i class="fas fa-thumbs-up"></i>
                          <span class="count" id="lkc-<?= $cid ?>"><?= (int)$likes ?></span>
                        </button>
                        <form class="inline" method="post" action="<?= escx($viewAction) ?>">
                          <input type="hidden" name="csrf" value="<?= escx($CSRF) ?>">
                          <input type="hidden" name="token" value="<?= escx($ctok) ?>">
                          <input type="hidden" name="origin" value="<?= escx($origin) ?>">
                          <button class="btn primary" type="submit">
                            <i class="fas fa-folder-open"></i> <span class="label">Ver recursos</span>
                          </button>
                        </form>
                      </div>
                    </div>
                  </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </div>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </section>
  <?php endforeach; ?>

  <div id="examSetupBackdrop" class="modal-backdrop exam-config-backdrop" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal exam-config-modal" role="document" aria-labelledby="examSetupTitle">
      <header>
        <div>
          <div class="exam-config-kicker"><i class="fas fa-sliders"></i> Configuración del examen</div>
          <div id="examSetupTitle" class="exam-config-modal-title">Preparar examen predictivo</div>
        </div>
        <button id="examSetupClose" class="btn ghost modal-close-x" type="button" aria-label="Cerrar configuración"><i class="fas fa-xmark"></i></button>
      </header>
      <div class="body">
        <div class="exam-config-preview">
          <div class="exam-config-preview-icon"><i class="fas fa-layer-group"></i></div>
          <div>
            <div class="small">Unidad que se usará</div>
            <div id="examSetupUnit" class="exam-config-preview-title">Selecciona una unidad</div>
          </div>
        </div>

        <div class="exam-controls-grid kv exam-controls-interactive exam-modal-controls" aria-label="Opciones del examen">
          <div class="exam-field exam-control-card exam-field-questions">
            <label for="setup-qsel">Número de preguntas <span class="field-hint">1 a 50</span></label>
            <div class="question-stepper" aria-label="Número de preguntas">
              <button type="button" class="exam-step-btn" data-step="-1" data-unidad="setup" aria-label="Disminuir preguntas"><i class="fas fa-minus"></i></button>
              <input id="setup-qsel" class="select qsel exam-number-input" data-unidad="setup" type="number" min="1" max="50" step="1" value="5" inputmode="numeric" title="Puedes elegir de 1 a 50 preguntas">
              <button type="button" class="exam-step-btn" data-step="1" data-unidad="setup" aria-label="Aumentar preguntas"><i class="fas fa-plus"></i></button>
            </div>
            <div class="exam-quick-buttons" aria-label="Atajos de número de preguntas">
              <button type="button" class="exam-quick-btn is-active" data-value="5" data-unidad="setup">5</button>
              <button type="button" class="exam-quick-btn" data-value="10" data-unidad="setup">10</button>
              <button type="button" class="exam-quick-btn" data-value="15" data-unidad="setup">15</button>
              <button type="button" class="exam-quick-btn" data-value="20" data-unidad="setup">20</button>
            </div>
          </div>
          <div class="exam-field exam-control-card">
            <label for="setup-style">Tipo de examen</label>
            <select id="setup-style" class="select style-sel exam-native-select" data-unidad="setup" aria-label="Tipo de examen">
              <option value="mixto">Mixto</option>
              <option value="teorico">Teórico</option>
              <option value="practico">Práctico</option>
            </select>
            <div class="exam-option-row" role="group" aria-label="Tipo de examen">
              <button type="button" class="exam-option-btn is-active" data-select="#setup-style" data-unidad="setup" data-exam-option="mixto"><i class="fas fa-shuffle"></i><span>Mixto</span></button>
              <button type="button" class="exam-option-btn" data-select="#setup-style" data-unidad="setup" data-exam-option="teorico"><i class="fas fa-book-open"></i><span>Teórico</span></button>
              <button type="button" class="exam-option-btn" data-select="#setup-style" data-unidad="setup" data-exam-option="practico"><i class="fas fa-screwdriver-wrench"></i><span>Práctico</span></button>
            </div>
          </div>
          <div class="exam-field exam-control-card difficulty-modal-card">
            <label for="setup-difficulty">Dificultad</label>
            <select id="setup-difficulty" class="select difficulty-sel exam-native-select" data-unidad="setup" aria-label="Dificultad del examen">
              <option value="basico">Básico</option>
              <option value="intermedio" selected>Intermedio</option>
              <option value="avanzado">Avanzado</option>
            </select>
            <div class="exam-option-row difficulty-options" role="group" aria-label="Dificultad del examen">
              <button type="button" class="exam-option-btn" data-select="#setup-difficulty" data-unidad="setup" data-exam-option="basico"><i class="fas fa-seedling"></i><span>Básico</span></button>
              <button type="button" class="exam-option-btn is-active" data-select="#setup-difficulty" data-unidad="setup" data-exam-option="intermedio"><i class="fas fa-bolt"></i><span>Intermedio</span></button>
              <button type="button" class="exam-option-btn" data-select="#setup-difficulty" data-unidad="setup" data-exam-option="avanzado"><i class="fas fa-fire"></i><span>Avanzado</span></button>
            </div>
          </div>
        </div>
      </div>
      <div class="foot">
        <button id="examSetupGenerate" class="btn primary" type="button"><i class="fas fa-vial"></i> Generar examen</button>
      </div>
    </div>
  </div>

  <div id="examBackdrop" class="modal-backdrop" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal exam-modal" role="document" aria-labelledby="examTitle">
      <header>
        <div style="font-weight:900;color:#0b2545;"><i class="fas fa-vial"></i> <span id="examTitle">Examen predictivo</span></div>
        <div id="examMeta" class="small" style="margin-left:auto;"></div>
        <button id="examClose" class="btn ghost modal-close-x" type="button" aria-label="Cerrar ventana"><i class="fas fa-xmark"></i></button>
      </header>
      <div class="body">
        <div id="examAlert" class="alert hidden"></div>
        <div id="examStatus" class="small">Selecciona una unidad y genera un examen.</div>
        <div class="progress" aria-hidden="true"><div id="examBar"></div></div>
        <div id="examBox" style="margin-top:12px;"></div>
      </div>
      <div class="foot">
        <div id="examScore" class="meta"></div>
        <div style="display:flex; gap:8px; align-items:center;">
          <button id="btnNewExam" class="btn hidden"><i class="fas fa-arrows-rotate"></i> Nuevo intento</button>
        </div>
      </div>
    </div>
  </div>

  <div id="deepExplainBackdrop" class="modal-backdrop deep-explain-backdrop" role="dialog" aria-modal="true" aria-hidden="true">
    <div class="modal deep-explain-modal" role="document" aria-labelledby="deepExplainTitle">
      <header>
        <div style="font-weight:900;color:#0b2545;"><i class="fas fa-brain"></i> <span id="deepExplainTitle">Explicación más profunda</span></div>
        <button id="deepExplainClose" class="btn ghost"><i class="fas fa-arrow-left"></i> Volver a resultados</button>
      </header>
      <div class="body">
        <div id="deepExplainQuestion" class="deep-question"></div>
        <div id="deepExplainContent" class="deep-content">Preparando explicación…</div>
      </div>
    </div>
  </div>

  <script>
  (function(){
    const tabs = Array.from(document.querySelectorAll('.tab-btn'));
    const panes = Array.from(document.querySelectorAll('.unit-pane'));
    const examBackdrop = document.getElementById('examBackdrop');
    const examSetupBackdrop = document.getElementById('examSetupBackdrop');
    const examSetupClose = document.getElementById('examSetupClose');
    const examSetupGenerate = document.getElementById('examSetupGenerate');
    const examSetupUnit = document.getElementById('examSetupUnit');
    const setupQsel = document.getElementById('setup-qsel');
    const setupStyle = document.getElementById('setup-style');
    const setupDifficulty = document.getElementById('setup-difficulty');
    const deepExplainBackdrop = document.getElementById('deepExplainBackdrop');
    const deepExplainTitle = document.getElementById('deepExplainTitle');
    const deepExplainQuestion = document.getElementById('deepExplainQuestion');
    const deepExplainContent = document.getElementById('deepExplainContent');
    const examTitle = document.getElementById('examTitle');
    const examMeta = document.getElementById('examMeta');
    const examStatus = document.getElementById('examStatus');
    const examAlert = document.getElementById('examAlert');
    const examBox = document.getElementById('examBox');
    const examBar = document.getElementById('examBar');
    const examScore = document.getElementById('examScore');
    const btnNewExam = document.getElementById('btnNewExam');
    const btnClose = document.getElementById('examClose');
    const btnDeepClose = document.getElementById('deepExplainClose');

    let currentExam = null;
    let setupUnitId = null;
    let setupUnitTitle = '';
    let currentUnitId = null;
    let currentStyle = 'mixto';
    let currentDifficulty = 'intermedio';
    let currentN = 5;
    let currentQuestionIndex = 0;
    let examAnswers = {};
    let latestResult = null;
    let isGeneratingExam = false;
    let isSubmittingExam = false;

    const CSRF = <?= json_encode($CSRF, JSON_UNESCAPED_UNICODE) ?>;

    async function postExamJson(payload, retries = 1){
      let lastError = null;
      for (let attempt = 0; attempt <= retries; attempt++) {
        try {
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), payload.ajax === 'gen_exam' ? 20000 : 20000);
          const res = await fetch('?ajax=' + encodeURIComponent(payload.ajax || ''), {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Accept': 'application/json',
              'X-Requested-With': 'XMLHttpRequest'
            },
            body: JSON.stringify(payload),
            signal: controller.signal,
            cache: 'no-store'
          });
          clearTimeout(timeout);
          const raw = await res.text();
          let data = null;
          try { data = JSON.parse(raw); }
          catch (parseError) {
            const clean = raw.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
            throw new Error(clean ? clean.slice(0, 280) : 'El servidor devolvió una respuesta inválida.');
          }
          if (!res.ok && data && !data.ok) {
            throw new Error(data.detail || data.err || 'Error del servidor.');
          }
          return data;
        } catch (err) {
          lastError = err;
          if (attempt < retries) {
            await new Promise(resolve => setTimeout(resolve, 650));
            continue;
          }
        }
      }
      throw lastError || new Error('No fue posible conectar con el servidor.');
    }

    function setAlert(message, isError=false){
      if (!message) {
        examAlert.classList.add('hidden');
        examAlert.textContent = '';
        examAlert.classList.remove('error');
        return;
      }
      examAlert.textContent = message;
      examAlert.classList.remove('hidden');
      examAlert.classList.toggle('error', !!isError);
    }
    function escapeHtml(s){
      return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
    }
    function difficultyLabel(value){
      if (value === 'basico') return 'Básico';
      if (value === 'avanzado') return 'Avanzado';
      return 'Intermedio';
    }
    function choiceText(detail, letter){
      const idx = letter ? (String(letter).charCodeAt(0) - 65) : -1;
      return (idx >= 0 && detail.choices && detail.choices[idx]) ? detail.choices[idx] : '';
    }
    function riskKey(prob){
      if (!prob || !prob.hay_historial) return 'sin';
      const nivel = String(prob.nivel || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
      return ['alta','media','baja','critica'].includes(nivel) ? nivel : 'sin';
    }
    function probabilitySummary(prob){
      if (!prob || !prob.hay_historial) return 'Probabilidad: sin historial suficiente';
      return 'Probabilidad Bayes: ' + prob.probabilidad + '%';
    }
    function updateProbabilityCards(prob){
      if (!prob) return;
      document.querySelectorAll('[data-prob-card]').forEach(card=>{
        card.dataset.risk = riskKey(prob);
        const main = card.querySelector('.prob-main');
        const detail = card.querySelector('.prob-detail');
        const badge = card.querySelector('.prob-badge-text');
        if (main) {
          main.innerHTML = prob.hay_historial
            ? 'Tienes <strong class="prob-value">' + escapeHtml(prob.probabilidad) + '%</strong> de probabilidad de aprobar el siguiente examen de esta materia.'
            : '<strong class="prob-value">Sin historial suficiente</strong> para estimar tu probabilidad en esta materia.';
        }
        if (detail) {
          detail.textContent = prob.hay_historial
            ? 'Teorema de Bayes: probabilidad previa ' + (prob.prior || '—') + '%, actualizada con ' + prob.intentos_usados + ' intento(s), promedio ' + prob.promedio + '% y último resultado ' + prob.ultimo_porcentaje + '%.'
            : (prob.mensaje || 'Realiza al menos un examen predictivo para obtener una estimación personalizada con Bayes.');
        }
        if (badge) badge.textContent = prob.nivel || 'Sin historial';
      });
    }
    function resetExamUI(){
      currentExam = null;
      currentQuestionIndex = 0;
      examAnswers = {};
      latestResult = null;
      examTitle.textContent = 'Examen predictivo';
      examMeta.textContent = '';
      examStatus.textContent = 'Preparando…';
      examBox.innerHTML = '';
      examScore.textContent = '';
      examBar.style.width = '0%';
      btnNewExam.classList.add('hidden');
      setAlert('');
    }
    function openSetupModal(btn){
      setupUnitId = parseInt(btn.getAttribute('data-unidad') || '0', 10);
      setupUnitTitle = btn.getAttribute('data-unit-title') || 'Unidad seleccionada';
      if (examSetupUnit) examSetupUnit.textContent = setupUnitTitle;
      if (setupQsel) clampQuestionInput(setupQsel, setupQsel.value || '5');
      if (setupStyle) syncOptionButtons(setupStyle);
      if (setupDifficulty) syncOptionButtons(setupDifficulty);
      clearFloatingTooltips();
      setModalState(examSetupBackdrop, true);
      document.body.classList.add('exam-modal-open');
      requestAnimationFrame(()=>{ if (setupQsel) setupQsel.focus({preventScroll:true}); });
    }
    function clearFloatingTooltips(){
      try {
        document.querySelectorAll('.tooltip,.popover').forEach(el=>el.remove());
        if (window.bootstrap && window.bootstrap.Tooltip) {
          document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(el=>{
            const instance = window.bootstrap.Tooltip.getInstance(el);
            if (instance) instance.hide();
          });
        }
      } catch(e) {}
    }
    function setModalState(backdrop, open){
      if (!backdrop) return;
      backdrop.classList.toggle('is-open', !!open);
      backdrop.setAttribute('aria-hidden', open ? 'false' : 'true');
      if (open) {
        backdrop.style.display = 'flex';
        requestAnimationFrame(()=>backdrop.classList.add('is-visible'));
      } else {
        backdrop.classList.remove('is-visible');
        window.setTimeout(()=>{
          if (!backdrop.classList.contains('is-open')) backdrop.style.display = 'none';
        }, 130);
      }
    }
    function closeSetupModal(){
      clearFloatingTooltips();
      setModalState(examSetupBackdrop, false);
      document.body.classList.remove('exam-modal-open');
    }

    function openModal(){
      setModalState(examBackdrop, true);
      document.body.classList.add('exam-modal-open');
    }
    function closeModal(){
      clearFloatingTooltips();
      closeDeepExplanation();
      setModalState(examBackdrop, false);
      document.body.classList.remove('exam-modal-open');
      window.setTimeout(resetExamUI, 140);
    }
    function openDeepExplanation(){
      setModalState(deepExplainBackdrop, true);
    }
    function closeDeepExplanation(){
      if (!deepExplainBackdrop) return;
      clearFloatingTooltips();
      setModalState(deepExplainBackdrop, false);
    }

    function activate(btn){
      const target = btn.getAttribute('data-target');
      const label = btn.getAttribute('data-label') || btn.textContent.trim();
      tabs.forEach(b=>{ b.classList.remove('is-active'); b.setAttribute('aria-selected','false'); b.setAttribute('tabindex','-1'); });
      panes.forEach(p=>p.classList.remove('show'));
      btn.classList.add('is-active');
      btn.setAttribute('aria-selected','true');
      btn.setAttribute('tabindex','0');
      const pane = document.getElementById(target);
      if (pane) pane.classList.add('show');
    }
    if (tabs[0]) activate(tabs[0]);
    tabs.forEach((b, idx)=>{
      b.addEventListener('click', ()=>activate(b));
      b.addEventListener('keydown', (e)=>{
        if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
          e.preventDefault();
          const dir = e.key === 'ArrowRight' ? 1 : -1;
          const next = tabs[(idx + dir + tabs.length) % tabs.length];
          next.focus(); activate(next);
        }
      });
    });

    function reorderList(ul){
      const items = Array.from(ul.querySelectorAll('.cont-item'));
      items.sort((a,b)=> (parseInt(b.dataset.likes || '0', 10) - parseInt(a.dataset.likes || '0', 10)));
      items.forEach(li => ul.appendChild(li));
    }
    document.querySelectorAll('.btn.like[data-cid]').forEach(btn=>{
      btn.addEventListener('click', async ()=>{
        const cid = btn.getAttribute('data-cid');
        try {
          const res = await fetch('?ajax=toggle_like', {
            method: 'POST',
            headers: {'Content-Type':'application/json'},
            body: JSON.stringify({ajax:'toggle_like', csrf: CSRF, contenido_id: parseInt(cid, 10)})
          });
          const j = await res.json();
          if (!j.ok) return;
          const cntEl = document.getElementById('lkc-' + cid);
          if (cntEl) cntEl.textContent = String(j.likes ?? 0);
          const li = document.getElementById('citem-' + cid);
          if (li) {
            li.dataset.likes = String(j.likes ?? 0);
            const ul = li.closest('.cont-list');
            if (ul) reorderList(ul);
          }
          const liked = !!j.liked;
          btn.classList.toggle('liked', liked);
          btn.setAttribute('aria-pressed', liked ? 'true' : 'false');
        } catch (e) {}
      });
    });

    function renderExam(exam, meta){
      currentExam = exam;
      currentQuestionIndex = 0;
      examAnswers = {};
      latestResult = null;
      const total = exam.questions?.length || 0;
      examTitle.textContent = exam.title || 'Examen predictivo';
      const diffLabel = exam.difficulty_label || difficultyLabel(currentDifficulty);
      const probMeta = probabilitySummary(exam.probability_before || null);
      examMeta.textContent = 'Unidad ' + (exam.unit?.numero ?? '') + ' · ' + (exam.unit?.titulo ?? '') + ' · ' + (exam.unit?.materia?.nombre ?? '') + ' · ' + diffLabel + ' · ' + probMeta;
      examScore.textContent = total + ' pregunta(s)';
      btnNewExam.classList.remove('hidden');
      setAlert('');
      renderCurrentQuestion();
    }

    function renderCurrentQuestion(){
      if (!currentExam) return;
      const questions = currentExam.questions || [];
      const total = questions.length;
      if (!total) {
        examStatus.textContent = 'No hay preguntas disponibles.';
        examBox.innerHTML = '<div class="alert error">No se encontraron preguntas para mostrar.</div>';
        return;
      }
      if (currentQuestionIndex >= total) {
        submitExam();
        return;
      }
      const q = questions[currentQuestionIndex];
      const num = currentQuestionIndex + 1;
      const pct = Math.round(((currentQuestionIndex) / total) * 100);
      examStatus.textContent = 'Pregunta ' + num + ' de ' + total;
      examBar.style.width = Math.max(8, pct) + '%';
      examScore.textContent = 'Avance: ' + (currentQuestionIndex) + '/' + total;
      examBox.innerHTML = '';

      const card = document.createElement('div');
      card.className = 'exam-step-card';
      card.innerHTML =
        '<div class="exam-step-head">' +
          '<span class="exam-step-badge">Pregunta ' + num + '</span>' +
          '<span class="exam-step-count">' + num + ' / ' + total + '</span>' +
        '</div>' +
        '<div class="exam-step-question">' + escapeHtml(q.question) + '</div>';

      const choices = document.createElement('div');
      choices.className = 'exam-step-choices';
      (q.choices || []).forEach((choice, cIdx)=>{
        const letter = String.fromCharCode(65 + cIdx);
        const btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'exam-choice-btn';
        btn.dataset.letter = letter;
        btn.innerHTML = '<span class="letter">' + letter + '</span><span>' + escapeHtml(choice) + '</span>';
        btn.addEventListener('click', ()=>selectAnswer(q.id, letter, btn));
        choices.appendChild(btn);
      });
      card.appendChild(choices);
      const help = document.createElement('div');
      help.className = 'small exam-step-help';
      help.textContent = 'Selecciona una respuesta para avanzar automáticamente.';
      card.appendChild(help);
      examBox.appendChild(card);
    }

    function selectAnswer(questionId, letter, btn){
      if (!currentExam) return;
      examAnswers[questionId] = letter;
      const buttons = Array.from(document.querySelectorAll('.exam-choice-btn'));
      buttons.forEach(b=>{ b.disabled = true; b.classList.toggle('selected', b === btn); });
      const total = currentExam.questions?.length || 0;
      examScore.textContent = 'Avance: ' + Math.min(currentQuestionIndex + 1, total) + '/' + total;
      examBar.style.width = Math.round(((currentQuestionIndex + 1) / Math.max(1,total)) * 100) + '%';
      setTimeout(()=>{
        currentQuestionIndex++;
        if (currentQuestionIndex >= total) submitExam();
        else renderCurrentQuestion();
      }, 320);
    }

    async function generateExam(unidadId, n, style, difficulty){
      if (isGeneratingExam) return;
      isGeneratingExam = true;
      if (examSetupGenerate) examSetupGenerate.disabled = true;
      openModal();
      resetExamUI();
      currentUnitId = unidadId;
      currentStyle = style;
      currentDifficulty = difficulty || 'intermedio';
      currentN = n;
      examStatus.textContent = 'Generando examen…';
      examBar.style.width = '12%';
      examBox.innerHTML = '<div class="exam-loading"><i class="fas fa-spinner fa-spin"></i><strong>Generando preguntas…</strong><span>Preparando ' + n + ' pregunta(s) de nivel ' + difficultyLabel(currentDifficulty) + '.</span></div>';

      try {
        const j = await postExamJson({ajax:'gen_exam', csrf: CSRF, unidad_id: unidadId, n: n, style: style, difficulty: currentDifficulty}, 0);
        if (!j.ok) {
          examStatus.textContent = 'No se pudo generar el examen.';
          examBar.style.width = '0%';
          examBox.innerHTML = '';
          setAlert(j.detail || 'No hay preguntas disponibles.', true);
          btnNewExam.classList.remove('hidden');
          return;
        }
        if (j.exam) j.exam.probability_before = j.probability_before || null;
        examBar.style.width = '20%';
        renderExam(j.exam, j.meta || null);
      } catch (e) {
        examStatus.textContent = 'Error del servidor.';
        examBox.innerHTML = '';
        const msg = (e && e.message ? e.message : 'No fue posible conectar con el servidor.').toString();
        setAlert(msg, true);
        btnNewExam.classList.remove('hidden');
      } finally {
        isGeneratingExam = false;
        if (examSetupGenerate) examSetupGenerate.disabled = false;
      }
    }

    async function submitExam(){
      if (!currentExam || isSubmittingExam) return;
      isSubmittingExam = true;
      const answers = {...examAnswers};
      const total = (currentExam.questions || []).length;
      const answered = Object.keys(answers).length;
      if (answered < total) {
        setAlert('Faltan respuestas por registrar.', true);
        isSubmittingExam = false;
        return;
      }
      examStatus.textContent = 'Calificando…';
      examBar.style.width = '100%';
      examBox.innerHTML = '<div class="exam-loading"><i class="fas fa-circle-notch fa-spin"></i><strong>Calificando tu examen…</strong><span>Estamos preparando tu resultado.</span></div>';
      setAlert('');

      try {
        const j = await postExamJson({ajax:'submit_exam', csrf: CSRF, exam_id: currentExam.id, answers: answers}, 1);
        if (!j.ok) {
          setAlert(j.detail || 'No se pudo calificar el examen.', true);
          return;
        }
        latestResult = {details:j.details || [], aciertos:j.aciertos || 0, errores:j.errores || 0, porcentaje:Number(j.porcentaje || 0), nextProbability:j.next_probability || null};
        if (latestResult.nextProbability) updateProbabilityCards(latestResult.nextProbability);
        renderScoreSummary(latestResult);
      } catch (e) {
        setAlert((e && e.message ? e.message : 'Error al enviar el examen. Revisa tu conexión o vuelve a intentar.'), true);
      } finally {
        isSubmittingExam = false;
      }
    }

    function renderScoreSummary(result){
      const total = result.details.length || 0;
      const pct = Number(result.porcentaje || 0);
      const approved = pct >= 70;
      examTitle.textContent = 'Calificación del examen';
      examStatus.textContent = approved ? 'Aprobado' : 'Necesitas estudiar un poco más';
      examBar.style.width = '100%';
      examScore.innerHTML = '<strong>' + result.aciertos + '/' + total + '</strong> correctas · ' + pct + '%';
      examBox.innerHTML = '';

      const summary = document.createElement('div');
      summary.className = 'exam-score-summary ' + (approved ? 'approved' : 'study');
      summary.innerHTML =
        '<div class="score-ring" style="--score:' + Math.max(0, Math.min(100, pct)) + '%"><span>' + pct + '%</span></div>' +
        '<div class="score-info">' +
          '<div class="score-kicker">Resultado del intento</div>' +
          '<h3>' + (approved ? 'Aprobado' : 'Necesitas estudiar un poco más') + '</h3>' +
          '<p>' + (approved ? 'Buen trabajo. Alcanzaste el promedio necesario para aprobar.' : 'No pasa nada, revisa tus errores y vuelve a intentarlo después de estudiar los temas marcados.') + '</p>' +
          (result.nextProbability ? '<p><strong>' + escapeHtml(probabilitySummary(result.nextProbability)) + '</strong></p>' : '') +
          '<div class="score-actions"><button type="button" class="btn primary" id="btnGoResults"><i class="fas fa-list-check"></i> Ir a resultados</button></div>' +
        '</div>';
      examBox.appendChild(summary);
      const btnGo = document.getElementById('btnGoResults');
      if (btnGo) btnGo.addEventListener('click', ()=>renderResults(result.details, result.aciertos, pct));
    }

    function renderResults(details, aciertos, porcentaje){
      examTitle.textContent = 'Resultados detallados';
      examStatus.textContent = 'Revisa cada pregunta, tu respuesta y la respuesta correcta.';
      examBar.style.width = '100%';
      examScore.innerHTML = '<strong>' + aciertos + '/' + details.length + '</strong> correctas · ' + porcentaje + '%';
      examBox.innerHTML = '';

      const top = document.createElement('div');
      top.className = 'result-card result-overview';
      top.innerHTML =
        '<div><div class="qtitle">Resumen</div><div class="meta">Tu calificación fue <strong>' + porcentaje + '%</strong>. Las respuestas correctas aparecen en verde y tus errores en rojo.</div></div>' +
        '<button type="button" class="btn" id="btnBackScore"><i class="fas fa-arrow-left"></i> Ver calificación</button>';
      examBox.appendChild(top);
      const back = document.getElementById('btnBackScore');
      if (back && latestResult) back.addEventListener('click', ()=>renderScoreSummary(latestResult));

      const wrap = document.createElement('div');
      wrap.className = 'exam-grid results-list';

      details.forEach(d=>{
        const ok = d.selected === d.correct;
        const card = document.createElement('div');
        card.className = 'qcard result-question-card ' + (ok ? 'is-correct' : 'is-wrong');
        card.innerHTML =
          '<div class="result-question-head">' +
            '<div class="qtitle">Pregunta ' + d.orden + ': ' + escapeHtml(d.question) + '</div>' +
            '<span class="result-status ' + (ok ? 'ok' : 'bad') + '">' + (ok ? 'Correcta' : 'Incorrecta') + '</span>' +
          '</div>';

        const choices = document.createElement('div');
        choices.className = 'choices';
        (d.choices || []).forEach((choice, idx)=>{
          const letter = String.fromCharCode(65 + idx);
          const row = document.createElement('div');
          row.className = 'choice-label result-choice';
          if (letter === d.correct) row.classList.add('correct');
          if (d.selected === letter && d.selected !== d.correct) row.classList.add('wrong');
          if (d.selected === letter) row.classList.add('selected-choice');
          const tags = [];
          if (d.selected === letter) tags.push('<span class="answer-tag yours">Tu respuesta</span>');
          if (d.correct === letter) tags.push('<span class="answer-tag correct-tag">Correcta</span>');
          row.innerHTML = '<span><strong>' + letter + '.</strong> ' + escapeHtml(choice) + '</span><span class="answer-tags">' + tags.join('') + '</span>';
          choices.appendChild(row);
        });
        card.appendChild(choices);

        const selectedText = d.selected ? choiceText(d, d.selected) : 'Sin responder';
        const correctText = choiceText(d, d.correct);
        const info = document.createElement('div');
        info.className = 'result-answer-line';
        info.innerHTML =
          '<span>Tu respuesta: <strong>' + escapeHtml(d.selected || 'Sin responder') + '</strong> ' + (d.selected ? '(' + escapeHtml(selectedText) + ')' : '') + '</span>' +
          '<span>Correcta: <strong>' + escapeHtml(d.correct) + '</strong> (' + escapeHtml(correctText) + ')</span>';
        card.appendChild(info);

        const exp = document.createElement('div');
        exp.className = 'result-explain-box';
        exp.innerHTML =
          '<div><strong>Explicación breve:</strong> ' + escapeHtml(d.explanation || 'Sin explicación breve guardada.') + '</div>' +
          '<button type="button" class="btn ghost btn-deep-explain"><i class="fas fa-brain"></i> Explicación más profunda</button>';
        exp.querySelector('.btn-deep-explain').addEventListener('click', ()=>requestDeepExplanation(d));
        card.appendChild(exp);

        wrap.appendChild(card);
      });

      examBox.appendChild(wrap);
    }

    async function requestDeepExplanation(detail){
      if (!currentExam || !detail) return;
      openDeepExplanation();
      deepExplainTitle.textContent = 'Explicación · Pregunta ' + detail.orden;
      deepExplainQuestion.innerHTML = '<strong>Pregunta:</strong> ' + escapeHtml(detail.question);
      deepExplainContent.innerHTML = '<div class="exam-loading"><i class="fas fa-spinner fa-spin"></i><strong>Generando explicación con IA…</strong><span>Esto puede tardar unos segundos.</span></div>';

      try {
        const res = await fetch('?ajax=deep_explain', {
          method: 'POST',
          headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ajax:'deep_explain', csrf: CSRF, exam_id: currentExam.id, question_id: detail.question_id, selected: detail.selected || ''})
        });
        const j = await res.json();
        if (!j.ok) {
          deepExplainContent.innerHTML = '<div class="alert error">No se pudo generar la explicación.</div>';
          return;
        }
        const notice = '';
        deepExplainContent.innerHTML = notice + '<div class="deep-text">' + escapeHtml(j.explanation || 'Sin explicación disponible.').replace(/\n/g, '<br>') + '</div>';
      } catch (e) {
        deepExplainContent.innerHTML = '<div class="alert error">Error de red al solicitar la explicación.</div>';
      }
    }

    btnNewExam.addEventListener('click', ()=>{
      if (!currentUnitId) return;
      generateExam(currentUnitId, currentN, currentStyle, currentDifficulty);
    });
    btnClose.addEventListener('click', closeModal);
    btnDeepClose.addEventListener('click', closeDeepExplanation);
    if (examSetupClose) examSetupClose.addEventListener('click', closeSetupModal);
    if (examSetupBackdrop) examSetupBackdrop.addEventListener('click', (e)=>{ if (e.target === examSetupBackdrop) closeSetupModal(); });
    deepExplainBackdrop.addEventListener('click', (e)=>{ if (e.target === deepExplainBackdrop) closeDeepExplanation(); });
    examBackdrop.addEventListener('click', (e)=>{ if (e.target === examBackdrop) closeModal(); });
    document.addEventListener('keydown', (e)=>{
      if (e.key === 'Escape') {
        if (deepExplainBackdrop.getAttribute('aria-hidden') === 'false') closeDeepExplanation();
        else if (examBackdrop.getAttribute('aria-hidden') === 'false') closeModal();
        else if (examSetupBackdrop && examSetupBackdrop.getAttribute('aria-hidden') === 'false') closeSetupModal();
      }
    });

    function clampQuestionInput(input, value){
      if (!input) return 5;
      const min = parseInt(input.getAttribute('min') || '1', 10);
      const max = parseInt(input.getAttribute('max') || '50', 10);
      let next = parseInt(value, 10);
      if (!Number.isFinite(next)) next = parseInt(input.value || '5', 10);
      if (!Number.isFinite(next)) next = 5;
      next = Math.max(min, Math.min(max, next));
      input.value = String(next);
      updateQuestionQuickState(input);
      return next;
    }
    function updateQuestionQuickState(input){
      if (!input) return;
      const unidadId = input.getAttribute('data-unidad');
      const value = String(parseInt(input.value || '0', 10));
      document.querySelectorAll('.exam-quick-btn[data-unidad="' + unidadId + '"]').forEach(btn=>{
        btn.classList.toggle('is-active', btn.getAttribute('data-value') === value);
      });
    }
    function syncOptionButtons(select){
      if (!select) return;
      const safeId = (window.CSS && CSS.escape) ? CSS.escape(select.id) : String(select.id).replace(/[^a-zA-Z0-9_-]/g, '\\$&');
      const selector = '#' + safeId;
      document.querySelectorAll('.exam-option-btn[data-select="' + selector + '"]').forEach(btn=>{
        btn.classList.toggle('is-active', btn.getAttribute('data-exam-option') === select.value);
      });
    }
    document.querySelectorAll('.exam-step-btn[data-unidad]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const unidadId = btn.getAttribute('data-unidad');
        const input = document.querySelector('.qsel[data-unidad="' + unidadId + '"]');
        const current = parseInt((input && input.value) || '5', 10);
        const step = parseInt(btn.getAttribute('data-step') || '1', 10);
        clampQuestionInput(input, (Number.isFinite(current) ? current : 5) + step);
      });
    });
    document.querySelectorAll('.exam-quick-btn[data-unidad]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const unidadId = btn.getAttribute('data-unidad');
        const input = document.querySelector('.qsel[data-unidad="' + unidadId + '"]');
        clampQuestionInput(input, btn.getAttribute('data-value') || '5');
      });
    });
    document.querySelectorAll('.qsel[data-unidad]').forEach(input=>{
      updateQuestionQuickState(input);
      input.addEventListener('input', ()=>clampQuestionInput(input, input.value));
      input.addEventListener('change', ()=>clampQuestionInput(input, input.value));
    });
    document.querySelectorAll('.exam-option-btn[data-select]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const select = document.querySelector(btn.getAttribute('data-select'));
        if (!select) return;
        select.value = btn.getAttribute('data-exam-option') || select.value;
        syncOptionButtons(select);
        select.dispatchEvent(new Event('change', {bubbles:true}));
      });
    });
    document.querySelectorAll('.style-sel[data-unidad], .difficulty-sel[data-unidad]').forEach(select=>{
      syncOptionButtons(select);
      select.addEventListener('change', ()=>syncOptionButtons(select));
    });

    document.querySelectorAll('.open-exam-config-btn[data-unidad]').forEach(btn=>{
      btn.addEventListener('click', ()=>openSetupModal(btn));
    });
    if (examSetupGenerate) {
      examSetupGenerate.addEventListener('click', ()=>{
        const unidadId = parseInt(setupUnitId || '0', 10);
        if (!unidadId) return;
        let n = parseInt((setupQsel && setupQsel.value) || '5', 10);
        if (!Number.isFinite(n) || n < 1) n = 1;
        if (n > 50) n = 50;
        if (setupQsel) setupQsel.value = String(n);
        const style = (setupStyle && setupStyle.value) || 'mixto';
        const difficulty = (setupDifficulty && setupDifficulty.value) || 'intermedio';
        closeSetupModal();
        generateExam(unidadId, n, style, difficulty);
      });
    }

    document.querySelectorAll('.gen-btn[data-unidad]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const unidadId = parseInt(btn.getAttribute('data-unidad') || '0', 10);
        if (!unidadId) return;
        const qsel = document.querySelector('.qsel[data-unidad="' + unidadId + '"]');
        const styleSel = document.querySelector('.style-sel[data-unidad="' + unidadId + '"]');
        const difficultySel = document.querySelector('.difficulty-sel[data-unidad="' + unidadId + '"]');
        let n = parseInt((qsel && qsel.value) || '5', 10);
        if (!Number.isFinite(n) || n < 1) n = 1;
        if (n > 50) n = 50;
        if (qsel) qsel.value = String(n);
        const style = (styleSel && styleSel.value) || 'mixto';
        const difficulty = (difficultySel && difficultySel.value) || 'intermedio';
        generateExam(unidadId, n, style, difficulty);
      });
    });
  })();
  </script>
<?php endif; ?>

<?php require __DIR__ . '/partials/footer.php'; ?>
