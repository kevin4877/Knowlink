<?php
// public/estudiantes/notificaciones.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/auth.php';
require_once __DIR__ . '/../../src/helpers.php';

header('Content-Type: application/json; charset=utf-8');

start_session();
$u = auth_user();
if (!$u || ($u['rol'] ?? '') !== 'estudiante') {
  http_response_code(403);
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
  exit;
}

$pdo = db();

try {
  $sinceId      = isset($_GET['since_id']) ? (int)$_GET['since_id'] : 0;
  $estudianteId = (int)($u['id'] ?? 0);

  // Total de nuevas desde since_id (para el badge)
  $countStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM estudiante_notifs
    WHERE estudiante_id = :e AND id > :since_id
  ");
  $countStmt->execute([':e'=>$estudianteId, ':since_id'=>$sinceId]);
  $totalNew = (int)$countStmt->fetchColumn();

  // Últimas 10 para el menú
  $listStmt = $pdo->prepare("
    SELECT id, tipo, materia_clave, unidad_id, tema_id, contenido_id, titulo,
           creado_en, DATE_FORMAT(creado_en, '%Y-%m-%d %H:%i') AS creado_en_fmt
    FROM estudiante_notifs
    WHERE estudiante_id = :e
    ORDER BY id DESC
    LIMIT 10
  ");
  $listStmt->execute([':e'=>$estudianteId]);
  $items = $listStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

  echo json_encode(['total'=>$totalNew,'items'=>$items], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
}
