<?php
// public/estudiantes/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo || ($yo['rol'] ?? '') !== 'estudiante') {
  redirect(base_url('login.php'));
  exit;
}

// Seguridad básica
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** Portada SVG (data URI) para tarjetas de materia — mismo estilo que Docentes */
function materia_cover_svg(string $clave, string $nombre=''): string {
  $txt = strtoupper($clave ?: 'MAT');
  $siglas = preg_replace('/[^A-Z0-9]/', '', $txt);
  if ($siglas === '') $siglas = 'MAT';
  $hash = crc32($siglas); $h = $hash % 360; $h2 = ($h + 30) % 360;
  $title = htmlspecialchars($nombre ?: $siglas, ENT_QUOTES, 'UTF-8');
  $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360" role="img" aria-label="{$title}">
  <defs><linearGradient id="g{$hash}" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="hsl({$h},75%,62%)"/><stop offset="1" stop-color="hsl({$h2},82%,64%)"/></linearGradient></defs>
  <rect width="100%" height="100%" fill="url(#g{$hash})"/>
  <g fill="rgba(255,255,255,0.18)"><circle cx="520" cy="90" r="80"/><circle cx="120" cy="300" r="90"/><rect x="420" y="230" width="120" height="24" rx="12"/></g>
  <text x="50%" y="52%" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="92" font-weight="900" fill="#ffffff" opacity="0.96">{$siglas}</text>
</svg>
SVG;
  return 'data:image/svg+xml;utf8,'.rawurlencode($svg);
}


/** Estilo visual local para portadas de materias: no carga imágenes externas. */
function materia_cover_style(string $clave, string $nombre=''): string {
  $texto = mb_strtolower(trim($clave.' '.$nombre), 'UTF-8');
  $palettes = [
    ['#0ea5e9','#2563eb','#1e3a8a','#e0f2fe'], // azul
    ['#22c55e','#16a34a','#065f46','#dcfce7'], // verde
    ['#f97316','#ea580c','#7c2d12','#ffedd5'], // naranja
    ['#a855f7','#7c3aed','#3b0764','#f3e8ff'], // morado
    ['#ec4899','#be185d','#831843','#fce7f3'], // rosa
    ['#14b8a6','#0f766e','#134e4a','#ccfbf1'], // teal
    ['#f59e0b','#d97706','#78350f','#fef3c7'], // ámbar
    ['#06b6d4','#0284c7','#164e63','#cffafe'], // cyan
    ['#ef4444','#dc2626','#7f1d1d','#fee2e2'], // rojo
    ['#64748b','#334155','#0f172a','#e2e8f0'], // slate
    ['#6366f1','#4f46e5','#312e81','#e0e7ff'], // indigo
    ['#84cc16','#65a30d','#365314','#ecfccb'], // lima
  ];
  $keywords = [
    'program' => 10, 'software' => 10, 'datos' => 7, 'redes' => 7, 'sistemas' => 10,
    'calculo' => 0, 'matemat' => 0, 'algebra' => 10, 'estad' => 3, 'fisica' => 7,
    'quimica' => 5, 'biologia' => 1, 'microbiologia' => 5, 'alimentos' => 11,
    'administr' => 3, 'gestion' => 4, 'contabilidad' => 6, 'financ' => 6,
    'mercado' => 4, 'costos' => 6, 'civil' => 2, 'constru' => 2, 'arquitect' => 9,
    'electr' => 8, 'mecanica' => 9, 'hidraulica' => 0, 'agric' => 1, 'frut' => 11,
    'investig' => 9, 'etica' => 4, 'calidad' => 1,
  ];
  $idx = abs((int)crc32($clave ?: $nombre)) % count($palettes);
  foreach ($keywords as $kw => $forced) {
    if ($kw !== '' && mb_strpos($texto, $kw, 0, 'UTF-8') !== false) { $idx = $forced; break; }
  }
  [$a,$b,$c,$soft] = $palettes[$idx];
  return '--cover-a:'.$a.';--cover-b:'.$b.';--cover-c:'.$c.';--cover-soft:'.$soft.';';
}

/** Token de vista (igual que en buscar_recurso.php) para compatibilidad con ver_materia.php */
function mint_materia_view_token(string $clave): string {
  if (!isset($_SESSION['materia_view_tokens'])) $_SESSION['materia_view_tokens'] = [];
  $t = bin2hex(random_bytes(16));
  $_SESSION['materia_view_tokens'][$t] = ['materia_clave'=>$clave, 'exp'=> time()+300];
  return $t;
}

$pdo = db();

/** === Datos del estudiante (retícula + semestre) === */
$st = $pdo->prepare("
  SELECT e.reticula_id, e.semestre_actual, e.carrera_id,
         r.clave AS reticula_clave, r.nombre AS reticula_nombre
  FROM estudiantes e
  LEFT JOIN reticulas r ON r.id = e.reticula_id
  WHERE e.usuario_id = :uid
  LIMIT 1
");
$st->execute([':uid' => (int)$yo['id']]);
$E = $st->fetch(PDO::FETCH_ASSOC) ?: [];

$reticula_id    = (int)($E['reticula_id'] ?? 0);
$semestre       = (int)($E['semestre_actual'] ?? 0);
$reticula_clave = (string)($E['reticula_clave'] ?? '');
$reticula_nom   = (string)($E['reticula_nombre'] ?? '');

/** === Materias “En curso”: por retícula y semestre del alumno === */
$materias = [];
if ($reticula_id > 0 && $semestre > 0) {
  $q = $pdo->prepare("
    SELECT
      rm.id AS reticula_materia_id,
      rm.materia_clave,
      rm.semestre,
      m.nombre AS materia_nombre,
      COALESCE(m.descripcion,'') AS materia_desc
    FROM reticula_materias rm
    JOIN materias m ON LOWER(m.clave) = LOWER(rm.materia_clave)
    WHERE rm.reticula_id = :rid
      AND rm.semestre    = :sem
    ORDER BY m.nombre ASC
  ");
  $q->execute([':rid' => $reticula_id, ':sem' => $semestre]);
  $materias = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
}

// === Vista ===
$title  = 'KnowLink · Estudiantes · En curso';
$active = 'en_curso';
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .tools{display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap}
  .field label{font-size:12px;color:#6b7280;display:block;margin-bottom:6px}
  .field input{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;min-width:260px}

  .card{background:#fff;border-radius:12px;padding:16px;border:1px solid #e6eef2;box-shadow:0 10px 30px rgba(2,6,23,.06)}
  .muted{color:#94a3b8}
  .empty{color:#64748b;padding:12px;border:1px dashed #e6eef2;border-radius:10px;background:#fafcff}

  /* === Diseño de materias (igual que Docentes) === */
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
  .m-card{background:#fff;border:1px solid #e6eef2;border-radius:12px;overflow:hidden;cursor:pointer;display:flex;flex-direction:column;transition:transform .1s ease, box-shadow .12s ease}
  .m-card:hover{transform:translateY(-2px);box-shadow:0 16px 36px rgba(2,6,23,0.08)}
  .thumb{aspect-ratio:16/9;background:#eef3f6;border-bottom:1px solid #eef2f6}
  .m-body{padding:10px}

  /* ===== Portada decorativa sin imágenes externas ===== */
  .m-card .thumb.materia-name-cover{
    --cover-a:#0ea5e9;
    --cover-b:#2563eb;
    --cover-c:#1e3a8a;
    --cover-soft:#e0f2fe;
    position:relative;
    overflow:hidden;
    aspect-ratio:auto;
    min-height:160px;
    padding:16px;
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:12px;
    isolation:isolate;
    color:#ffffff;
    background:
      radial-gradient(circle at 14% 18%, rgba(255,255,255,.28) 0 0, transparent 28%),
      radial-gradient(circle at 92% 82%, rgba(255,255,255,.18) 0 0, transparent 32%),
      linear-gradient(135deg,var(--cover-a),var(--cover-b) 52%,var(--cover-c));
  }
  .m-card .thumb.materia-name-cover::before{
    content:"";
    position:absolute;
    inset:10px;
    border:1px solid rgba(255,255,255,.19);
    border-radius:16px;
    pointer-events:none;
    z-index:1;
  }
  .m-card .thumb.materia-name-cover::after{
    content:"";
    position:absolute;
    right:-38px;
    bottom:-48px;
    width:160px;
    height:160px;
    border-radius:999px;
    background:rgba(255,255,255,.13);
    box-shadow:
      -125px -82px 0 -52px rgba(255,255,255,.17),
      -35px -142px 0 -64px rgba(255,255,255,.20);
    z-index:0;
  }
  .cover-top{
    position:absolute;
    z-index:2;
    top:14px;
    right:16px;
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
  }
  .cover-code{
    display:none;
    align-items:center;
    max-width:68%;
    padding:5px 9px;
    border-radius:999px;
    background:rgba(255,255,255,.18);
    border:1px solid rgba(255,255,255,.24);
    color:rgba(255,255,255,.95);
    font-size:11px;
    font-weight:950;
    letter-spacing:.01em;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    backdrop-filter:blur(8px);
  }
  .cover-dots{
    display:inline-flex;
    gap:5px;
    align-items:center;
    opacity:.9;
  }
  .cover-dots i{
    width:8px;
    height:8px;
    border-radius:999px;
    background:rgba(255,255,255,.56);
    display:block;
    box-shadow:18px 0 0 rgba(255,255,255,.34),36px 0 0 rgba(255,255,255,.22);
  }
  .cover-name{
    position:relative;
    z-index:2;
    font-size:20px;
    line-height:1.08;
    font-weight:950;
    letter-spacing:-.035em;
    text-shadow:0 3px 14px rgba(0,0,0,.30);
    display:block;
    overflow:visible;
    max-width:100%;
    white-space:normal;
    word-break:normal;
    overflow-wrap:anywhere;
  }
  .cover-meta{
    position:relative;
    z-index:2;
    display:none;
    align-items:center;
    width:max-content;
    max-width:100%;
    padding:4px 8px;
    border-radius:999px;
    background:rgba(0,0,0,.16);
    color:rgba(255,255,255,.86);
    font-size:10px;
    font-weight:900;
    letter-spacing:.02em;
  }
  .m-card:hover .thumb.materia-name-cover{
    filter:saturate(1.08) brightness(1.03);
  }


  html[data-theme="dark"] .m-card,
  body[data-theme="dark"] .m-card{
    background:#111827!important;
    border-color:rgba(148,163,184,.18)!important;
    box-shadow:0 14px 34px rgba(0,0,0,.28)!important;
  }
  html[data-theme="dark"] .m-card:hover,
  body[data-theme="dark"] .m-card:hover{
    border-color:rgba(56,189,248,.35)!important;
    box-shadow:0 18px 42px rgba(0,0,0,.36)!important;
  }
  html[data-theme="dark"] .thumb.materia-name-cover,
  body[data-theme="dark"] .thumb.materia-name-cover{
    background:
      radial-gradient(circle at 14% 18%, rgba(255,255,255,.18) 0 0, transparent 28%),
      radial-gradient(circle at 92% 82%, rgba(255,255,255,.11) 0 0, transparent 32%),
      linear-gradient(135deg,var(--cover-a),var(--cover-b) 52%,var(--cover-c))!important;
    border-bottom-color:rgba(148,163,184,.16)!important;
  }
  html[data-theme="dark"] .m-title,
  body[data-theme="dark"] .m-title{color:#f8fafc!important}
  html[data-theme="dark"] .m-sub,
  body[data-theme="dark"] .m-sub{color:#cbd5e1!important}

  .m-title{font-weight:900;color:#0b2545;line-height:1.22;white-space:normal;overflow:visible;word-break:normal;overflow-wrap:anywhere}
  .m-sub{font-size:13px;color:#6b7280}

  .hero{
    display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap
  }
  .chip{display:inline-flex;align-items:center;gap:8px;padding:6px 10px;border-radius:999px;border:1px solid #e6eef2;background:#fff;font-weight:800;font-size:12.5px;color:#0b2545}
  .chip i{color:#64748b}
  .hidden{display:none!important}
  .search-empty{margin-top:12px}
  .field input:focus{outline:none;border-color:#8bb8ff;box-shadow:0 0 0 3px rgba(0,85,212,.12)}

  html[data-theme="dark"] .empty{background:#0f172a!important;border-color:rgba(148,163,184,.24)!important;color:#cbd5e1!important}
  html[data-theme="dark"] .field label{color:#cbd5e1!important}

  @media (max-width: 720px){
    .page-header{align-items:stretch;flex-direction:column}
    .tools,.field,.field input{width:100%;min-width:0}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title">Tus materias en curso</div>
    <div class="page-sub">Materias disponibles para continuar aprendiendo</div>
  </div>
  <div class="tools">
    <div class="field">
      <label>Buscar materia</label>
      <input id="q" type="text" placeholder="Ej. Cálculo" autocomplete="off">
    </div>
  </div>
</div>

<section class="card" aria-label="Materias en curso">
  <?php if ($reticula_id <= 0): ?>
    <div class="empty">Tu cuenta aún no tiene materias asignadas. Pide al administrador que revise tu información académica.</div>

  <?php elseif ($semestre <= 0 || $semestre > 12): ?>
    <div class="empty">No se pudieron cargar tus materias. Pide al administrador que revise tu información académica.</div>

  <?php elseif (!$materias): ?>
    <div class="empty">
      No hay materias disponibles por el momento.
    </div>

  <?php else: ?>
    <div id="count" class="muted" style="margin-bottom:8px;"><?= count($materias) ?> materia(s)</div>
    <div id="grid" class="grid">
      <?php foreach ($materias as $m):
        $clave   = (string)$m['materia_clave'];
        $nombre  = (string)$m['materia_nombre'];
        $desc    = (string)$m['materia_desc'];
        $rmid    = (int)$m['reticula_materia_id'];
        $haystack= mb_strtolower($clave.' '.$nombre.' '.$desc, 'UTF-8');

        // Navegación por POST (compatible con ver_materia.php)
        $token = mint_materia_view_token($clave);
        $action = function_exists('base_url') ? base_url('estudiantes/ver_materia.php') : './ver_materia.php';
      ?>
      <article class="m-card" tabindex="0"
               data-haystack="<?= esc($haystack) ?>">
        <div class="thumb materia-name-cover" style="<?= esc(materia_cover_style($clave, $nombre)) ?>" aria-label="<?= esc($nombre ?: $clave) ?>">
          <div class="cover-top">
            <span class="cover-dots" aria-hidden="true"><i></i></span>
          </div>
          <span class="cover-name"><?= esc($nombre ?: $clave) ?></span>
          <span class="cover-meta">Materia disponible</span>
        </div>
        <div class="m-body">
          <div class="m-title"><?= esc($nombre ?: 'Materia') ?></div>
          <?php if ($desc !== ''): ?>
            <div class="m-sub" style="margin-top:6px;max-height:42px;overflow:hidden;"><?= esc($desc) ?></div>
          <?php endif; ?>
        </div>
        <!-- Formulario oculto (fallback y navegación por teclado/click) -->
        <form class="hidden" method="post" action="<?= esc($action) ?>">
          <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
          <input type="hidden" name="token" value="<?= esc($token) ?>">
          <input type="hidden" name="rmid" value="<?= (int)$rmid ?>">
          <input type="hidden" name="materia_clave" value="<?= esc($clave) ?>">
          <input type="hidden" name="origin" value="en_curso">
        </form>
      </article>
      <?php endforeach; ?>
    </div>
    <div id="emptySearch" class="empty search-empty hidden">No se encontraron materias con ese texto.</div>
  <?php endif; ?>
</section>

<script>
(function(){
  const q = document.getElementById('q');
  const grid = document.getElementById('grid');
  const count = document.getElementById('count');
  const emptySearch = document.getElementById('emptySearch');
  const total = grid ? grid.querySelectorAll('.m-card').length : 0;

  const normalize = (txt) => String(txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .trim();

  let pending = false;
  function filter(){
    if(!grid) return;
    const term = normalize(q?.value || '');
    let visible = 0;

    grid.querySelectorAll('.m-card').forEach(card=>{
      const hay = normalize(card.getAttribute('data-haystack') || '');
      const show = term === '' || hay.includes(term);
      card.classList.toggle('hidden', !show);
      if (show) visible++;
    });

    if (count) {
      count.textContent = term === ''
        ? `${total} materia(s)`
        : `${visible} de ${total} materia(s)`;
    }
    emptySearch?.classList.toggle('hidden', term === '' || visible > 0);
  }

  function scheduleFilter(){
    if (pending) return;
    pending = true;
    requestAnimationFrame(()=>{
      pending = false;
      filter();
    });
  }

  q?.addEventListener('input', scheduleFilter);
  q?.addEventListener('search', scheduleFilter);

  function goto(card){
    const form = card.querySelector('form');
    if (form) form.submit();
  }

  grid?.addEventListener('click', (e)=>{
    const card = e.target.closest('.m-card');
    if (!card || card.classList.contains('hidden')) return;
    goto(card);
  });

  grid?.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter' || e.key === ' ') {
      const card = e.target.closest('.m-card');
      if (!card || card.classList.contains('hidden')) return;
      e.preventDefault();
      goto(card);
    }
  });

  filter();
})();
</script>

<?php require __DIR__ . '/partials/footer.php';
