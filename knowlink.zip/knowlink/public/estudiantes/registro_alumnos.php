<?php
// public/estudiantes/registro_alumnos.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();

// Seguridad básica
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
function buildDefaultAvatar(): string {
  return 'data:image/svg+xml;utf8,' . rawurlencode(
    '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="48" cy="34" r="18" fill="#cfd8e3"/><rect x="18" y="58" width="60" height="24" rx="12" fill="#cfd8e3"/></svg>'
  );
}
$defaultAvatar = buildDefaultAvatar();

$pdo = db();

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ==============================
   AJAX: username availability
   ============================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  $ok = false; $available = false;
  if ($u !== '' && mb_strlen($u) >= 3) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u");
    $st->execute([':u'=>$u]);
    $available = ((int)$st->fetchColumn() === 0);
    $ok = true;
  }
  echo json_encode(['ok'=>$ok, 'available'=>$available], JSON_UNESCAPED_UNICODE);
  exit;
}

/* -------------------------
   Cargar carreras para <select>
   ------------------------- */
$carreras_db = [];
try {
  $carreras_db = $pdo->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch(Throwable $e){ $carreras_db = []; }

/* -------------------------
   Helpers de negocio (server)
   ------------------------- */
function year_from_no_control(string $no_control): ?int {
  $no_control = preg_replace('/\D+/', '', $no_control);
  if (strlen($no_control) < 2) return null;
  $yy = (int)substr($no_control, 0, 2);
  $curYY = (int)date('y');
  $year = 2000 + $yy;
  if ($yy > $curYY + 1) { $year = 1900 + $yy; }
  return $year;
}

/** Semestre (servidor) asumiendo ingreso ciclo agosto. */
function calcular_semestre(int $anio_ingreso, ?DateTime $hoy = null): int {
  $hoy = $hoy ?: new DateTime('now');
  $inicio = new DateTime($anio_ingreso . '-08-01');
  if ($hoy < $inicio) { return 1; }
  $diffMeses = ((int)$hoy->format('Y') - (int)$inicio->format('Y')) * 12 + ((int)$hoy->format('n') - 8);
  $sem = intdiv($diffMeses, 6) + 1;
  return max(1, min(12, $sem));
}

function pick_reticula_por_anio(PDO $pdo, int $carrera_id, int $anio_ingreso): ?int {
  $st = $pdo->prepare("
    SELECT id
    FROM reticulas
    WHERE carrera_id = :c
      AND YEAR(vigente_desde) <= :y
      AND (vigente_hasta IS NULL OR YEAR(vigente_hasta) >= :y)
    ORDER BY vigente_desde DESC
    LIMIT 1
  ");
  $st->execute([':c'=>$carrera_id, ':y'=>$anio_ingreso]);
  $id = $st->fetchColumn();
  if ($id) return (int)$id;

  $st = $pdo->prepare("SELECT id FROM reticulas WHERE carrera_id=:c ORDER BY vigente_desde DESC LIMIT 1");
  $st->execute([':c'=>$carrera_id]);
  $id = $st->fetchColumn();
  return $id ? (int)$id : null;
}

/* -------------------------
   Estado del formulario
   ------------------------- */
$errors = [];
$flash  = null;
$old = [
  'nombre'         => '',
  'carrera'        => '',
  'numero_control' => '',
  'username'       => '',
  'password'       => '',
  'password2'      => '',
];
$correo_institucional = '';

/* -------------------------
   POST (crear alumno)
   ------------------------- */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($CSRF, $_POST['csrf'] ?? '')) {
    $errors[] = 'CSRF inválido. Refresca la página.';
  }

  $old['nombre']         = trim((string)($_POST['nombre'] ?? ''));
  $old['carrera']        = (string)($_POST['carrera'] ?? '');
  $old['numero_control'] = preg_replace('/\D+/', '', (string)($_POST['numero_control'] ?? ''));
  $old['username']       = trim((string)($_POST['username'] ?? ''));
  $old['password']       = (string)($_POST['password'] ?? '');
  $old['password2']      = (string)($_POST['password2'] ?? '');

  $correo_institucional = (strlen($old['numero_control']) === 8) ? ('L'.$old['numero_control'].'@zitacuaro.tecnm.mx') : '';

  // Validaciones
  if ($old['nombre'] === '' || mb_strlen($old['nombre']) < 3) $errors[] = 'Nombre completo inválido.';
  $carrera_id = (int)$old['carrera'];
  if ($carrera_id <= 0) $errors[] = 'Selecciona una carrera.';
  if (!preg_match('/^\d{8}$/', $old['numero_control'])) $errors[] = 'Número de control inválido (8 dígitos).';
  if ($old['username'] === '' || mb_strlen($old['username']) < 3) $errors[] = 'El usuario debe tener al menos 3 caracteres.';
  if ($old['password'] === '' || mb_strlen($old['password']) < 8) $errors[] = 'La contraseña debe tener al menos 8 caracteres.';
  if ($old['password'] !== $old['password2']) $errors[] = 'Las contraseñas no coinciden.';
  if ($correo_institucional === '') $errors[] = 'No se pudo generar el correo institucional.';

  // Unicidad
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u");
    $st->execute([':u'=>$old['username']]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'El nombre de usuario ya está en uso.';

    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e");
    $st->execute([':e'=>$correo_institucional]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'El correo institucional ya está registrado.';

    $st = $pdo->prepare("SELECT COUNT(*) FROM estudiantes WHERE no_control=:nc");
    $st->execute([':nc'=>$old['numero_control']]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'El número de control ya existe.';
  }

  // Foto (opcional)
  $foto_url = null;
  if (!$errors && isset($_FILES['foto']) && is_array($_FILES['foto']) && ($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['foto'];
    if ($f['error'] !== UPLOAD_ERR_OK) { $errors[]='Error al subir la imagen.'; }
    else {
      if ($f['size'] > 3*1024*1024) $errors[]='La imagen excede 3 MB.';
      $finfo = finfo_open(FILEINFO_MIME_TYPE);
      $mime  = finfo_file($finfo, $f['tmp_name']);
      finfo_close($finfo);
      $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
      if (!isset($allowed[$mime])) $errors[]='Formato de imagen no permitido (JPG, PNG, GIF, WEBP).';
      if (!$errors) {
        $ext  = $allowed[$mime];
        $dir  = __DIR__ . '/../../public/uploads/avatars';
        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
        $fname = 'alu_' . time() . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
        $dest  = $dir . '/' . $fname;
        if (!move_uploaded_file($f['tmp_name'], $dest)) {
          $errors[] = 'No se pudo guardar la imagen.';
        } else {
          $foto_url = '/uploads/avatars/' . $fname;
        }
      }
    }
  }

  // Crear alumno + AUTO LOGIN
  if (!$errors) {
    try {
      $pdo->beginTransaction();

      $anio_ingreso = year_from_no_control($old['numero_control']);
      if (!$anio_ingreso) { throw new RuntimeException('No se pudo calcular el año de ingreso.'); }
      $semestre = calcular_semestre($anio_ingreso, new DateTime('now'));

      $reticula_id = pick_reticula_por_anio($pdo, $carrera_id, $anio_ingreso);

      // usuarios (rol estudiante)
      $hash = password_hash($old['password'], PASSWORD_BCRYPT, ['cost'=>10]);

      // separar nombre/apellidos rudimentariamente (si vienen juntos)
      $nombreSolo = $old['nombre'];
      $apellidos  = '';
      $parts = preg_split('/\s+/', trim($old['nombre']));
      if (count($parts) >= 3) {
        $nombreSolo = array_shift($parts);
        $apellidos  = implode(' ', $parts);
      }

      $sqlU = "INSERT INTO usuarios (nombre, apellidos, email, username, password_hash, rol, foto_url, activo, creado_en, actualizado_en)
               VALUES (:n, :a, :e, :u, :ph, 'estudiante', :f, 1, NOW(), NOW())";
      $stU = $pdo->prepare($sqlU);
      $stU->execute([
        ':n'=>$nombreSolo,
        ':a'=>$apellidos,
        ':e'=>$correo_institucional,
        ':u'=>$old['username'],
        ':ph'=>$hash,
        ':f'=>$foto_url
      ]);
      $uid = (int)$pdo->lastInsertId();

      // estudiantes
      $sqlE = "INSERT INTO estudiantes (usuario_id, no_control, reticula_id, carrera_id, semestre_actual, extra_json)
               VALUES (:uid, :nc, :rid, :cid, :sem, NULL)";
      $stE = $pdo->prepare($sqlE);
      $stE->execute([
        ':uid'=>$uid,
        ':nc'=>$old['numero_control'],
        ':rid'=>$reticula_id,
        ':cid'=>$carrera_id,
        ':sem'=>$semestre,
      ]);

      $pdo->commit();

      // ====== AUTO LOGIN ======
      // Lee el usuario recién creado y colócalo en la sesión, tal como espera auth_user()
      $st = $pdo->prepare("SELECT id,nombre,apellidos,email,username,rol,foto_url,activo,creado_en,actualizado_en FROM usuarios WHERE id=:id LIMIT 1");
      $st->execute([':id'=>$uid]);
      $usr = $st->fetch(PDO::FETCH_ASSOC) ?: null;
      if ($usr) {
        // Si tu auth.php expone una función tipo set_auth_user($usr), úsala.
        // Aquí dejamos la forma directa, compatible con auth_user() que lee $_SESSION['user'].
        $_SESSION['user'] = $usr;
      }

      // Redirige al dashboard del estudiante
      redirect(base_url('estudiantes/index.php'));
      exit;

    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'No se pudo registrar al alumno.';
    }
  }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Registro — Estudiante</title>
  <script>
    (function(){
      try{
        var saved = localStorage.getItem('knowlink-theme');
        var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        var theme = (saved === 'dark' || saved === 'light') ? saved : (prefersDark ? 'dark' : 'light');
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.setAttribute('data-bs-theme', theme);
      }catch(e){
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.setAttribute('data-bs-theme', 'light');
      }
    })();
  </script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link rel="stylesheet" href="<?= esc(base_url('assets/css/knowlink-modern.css')) ?>?v=20260524-mobile-responsive">
  <style>
    :root,
    html[data-theme="light"]{
      --reg-bg:#eef7fb;
      --reg-surface:#ffffff;
      --reg-surface-soft:#f7fbff;
      --reg-text:#0f172a;
      --reg-muted:#5f6f84;
      --reg-border:#d7e8f3;
      --reg-primary:#0284c7;
      --reg-primary-2:#0f766e;
      --reg-shadow:0 24px 70px rgba(15,23,42,.12);
      --reg-shadow-soft:0 12px 34px rgba(15,23,42,.08);
      --reg-focus:rgba(14,165,233,.18);
    }
    html[data-theme="dark"]{
      --reg-bg:#07101d;
      --reg-surface:#111827;
      --reg-surface-soft:#172033;
      --reg-text:#e5eefb;
      --reg-muted:#a8b3c7;
      --reg-border:#2b3a52;
      --reg-primary:#38bdf8;
      --reg-primary-2:#5eead4;
      --reg-shadow:0 28px 85px rgba(0,0,0,.50);
      --reg-shadow-soft:0 16px 44px rgba(0,0,0,.38);
      --reg-focus:rgba(56,189,248,.20);
      color-scheme:dark;
    }
    *{box-sizing:border-box}
    html{min-height:100%;background:var(--reg-bg)}
    body.student-register-page{
      min-height:100vh;
      margin:0;
      font-family:Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
      color:var(--reg-text);
      background:
        radial-gradient(circle at 9% -8%, rgba(14,165,233,.22), transparent 32rem),
        radial-gradient(circle at 95% 10%, rgba(20,184,166,.16), transparent 28rem),
        linear-gradient(135deg,var(--reg-bg),#f8fcff 58%,#edf8ff);
      background-attachment:fixed;
      overflow-x:hidden;
    }
    html[data-theme="dark"] body.student-register-page{
      background:
        radial-gradient(circle at 10% -8%, rgba(56,189,248,.14), transparent 34rem),
        radial-gradient(circle at 96% 16%, rgba(94,234,212,.10), transparent 30rem),
        linear-gradient(135deg,#07101d,#0b1220 58%,#101827);
      background-attachment:fixed;
    }
    .register-theme-toggle{
      position:fixed;
      top:18px;
      right:20px;
      z-index:20;
      display:inline-flex;
      align-items:center;
      gap:9px;
      min-height:42px;
      padding:9px 13px;
      border-radius:999px;
      border:1px solid rgba(186,230,253,.82);
      background:rgba(255,255,255,.82);
      color:#075985;
      font-weight:900;
      box-shadow:0 12px 34px rgba(15,23,42,.10);
      backdrop-filter:blur(14px);
      cursor:pointer;
      transition:transform .16s ease, box-shadow .16s ease, background .16s ease, border-color .16s ease;
    }
    .register-theme-toggle:hover{transform:translateY(-1px);box-shadow:0 18px 40px rgba(14,165,233,.16)}
    .register-theme-toggle i{font-size:15px}
    .register-theme-toggle .theme-label{font-size:13px;letter-spacing:-.01em}
    html[data-theme="dark"] .register-theme-toggle{
      background:rgba(17,24,39,.86);
      border-color:rgba(125,211,252,.24);
      color:#bae6fd;
      box-shadow:0 16px 44px rgba(0,0,0,.42);
    }
    .wrap{
      width:min(1120px,calc(100% - 28px));
      margin:0 auto;
      padding:72px 0 34px;
      position:relative;
    }
    .register-hero.card{
      display:grid;
      grid-template-columns:1.2fr auto;
      gap:22px;
      align-items:center;
      padding:26px !important;
      border-radius:28px !important;
      overflow:hidden;
      background:
        linear-gradient(135deg,rgba(224,242,254,.96),rgba(204,251,241,.92)),
        radial-gradient(circle at 94% 0%, rgba(255,255,255,.78), transparent 18rem) !important;
      border:1px solid rgba(186,230,253,.98) !important;
      box-shadow:var(--reg-shadow) !important;
      color:#0f172a !important;
      position:relative;
    }
    .register-hero.card::after{
      content:"";
      position:absolute;
      width:210px;height:210px;border-radius:50%;
      right:-72px;top:-92px;
      background:rgba(255,255,255,.35);
      pointer-events:none;
    }
    html[data-theme="dark"] .register-hero.card{
      background:
        linear-gradient(135deg,rgba(14,116,144,.90),rgba(15,23,42,.95)),
        radial-gradient(circle at 94% 0%, rgba(125,211,252,.18), transparent 18rem) !important;
      border-color:rgba(125,211,252,.22) !important;
      color:#f8fafc !important;
    }
    .register-hero > *{position:relative;z-index:1}
    .hero-left{display:flex;align-items:center;gap:18px;min-width:0}
    .avatar{
      width:92px;
      height:92px;
      border-radius:26px;
      overflow:hidden;
      border:4px solid rgba(255,255,255,.78);
      flex:0 0 92px;
      background:#e0f2fe;
      box-shadow:0 16px 38px rgba(14,116,144,.18);
    }
    .avatar img{width:100%;height:100%;object-fit:cover;display:block}
    .register-badge{
      display:inline-flex;
      align-items:center;
      gap:8px;
      padding:7px 11px;
      border-radius:999px;
      border:1px solid rgba(14,116,144,.18);
      background:rgba(255,255,255,.64);
      color:#075985;
      font-size:12px;
      font-weight:950;
      margin-bottom:9px;
    }
    html[data-theme="dark"] .register-badge{background:rgba(125,211,252,.12);border-color:rgba(125,211,252,.24);color:#bae6fd}
    .name{
      font-weight:950;
      font-size:clamp(28px,3vw,40px);
      line-height:1.02;
      color:inherit;
      letter-spacing:-.045em;
      margin:0;
    }
    .kv{color:var(--reg-muted);font-size:14px;line-height:1.55;margin-top:6px}
    .register-hero .kv{font-size:15px;color:#475569;max-width:620px}
    html[data-theme="dark"] .register-hero .kv{color:#cbd5e1}
    .header-actions{display:flex;gap:10px;align-items:center;justify-content:flex-end;flex-wrap:wrap}
    .card{
      background:rgba(255,255,255,.94) !important;
      color:var(--reg-text) !important;
      border:1px solid rgba(215,232,243,.95) !important;
      border-radius:22px !important;
      padding:22px !important;
      box-shadow:var(--reg-shadow-soft) !important;
      margin-bottom:18px !important;
      backdrop-filter:blur(12px);
    }
    html[data-theme="dark"] .card{
      background:rgba(17,24,39,.94) !important;
      border-color:var(--reg-border) !important;
      box-shadow:var(--reg-shadow-soft) !important;
    }
    .card h3{
      color:var(--reg-text);
      margin:0;
      font-size:19px;
      font-weight:950;
      display:flex;
      align-items:center;
      gap:10px;
      letter-spacing:-.02em;
    }
    .card h3 i{color:var(--reg-primary)}
    .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(265px,1fr));gap:16px;margin-top:16px}
    .form-grid .full{grid-column:1 / -1}
    label.field{display:flex;flex-direction:column;gap:8px;position:relative}
    .label,.field .label{
      color:var(--reg-text);
      font-size:13px;
      font-weight:900;
    }
    input[type="text"],input[type="email"],input[type="password"],select,textarea,input[type="file"]{
      width:100%;
      box-sizing:border-box;
      min-height:46px;
      padding:11px 13px;
      border-radius:14px;
      border:1px solid var(--reg-border);
      outline:none;
      font-size:14px;
      background:var(--reg-surface-soft);
      color:var(--reg-text);
      transition:border-color .16s ease, box-shadow .16s ease, background .16s ease;
    }
    input[type="file"]{padding:10px;background:transparent}
    input::placeholder,textarea::placeholder{color:#8aa0b6}
    html[data-theme="dark"] input::placeholder,html[data-theme="dark"] textarea::placeholder{color:#73839a}
    input:focus,select:focus,textarea:focus{
      border-color:var(--reg-primary);
      box-shadow:0 0 0 .25rem var(--reg-focus);
      background:var(--reg-surface);
    }
    select option{color:#0f172a;background:#fff}
    html[data-theme="dark"] select option{color:#e5eefb;background:#111827}
    .actions,.form-grid .full[style*="display:flex"]{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
    .btn{
      display:inline-flex;
      align-items:center;
      justify-content:center;
      gap:8px;
      min-height:42px;
      padding:10px 15px;
      border-radius:14px;
      background:linear-gradient(135deg,var(--reg-primary),var(--reg-primary-2));
      color:#fff;
      border:1px solid transparent;
      cursor:pointer;
      font-weight:900;
      text-decoration:none;
      box-shadow:0 12px 28px rgba(14,116,144,.20);
      transition:transform .16s ease, box-shadow .16s ease, filter .16s ease;
    }
    .btn:hover{color:#fff;transform:translateY(-1px);filter:brightness(1.03);box-shadow:0 18px 38px rgba(14,116,144,.26)}
    .btn.ghost{
      background:var(--reg-surface);
      color:var(--reg-primary);
      border-color:var(--reg-border);
      box-shadow:0 8px 18px rgba(15,23,42,.05);
    }
    .btn.ghost:hover{color:var(--reg-primary);background:var(--reg-surface-soft)}
    html[data-theme="dark"] .btn.ghost{background:#0b1220;color:#bae6fd;border-color:var(--reg-border);box-shadow:none}
    .hint{font-size:13px;color:var(--reg-muted);line-height:1.45}
    .errors{
      padding:12px 14px;
      border-radius:15px;
      margin-bottom:0;
      background:#fff1f2;
      border:1px solid #fecdd3;
      color:#9f1239;
    }
    html[data-theme="dark"] .errors{background:rgba(251,113,133,.12);border-color:rgba(251,113,133,.4);color:#fecdd3}
    .errors ul{margin:0;padding-left:20px}
    .photo-row{display:flex;align-items:center;gap:14px}
    .photo-preview{
      width:98px;
      height:98px;
      border-radius:24px;
      background-size:cover;
      background-position:center;
      border:1px dashed var(--reg-border);
      display:flex;
      align-items:center;
      justify-content:center;
      color:var(--reg-muted);
      background-color:var(--reg-surface-soft);
      flex:0 0 98px;
    }
    .email-preview{
      display:inline-flex;
      align-items:center;
      gap:10px;
      width:max-content;
      max-width:100%;
      padding:10px 13px;
      border-radius:14px;
      background:var(--reg-surface-soft);
      border:1px solid var(--reg-border);
      transition:all .18s ease;
      font-weight:900;
      color:var(--reg-text);
      overflow-wrap:anywhere;
    }
    .email-preview .icon{font-size:14px;color:var(--reg-primary)}
    .email-preview.valid{background:#ecfdf5;border-color:#bbf7d0;color:#065f46;box-shadow:0 12px 24px rgba(5,150,105,.10)}
    .email-preview.invalid{background:#fff7ed;border-color:#fed7aa;color:#9a3412}
    html[data-theme="dark"] .email-preview.valid{background:rgba(52,211,153,.12);border-color:rgba(52,211,153,.34);color:#bbf7d0}
    html[data-theme="dark"] .email-preview.invalid{background:rgba(251,191,36,.12);border-color:rgba(251,191,36,.34);color:#fde68a}
    .avail{
      display:inline-flex;
      align-items:center;
      width:max-content;
      gap:8px;
      padding:7px 11px;
      border-radius:999px;
      font-weight:900;
      margin-top:6px;
      border:1px solid var(--reg-border);
      background:var(--reg-surface-soft);
      color:var(--reg-text);
      font-size:12px;
    }
    .avail.good{background:#ecfdf5;border-color:#bbf7d0;color:#065f46}
    .avail.bad{background:#fff1f2;border-color:#fecdd3;color:#9f1239}
    html[data-theme="dark"] .avail.good{background:rgba(52,211,153,.12);border-color:rgba(52,211,153,.34);color:#bbf7d0}
    html[data-theme="dark"] .avail.bad{background:rgba(251,113,133,.12);border-color:rgba(251,113,133,.40);color:#fecdd3}
    .pw-meter{height:9px;width:100%;background:rgba(148,163,184,.22);border-radius:999px;overflow:hidden;margin-top:7px}
    .pw-meter > div{height:9px;width:0%;background:#ef4444;transition:width .2s ease, background .2s ease}
    .pw-tip{font-size:12px;color:var(--reg-muted);margin-top:6px}
    input[type="password"]::-webkit-textfield-decoration-container,
    input[type="password"]::-webkit-password-reveal-button,
    input[type="password"]::-ms-reveal,
    input[type="password"]::-ms-clear{display:none!important;appearance:none!important;width:0;height:0;margin:0;padding:0;border:0;pointer-events:none}
    input[type="password"]{-moz-appearance:textfield!important}
    .field .toggle-eye{
      position:absolute;
      right:9px;
      z-index:4;
      display:inline-flex;
      align-items:center;
      justify-content:center;
      width:34px;
      height:34px;
      border-radius:11px;
      background:transparent;
      color:var(--reg-muted);
      border:none;
      padding:6px;
      cursor:pointer;
      transition:background .14s ease,color .14s ease;
    }
    .field .toggle-eye:hover{background:rgba(14,165,233,.11);color:var(--reg-primary)}
    .field input[type="password"],.field input[type="text"]{padding-right:52px}
    .flash{padding:12px 14px;border-radius:15px;margin-bottom:0;font-size:14px;font-weight:750}
    .flash.ok{background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46}
    .flash.error{background:#fff1f2;border:1px solid #fecdd3;color:#9f1239}
    html[data-theme="dark"] .flash.ok{background:rgba(52,211,153,.12);border-color:rgba(52,211,153,.34);color:#bbf7d0}
    html[data-theme="dark"] .flash.error{background:rgba(251,113,133,.12);border-color:rgba(251,113,133,.40);color:#fecdd3}
    .terms-note{margin-top:14px;color:var(--reg-muted);font-size:13px;text-align:center}
    .terms-note i{color:var(--reg-primary);margin-right:6px}
    @keyframes pulsePreview{0%{transform:scale(1)}50%{transform:scale(1.025)}100%{transform:scale(1)}}
    .pulse{animation:pulsePreview .38s ease}
    @media (max-width:820px){
      .register-hero.card{grid-template-columns:1fr;padding:22px !important}
      .hero-left{align-items:flex-start}
      .header-actions{justify-content:flex-start}
      .register-theme-toggle .theme-label{display:none}
    }
    @media (max-width:620px){
      .wrap{width:min(100% - 18px,1120px);padding-top:68px}
      .hero-left,.photo-row{flex-direction:column;align-items:flex-start}
      .avatar{width:82px;height:82px;flex-basis:82px;border-radius:22px}
      .card{padding:18px !important;border-radius:19px !important}
      .form-grid{grid-template-columns:1fr;gap:14px}
      .form-grid .full[style*="display:flex"]{align-items:stretch}
      .form-grid .full[style*="display:flex"] .btn{width:100%}
      .register-theme-toggle{right:12px;top:12px}
    }
  </style>
</head>
<body class="student-register-page">
  <button id="themeToggle" class="register-theme-toggle theme-toggle" type="button" data-theme-toggle aria-label="Cambiar modo claro u oscuro" title="Cambiar modo claro u oscuro">
    <i class="fas fa-moon" aria-hidden="true"></i>
    <span class="theme-label">Oscuro</span>
  </button>

  <div class="wrap">
    <?php if (!empty($errors)): ?>
      <div class="card">
        <div class="errors" role="alert">
          <ul><?php foreach ($errors as $err): ?><li><?= esc($err) ?></li><?php endforeach; ?></ul>
        </div>
      </div>
    <?php endif; ?>

    <?php if ($flash): ?>
      <div class="card">
        <div class="flash <?= $flash['type']==='ok'?'ok':'error' ?>"><?= esc($flash['msg']) ?></div>
      </div>
    <?php endif; ?>

    <!-- Header -->
    <div class="card head register-hero">
      <div class="hero-left">
        <div class="avatar"><img id="avatarPreview" src="<?= esc($defaultAvatar) ?>" alt="Avatar"></div>
        <div>
          <div class="register-badge"><i class="fas fa-user-graduate"></i> Alta de estudiante</div>
          <h1 class="name">Registro de alumno</h1>
          <div class="kv">Crea tu cuenta para consultar materias, recursos por tema y exámenes disponibles dentro de KnowLink.</div>
        </div>
      </div>
      <div class="header-actions">
        <a class="btn ghost" href="<?= esc(base_url('login.php')) ?>"><i class="fas fa-arrow-left"></i> Iniciar sesión</a>
      </div>
    </div>

    <form id="registroForm" method="post" enctype="multipart/form-data" novalidate>
      <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">

      <!-- Foto -->
      <div class="card" aria-labelledby="hdr-foto">
        <h3 id="hdr-foto"><i class="fas fa-camera"></i> Foto de perfil</h3>
        <p class="kv">Sube una foto (opcional). JPG/PNG/GIF/WebP, máx 3 MB.</p>
        <div class="form-grid" style="margin-top:12px;">
          <div class="full photo-row">
            <div class="photo-preview" id="preview" style="background-image:url('<?= esc($defaultAvatar) ?>');"></div>
            <div style="flex:1;">
              <label class="field">
                <span class="label">Seleccionar imagen</span>
                <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/gif, image/webp">
                <div class="hint">JPG/PNG/GIF/WEBP — Máx 3MB</div>
              </label>
            </div>
          </div>
        </div>
      </div>

      <!-- Datos personales -->
      <div class="card" aria-labelledby="hdr-datos">
        <h3 id="hdr-datos"><i class="fas fa-id-card"></i> Datos personales</h3>
        <p class="kv">Introduce tu nombre completo, selecciona tu carrera y escribe tu número de control.</p>

        <div class="form-grid" style="margin-top:12px;">
          <label class="field full">
            <span class="label">Nombre completo</span>
            <input type="text" name="nombre" id="nombre" minlength="3" placeholder="Escribe tu nombre completo" required value="<?= esc($old['nombre']) ?>">
          </label>

          <label class="field">
            <span class="label">Carrera</span>
            <select name="carrera" id="carrera" required>
              <option value="">-- Selecciona tu carrera --</option>
              <?php
                if (!empty($carreras_db)) {
                  foreach ($carreras_db as $row) {
                    $idCarr = (int)$row['id'];
                    $nombreCarr = $row['nombre'];
                    $sel = ((string)$old['carrera'] === (string)$idCarr) ? 'selected' : '';
                    echo '<option value="'.esc($idCarr).'" '.$sel.'>'.esc($nombreCarr).'</option>';
                  }
                } else {
                  $fallback = ['Ing. en Sistemas Computacionales','Ing. Industrial','Ing. en Gestión Empresarial','Ing. Electromecánica','Lic. en Administración'];
                  foreach ($fallback as $opt) {
                    $sel = ($old['carrera'] === $opt) ? 'selected' : '';
                    echo '<option '.$sel.'>' . esc($opt) . '</option>';
                  }
                }
              ?>
            </select>
          </label>

          <label class="field">
            <span class="label">Número de control</span>
            <input type="text" name="numero_control" id="numero_control" inputmode="numeric" pattern="\d{8}" maxlength="8" placeholder="Escribe tu número de control" required value="<?= esc($old['numero_control']) ?>">
            <div class="hint">Introduce los 8 dígitos de tu número de control.</div>
          </label>

          <label class="field full">
            <span class="label">Correo institucional</span>
            <input type="hidden" id="correoHidden" name="correo" value="<?= esc($correo_institucional) ?>">
            <div id="correoPreview" class="email-preview <?= ($correo_institucional !== '') ? 'valid' : '' ?>" role="status" aria-live="polite" title="Correo institucional generado">
              <span class="icon"><i class="fas fa-envelope"></i></span>
              <span id="correoPreviewText" class="email-text"><?= esc($correo_institucional !== '' ? $correo_institucional : '—') ?></span>
            </div>
            <small id="correoError" class="hint" style="color:#b00020;display:none;" aria-live="polite"></small>
          </label>
        </div>
      </div>

      <!-- Datos de acceso -->
      <div class="card" aria-labelledby="hdr-access">
        <h3 id="hdr-access"><i class="fas fa-key"></i> Datos de acceso</h3>
        <p class="kv">Define tu nombre de usuario y contraseña (mínimo 8 caracteres).</p>

        <div class="form-grid" style="margin-top:12px;">
          <label class="field">
            <span class="label">Nombre de usuario</span>
            <input type="text" name="username" id="username" minlength="3" placeholder="Escribe tu usuario" required value="<?= esc($old['username']) ?>" autocomplete="off">
            <div id="unameStatus" class="avail" role="status" aria-live="polite" aria-atomic="true" style="display:none;">
              <i class="fas fa-circle-notch fa-spin"></i> Comprobando…
            </div>
            <div class="hint">Mínimo 3 caracteres. Se mostrará como tu identificador.</div>
          </label>

          <label class="field" id="fieldPwd">
            <span class="label">Contraseña</span>
            <input type="password" name="password" id="password" placeholder="Escribe tu contraseña" required minlength="8" autocomplete="new-password" />
            <button type="button" class="toggle-eye" id="togglePwd" aria-label="Mostrar contraseña" title="Mostrar contraseña" aria-pressed="false">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.1"/>
              </svg>
            </button>
            <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
            <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
          </label>

          <label class="field" id="fieldPwd2">
            <span class="label">Confirmar contraseña</span>
            <input type="password" name="password2" id="password2" placeholder="Confirma tu contraseña" required minlength="8" autocomplete="new-password" />
            <button type="button" class="toggle-eye" id="togglePwd2" aria-label="Mostrar contraseña de confirmación" title="Mostrar contraseña" aria-pressed="false">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/>
                <circle cx="12" cy="12" r="3" stroke="currentColor" stroke-width="1.1"/>
              </svg>
            </button>
            <small id="pwMatchHint" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
          </label>

          <div class="full" style="display:flex; gap:8px; align-items:center;">
            <button type="submit" class="btn" id="submitBtn"><i class="fas fa-circle-check"></i> Crear cuenta</button>
            <button type="reset" class="btn ghost"><i class="fas fa-eraser"></i> Limpiar</button>
            <a class="btn ghost" href="<?= esc(base_url('login.php')) ?>"><i class="fas fa-arrow-left"></i> Regresar</a>
          </div>
        </div>
      </div>
    </form>

    <div class="terms-note"><i class="fas fa-shield-halved"></i> Al registrarte aceptas términos y condiciones.</div>
  </div>

<script>
/* ------- Imagen preview ------- */
const fotoInput = document.getElementById('foto');
const preview = document.getElementById('preview');
const defaultAvatar = '<?= esc($defaultAvatar) ?>';
document.addEventListener('DOMContentLoaded', () => { preview.style.backgroundImage = `url('${defaultAvatar}')`; });
fotoInput?.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) { preview.style.backgroundImage = `url('${defaultAvatar}')`; return; }
  if (file.size > 3 * 1024 * 1024) { alert('La imagen excede 3 MB.'); fotoInput.value=''; preview.style.backgroundImage=`url('${defaultAvatar}')`; return; }
  const reader = new FileReader();
  reader.onload = () => preview.style.backgroundImage = `url('${reader.result}')`;
  reader.readAsDataURL(file);
});

/* ------- Correo desde número de control (en vivo) ------- */
const ncInput = document.getElementById('numero_control');
const correoHidden = document.getElementById('correoHidden');
const correoPreview = document.getElementById('correoPreview');
const correoPreviewText = document.getElementById('correoPreviewText');
const correoError = document.getElementById('correoError');

function animatePreview() {
  correoPreview.classList.remove('pulse');
  void correoPreview.offsetWidth;
  correoPreview.classList.add('pulse');
  setTimeout(() => correoPreview.classList.remove('pulse'), 400);
}
function updateCorreoFromControl() {
  if (!ncInput) return;
  let raw = ncInput.value || '';
  raw = raw.replace(/\D/g, '').slice(0,8);
  if (raw !== ncInput.value) ncInput.value = raw;

  const v = raw.trim();
  if (/^\d{8}$/.test(v)) {
    const email = 'L' + v + '@zitacuaro.tecnm.mx';
    correoHidden.value = email;
    correoPreviewText.textContent = email;
    correoPreview.classList.remove('invalid');
    correoPreview.classList.add('valid');
    correoError.style.display = 'none';
    animatePreview();
  } else {
    correoHidden.value = '';
    if (v.length === 0) {
      correoPreviewText.textContent = '—';
      correoPreview.classList.remove('valid','invalid');
      correoError.style.display = 'none';
    } else {
      correoPreviewText.textContent = v.length <= 8 ? ('L' + v + '…') : 'Formato inválido';
      correoPreview.classList.remove('valid');
      correoPreview.classList.add('invalid');
      if (v.length > 8 || /[^\d]/.test(v)) {
        correoError.textContent = 'Formato inválido: solo números, máximo 8 dígitos.';
        correoError.style.display = 'block';
      } else {
        correoError.style.display = 'none';
      }
      animatePreview();
    }
  }
}
ncInput?.addEventListener('input', updateCorreoFromControl);
ncInput?.addEventListener('paste', () => setTimeout(updateCorreoFromControl, 0));
ncInput?.addEventListener('blur', updateCorreoFromControl);

/* ------- Medidor de contraseña ------- */
const password = document.getElementById('password');
const password2 = document.getElementById('password2');
const pwBar = document.getElementById('pwBar');
const pwTip = document.getElementById('pwTip');
const pwMatchHint = document.getElementById('pwMatchHint');

function scorePassword(pw){
  let score = 0;
  if (!pw) return 0;
  const letters = {};
  for (let i=0; i<pw.length; i++) {
    letters[pw[i]] = (letters[pw[i]] || 0) + 1;
    score += 5.0 / letters[pw[i]];
  }
  const variations = { digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
  let vc = 0; for (const k in variations) vc += variations[k] ? 1 : 0;
  score += (vc - 1) * 10;
  return parseInt(score);
}
function updatePwMeter(){
  const val = password.value || '';
  const s = Math.min(100, scorePassword(val));
  pwBar.style.width = Math.max(8, s) + '%';
  if (s < 30){ pwBar.style.background = '#ef4444'; pwTip.textContent = 'Muy débil — añade longitud y símbolos.'; }
  else if (s < 60){ pwBar.style.background = '#f59e0b'; pwTip.textContent = 'Aceptable — usa mayúsculas y números.'; }
  else if (s < 80){ pwBar.style.background = '#10b981'; pwTip.textContent = 'Buena — casi listo.'; }
  else { pwBar.style.background = '#0ea5e9'; pwTip.textContent = 'Fuerte — excelente.'; }
}
password?.addEventListener('input', updatePwMeter);
password2?.addEventListener('input', ()=> {
  pwMatchHint.style.display = (password.value && password2.value && password.value !== password2.value) ? 'block' : 'none';
});

/* ------- Ojo centrado ------- */
let togglePwd = document.getElementById('togglePwd');
let togglePwd2 = document.getElementById('togglePwd2');
function alignEyeToInput(btn, input){
  if (!btn || !input) return;
  const field = input.closest('.field') || input.parentElement || document.body;
  const inRect = input.getBoundingClientRect();
  const fRect  = field.getBoundingClientRect();
  const topPx  = (inRect.top - fRect.top) + (inRect.height / 2);
  btn.style.top = topPx + 'px';
  btn.style.transform = 'translateY(-50%)';
  const pr = parseInt(getComputedStyle(input).paddingRight || '0', 10);
  if (isNaN(pr) || pr < 40) input.style.paddingRight = '52px';
}
function alignAllEyes(){ alignEyeToInput(togglePwd, password); alignEyeToInput(togglePwd2, password2); }
function toggleAction(btn, input){
  if (!btn || !input) return;
  const wasText = input.type === 'text';
  try { input.type = wasText ? 'password' : 'text'; } catch(e){}
  btn.setAttribute('aria-pressed', String(input.type === 'text'));
  btn.setAttribute('aria-label', input.type === 'text' ? 'Ocultar contraseña' : 'Mostrar contraseña');
  input.focus(); alignEyeToInput(btn, input);
}
togglePwd?.addEventListener('click', ()=> toggleAction(togglePwd, password));
togglePwd2?.addEventListener('click', ()=> toggleAction(togglePwd2, password2));
['load','resize','orientationchange'].forEach(ev => window.addEventListener(ev, ()=> setTimeout(alignAllEyes, 30)));
['input','focus','blur','keyup','change'].forEach(ev => {
  password?.addEventListener(ev, ()=> setTimeout(alignAllEyes, 10));
  password2?.addEventListener(ev, ()=> setTimeout(alignAllEyes, 10));
});
document.addEventListener('DOMContentLoaded', ()=> setTimeout(alignAllEyes, 80));

/* ------- Disponibilidad de usuario ------- */
const unameInput = document.getElementById('username');
const unameStatus = document.getElementById('unameStatus');
const submitBtn = document.getElementById('submitBtn');
let unameTimer = null;
let unameOk = false;

function setUnameStatus(state, text, icon){
  unameStatus.style.display = 'inline-flex';
  unameStatus.classList.remove('good','bad');
  if (state === 'good') unameStatus.classList.add('good');
  if (state === 'bad')  unameStatus.classList.add('bad');
  unameStatus.innerHTML = `<i class="fas ${icon}"></i> ${text}`;
}
async function checkUsername(u){
  if (!u || u.trim().length < 3){
    unameOk = false;
    setUnameStatus('', 'Escribe al menos 3 caracteres.', 'fa-info-circle');
    submitBtn && (submitBtn.disabled = true);
    return;
  }
  setUnameStatus('', 'Comprobando…', 'fa-circle-notch fa-spin');
  try{
    const res = await fetch(`?ajax=username&u=${encodeURIComponent(u)}`, {cache:'no-store'});
    const data = await res.json();
    if (data.ok && data.available){
      unameOk = true;
      setUnameStatus('good', 'Disponible', 'fa-check-circle');
      submitBtn && (submitBtn.disabled = false);
    } else {
      unameOk = false;
      setUnameStatus('bad', 'No disponible', 'fa-times-circle');
      submitBtn && (submitBtn.disabled = true);
    }
  }catch(e){
    unameOk = false;
    setUnameStatus('bad', 'Error al comprobar', 'fa-exclamation-triangle');
    submitBtn && (submitBtn.disabled = true);
  }
}
unameInput?.addEventListener('input', ()=>{
  clearTimeout(unameTimer);
  unameTimer = setTimeout(()=> checkUsername(unameInput.value.trim()), 300);
});
document.addEventListener('DOMContentLoaded', ()=> {
  if (unameInput.value.trim().length){ checkUsername(unameInput.value.trim()); }
});

/* ------- Validación final (cliente) ------- */
const form = document.getElementById('registroForm');
form?.addEventListener('submit', (e) => {
  const nc = (ncInput?.value || '').trim();
  if (!/^\d{8}$/.test(nc)) { e.preventDefault(); alert('Introduce un número de control válido (8 dígitos).'); ncInput.focus(); return; }
  const emailVal = correoHidden.value.trim();
  if (!/^[Ll]\d{8}@zitacuaro\.tecnm\.mx$/.test(emailVal)) { e.preventDefault(); alert('Correo institucional inválido generado.'); ncInput.focus(); return; }
  if (!unameOk){ e.preventDefault(); alert('El nombre de usuario no está disponible.'); unameInput.focus(); return; }
  if (password.value.length < 8) { e.preventDefault(); alert('La contraseña debe tener al menos 8 caracteres.'); password.focus(); return; }
  if (password.value !== password2.value) { e.preventDefault(); alert('Las contraseñas no coinciden.'); password2.focus(); return; }
});
</script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= esc(base_url('assets/js/knowlink-theme.js')) ?>?v=20260524-mobile-responsive"></script>
</body>
</html>
