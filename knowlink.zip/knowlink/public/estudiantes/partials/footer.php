<?php
// public/estudiantes/partials/footer.php
$EST_NOTIF_URL = function_exists('base_url') ? base_url('estudiantes/notificaciones.php') : '/estudiantes/notificaciones.php';
?>
    </main>
  </div>

  <!-- Overlay para sidebar móvil -->
  <div id="overlay" style="display:none; position:fixed; inset:0; background:rgba(2,6,23,0.36); z-index:1140;"></div>

  <script>
  (function(){
    function isWide(){ return window.innerWidth >= 1000; }

    // ===== Sidebar + overlay =====
    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const body    = document.body;

    try {
      if (localStorage.getItem('est_sidebar_collapsed') === '1') {
        sidebar.classList.add('collapsed'); body.classList.add('sidebar-collapsed');
      }
    } catch(e){}

    function toggleMenu(){
      if (isWide()) {
        sidebar.classList.toggle('collapsed');
        const collapsed = sidebar.classList.contains('collapsed');
        body.classList.toggle('sidebar-collapsed', collapsed);
        try { localStorage.setItem('est_sidebar_collapsed', collapsed ? '1' : '0'); } catch(e){}
        menuBtn?.setAttribute('aria-expanded', String(!collapsed));
      } else {
        sidebar.classList.toggle('open');
        const isOpen = sidebar.classList.contains('open');
        overlay.style.display = isOpen ? 'block' : 'none';
        body.classList.toggle('sidebar-open', isOpen);
        menuBtn?.setAttribute('aria-expanded', String(isOpen));
      }
    }
    menuBtn?.addEventListener('click', function(e){ e.stopPropagation(); toggleMenu(); });
    overlay?.addEventListener('click', function(){
      sidebar.classList.remove('open'); overlay.style.display='none'; body.classList.remove('sidebar-open');
      menuBtn?.setAttribute('aria-expanded','false');
    });

    // ===== User menu (hover + pin con click) =====
    const userArea = document.getElementById('userArea');
    const userBtn  = document.getElementById('userDropdownBtn');
    const userMenu = document.getElementById('userMenu');
    let userSticky = false, userHoverTimer;

    function openUser(sticky=false){
      userMenu.setAttribute('aria-hidden','false');
      userBtn.setAttribute('aria-expanded','true');
      userArea.classList.add('open');
      if (sticky) userSticky = true;
    }
    function closeUser(){
      userMenu.setAttribute('aria-hidden','true');
      userBtn.setAttribute('aria-expanded','false');
      userArea.classList.remove('open');
      userSticky = false;
    }
    function isUserOpen(){ return userMenu.getAttribute('aria-hidden')==='false'; }

    userArea?.addEventListener('mouseenter', ()=>{
      if (!isWide()) return;
      clearTimeout(userHoverTimer);
      if (!userSticky) openUser(false);
    });
    userArea?.addEventListener('mouseleave', ()=>{
      if (!isWide()) return;
      userHoverTimer = setTimeout(()=>{ if (!userSticky) closeUser(); }, 150);
    });
    userBtn?.addEventListener('click', (e)=>{
      e.stopPropagation();
      if (isUserOpen() && userSticky) closeUser(); else openUser(true);
    });
    document.addEventListener('click',(e)=>{ if (userArea && !userArea.contains(e.target)) closeUser(); });
    document.addEventListener('keydown',(e)=>{ if (e.key==='Escape') closeUser(); });

    // ===== Notificaciones (hover + pin con click) =====
    const notifArea  = document.getElementById('notifArea');
    const notifBtn   = document.getElementById('notifBtn');
    const notifMenu  = document.getElementById('notifMenu');
    const notifList  = document.getElementById('notifList');
    const notifBadge = document.getElementById('notifBadge');
    const NOTIF_URL  = <?= json_encode($EST_NOTIF_URL) ?>;

    let notifSticky=false, notifHoverTimer;
    let maxFetchedId = 0;

    // Usamos localStorage para el último id visto (clave separada para estudiante)
    function getLastSeen(){
      const v = parseInt(localStorage.getItem('est_notif_last_seen')||'0',10);
      return Number.isFinite(v) && v>0 ? v : 0;
    }
    function setLastSeen(id){
      try{ localStorage.setItem('est_notif_last_seen', String(id||0)); }catch(e){}
    }
    let lastSeenId = getLastSeen();

    function openNotif(sticky=false){
      notifMenu.setAttribute('aria-hidden','false');
      notifBtn.setAttribute('aria-expanded','true');
      notifArea.classList.add('open');
      if (sticky) notifSticky = true;
      // Al abrir, marcamos como vistas las cargadas
      if (maxFetchedId > lastSeenId){
        setLastSeen(maxFetchedId);
        lastSeenId = maxFetchedId;
        updateBadge(0);
      }
    }
    function closeNotif(){
      notifMenu.setAttribute('aria-hidden','true');
      notifBtn.setAttribute('aria-expanded','false');
      notifArea.classList.remove('open');
      notifSticky = false;
    }
    function isNotifOpen(){ return notifMenu.getAttribute('aria-hidden')==='false'; }

    notifArea?.addEventListener('mouseenter', ()=>{
      // en pantallas muy chicas evitamos hover (se usa tap)
      if (window.innerWidth < 680) return;
      clearTimeout(notifHoverTimer);
      if (!notifSticky) openNotif(false);
    });
    notifArea?.addEventListener('mouseleave', ()=>{
      if (window.innerWidth < 680) return;
      notifHoverTimer = setTimeout(()=>{ if (!notifSticky) closeNotif(); }, 150);
    });
    notifBtn?.addEventListener('click', (e)=>{
      e.stopPropagation();
      if (isNotifOpen() && notifSticky) closeNotif(); else openNotif(true);
    });
    document.addEventListener('click', (e)=>{
      if (notifArea && !notifArea.contains(e.target)) closeNotif();
    });
    document.addEventListener('keydown',(e)=>{ if (e.key==='Escape') closeNotif(); });

    function escapeHtml(s){
      return (s ?? '').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
    }
    function iconFor(tipo){
      switch(String(tipo||'')){
        case 'tema_nuevo': return 'fa-book-open';
        default:           return 'fa-bell';
      }
    }
    function renderNotifications(items){
      if (!notifList) return;
      if (!items || !items.length){
        notifList.innerHTML = '<div class="notif-empty">Sin novedades por ahora.</div>';
        return;
      }
      let html = '';
      maxFetchedId = 0;
      for (const it of items){
        const id      = parseInt(it.id||0,10) || 0;
        if (id > maxFetchedId) maxFetchedId = id;
        const icon    = iconFor(it.tipo);
        const titulo  = it.titulo ? escapeHtml(it.titulo) : '(sin título)';
        const mat     = it.materia_clave ? escapeHtml(it.materia_clave) : '';
        const fecha   = escapeHtml(it.creado_en_fmt || it.creado_en || '');
        html += `
          <div class="notif-item" data-id="${id}">
            <div class="ico"><i class="fas ${icon}"></i></div>
            <div class="txt">
              <div><strong>${it.tipo==='tema_nuevo'?'Nuevo tema':'Notificación'}:</strong> ${titulo}</div>
              <div class="meta">${mat}${mat && fecha ? ' · ' : ''}${fecha}</div>
            </div>
          </div>`;
      }
      notifList.innerHTML = html;
    }
    function updateBadge(total){
      if (!notifBadge) return;
      if (total > 0){ notifBadge.style.display='inline-block'; notifBadge.textContent = (total>99 ? '99+' : String(total)); }
      else { notifBadge.style.display='none'; }
    }
    async function fetchNotifications(){
      try{
        const res = await fetch(NOTIF_URL + '?since_id=' + encodeURIComponent(lastSeenId), {cache:'no-store'});
        if (!res.ok) return;
        const data = await res.json();
        renderNotifications(data.items || []);
        const total = parseInt(data.total || 0, 10) || 0;
        if (isNotifOpen() && maxFetchedId > lastSeenId){
          setLastSeen(maxFetchedId); lastSeenId = maxFetchedId; updateBadge(0);
        } else {
          updateBadge(total);
        }
      }catch(e){}
    }

    // Carga inicial + polling
    fetchNotifications();
    setInterval(fetchNotifications, 10000);
  })();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/js/knowlink-theme.js') : '/assets/js/knowlink-theme.js', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive"></script>
</body>
</html>
