<?php
// public/estudiantes/recurso.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';
require_once __DIR__ . '/../../src/asset_paths.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'estudiante') { http_response_code(403); echo "Acceso denegado"; exit; }

$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

// === Mantén el menú activo según lo último usado ===
$origin  = (string)($_SESSION['student_last_menu'] ?? 'en_curso');
$allowed = ['en_curso','buscar','grupos','cursos'];
if (!in_array($origin,$allowed,true)) $origin = 'en_curso';
$active = $origin;

function escx($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/* ========= URLs de recursos ========= */
function safe_external_or_local_url(?string $u): string {
  $u = trim((string)$u);
  if ($u === '') return '';
  $u = str_replace('\\', '/', $u);
  if (preg_match('#^https?://#i', $u)) return $u;
  return '/' . ltrim($u, '/');
}
function asset_open_url(int $id): string {
  return kl_asset_stream_url($id, 'open');
}
function asset_download_url(int $id): string {
  return kl_asset_stream_url($id, 'download');
}
function text_open_url(int $id): string {
  return base_url('estudiantes/texto.php?id=' . $id);
}

/* ========= PRG: si llega por POST con token, valida y redirige (GET) ========= */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $token = (string)($_POST['token'] ?? '');
  if ($token === '' || empty($_SESSION['contenido_view_tokens'][$token])) {
    http_response_code(400);
    echo "Acceso inválido (falta token).";
    exit;
  }
  $T = $_SESSION['contenido_view_tokens'][$token];
  if (($T['exp'] ?? 0) < time()) {
    unset($_SESSION['contenido_view_tokens'][$token]);
    http_response_code(400);
    echo "Enlace expirado. Regresa y vuelve a abrir el recurso.";
    exit;
  }
  $contenido_id = (int)($T['contenido_id'] ?? 0);
  if ($contenido_id <= 0) { http_response_code(400); echo "Token inválido."; exit; }

  $back = is_array($T['back'] ?? null) ? $T['back'] : [];
  $originPost = (string)($_POST['origin'] ?? '');
  if (in_array($originPost, ['en_curso','buscar','grupos','cursos'], true)) {
    $back['origin'] = $originPost;
  }

  // Guarda en sesión (válido 5 min) y redirige para evitar “reenvío del formulario”.
  // Además guarda el contexto de regreso para volver a la misma materia y unidad.
  $_SESSION['last_recurso_view'] = [
    'id' => $contenido_id,
    'back' => $back,
    'exp' => time()+300,
  ];
  redirect(base_url('estudiantes/recurso.php')); // GET limpio
  exit;
}

/* ========= GET: usa el id almacenado por PRG ========= */
$lastRecursoView = is_array($_SESSION['last_recurso_view'] ?? null) ? $_SESSION['last_recurso_view'] : [];
$contenido_id = (int)($lastRecursoView['id'] ?? 0);
$exp          = (int)($lastRecursoView['exp'] ?? 0);
$backContext  = is_array($lastRecursoView['back'] ?? null) ? $lastRecursoView['back'] : [];
if ($contenido_id <= 0 || $exp < time()) {
  http_response_code(400);
  echo "No se encontró un recurso activo para mostrar. Vuelve a abrirlo desde la lista.";
  exit;
}

// ====== CARGAR CONTENIDO + DOCENTE/UNIDAD/MATERIA ======
$sqlC = "
  SELECT
    c.id, c.titulo, c.descripcion, c.visibilidad, c.creado_en, c.actualizado_en,
    t.id   AS tema_id, t.titulo AS tema_titulo,
    u.id   AS docente_user_id, u.nombre AS docente_nombre, u.apellidos AS docente_apellidos,
    uu.id  AS unidad_id, uu.numero AS unidad_numero, uu.titulo AS unidad_titulo,
    m.clave AS materia_clave, m.nombre AS materia_nombre
  FROM contenidos c
  JOIN temas t          ON t.id = c.tema_id
  JOIN unidades uu      ON uu.id = t.unidad_id
  JOIN materias m       ON LOWER(m.clave) = LOWER(uu.materia_clave)
  JOIN docentes d       ON d.usuario_id = c.docente_id
  JOIN usuarios u       ON u.id = d.usuario_id
  WHERE c.id = :id
  LIMIT 1
";
$st = $pdo->prepare($sqlC);
$st->execute([':id'=>$contenido_id]);
$C = $st->fetch(PDO::FETCH_ASSOC);

if (!$C) { http_response_code(404); echo "Recurso no encontrado."; exit; }
if (!in_array(($C['visibilidad'] ?? ''), ['publico','solo_estudiantes'], true)) {
  http_response_code(403); echo "Este recurso no está disponible para estudiantes."; exit;
}

// ====== ACTIVOS/ARCHIVOS DEL CONTENIDO ======
$activos = [];
try {
  $q = $pdo->prepare("
    SELECT id, tipo, titulo, url, texto_largo, metadata, orden, creado_en
    FROM contenido_activos
    WHERE contenido_id = :cid
    ORDER BY orden ASC, id ASC
  ");
  $q->execute([':cid'=>$contenido_id]);
  $activos = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) {
  $activos = [];
}

// ====== UI helpers ======
function tipo_icon(string $t): string {
  $t = strtolower($t);
  return match ($t) {
    'pdf'        => 'fa-file-pdf',
    'word'       => 'fa-file-word',
    'imagen'     => 'fa-image',
    'texto'      => 'fa-file-lines',
    'enlace'     => 'fa-link',
    'video'      => 'fa-video',
    'powerpoint' => 'fa-file-powerpoint',
    'excel'      => 'fa-file-excel',
    default      => 'fa-file',
  };
}

function tipo_label(string $t): string {
  $t = strtolower($t);
  return match ($t) {
    'pdf'        => 'PDF',
    'word'       => 'Word',
    'imagen'     => 'Imagen',
    'texto'      => 'Texto',
    'enlace'     => 'Enlace',
    'video'      => 'Video',
    'powerpoint' => 'PowerPoint',
    'excel'      => 'Excel',
    default      => 'Archivo',
  };
}

function tipo_note(string $t): string {
  $t = strtolower($t);
  return match ($t) {
    'pdf'        => 'Documento PDF disponible para consulta.',
    'word'       => 'Documento de Word disponible para consulta o descarga.',
    'imagen'     => 'Imagen adjunta al tema.',
    'texto'      => 'Texto de apoyo del tema.',
    'enlace'     => 'Enlace externo relacionado con el tema.',
    'video'      => 'Video de apoyo para reforzar el contenido.',
    'powerpoint' => 'Presentación adjunta para estudiar el tema.',
    'excel'      => 'Hoja de cálculo adjunta al tema.',
    default      => 'Archivo adjunto disponible para consulta.',
  };
}

$backOrigin = (string)($backContext['origin'] ?? $origin);
if (!in_array($backOrigin, ['en_curso','buscar','grupos','cursos'], true)) $backOrigin = 'en_curso';
$origin = $backOrigin;
$active = $origin;
$_SESSION['student_last_menu'] = $origin;

$backFocusUnidadId = (int)($backContext['unidad_id'] ?? ($C['unidad_id'] ?? 0));
$backMateriaClave = (string)($backContext['materia_clave'] ?? ($C['materia_clave'] ?? ''));
$backToken = bin2hex(random_bytes(16));

if (!isset($_SESSION['materia_view_tokens']) || !is_array($_SESSION['materia_view_tokens'])) {
  $_SESSION['materia_view_tokens'] = [];
}
if (!isset($_SESSION['rm_view_tokens']) || !is_array($_SESSION['rm_view_tokens'])) {
  $_SESSION['rm_view_tokens'] = [];
}

if (($backContext['mode'] ?? '') === 'rm' && (int)($backContext['reticula_materia_id'] ?? 0) > 0) {
  $_SESSION['rm_view_tokens'][$backToken] = [
    'rm_id' => (int)$backContext['reticula_materia_id'],
    'exp' => time() + 300,
  ];
} else {
  $_SESSION['materia_view_tokens'][$backToken] = [
    'materia_clave' => $backMateriaClave,
    'exp' => time() + 300,
  ];
}

$title = 'Recurso · ' . ($C['titulo'] ?: 'Contenido');
require __DIR__ . '/partials/header.php';
?>
<style>
  :root{
    --res-bg:#ffffff;
    --res-panel:#ffffff;
    --res-panel-soft:#f8fafc;
    --res-text:#0b2545;
    --res-muted:#64748b;
    --res-line:#e6eef2;
    --res-accent:#0891b2;
    --res-accent-2:#0f766e;
    --res-shadow:0 12px 28px rgba(15,23,42,.08);
  }

  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .qa form{margin:0}
  .page-title{font-size:20px;font-weight:900;color:var(--res-text);letter-spacing:-.02em}
  .page-sub{color:var(--res-muted);font-size:14px;line-height:1.55}

  .card{
    background:var(--res-panel);
    border-radius:22px;
    padding:18px;
    box-shadow:var(--res-shadow);
    border:1px solid var(--res-line);
    margin-bottom:18px;
  }
  .muted{color:var(--res-muted)}
  .pill{display:inline-flex;align-items:center;gap:6px;padding:4px 9px;border-radius:999px;border:1px solid #dbeafe;background:#eff6ff;color:#0369a1;font-size:12px;font-weight:800}

  .btn{padding:10px 14px;border-radius:13px;border:1px solid var(--res-line);background:#fff;color:var(--res-text);font-weight:900;cursor:pointer;transition:transform .16s ease,box-shadow .16s ease,background .16s ease,border-color .16s ease,color .16s ease}
  .btn:hover{background:#f5f8ff;color:#0284c7;transform:translateY(-1px);box-shadow:0 10px 22px rgba(15,23,42,.08)}
  .btn.primary{background:linear-gradient(135deg,#0ea5e9,#0f766e);border:0;color:#fff;box-shadow:0 12px 24px rgba(14,165,233,.18)}
  .btn.small{padding:9px 13px;border-radius:12px}
  .btn-icon{display:inline-flex;gap:8px;align-items:center;justify-content:center}
  a.btn{text-decoration:none}

  .resource-section-title{font-size:18px;margin:0 0 14px;color:var(--res-text);display:flex;align-items:center;gap:10px;font-weight:950;letter-spacing:-.02em}
  .resource-section-title i{color:#0284c7}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(265px,1fr));gap:16px}

  .asset{
    position:relative;
    border:1px solid var(--res-line);
    border-radius:22px;
    background:var(--res-bg);
    overflow:hidden;
    display:flex;
    flex-direction:column;
    min-height:310px;
    box-shadow:0 14px 30px rgba(15,23,42,.08);
    transition:transform .18s ease,box-shadow .18s ease,border-color .18s ease;
  }
  .asset:hover{transform:translateY(-3px);box-shadow:0 18px 42px rgba(15,23,42,.13);border-color:rgba(14,165,233,.36)}
  .asset .badge-file{
    position:absolute;
    top:12px;
    right:12px;
    z-index:2;
    padding:5px 10px;
    border-radius:999px;
    background:rgba(255,255,255,.88);
    border:1px solid rgba(148,163,184,.22);
    color:#334155;
    font-size:11px;
    font-weight:950;
    letter-spacing:.04em;
    text-transform:uppercase;
    backdrop-filter:blur(8px);
  }
  .asset .thumb{
    height:145px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:linear-gradient(180deg,#f8fbff,#eef5fb);
    border-bottom:1px solid var(--res-line);
    padding:18px;
  }
  .asset .thumb-icon{
    width:82px;
    height:82px;
    border-radius:22px;
    display:flex;
    align-items:center;
    justify-content:center;
    background:#fff;
    border:1px solid #dbeafe;
    box-shadow:0 12px 24px rgba(15,23,42,.08);
  }
  .asset .thumb i{font-size:38px;color:#335276;opacity:.95}
  .asset .body{padding:15px;display:flex;flex-direction:column;gap:9px;flex:1}
  .asset .title{font-weight:950;color:var(--res-text);line-height:1.35;word-break:break-word;font-size:1rem}
  .asset .resource-note{font-size:13px;line-height:1.45;color:var(--res-muted);word-break:break-word}
  .asset .actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:auto;padding-top:8px}

  .text-box{white-space:pre-wrap;border:1px dashed var(--res-line);background:var(--res-panel-soft);border-radius:14px;padding:12px;color:#0f172a;max-height:220px;overflow:auto}
  .img-fit{width:100%;height:100%;object-fit:cover;border-radius:16px}

  .empty{color:var(--res-muted);border:1px dashed var(--res-line);border-radius:16px;padding:14px;background:var(--res-panel-soft)}
  .toast{position:fixed;right:12px;bottom:12px;background:#0b2545;color:#fff;padding:10px 12px;border-radius:10px;box-shadow:0 10px 30px rgba(2,6,23,.18);display:none;z-index:9999}
  .toast.show{display:block;animation:fade .15s ease-out}
  @keyframes fade{from{opacity:0;transform:translateY(4px)}to{opacity:1;transform:none}}

  .asset.tipo-pdf .thumb-icon{background:linear-gradient(180deg,#fff5f5,#ffffff);border-color:#fecaca}
  .asset.tipo-pdf .thumb i{color:#b91c1c}
  .asset.tipo-word .thumb-icon{background:linear-gradient(180deg,#eff6ff,#ffffff);border-color:#bfdbfe}
  .asset.tipo-word .thumb i{color:#1d4ed8}
  .asset.tipo-excel .thumb-icon{background:linear-gradient(180deg,#ecfdf5,#ffffff);border-color:#bbf7d0}
  .asset.tipo-excel .thumb i{color:#15803d}
  .asset.tipo-powerpoint .thumb-icon{background:linear-gradient(180deg,#fff7ed,#ffffff);border-color:#fed7aa}
  .asset.tipo-powerpoint .thumb i{color:#c2410c}

  html[data-theme="dark"]{
    --res-bg:linear-gradient(180deg,rgba(15,31,54,.96),rgba(8,18,34,.98));
    --res-panel:rgba(8,18,34,.72);
    --res-panel-soft:rgba(15,31,54,.78);
    --res-text:#eef6ff;
    --res-muted:#aebed2;
    --res-line:rgba(148,163,184,.18);
    --res-shadow:0 18px 44px rgba(0,0,0,.28);
  }

  html[data-theme="dark"] .page-title,
  html[data-theme="dark"] .resource-section-title,
  html[data-theme="dark"] section.card[aria-label="Recursos"] h3{color:#f8fafc !important}
  html[data-theme="dark"] .page-sub{color:#c7d2e3}
  html[data-theme="dark"] section.card > div[style*="color:#334155"]{color:#dbeafe !important}
  html[data-theme="dark"] .muted{color:#aebed2 !important}

  html[data-theme="dark"] .card{
    background:linear-gradient(180deg,rgba(8,18,34,.74),rgba(7,15,29,.82)) !important;
    border-color:rgba(125,211,252,.16) !important;
    box-shadow:0 18px 48px rgba(0,0,0,.28), inset 0 1px 0 rgba(255,255,255,.04);
  }
  html[data-theme="dark"] .pill{
    background:rgba(14,165,233,.13) !important;
    border-color:rgba(125,211,252,.24) !important;
    color:#bae6fd !important;
  }

  html[data-theme="dark"] .asset{
    background:linear-gradient(180deg,rgba(15,31,54,.98),rgba(8,18,34,.98)) !important;
    border-color:rgba(125,211,252,.16) !important;
    box-shadow:0 18px 42px rgba(0,0,0,.34), inset 0 1px 0 rgba(255,255,255,.035);
  }
  html[data-theme="dark"] .asset:hover{
    border-color:rgba(56,189,248,.42) !important;
    box-shadow:0 22px 54px rgba(0,0,0,.48),0 0 0 1px rgba(56,189,248,.06) inset;
  }
  html[data-theme="dark"] .asset .thumb{
    background:
      radial-gradient(circle at 50% 0%,rgba(56,189,248,.16),transparent 58%),
      linear-gradient(180deg,rgba(17,39,69,.96),rgba(10,24,44,.98)) !important;
    border-bottom-color:rgba(148,163,184,.16) !important;
  }
  html[data-theme="dark"] .asset .thumb-icon{
    background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035)) !important;
    border-color:rgba(125,211,252,.20) !important;
    box-shadow:0 14px 28px rgba(0,0,0,.28);
  }
  html[data-theme="dark"] .asset .thumb i{color:#d9e8ff !important;opacity:1}
  html[data-theme="dark"] .asset .title{color:#f8fafc !important}
  html[data-theme="dark"] .asset .resource-note{color:#aebed2 !important}
  html[data-theme="dark"] .asset .badge-file{
    background:rgba(15,23,42,.72) !important;
    color:#cfe8ff !important;
    border-color:rgba(125,211,252,.18) !important;
  }
  html[data-theme="dark"] .asset.tipo-pdf .thumb-icon{
    background:linear-gradient(180deg,rgba(248,113,113,.16),rgba(255,255,255,.035)) !important;
    border-color:rgba(248,113,113,.22) !important;
  }
  html[data-theme="dark"] .asset.tipo-pdf .thumb i{color:#fecaca !important}
  html[data-theme="dark"] .asset.tipo-word .thumb i{color:#bfdbfe !important}
  html[data-theme="dark"] .asset.tipo-excel .thumb i{color:#bbf7d0 !important}
  html[data-theme="dark"] .asset.tipo-powerpoint .thumb i{color:#fed7aa !important}

  html[data-theme="dark"] .btn{
    background:rgba(255,255,255,.055) !important;
    border-color:rgba(148,163,184,.18) !important;
    color:#e8f1ff !important;
    box-shadow:none;
  }
  html[data-theme="dark"] .btn:hover{
    background:rgba(255,255,255,.095) !important;
    color:#ffffff !important;
    border-color:rgba(125,211,252,.28) !important;
  }
  html[data-theme="dark"] .btn.primary{
    background:linear-gradient(135deg,#0ea5e9,#0f766e) !important;
    color:#ffffff !important;
    border:0 !important;
    box-shadow:0 14px 30px rgba(14,165,233,.18) !important;
  }
  html[data-theme="dark"] .text-box{
    background:rgba(15,31,54,.92) !important;
    border-color:rgba(148,163,184,.22) !important;
    color:#eaf2ff !important;
  }
  html[data-theme="dark"] .empty{
    background:rgba(15,31,54,.62) !important;
    border-color:rgba(148,163,184,.20) !important;
    color:#aebed2 !important;
  }

  @media (max-width:768px){
    .page-header{align-items:flex-start;flex-direction:column}
    .grid{grid-template-columns:1fr;gap:12px}
    .asset{min-height:auto;border-radius:20px}
    .asset .thumb{height:124px}
    .asset .thumb-icon{width:72px;height:72px;border-radius:18px}
    .asset .thumb i{font-size:32px}
    .asset .actions{flex-direction:row}
    .asset .actions .btn{flex:1;min-width:118px}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= escx($C['titulo'] ?: 'Contenido') ?></div>
    <div class="page-sub">
      <?= escx($C['materia_nombre'] ?? '') ?> · Unidad <?= (int)($C['unidad_numero'] ?? 0) ?> — <?= escx($C['unidad_titulo'] ?? '') ?>
      <span class="pill" style="margin-left:8px;"><i class="fas fa-user"></i><?= escx(trim(($C['docente_nombre'] ?? '').' '.($C['docente_apellidos'] ?? ''))) ?></span>
    </div>
  </div>
  <div class="qa">
    <form method="post" action="<?= escx(base_url('estudiantes/ver_materia.php')) ?>">
      <input type="hidden" name="csrf" value="<?= escx($CSRF) ?>">
      <input type="hidden" name="token" value="<?= escx($backToken) ?>">
      <input type="hidden" name="origin" value="<?= escx($origin) ?>">
      <input type="hidden" name="focus_unidad_id" value="<?= (int)$backFocusUnidadId ?>">
      <button class="btn btn-icon" type="submit">
        <i class="fas fa-arrow-left"></i><span class="label">Volver</span>
      </button>
    </form>
  </div>
</div>

<section class="card">
  <?php if (!empty($C['descripcion'])): ?>
    <div style="font-size:14px;color:#334155;margin-bottom:8px;"><?= escx($C['descripcion']) ?></div>
  <?php endif; ?>
  <div class="muted" style="font-size:12px;">
    Publicado: <?= escx(date('d/m/Y H:i', strtotime((string)$C['creado_en'] ?? 'now'))) ?>
    <?php if (!empty($C['actualizado_en'])): ?>
      · Actualizado: <?= escx(date('d/m/Y H:i', strtotime((string)$C['actualizado_en']))) ?>
    <?php endif; ?>
  </div>
</section>

<section class="card" aria-label="Recursos">
  <h3 class="resource-section-title"><i class="fas fa-folder-open"></i> Recursos adjuntos</h3>

  <?php if (!$activos): ?>
    <div class="empty">Este contenido aún no tiene recursos adjuntos.</div>
  <?php else: ?>
    <div class="grid">
      <?php foreach ($activos as $a):
        $tipo   = strtolower((string)($a['tipo'] ?? 'otro'));
        $icon   = tipo_icon($tipo);
        $titulo = trim((string)($a['titulo'] ?? 'Recurso'));
        $assetId = (int)($a['id'] ?? 0);
        $rawUrl  = trim((string)($a['url'] ?? ''));
        $url     = $tipo === 'enlace' ? safe_external_or_local_url($rawUrl) : ($assetId > 0 ? asset_open_url($assetId) : '');
        $downloadUrl = ($assetId > 0 ? asset_download_url($assetId) : '');
        $textUrl = ($assetId > 0 ? text_open_url($assetId) : '');
        $texto  = (string)($a['texto_largo'] ?? '');
        $meta   = (string)($a['metadata'] ?? '');
        $isLink = ($tipo === 'enlace');
        $tipoClass = preg_replace('/[^a-z0-9_-]/i', '', $tipo) ?: 'archivo';
        $tipoLabel = tipo_label($tipo);
        $tipoNote  = tipo_note($tipo);
      ?>
      <article class="asset tipo-<?= escx($tipoClass) ?>">
        <span class="badge-file"><?= escx($tipoLabel) ?></span>
        <div class="thumb">
          <?php if ($tipo === 'imagen' && $url !== ''): ?>
            <img class="img-fit" src="<?= escx($url) ?>" alt="<?= escx($titulo ?: 'Imagen') ?>">
          <?php else: ?>
            <span class="thumb-icon"><i class="fas <?= escx($icon) ?>"></i></span>
          <?php endif; ?>
        </div>
        <div class="body">
          <div class="title"><?= escx($titulo ?: $tipoLabel) ?></div>

          <div class="resource-note"><?= escx($tipoNote) ?></div>

          <div class="actions">
            <?php if ($tipo === 'texto' && $texto !== '' && $textUrl !== ''): ?>
              <a class="btn small btn-icon primary" href="<?= escx($textUrl) ?>">
                <i class="fas fa-up-right-from-square"></i><span class="label">Abrir texto</span>
              </a>
            <?php elseif ($url !== ''): ?>
              <a class="btn small btn-icon primary" href="<?= escx($url) ?>" target="_blank" rel="noopener">
                <i class="fas fa-up-right-from-square"></i><span class="label">Abrir</span>
              </a>

              <?php if ($isLink): ?>
                <button class="btn small btn-icon" type="button" data-copy="<?= escx($url) ?>">
                  <i class="fas fa-copy"></i><span class="label">Copiar enlace</span>
                </button>
              <?php endif; ?>

              <?php
                $canDownload = in_array($tipo, ['pdf','word','excel','powerpoint','imagen','video','otro'], true) && $downloadUrl !== '';
                if ($canDownload):
              ?>
                <a class="btn small btn-icon" href="<?= escx($downloadUrl) ?>">
                  <i class="fas fa-download"></i><span class="label">Descargar</span>
                </a>
              <?php endif; ?>
            <?php endif; ?>
          </div>

          <?php if ($meta !== ''): ?>
            <details style="margin-top:4px;">
              <summary class="muted" style="cursor:pointer">Metadatos</summary>
              <pre class="text-box" style="max-height:140px"><?= escx($meta) ?></pre>
            </details>
          <?php endif; ?>
        </div>
      </article>
      <?php endforeach; ?>
    </div>
  <?php endif; ?>
</section>

<div id="toast" class="toast">Copiado</div>

<script>
(function(){
  const toast = document.getElementById('toast');
  function showToast(msg){
    if(!toast) return;
    toast.textContent = msg || 'Copiado';
    toast.classList.add('show');
    setTimeout(()=>toast.classList.remove('show'), 1200);
  }
  document.querySelectorAll('[data-copy]').forEach(btn=>{
    btn.addEventListener('click', async ()=>{
      const txt = btn.getAttribute('data-copy') || '';
      try{
        await navigator.clipboard.writeText(txt);
        showToast('Enlace copiado');
      }catch(e){
        showToast('No se pudo copiar');
      }
    });
  });
})();
</script>

<?php require __DIR__ . '/partials/footer.php';
