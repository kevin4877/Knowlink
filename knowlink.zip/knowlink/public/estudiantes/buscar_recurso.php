<?php
// public/estudiantes/buscar_recurso.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo || ($yo['rol'] ?? '') !== 'estudiante') {
  redirect(base_url('login.php'));
  exit;
}

// Seguridad básica
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/** Portada SVG para materias */
function materia_cover_svg(string $clave, string $nombre=''): string {
  $txt = strtoupper($clave ?: 'MAT');
  $siglas = preg_replace('/[^A-Z0-9]/', '', $txt);
  if ($siglas === '') $siglas = 'MAT';
  $hash = crc32($siglas);
  $h = $hash % 360;
  $h2 = ($h + 30) % 360;
  $title = htmlspecialchars($nombre ?: $siglas, ENT_QUOTES, 'UTF-8');
  $svg = <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360" role="img" aria-label="{$title}">
  <defs>
    <linearGradient id="g{$hash}" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="hsl({$h},75%,62%)"/>
      <stop offset="1" stop-color="hsl({$h2},82%,64%)"/>
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#g{$hash})"/>
  <g fill="rgba(255,255,255,0.18)">
    <circle cx="520" cy="90" r="80"/>
    <circle cx="120" cy="300" r="90"/>
    <rect x="420" y="230" width="120" height="24" rx="12"/>
  </g>
  <text x="50%" y="52%" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="92" font-weight="900" fill="#ffffff" opacity="0.96">{$siglas}</text>
</svg>
SVG;
  return 'data:image/svg+xml;utf8,'.rawurlencode($svg);
}


/** Estilo visual local para portadas de materias: no carga imágenes externas. */
function materia_cover_style(string $clave, string $nombre=''): string {
  $texto = mb_strtolower(trim($clave.' '.$nombre), 'UTF-8');
  $palettes = [
    ['#0ea5e9','#2563eb','#1e3a8a','#e0f2fe'], // azul
    ['#22c55e','#16a34a','#065f46','#dcfce7'], // verde
    ['#f97316','#ea580c','#7c2d12','#ffedd5'], // naranja
    ['#a855f7','#7c3aed','#3b0764','#f3e8ff'], // morado
    ['#ec4899','#be185d','#831843','#fce7f3'], // rosa
    ['#14b8a6','#0f766e','#134e4a','#ccfbf1'], // teal
    ['#f59e0b','#d97706','#78350f','#fef3c7'], // ámbar
    ['#06b6d4','#0284c7','#164e63','#cffafe'], // cyan
    ['#ef4444','#dc2626','#7f1d1d','#fee2e2'], // rojo
    ['#64748b','#334155','#0f172a','#e2e8f0'], // slate
    ['#6366f1','#4f46e5','#312e81','#e0e7ff'], // indigo
    ['#84cc16','#65a30d','#365314','#ecfccb'], // lima
  ];
  $keywords = [
    'program' => 10, 'software' => 10, 'datos' => 7, 'redes' => 7, 'sistemas' => 10,
    'calculo' => 0, 'matemat' => 0, 'algebra' => 10, 'estad' => 3, 'fisica' => 7,
    'quimica' => 5, 'biologia' => 1, 'microbiologia' => 5, 'alimentos' => 11,
    'administr' => 3, 'gestion' => 4, 'contabilidad' => 6, 'financ' => 6,
    'mercado' => 4, 'costos' => 6, 'civil' => 2, 'constru' => 2, 'arquitect' => 9,
    'electr' => 8, 'mecanica' => 9, 'hidraulica' => 0, 'agric' => 1, 'frut' => 11,
    'investig' => 9, 'etica' => 4, 'calidad' => 1,
  ];
  $idx = abs((int)crc32($clave ?: $nombre)) % count($palettes);
  foreach ($keywords as $kw => $forced) {
    if ($kw !== '' && mb_strpos($texto, $kw, 0, 'UTF-8') !== false) { $idx = $forced; break; }
  }
  [$a,$b,$c,$soft] = $palettes[$idx];
  return '--cover-a:'.$a.';--cover-b:'.$b.';--cover-c:'.$c.';--cover-soft:'.$soft.';';
}

/** Token para ver_materia.php */
function mint_materia_view_token(string $clave): string {
  if (!isset($_SESSION['materia_view_tokens'])) $_SESSION['materia_view_tokens'] = [];
  $t = bin2hex(random_bytes(16));
  $_SESSION['materia_view_tokens'][$t] = ['materia_clave'=>$clave, 'exp'=> time()+300];
  return $t;
}

$pdo = db();

/** ===== Materias (vista inicial) ===== */
$materias = $pdo->query("
  SELECT m.clave, m.nombre, COALESCE(m.descripcion,'') AS descripcion
  FROM materias m
  ORDER BY m.nombre ASC
")->fetchAll(PDO::FETCH_ASSOC) ?: [];

/** ===== Temas (para búsqueda dinámica) ===== */
$temas = $pdo->query("
  SELECT
    t.id AS tema_id,
    t.titulo AS tema_titulo,
    COALESCE(t.descripcion, '') AS tema_descripcion,

    u.id AS unidad_id,
    u.numero AS unidad_numero,
    COALESCE(u.titulo, '') AS unidad_titulo,

    m.clave AS materia_clave,
    m.nombre AS materia_nombre,
    COALESCE(m.descripcion, '') AS materia_descripcion,

    COUNT(DISTINCT c.id) AS contenidos_visibles
  FROM temas t
  JOIN unidades u ON u.id = t.unidad_id
  JOIN materias m ON LOWER(m.clave) = LOWER(u.materia_clave)
  JOIN contenidos c ON c.tema_id = t.id
  WHERE c.visibilidad IN ('publico', 'solo_estudiantes')
  GROUP BY
    t.id, t.titulo, t.descripcion,
    u.id, u.numero, u.titulo,
    m.clave, m.nombre, m.descripcion
  ORDER BY t.titulo ASC, m.nombre ASC, u.numero ASC
")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$title  = 'KnowLink · Estudiantes · Buscar recurso';
$active = 'buscar';
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:flex-start;justify-content:space-between;gap:16px;margin-bottom:18px;flex-wrap:wrap}
  .page-title{font-size:22px;font-weight:900;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px;margin-top:4px}

  .tools{display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap}
  .field label{font-size:12px;color:#6b7280;display:block;margin-bottom:6px}
  .field input{
    padding:12px 14px;border-radius:12px;border:1px solid #dbe4ee;background:#fff;
    font-size:14px;min-width:360px;outline:none
  }
  .field input:focus{
    border-color:#8bb8ff;box-shadow:0 0 0 3px rgba(0,85,212,.12)
  }

  .card{
    background:#fff;border-radius:14px;padding:16px;border:1px solid #e6eef2;
    box-shadow:0 10px 30px rgba(2,6,23,.06)
  }
  .muted{color:#94a3b8}
  .empty{
    color:#64748b;padding:14px;border:1px dashed #d9e4f1;border-radius:12px;background:#fafcff
  }
  .hidden{display:none!important}
  .section-heading{
    display:flex;align-items:center;justify-content:space-between;gap:10px;
    margin:0 0 12px;color:#0b2545;font-size:15px;font-weight:900
  }
  .section-heading .muted{font-size:13px;font-weight:700}
  .search-section + .search-section{margin-top:20px}

  /* ===== Vista inicial: materias ===== */
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
  .m-card{
    background:#fff;border:1px solid #e6eef2;border-radius:12px;overflow:hidden;cursor:pointer;
    display:flex;flex-direction:column;transition:transform .1s ease, box-shadow .12s ease
  }
  .m-card:hover{transform:translateY(-2px);box-shadow:0 16px 36px rgba(2,6,23,.08)}
  .thumb{aspect-ratio:16/9;background:#eef3f6;border-bottom:1px solid #eef2f6}
  .m-body{padding:10px}

  /* ===== Portada decorativa sin imágenes externas ===== */
  .m-card .thumb.materia-name-cover{
    --cover-a:#0ea5e9;
    --cover-b:#2563eb;
    --cover-c:#1e3a8a;
    --cover-soft:#e0f2fe;
    position:relative;
    overflow:hidden;
    aspect-ratio:auto;
    min-height:160px;
    padding:16px;
    display:flex;
    flex-direction:column;
    justify-content:center;
    gap:12px;
    isolation:isolate;
    color:#ffffff;
    background:
      radial-gradient(circle at 14% 18%, rgba(255,255,255,.28) 0 0, transparent 28%),
      radial-gradient(circle at 92% 82%, rgba(255,255,255,.18) 0 0, transparent 32%),
      linear-gradient(135deg,var(--cover-a),var(--cover-b) 52%,var(--cover-c));
  }
  .m-card .thumb.materia-name-cover::before{
    content:"";
    position:absolute;
    inset:10px;
    border:1px solid rgba(255,255,255,.19);
    border-radius:16px;
    pointer-events:none;
    z-index:1;
  }
  .m-card .thumb.materia-name-cover::after{
    content:"";
    position:absolute;
    right:-38px;
    bottom:-48px;
    width:160px;
    height:160px;
    border-radius:999px;
    background:rgba(255,255,255,.13);
    box-shadow:
      -125px -82px 0 -52px rgba(255,255,255,.17),
      -35px -142px 0 -64px rgba(255,255,255,.20);
    z-index:0;
  }
  .cover-top{
    position:absolute;
    z-index:2;
    top:14px;
    right:16px;
    display:flex;
    align-items:center;
    justify-content:flex-end;
    gap:8px;
  }
  .cover-code{
    display:none;
    align-items:center;
    max-width:68%;
    padding:5px 9px;
    border-radius:999px;
    background:rgba(255,255,255,.18);
    border:1px solid rgba(255,255,255,.24);
    color:rgba(255,255,255,.95);
    font-size:11px;
    font-weight:950;
    letter-spacing:.01em;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
    backdrop-filter:blur(8px);
  }
  .cover-dots{
    display:inline-flex;
    gap:5px;
    align-items:center;
    opacity:.9;
  }
  .cover-dots i{
    width:8px;
    height:8px;
    border-radius:999px;
    background:rgba(255,255,255,.56);
    display:block;
    box-shadow:18px 0 0 rgba(255,255,255,.34),36px 0 0 rgba(255,255,255,.22);
  }
  .cover-name{
    position:relative;
    z-index:2;
    font-size:20px;
    line-height:1.08;
    font-weight:950;
    letter-spacing:-.035em;
    text-shadow:0 3px 14px rgba(0,0,0,.30);
    display:block;
    overflow:visible;
    max-width:100%;
    white-space:normal;
    word-break:normal;
    overflow-wrap:anywhere;
  }
  .cover-meta{
    position:relative;
    z-index:2;
    display:none;
    align-items:center;
    width:max-content;
    max-width:100%;
    padding:4px 8px;
    border-radius:999px;
    background:rgba(0,0,0,.16);
    color:rgba(255,255,255,.86);
    font-size:10px;
    font-weight:900;
    letter-spacing:.02em;
  }
  .m-card:hover .thumb.materia-name-cover{
    filter:saturate(1.08) brightness(1.03);
  }


  html[data-theme="dark"] .m-card,
  body[data-theme="dark"] .m-card{
    background:#111827!important;
    border-color:rgba(148,163,184,.18)!important;
    box-shadow:0 14px 34px rgba(0,0,0,.28)!important;
  }
  html[data-theme="dark"] .m-card:hover,
  body[data-theme="dark"] .m-card:hover{
    border-color:rgba(56,189,248,.35)!important;
    box-shadow:0 18px 42px rgba(0,0,0,.36)!important;
  }
  html[data-theme="dark"] .thumb.materia-name-cover,
  body[data-theme="dark"] .thumb.materia-name-cover{
    background:
      radial-gradient(circle at 14% 18%, rgba(255,255,255,.18) 0 0, transparent 28%),
      radial-gradient(circle at 92% 82%, rgba(255,255,255,.11) 0 0, transparent 32%),
      linear-gradient(135deg,var(--cover-a),var(--cover-b) 52%,var(--cover-c))!important;
    border-bottom-color:rgba(148,163,184,.16)!important;
  }
  html[data-theme="dark"] .m-title,
  body[data-theme="dark"] .m-title{color:#f8fafc!important}
  html[data-theme="dark"] .m-sub,
  body[data-theme="dark"] .m-sub{color:#cbd5e1!important}

  .m-title{font-weight:900;color:#0b2545;line-height:1.22;white-space:normal;overflow:visible;word-break:normal;overflow-wrap:anywhere}
  .m-sub{font-size:13px;color:#6b7280}

  /* ===== Vista al buscar: temas ===== */
  .results{display:flex;flex-direction:column;gap:14px}
  .topic-card{
    border:1px solid #e6eef2;border-radius:16px;background:#fff;
    padding:18px;display:grid;grid-template-columns:1.7fr 0.9fr;gap:18px;
    transition:transform .12s ease, box-shadow .12s ease, border-color .12s ease;
    cursor:pointer
  }
  .topic-card:hover{
    transform:translateY(-2px);
    box-shadow:0 18px 38px rgba(2,6,23,.08);
    border-color:#cfe1ff
  }
  .topic-main{min-width:0}
  .topic-tag{
    display:inline-flex;align-items:center;gap:8px;
    padding:6px 10px;border-radius:999px;
    background:#eef6ff;border:1px solid #dbeafe;color:#0b2545;
    font-size:12px;font-weight:800;margin-bottom:12px
  }
  .topic-title{
    font-size:24px;line-height:1.15;font-weight:900;color:#0b2545;margin:0 0 10px
  }
  .topic-desc{
    color:#475569;font-size:14px;line-height:1.55;margin-bottom:14px
  }
  .topic-meta{display:flex;gap:10px;flex-wrap:wrap}
  .pill{
    display:inline-flex;align-items:center;gap:8px;
    padding:7px 11px;border-radius:999px;
    font-size:12px;font-weight:800;
    background:#f8fbff;border:1px solid #dbeafe;color:#0b2545
  }
  .topic-side{
    border-left:1px solid #eef2f6;padding-left:18px;
    display:flex;flex-direction:column;justify-content:space-between;gap:12px
  }
  .side-block{
    background:linear-gradient(180deg,#fbfdff,#f6faff);
    border:1px solid #e6eef2;border-radius:14px;padding:14px
  }
  .side-label{
    font-size:11px;font-weight:900;letter-spacing:.04em;
    color:#64748b;text-transform:uppercase;margin-bottom:6px
  }
  .side-title{
    font-size:18px;font-weight:900;color:#0b2545;line-height:1.2
  }
  .side-sub{
    color:#64748b;font-size:13px;margin-top:6px;line-height:1.45
  }
  .btn-go{
    display:inline-flex;align-items:center;justify-content:center;gap:8px;
    padding:11px 14px;border-radius:12px;border:0;cursor:pointer;
    background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;
    font-weight:900;font-size:14px;text-decoration:none
  }

  html[data-theme="dark"] .section-heading{color:#f8fafc!important}
  html[data-theme="dark"] .topic-card,
  html[data-theme="dark"] .side-block{
    background:#111827!important;border-color:rgba(148,163,184,.18)!important;color:#e5e7eb!important
  }
  html[data-theme="dark"] .topic-title,
  html[data-theme="dark"] .side-title{color:#f8fafc!important}
  html[data-theme="dark"] .topic-desc,
  html[data-theme="dark"] .side-sub{color:#cbd5e1!important}
  html[data-theme="dark"] .topic-side{border-color:rgba(148,163,184,.18)!important}

  @media (max-width: 900px){
    .topic-card{grid-template-columns:1fr}
    .topic-side{border-left:0;padding-left:0;border-top:1px solid #eef2f6;padding-top:14px}
    .field input{min-width:260px;width:100%}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title">Buscar recurso</div>
    <div class="page-sub">Explora materias o escribe para buscar por tema</div>
  </div>

  <div class="tools">
    <div class="field">
      <label>Buscar materia o tema</label>
      <input id="q" type="text" placeholder="Ej. Cálculo, Inecuaciones, Derivadas..." autocomplete="off">
    </div>
  </div>
</div>

<section class="card" aria-label="Resultados de búsqueda">
  <?php if (!$materias): ?>
    <div class="empty">Aún no hay materias registradas.</div>
  <?php else: ?>

    <div id="countMaterias" class="muted" style="margin-bottom:10px;"><?= count($materias) ?> materia(s)</div>
    <div id="countTemas" class="muted hidden" style="margin-bottom:10px;">0 tema(s)</div>

    <!-- ===== Materias: vista inicial y resultados por nombre ===== -->
    <div id="materiasWrap" class="search-section">
      <div id="materiasHeading" class="section-heading hidden">
        <span>Materias encontradas</span>
        <span id="materiasSearchCount" class="muted"></span>
      </div>
      <div id="materiasGrid" class="grid">
        <?php foreach ($materias as $m):
          $clave   = (string)$m['clave'];
          $nombre  = (string)$m['nombre'];
          $desc    = (string)$m['descripcion'];
            $haystack = mb_strtolower(trim($clave . ' ' . $nombre . ' ' . $desc), 'UTF-8');

          $token  = mint_materia_view_token($clave);
          $action = function_exists('base_url') ? base_url('estudiantes/ver_materia.php') : './ver_materia.php';
        ?>
        <article class="m-card" tabindex="0" data-haystack="<?= esc($haystack) ?>">
          <div class="thumb materia-name-cover" style="<?= esc(materia_cover_style($clave, $nombre)) ?>" aria-label="<?= esc($nombre ?: $clave) ?>">
          <div class="cover-top">
            <span class="cover-dots" aria-hidden="true"><i></i></span>
          </div>
          <span class="cover-name"><?= esc($nombre ?: $clave) ?></span>
          <span class="cover-meta">Materia disponible</span>
        </div>
          <div class="m-body">
            <div class="m-title"><?= esc($nombre ?: 'Materia') ?></div>
            <?php if ($desc !== ''): ?>
              <div class="m-sub" style="margin-top:6px;max-height:42px;overflow:hidden;"><?= esc($desc) ?></div>
            <?php endif; ?>
          </div>

          <form class="hidden" method="post" action="<?= esc($action) ?>">
            <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
            <input type="hidden" name="token" value="<?= esc($token) ?>">
            <input type="hidden" name="materia_clave" value="<?= esc($clave) ?>">
            <input type="hidden" name="origin" value="buscar">
          </form>
        </article>
        <?php endforeach; ?>
      </div>
    </div>

    <!-- ===== Temas: solo cuando se busca ===== -->
    <div id="temasWrap" class="search-section hidden">
      <div class="section-heading">
        <span>Temas encontrados</span>
      </div>
      <div id="temasResults" class="results">
        <?php foreach ($temas as $r):
          $temaTitulo   = (string)$r['tema_titulo'];
          $temaDesc     = (string)$r['tema_descripcion'];
          $unidadNumero = (int)$r['unidad_numero'];
          $unidadTitulo = (string)$r['unidad_titulo'];
          $materiaClave = (string)$r['materia_clave'];
          $materiaNom   = (string)$r['materia_nombre'];
          $materiaDesc  = (string)$r['materia_descripcion'];
          $nContenidos  = (int)$r['contenidos_visibles'];

          $haystack = mb_strtolower(trim(
            $temaTitulo . ' ' .
            $temaDesc . ' ' .
            $unidadTitulo . ' ' .
            $materiaClave . ' ' .
            $materiaNom . ' ' .
            $materiaDesc
          ), 'UTF-8');

          $token  = mint_materia_view_token($materiaClave);
          $action = function_exists('base_url') ? base_url('estudiantes/ver_materia.php') : './ver_materia.php';
        ?>
        <article class="topic-card" tabindex="0" data-haystack="<?= esc($haystack) ?>">
          <div class="topic-main">
            <div class="topic-tag">
              <i class="fas fa-book-open"></i>
              Tema encontrado
            </div>

            <h3 class="topic-title"><?= esc($temaTitulo) ?></h3>

            <?php if ($temaDesc !== ''): ?>
              <div class="topic-desc"><?= esc($temaDesc) ?></div>
            <?php else: ?>
              <div class="topic-desc">Tema disponible dentro de la unidad <?= esc((string)$unidadNumero) ?>.</div>
            <?php endif; ?>

            <div class="topic-meta">
              <span class="pill"><i class="fas fa-layer-group"></i> Unidad <?= esc((string)$unidadNumero) ?><?= $unidadTitulo !== '' ? ': '.esc($unidadTitulo) : '' ?></span>
              <span class="pill"><i class="fas fa-file-alt"></i> <?= esc((string)$nContenidos) ?> recurso(s) visible(s)</span>
            </div>
          </div>

          <div class="topic-side">
            <div class="side-block">
              <div class="side-label">Materia relacionada</div>
              <div class="side-title"><?= esc($materiaNom) ?></div>
              <?php if ($materiaDesc !== ''): ?>
                <div class="side-sub"><?= esc($materiaDesc) ?></div>
              <?php endif; ?>
            </div>

            <form method="post" action="<?= esc($action) ?>">
              <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
              <input type="hidden" name="token" value="<?= esc($token) ?>">
              <input type="hidden" name="materia_clave" value="<?= esc($materiaClave) ?>">
              <input type="hidden" name="origin" value="buscar">
              <button type="submit" class="btn-go">
                <i class="fas fa-arrow-right"></i>
                Ver materia
              </button>
            </form>
          </div>
        </article>
        <?php endforeach; ?>
      </div>

      <div id="emptySearch" class="empty hidden" style="margin-top:12px;">
        No se encontraron materias ni temas con ese texto.
      </div>
    </div>

  <?php endif; ?>
</section>

<script>
(function(){
  const q = document.getElementById('q');

  const materiasWrap = document.getElementById('materiasWrap');
  const materiasGrid = document.getElementById('materiasGrid');
  const materiasHeading = document.getElementById('materiasHeading');
  const materiasSearchCount = document.getElementById('materiasSearchCount');
  const countMaterias = document.getElementById('countMaterias');

  const temasWrap = document.getElementById('temasWrap');
  const temasResults = document.getElementById('temasResults');
  const countTemas = document.getElementById('countTemas');
  const emptySearch = document.getElementById('emptySearch');

  const totalMaterias = materiasGrid ? materiasGrid.querySelectorAll('.m-card').length : 0;

  const normalize = (txt) => String(txt || '')
    .toLowerCase()
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '')
    .trim();

  let pending = false;

  function updateMode(){
    const term = normalize(q?.value || '');

    if (term === '') {
      materiasWrap?.classList.remove('hidden');
      materiasHeading?.classList.add('hidden');
      countMaterias?.classList.remove('hidden');
      if (countMaterias) countMaterias.textContent = totalMaterias + ' materia(s)';

      materiasGrid?.querySelectorAll('.m-card').forEach(card=>card.classList.remove('hidden'));

      temasWrap?.classList.add('hidden');
      countTemas?.classList.add('hidden');
      emptySearch?.classList.add('hidden');
      return;
    }

    let materiasVisibles = 0;
    materiasGrid?.querySelectorAll('.m-card').forEach(card=>{
      const hay = normalize(card.getAttribute('data-haystack') || '');
      const show = hay.includes(term);
      card.classList.toggle('hidden', !show);
      if (show) materiasVisibles++;
    });

    let temasVisibles = 0;
    temasResults?.querySelectorAll('.topic-card').forEach(card=>{
      const hay = normalize(card.getAttribute('data-haystack') || '');
      const show = hay.includes(term);
      card.classList.toggle('hidden', !show);
      if (show) temasVisibles++;
    });

    const hayMaterias = materiasVisibles > 0;
    const hayTemas = temasVisibles > 0;

    materiasWrap?.classList.toggle('hidden', !hayMaterias);
    materiasHeading?.classList.toggle('hidden', !hayMaterias);
    countMaterias?.classList.toggle('hidden', true);
    if (materiasSearchCount) materiasSearchCount.textContent = materiasVisibles + ' materia(s)';

    temasWrap?.classList.toggle('hidden', !hayTemas);
    countTemas?.classList.toggle('hidden', !hayTemas);
    if (countTemas) countTemas.textContent = temasVisibles + ' tema(s)';

    emptySearch?.classList.toggle('hidden', hayMaterias || hayTemas);
  }

  function scheduleUpdate(){
    if (pending) return;
    pending = true;
    requestAnimationFrame(()=>{
      pending = false;
      updateMode();
    });
  }

  q?.addEventListener('input', scheduleUpdate);
  q?.addEventListener('search', scheduleUpdate);

  function goto(card){
    const form = card.querySelector('form');
    if (form) form.submit();
  }

  materiasGrid?.addEventListener('click', (e)=>{
    const card = e.target.closest('.m-card');
    if (!card || card.classList.contains('hidden')) return;
    goto(card);
  });

  materiasGrid?.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter' || e.key === ' ') {
      const card = e.target.closest('.m-card');
      if (!card || card.classList.contains('hidden')) return;
      e.preventDefault();
      goto(card);
    }
  });

  temasResults?.addEventListener('click', (e)=>{
    const card = e.target.closest('.topic-card');
    if (!card || card.classList.contains('hidden')) return;
    if (e.target.closest('button')) return;
    goto(card);
  });

  temasResults?.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter' || e.key === ' ') {
      const card = e.target.closest('.topic-card');
      if (!card || card.classList.contains('hidden')) return;
      if (e.target.tagName.toLowerCase() === 'button') return;
      e.preventDefault();
      goto(card);
    }
  });

  updateMode();
})();
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>