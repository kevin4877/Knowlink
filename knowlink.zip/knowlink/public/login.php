<?php
// public/login.php · KnowLink Premium UI
// Mantiene la lógica original de autenticación; solo cambia la presentación.

require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/csrf.php';
require_once __DIR__ . '/../src/auth.php';

if (auth_user()) {
  redirect(base_url('index.php'));
}

$username = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrf = $_POST['csrf'] ?? '';
  if (!csrf_validate($csrf)) {
    $error = 'Token CSRF inválido, recarga la página.';
  } else {
    $identifier = trim($_POST['username'] ?? '');
    $password   = (string)($_POST['password'] ?? '');
    $remember   = !empty($_POST['remember']);
    $username   = $identifier;

    if ($identifier === '' || $password === '') {
      $error = 'Completa usuario/correo y contraseña.';
    } else {
      if (auth_login($identifier, $password, $remember)) {
        flash('ok', '¡Bienvenido!');
        redirect(base_url('index.php'));
      } else {
        $error = 'Credenciales incorrectas o cuenta inactiva.';
      }
    }
  }
}

$flash_ok = flash('ok');
$flash_err = flash('error');
if (!$error && $flash_err) { $error = $flash_err; }
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="theme-color" content="#243b46" />
  <title>Iniciar sesión - KnowLink</title>

  <script>
    (function(){
      try{
        var saved = localStorage.getItem('knowlink-theme');
        var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        var theme = (saved === 'dark' || saved === 'light') ? saved : (prefersDark ? 'dark' : 'light');
        document.documentElement.setAttribute('data-theme', theme);
        document.documentElement.setAttribute('data-bs-theme', theme);
      }catch(e){
        document.documentElement.setAttribute('data-theme', 'light');
        document.documentElement.setAttribute('data-bs-theme', 'light');
      }
    })();
  </script>

  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
  <link rel="stylesheet" type="text/css" href="../css/estilosLogin.css?v=20260524-login-mobile-responsive">

  <style>
    input[type="password"]::-webkit-textfield-decoration-container,
    input[type="password"]::-webkit-password-reveal-button,
    input[type="password"]::-webkit-clear-button{display:none!important;-webkit-appearance:none!important;appearance:none!important}
    input[type="password"]::-ms-reveal,input[type="password"]::-ms-clear{display:none!important}
    input[type="password"]{-moz-appearance:textfield!important}
  </style>
</head>
<body>
  <button id="themeToggle" class="login-theme-toggle" type="button" aria-label="Cambiar tema" title="Cambiar tema">
    <span class="theme-toggle-icon"><i class="fas fa-moon" aria-hidden="true"></i></span>
    <span class="theme-toggle-text">Modo oscuro</span>
  </button>

  <div class="login-shell">
    <aside class="login-hero" aria-label="Presentación de KnowLink">
      <div class="hero-glow hero-glow-a"></div>
      <div class="hero-glow hero-glow-b"></div>

      <div class="brand-strip">
        <div class="mark">KL</div>
        <div>
          <div class="brand-title">KnowLink</div>
          <div class="brand-sub">Plataforma académica</div>
        </div>
      </div>

      <div class="hero-copy">
        <span class="hero-kicker"><i class="fas fa-graduation-cap"></i> Nueva experiencia académica</span>
        <h1>Portal<br>Académico</h1>
        <p class="lead">
          Accede a recursos, materias, unidades y exámenes predictivos desde una experiencia moderna,
          rápida y optimizada para computadora, tablet y celular.
        </p>
      </div>

      <div class="features" aria-label="Beneficios principales de KnowLink">
        <div class="feature">
          <div class="icon"><i class="fas fa-layer-group"></i></div>
          <div>
            <strong>Contenido ordenado</strong>
            <span>Carrera, retícula, materia, unidad y tema en una sola plataforma.</span>
          </div>
        </div>
        <div class="feature">
          <div class="icon"><i class="fas fa-wand-magic-sparkles"></i></div>
          <div>
            <strong>IA predictiva</strong>
            <span>Práctica con exámenes generados según la materia y unidad.</span>
          </div>
        </div>
        <div class="feature">
          <div class="icon"><i class="fas fa-mobile-screen-button"></i></div>
          <div>
            <strong>Responsive</strong>
            <span>Diseñado para uso cómodo en celular, tablet y escritorio.</span>
          </div>
        </div>
      </div>

      <div id="left-blurb" class="hero-note" tabindex="0"></div>
    </aside>

    <main class="login-panel">
      <section class="login-card" role="region" aria-label="Formulario de inicio de sesión">
        <div class="login-card-head">
          <div class="login-card-logo">KL</div>
          <div>
            <h2>Iniciar sesión</h2>
            <p class="subtitle">Ingresa tus credenciales para entrar.</p>
          </div>
        </div>

        <form id="loginForm" method="post" action="" autocomplete="on">
          <?= csrf_input() ?>
          <?php if ($flash_ok): ?>
            <div class="msg ok"><i class="fas fa-circle-check"></i><span><?= htmlspecialchars($flash_ok) ?></span></div>
          <?php endif; ?>
          <?php if ($error): ?>
            <div class="msg error"><i class="fas fa-triangle-exclamation"></i><span><?= htmlspecialchars($error) ?></span></div>
          <?php endif; ?>

          <div class="field <?= (!empty($username) ? 'focused' : '') ?>" id="field-user">
            <svg class="left-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <path d="M12 12c2.7 0 5-2.3 5-5s-2.3-5-5-5-5 2.3-5 5 2.3 5 5 5z"
              stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
              <path d="M4 22c.8-4 4-6.5 8-6.5s7.2 2.5 8 6.5"
              stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/>
            </svg>
            <input id="username" name="username" type="text" placeholder=" " aria-label="Usuario o correo"
                   required autocomplete="username" value="<?= htmlspecialchars($username) ?>" />
            <label for="username">Usuario o correo</label>
          </div>

          <div class="field" id="field-pwd">
            <svg class="left-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
              <rect x="3" y="11" width="18" height="10" rx="2" stroke="currentColor" stroke-width="1.4"/>
              <path d="M7 11V8a5 5 0 0 1 10 0v3" stroke="currentColor" stroke-width="1.4" stroke-linecap="round"/>
            </svg>

            <div class="pwd-wrap">
              <input id="password" name="password" type="password" placeholder=" " aria-label="Contraseña" required autocomplete="current-password" />
              <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="password">
                <i class="far fa-eye"></i>
              </button>
            </div>

            <label for="password">Contraseña</label>
          </div>

          <div class="login-options">
            <label class="remember-label">
              <input id="remember" type="checkbox" name="remember" <?= isset($_POST['remember']) ? 'checked' : '' ?>>
              <span>Recuérdame</span>
            </label>
            <span class="login-safe-note"><i class="fas fa-shield-halved" aria-hidden="true"></i> Acceso seguro</span>
          </div>

          <div class="actions">
            <button class="login-submit" id="submitBtn" type="submit">
              <span id="btnText">Iniciar sesión</span>
              <i class="fas fa-arrow-right" aria-hidden="true"></i>
            </button>

            <div class="register-row">
              <span>¿Necesitas acceso?</span>
              <a href="<?= htmlspecialchars(base_url('estudiantes/registro_alumnos.php'), ENT_QUOTES, 'UTF-8') ?>" class="register-link">Registrarme</a>
            </div>
          </div>
        </form>

        <div id="tip" class="tip" tabindex="0"></div>
      </section>
    </main>
  </div>

  <script>
    (function(){
      const KEY = 'knowlink-theme';
      const root = document.documentElement;
      const btn = document.getElementById('themeToggle');

      function systemTheme(){
        try { return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; }
        catch(e){ return 'light'; }
      }
      function normalize(value){ return value === 'dark' || value === 'light' ? value : systemTheme(); }
      function currentTheme(){
        try { return normalize(localStorage.getItem(KEY) || root.getAttribute('data-theme')); }
        catch(e){ return normalize(root.getAttribute('data-theme')); }
      }
      let themeTimer = null;
      function applyTheme(theme, persist = true){
        const value = normalize(theme);
        root.classList.add('kl-theme-changing');
        clearTimeout(themeTimer);
        themeTimer = setTimeout(() => root.classList.remove('kl-theme-changing'), 560);
        root.setAttribute('data-theme', value);
        root.setAttribute('data-bs-theme', value);
        if (persist) {
          try { localStorage.setItem(KEY, value); } catch(e){}
        }
        updateButton(value);
      }
      function updateButton(theme){
        if (!btn) return;
        const icon = btn.querySelector('i');
        const text = btn.querySelector('.theme-toggle-text');
        const isDark = theme === 'dark';
        if (icon) icon.className = isDark ? 'fas fa-sun' : 'fas fa-moon';
        if (text) text.textContent = isDark ? 'Modo claro' : 'Modo oscuro';
        btn.setAttribute('aria-pressed', isDark ? 'true' : 'false');
      }
      applyTheme(currentTheme(), false);
      btn?.addEventListener('click', () => applyTheme(currentTheme() === 'dark' ? 'light' : 'dark'));
    })();

    (function(){
      document.querySelectorAll('.toggle-eye').forEach(btn=>{
        btn.addEventListener('click', ()=>{
          const id = btn.getAttribute('data-target');
          const input = document.getElementById(id);
          if (!input) return;
          if (input.type === 'password') {
            input.type = 'text';
            btn.innerHTML = '<i class="far fa-eye-slash"></i>';
          } else {
            input.type = 'password';
            btn.innerHTML = '<i class="far fa-eye"></i>';
          }
          input.focus();
        });
      });
    })();

    const form = document.getElementById('loginForm');
    const submitBtn = document.getElementById('submitBtn');
    const btnText = document.getElementById('btnText');
    const pwdInput = document.getElementById('password');

    if (form) {
      form.addEventListener('submit', (e) => {
        const user = document.getElementById('username').value.trim();
        const pass = (pwdInput ? pwdInput.value : '');
        if (user.length < 3 || pass.length < 1) {
          e.preventDefault();
          alert('Revisa usuario/correo y contraseña.');
          return;
        }
        submitBtn.setAttribute('disabled', 'disabled');
        btnText.textContent = 'Accediendo...';
      });
    }

    (function setupStableMessages() {
      const TICK_MS = 6500, FADE_MS = 260;
      const tipEl = document.getElementById('tip');
      const leftEl = document.getElementById('left-blurb');
      const userInput = document.getElementById('username');
      const passInput = document.getElementById('password');
      let paused = false;

      const tips = [
        "Tus datos se mantienen protegidos durante el acceso.",
        "La plataforma se adapta a celular, tablet y computadora.",
        "Puedes cambiar entre modo claro y oscuro sin perder lo que escribes."
      ];
      const leftBlurbs = [
        "Accede a tus materias, recursos y exámenes predictivos desde un entorno claro y seguro.",
        "KnowLink organiza el contenido académico para que encuentres lo necesario con menos pasos.",
        "Una experiencia moderna pensada para estudiantes, docentes y administradores."
      ];
      function show(el, value){
        if(!el || paused) return;
        el.style.opacity = '0';
        setTimeout(function(){ el.textContent = value; el.style.opacity = '1'; }, FADE_MS / 2);
      }
      function cycle(el, list){
        if(!el || !list.length) return;
        let idx = 0;
        el.textContent = list[idx];
        el.style.opacity = '1';
        setInterval(function(){
          if(paused) return;
          idx = (idx + 1) % list.length;
          show(el, list[idx]);
        }, TICK_MS);
      }
      [userInput, passInput].forEach(function(input){
        if(!input) return;
        input.addEventListener('focus', function(){ paused = true; });
        input.addEventListener('blur', function(){ setTimeout(function(){ paused = false; }, 900); });
      });
      cycle(tipEl, tips);
      cycle(leftEl, leftBlurbs);
    })();
  </script>
</body>
</html>
