<?php
require_once __DIR__ . '/../views/_header.php';
?>
  <h1>403 • Acceso denegado</h1>
  <p>No tienes permisos para ver esta sección.</p>
  <p><a class="btn" href="<?=base_url('index.php')?>">Volver</a></p>
<?php require_once __DIR__ . '/../views/_footer.php'; ?>
