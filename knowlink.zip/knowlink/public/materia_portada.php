<?php
// public/materia_portada.php
// Endpoint de compatibilidad: ya no consulta imágenes externas.
declare(strict_types=1);

require_once __DIR__ . '/../src/materia_images.php';

$clave = mb_substr(trim((string)($_GET['clave'] ?? '')), 0, 40, 'UTF-8');
$nombre = mb_substr(trim((string)($_GET['nombre'] ?? '')), 0, 120, 'UTF-8');

header('X-Content-Type-Options: nosniff');
header('Cache-Control: public, max-age=86400');
header('Content-Type: image/svg+xml; charset=UTF-8');
echo kl_materia_fallback_svg($clave, $nombre);
