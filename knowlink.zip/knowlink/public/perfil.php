<?php
// public/perfil.php
// Perfil unificado para administrador, docente y estudiante.
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// === Utilidades locales ===
if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="48" cy="36" r="16" fill="#cfd8e3"/><rect x="20" y="60" width="56" height="24" rx="12" fill="#cfd8e3"/></svg>'
    );
  }
}

if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) { return $needle !== '' && strpos($haystack, $needle) === 0; }
}

/**
 * Obtiene una ruta web limpia de avatar.
 * Acepta valores guardados como:
 * /uploads/avatars/archivo.jpg, uploads/avatars/archivo.jpg,
 * ../uploads/avatars/archivo.jpg, /KnowLink/public/uploads/avatars/archivo.jpg.
 */
function avatar_web_path(?string $url): ?string {
  if (!$url) return null;
  $u = trim(str_replace('\\', '/', $url));
  if ($u === '' || str_starts_with($u, 'data:') || preg_match('#^(?:https?:)?//#i', $u)) {
    return null;
  }
  if (preg_match('~uploads/avatars/[^?#]+~i', $u, $m)) {
    return '/' . ltrim($m[0], '/');
  }
  return str_starts_with($u, '/') ? $u : '/' . ltrim($u, '/');
}

/** Normaliza a URL web válida para <img src="...">. */
function foto_src(?string $url): string {
  if (!$url) return avatar_placeholder();
  $u = trim(str_replace('\\', '/', $url));
  if ($u === '') return avatar_placeholder();
  if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u;

  $path = avatar_web_path($u);
  if (!$path) return avatar_placeholder();
  return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
}

/** Borra el archivo físico del avatar, únicamente si pertenece a public/uploads/avatars. */
function deleteAvatarFile(?string $storedPath): void {
  $webPath = avatar_web_path($storedPath);
  if (!$webPath || !preg_match('#^/uploads/avatars/#', $webPath)) return;

  $publicRoot = realpath(__DIR__); // .../public
  if (!$publicRoot) return;

  $abs = $publicRoot . $webPath;
  if (is_file($abs)) { @unlink($abs); }
}

function refreshUserSession(array $row): void {
  if (function_exists('set_user_session')) {
    set_user_session($row);
  } else {
    $_SESSION['user'] = $row;
  }
}

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();
$uid = (int)($yo['id'] ?? 0);

// ====== AJAX: disponibilidad username para otros ======
if (isset($_GET['ajax']) && $_GET['ajax'] === 'check_username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  if ($u === '' || mb_strlen($u) < 3) { echo json_encode(['ok'=>false,'avail'=>false]); exit; }

  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u AND id<>:id");
  $st->execute([':u'=>$u, ':id'=>$uid]);
  $taken = (int)$st->fetchColumn() > 0;

  echo json_encode(['ok'=>true,'avail'=>!$taken], JSON_UNESCAPED_UNICODE);
  exit;
}

// ====== Datos actuales ======
$st = $pdo->prepare("SELECT id, nombre, apellidos, email, username, foto_url, rol FROM usuarios WHERE id=:id LIMIT 1");
$st->execute([':id'=>$uid]);
$me = $st->fetch(PDO::FETCH_ASSOC);
if (!$me) { http_response_code(404); echo "Usuario no encontrado."; exit; }

$fotoActual = foto_src($me['foto_url'] ?? null);

// ====== POST: eliminar o guardar perfil ======
$flash = null;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'perfil') {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido. Refresca la página.';
  }

  // 1) Eliminar foto
  if (!$errors && isset($_POST['del_foto']) && $_POST['del_foto'] === '1') {
    try {
      deleteAvatarFile($me['foto_url'] ?? null);

      $pdo->prepare("UPDATE usuarios SET foto_url=NULL, actualizado_en=NOW() WHERE id=:id")
          ->execute([':id'=>$uid]);

      $st = $pdo->prepare("SELECT id, nombre, apellidos, email, username, foto_url, rol FROM usuarios WHERE id=:id LIMIT 1");
      $st->execute([':id'=>$uid]);
      $me = $st->fetch(PDO::FETCH_ASSOC) ?: $me;
      refreshUserSession($me);
      $fotoActual = foto_src($me['foto_url'] ?? null);
      $flash = ['type'=>'ok','msg'=>'Foto eliminada correctamente.'];
    } catch(Throwable $e) {
      $errors[] = 'No se pudo eliminar la foto.';
    }
  }

  // 2) Guardar datos
  if (!$errors && (!isset($_POST['del_foto']) || $_POST['del_foto'] !== '1')) {
    $nombre    = trim((string)($_POST['nombre'] ?? ''));
    $apellidos = trim((string)($_POST['apellidos'] ?? ''));
    $email     = trim((string)($_POST['email'] ?? ''));
    $username  = trim((string)($_POST['username'] ?? ''));
    $pass1     = (string)($_POST['password'] ?? '');
    $pass2     = (string)($_POST['password2'] ?? '');

    if ($nombre === '' || mb_strlen($nombre) < 2)       $errors[] = 'Nombre inválido.';
    if ($apellidos === '' || mb_strlen($apellidos) < 2) $errors[] = 'Apellidos inválidos.';
    if ($username === '' || mb_strlen($username) < 3)   $errors[] = 'Usuario mínimo 3 caracteres.';
    if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Correo inválido.';

    if ($pass1 !== '' || $pass2 !== '') {
      if ($pass1 !== $pass2) $errors[] = 'Las contraseñas no coinciden.';
      if ($pass1 !== '' && mb_strlen($pass1) < 8) $errors[] = 'La nueva contraseña debe tener al menos 8 caracteres.';
    }

    // Unicidad, excluyendo al usuario actual
    if (!$errors) {
      $qU = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u AND id<>:id");
      $qU->execute([':u'=>$username, ':id'=>$uid]);
      if ((int)$qU->fetchColumn() > 0) $errors[] = 'El usuario ya está en uso.';

      $qE = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e AND id<>:id");
      $qE->execute([':e'=>$email, ':id'=>$uid]);
      if ((int)$qE->fetchColumn() > 0) $errors[] = 'El correo ya está en uso.';
    }

    $oldWeb = $me['foto_url'] ?? null;
    $foto_url = $me['foto_url'] ?? null;

    // Subida de foto opcional
    if (!$errors && isset($_FILES['foto']) && is_array($_FILES['foto']) && ($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
      $f = $_FILES['foto'];
      if ($f['error'] !== UPLOAD_ERR_OK) {
        $errors[] = 'Error al subir la imagen.';
      } else {
        if ((int)$f['size'] > 3*1024*1024) $errors[] = 'La imagen excede 3 MB.';

        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        $mime  = $finfo ? finfo_file($finfo, $f['tmp_name']) : '';
        if ($finfo) finfo_close($finfo);

        $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
        if (!isset($allowed[$mime])) $errors[] = 'Formato no permitido (JPG, PNG, GIF, WEBP).';

        if (!$errors) {
          $publicRoot = realpath(__DIR__); // .../public
          if (!$publicRoot) {
            $errors[] = 'No se pudo ubicar la carpeta pública del proyecto.';
          } else {
            $ext = $allowed[$mime];
            $dir = $publicRoot . '/uploads/avatars';
            if (!is_dir($dir)) { @mkdir($dir, 0775, true); }

            $fname   = 'u'.$uid.'_'.time().'_'.bin2hex(random_bytes(3)).'.'.$ext;
            $webPath = '/uploads/avatars/' . $fname;
            $dest    = $publicRoot . $webPath;

            if (!move_uploaded_file($f['tmp_name'], $dest)) {
              $errors[] = 'No se pudo guardar la imagen.';
            } else {
              $foto_url = $webPath; // Guardar ruta limpia en BD
            }
          }
        }
      }
    }

    if (!$errors) {
      try {
        $pdo->beginTransaction();

        $sqlU = "UPDATE usuarios
                 SET nombre=:n, apellidos=:a, username=:u, email=:e, actualizado_en=NOW()"
               . ($foto_url !== null ? ", foto_url=:f " : " ")
               . "WHERE id=:id";
        $stU = $pdo->prepare($sqlU);
        $params = [':n'=>$nombre, ':a'=>$apellidos, ':u'=>$username, ':e'=>$email, ':id'=>$uid];
        if ($foto_url !== null) $params[':f'] = $foto_url;
        $stU->execute($params);

        if ($pass1 !== '') {
          $hash = password_hash($pass1, PASSWORD_BCRYPT, ['cost'=>10]);
          $pdo->prepare("UPDATE usuarios SET password_hash=:ph WHERE id=:id")
              ->execute([':ph'=>$hash, ':id'=>$uid]);
        }

        $pdo->commit();

        if ($foto_url !== null && $foto_url !== $oldWeb) {
          deleteAvatarFile($oldWeb);
        }

        $st = $pdo->prepare("SELECT id, nombre, apellidos, email, username, foto_url, rol FROM usuarios WHERE id=:id LIMIT 1");
        $st->execute([':id'=>$uid]);
        $me = $st->fetch(PDO::FETCH_ASSOC) ?: $me;
        refreshUserSession($me);
        $fotoActual = foto_src($me['foto_url'] ?? null);
        $flash = ['type'=>'ok','msg'=>'Perfil actualizado correctamente.'];
      } catch(Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $errors[] = 'Error al guardar los cambios.';
      }
    }
  }
}

// ===== Header/footer según rol =====
$rol = (string)($me['rol'] ?? '');
$yo  = $me;
$title = 'KnowLink · Mi perfil';
$active = '';

switch ($rol) {
  case 'administrador':
    $headerFile = __DIR__ . '/admin/partials/header.php';
    $footerFile = __DIR__ . '/admin/partials/footer.php';
    $backUrl = base_url('admin/index.php');
    $backLabel = 'Volver al panel de administrador';
    break;

  case 'docente':
    $headerFile = __DIR__ . '/docentes/partials/header.php';
    $footerFile = __DIR__ . '/docentes/partials/footer.php';
    $backUrl = base_url('docentes/index.php');
    $backLabel = 'Volver al panel docente';
    break;

  case 'estudiante':
    $headerFile = __DIR__ . '/estudiantes/partials/header.php';
    $footerFile = __DIR__ . '/estudiantes/partials/footer.php';
    $backUrl = base_url('estudiantes/index.php');
    $backLabel = 'Volver al panel estudiante';
    break;

  default:
    $headerFile = __DIR__ . '/admin/partials/header.php';
    $footerFile = __DIR__ . '/admin/partials/footer.php';
    $backUrl = base_url('index.php');
    $backLabel = 'Volver al inicio';
    break;
}

require $headerFile;
?>
<style>
  .perfil-form{display:block;}
  .perfil-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px}
  label.field .label{font-weight:800;color:#0b2545;font-size:14px}
  .hint{font-size:12px;color:#6b7280;line-height:1.35}
  input[type="text"],input[type="email"],input[type="password"],select,textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  input[type="text"]:focus,input[type="email"]:focus,input[type="password"]:focus{border-color:#0fb5bf;box-shadow:0 0 0 3px rgba(15,181,191,.12)}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800;text-decoration:none;display:inline-flex;align-items:center;gap:8px}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn.small{padding:6px 10px;border-radius:8px;font-weight:700}
  .avatar-big{width:96px;height:96px;border-radius:999px;object-fit:cover;background:#eef3f6;border:4px solid #eef7f8}
  .flash{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:14px}
  .flash.ok{background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46}
  .flash.error{background:#fff1f0;border:1px solid #f5c2c7;color:#7a0021}
  .flash ul{margin:8px 0 0 18px}
  .avail{display:inline-flex;gap:10px;align-items:center;padding:6px 10px;border-radius:10px;border:1px solid #e6eef2;background:#f3f6f9;font-weight:700;margin-top:6px}
  .avail.ok{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;color:#065f46}
  .avail.bad{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}
  .pw-meter{height:8px;width:100%;background:#eef2f7;border-radius:999px;overflow:hidden;margin-top:6px}
  .pw-meter > div{height:8px;width:0%;background:#ef4444;transition:width .2s ease, background .2s ease}
  .pw-tip{font-size:12px;color:#6b7280;margin-top:6px}
  .pwd-wrap{position:relative;width:100%}
  .pwd-wrap input[type="password"],.pwd-wrap input[type="text"]{padding-right:42px}
  .toggle-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);background:transparent;border:0;cursor:pointer;font-size:16px;color:#6b7280;padding:6px;border-radius:8px}
  .toggle-eye:hover{background:#f3f6f9;color:#0b2545}
  .perfil-actions{margin-top:12px;display:flex;gap:8px;flex-wrap:wrap}
  .pulse{animation:pulseKL .45s ease}
  @keyframes pulseKL{0%{transform:scale(1)}50%{transform:scale(1.025)}100%{transform:scale(1)}}
</style>

<div class="page-header">
  <div>
    <div class="page-title">Mi perfil</div>
    <div class="page-sub">Actualiza tu información personal y de acceso</div>
  </div>
</div>

<?php if ($flash): ?>
  <div class="flash <?= $flash['type']==='ok' ? 'ok':'error' ?>"><?= esc($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
  <div class="flash error"><strong>Revisa lo siguiente:</strong><ul><?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?></ul></div>
<?php endif; ?>

<form class="perfil-form" method="post" enctype="multipart/form-data" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="form" value="perfil">

  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Foto de perfil</h3>
    <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
      <img id="avatar" class="avatar-big" src="<?= esc($fotoActual) ?>" alt="Foto">
      <label class="field" style="max-width:320px;">
        <span class="label">Cambiar foto</span>
        <input type="file" name="foto" id="foto" accept="image/png,image/jpeg,image/gif,image/webp">
        <div class="hint">JPG/PNG/GIF/WEBP — Máx 3MB</div>
      </label>

      <?php if (!empty($me['foto_url'])): ?>
        <button class="btn ghost" type="submit" name="del_foto" value="1" onclick="return confirm('¿Eliminar tu foto de perfil?');">
          <i class="fas fa-trash"></i> <span class="label">Eliminar foto</span>
        </button>
      <?php endif; ?>
    </div>
  </section>

  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos personales</h3>
    <div class="perfil-grid">
      <label class="field">
        <span class="label">Nombre(s)</span>
        <input type="text" name="nombre" required minlength="2" value="<?= esc($me['nombre'] ?? '') ?>">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" required minlength="2" value="<?= esc($me['apellidos'] ?? '') ?>">
      </label>
      <label class="field" style="grid-column:1/-1;">
        <span class="label">Correo</span>
        <input type="email" name="email" required value="<?= esc($me['email'] ?? '') ?>">
        <div class="hint">Este correo se utilizará para notificaciones.</div>
      </label>
    </div>
  </section>

  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de acceso</h3>
    <div class="perfil-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" required minlength="3" value="<?= esc($me['username'] ?? '') ?>" autocomplete="off">
        <div id="userAvail" class="avail" style="display:none;"></div>
      </label>

      <label class="field">
        <span class="label">Nueva contraseña (opcional)</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="password" minlength="8" placeholder="Dejar vacío para no cambiar" autocomplete="new-password">
          <button type="button" class="toggle-eye" data-target="password" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
        <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
      </label>

      <label class="field">
        <span class="label">Confirmar contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="password2" minlength="8" placeholder="Debe coincidir" autocomplete="new-password">
          <button type="button" class="toggle-eye" data-target="password2" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <small id="pwMatch" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
      </label>
    </div>

    <div class="perfil-actions">
      <button class="btn primary" type="submit"><i class="fas fa-save"></i> Guardar cambios</button>
      <a class="btn ghost" href="<?= esc($backUrl) ?>"><i class="fas fa-arrow-left"></i> <span class="label"><?= esc($backLabel) ?></span></a>
    </div>
  </section>
</form>

<script>
  function pulse(el){ if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'), 450); }

  // Preview de imagen
  (function(){
    const foto=document.getElementById('foto');
    const avatar=document.getElementById('avatar');
    foto?.addEventListener('change', (e)=>{
      const f = e.target.files[0];
      if (!f) return;
      if (f.size > 3*1024*1024) { alert('La imagen excede 3 MB'); e.target.value=''; return; }
      const rd = new FileReader();
      rd.onload = ()=> {
        avatar.src = rd.result;
        document.querySelectorAll('.profile').forEach(img => { img.src = rd.result; });
      };
      rd.readAsDataURL(f);
    });
  })();

  // Usuario disponible
  (function(){
    const u = document.getElementById('username');
    const box = document.getElementById('userAvail');
    let t=null;

    function show(text, cls, icon){
      box.style.display='inline-flex';
      box.className='avail ' + (cls||'');
      box.innerHTML = (icon ? `<i class="fas ${icon}"></i> ` : '') + text;
    }
    function hide(){ box.style.display='none'; }

    async function check({spin=true}={}){
      const v=(u.value||'').trim();
      if(!v){ hide(); return; }
      if(v.length<3){ show('Mínimo 3 caracteres','', 'fa-info-circle'); return; }
      if (spin) show('Comprobando…','', 'fa-circle-notch fa-spin');
      try{
        const res = await fetch('?ajax=check_username&u='+encodeURIComponent(v), {cache:'no-store'});
        const data = await res.json();
        if (data.ok && data.avail){ show('Disponible ✓','ok','fa-check-circle'); pulse(box); }
        else { show('Ya está en uso ✗','bad','fa-times-circle'); pulse(box); }
      }catch(e){ show('Intenta de nuevo','', 'fa-info-circle'); }
    }

    u?.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=>check({spin:true}), 300); });
    document.addEventListener('DOMContentLoaded', ()=>{ const v=(u?.value||'').trim(); if(v.length>=3){ check({spin:false}); } });
  })();

  // Mostrar/ocultar contraseña
  (function(){
    document.querySelectorAll('.toggle-eye').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = btn.getAttribute('data-target');
        const input = document.getElementById(id);
        if (!input) return;
        if (input.type === 'password') {
          input.type = 'text';
          btn.innerHTML = '<i class="far fa-eye-slash"></i>';
        } else {
          input.type = 'password';
          btn.innerHTML = '<i class="far fa-eye"></i>';
        }
        input.focus();
      });
    });
  })();

  // Medidor de password + coincidencia
  (function(){
    const p1=document.getElementById('password');
    const p2=document.getElementById('password2');
    const match=document.getElementById('pwMatch');
    const bar=document.getElementById('pwBar');
    const tip=document.getElementById('pwTip');

    function scorePassword(pw){
      let score=0; if(!pw) return 0;
      const letters={};
      for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
      const variations={ digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
      let vc=0; for(const k in variations) vc += variations[k] ? 1 : 0;
      score += (vc - 1) * 10; return parseInt(score);
    }
    function updateMeter(){
      const val=p1.value||'';
      const s=Math.min(100, scorePassword(val));
      bar.style.width = (val ? Math.max(8,s) : 0) + '%';
      if (!val){ tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
      if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
      else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
      else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
      else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
      pulse(bar.parentElement);
    }
    function updateMatch(){
      match.style.display = (p2.value && p1.value !== p2.value) ? 'block' : 'none';
      if (match.style.display==='block') pulse(match);
    }
    ['input','change','keyup','blur'].forEach(ev=>{
      p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
      p2?.addEventListener(ev, updateMatch);
    });
    updateMeter(); updateMatch();
  })();
</script>

<?php require $footerFile; ?>
