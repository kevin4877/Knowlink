<?php
// public/api/check_username.php
declare(strict_types=1);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

require_once __DIR__ . '/../../config/db.php';

function j($ok, $data = []) {
  http_response_code($ok ? 200 : 400);
  echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

try {
  $pdo = db();
} catch (Throwable $e) {
  j(false, ['error' => 'DB error']);
}

$q = isset($_GET['q']) ? trim((string)$_GET['q']) : '';
if ($q === '') {
  j(false, ['error' => 'Falta parámetro q']);
}

// Validaciones básicas de formato
$len = mb_strlen($q);
if ($len < 3 || $len > 32) {
  j(true, [
    'available' => false,
    'reason'    => 'El usuario debe tener entre 3 y 32 caracteres.',
    'suggestions' => [],
  ]);
}

// Permitimos letras, números, punto y guion bajo (ajusta a tu gusto)
if (!preg_match('/^[a-zA-Z0-9._]+$/', $q)) {
  j(true, [
    'available' => false,
    'reason'    => 'Usa solo letras, números, punto o guion bajo.',
    'suggestions' => [],
  ]);
}

// ¿Existe ya?
$st = $pdo->prepare('SELECT 1 FROM usuarios WHERE username = :u LIMIT 1');
$st->execute([':u' => $q]);
$exists = (bool)$st->fetchColumn();

if (!$exists) {
  j(true, [
    'available' => true,
    'reason'    => 'Disponible',
    'suggestions' => [],
  ]);
}

// Sugerencias simples si ya existe
$suggestions = [];
$base = $q;
$nums = [rand(10,99), rand(100,999)];
foreach ($nums as $n) {
  $candidate = $base . $n;
  $st = $pdo->prepare('SELECT 1 FROM usuarios WHERE username = :u LIMIT 1');
  $st->execute([':u' => $candidate]);
  if (!$st->fetchColumn()) $suggestions[] = $candidate;
}
if (strpos($base, '.') === false) {
  $candidate = $base . '.' . rand(1,9);
  $st = $pdo->prepare('SELECT 1 FROM usuarios WHERE username = :u LIMIT 1');
  $st->execute([':u' => $candidate]);
  if (!$st->fetchColumn()) $suggestions[] = $candidate;
}

j(true, [
  'available'  => false,
  'reason'     => 'Ya está en uso.',
  'suggestions'=> $suggestions,
]);
