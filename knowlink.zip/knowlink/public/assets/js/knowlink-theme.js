// KnowLink theme switcher + Premium interactions: modo claro / oscuro
(function(){
  const KEY = 'knowlink-theme';
  const ROOT = document.documentElement;
  let changingTimer = null;

  function systemTheme(){
    try { return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'; }
    catch(e){ return 'light'; }
  }
  function normalize(value){ return value === 'dark' || value === 'light' ? value : systemTheme(); }
  function currentTheme(){
    try { return normalize(localStorage.getItem(KEY) || ROOT.getAttribute('data-theme')); }
    catch(e){ return normalize(ROOT.getAttribute('data-theme')); }
  }
  function beginTransition(){
    ROOT.classList.add('kl-theme-changing');
    clearTimeout(changingTimer);
    changingTimer = setTimeout(function(){ ROOT.classList.remove('kl-theme-changing'); }, 140);
  }
  function applyTheme(theme, persist){
    const value = normalize(theme);
    beginTransition();
    ROOT.setAttribute('data-theme', value);
    ROOT.setAttribute('data-bs-theme', value);
    document.body && document.body.setAttribute('data-theme', value);
    const color = value === 'dark' ? '#08111f' : '#f6f8fc';
    let meta = document.querySelector('meta[name="theme-color"]');
    if(!meta){ meta = document.createElement('meta'); meta.name = 'theme-color'; document.head.appendChild(meta); }
    meta.setAttribute('content', color);
    if (persist !== false) {
      try { localStorage.setItem(KEY, value); } catch(e){}
    }
    updateButtons(value);
  }
  function updateButtons(theme){
    const value = normalize(theme || currentTheme());
    document.querySelectorAll('[data-theme-toggle], #themeToggle, .theme-toggle').forEach(function(btn){
      btn.setAttribute('aria-pressed', value === 'dark' ? 'true' : 'false');
      btn.setAttribute('aria-label', value === 'dark' ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro');
      btn.setAttribute('title', value === 'dark' ? 'Cambiar a modo claro' : 'Cambiar a modo oscuro');
      const icon = btn.querySelector('i');
      if (icon) icon.className = value === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
      const label = btn.querySelector('.theme-label');
      if (label) label.textContent = value === 'dark' ? 'Claro' : 'Oscuro';
      const text = btn.querySelector('.theme-toggle-text');
      if (text) text.textContent = value === 'dark' ? 'Modo claro' : 'Modo oscuro';
      const altIcon = btn.querySelector('.theme-toggle-icon i');
      if (altIcon) altIcon.className = value === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    });
  }
  function toggleTheme(){
    const next = currentTheme() === 'dark' ? 'light' : 'dark';
    // Cambio directo: evita que View Transition capture toda la página y se sienta trabado en pantallas con muchos componentes.
    applyTheme(next, true);
  }

  window.KnowLinkTheme = { apply: applyTheme, toggle: toggleTheme, current: currentTheme };

  document.addEventListener('DOMContentLoaded', function(){
    applyTheme(currentTheme(), false);
    document.querySelectorAll('[data-theme-toggle], #themeToggle, .theme-toggle').forEach(function(btn){
      if (btn.dataset.themeReady === '1') return;
      btn.dataset.themeReady = '1';
      btn.addEventListener('click', function(e){ e.preventDefault(); toggleTheme(); });
    });
  });
})();

// KnowLink Premium interactions · progressive enhancement
(function(){
  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }
  function escapeHtml(value){
    return (value || '').toString().replace(/[&<>"']/g, function(m){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]); });
  }
  ready(function(){
    document.body.classList.add('kl-ready','kl-ultra-ready');

    // Etiquetas automáticas para tablas en móvil: convierte filas en tarjetas legibles.
    document.querySelectorAll('table').forEach(function(table){
      var heads = Array.from(table.querySelectorAll('thead th')).map(function(th){ return th.textContent.trim(); });
      if(!heads.length) return;
      table.classList.add('table','table-hover','align-middle');
      if(!table.parentElement || !table.parentElement.classList.contains('table-responsive')){
        var wrap = document.createElement('div');
        wrap.className = 'table-responsive kl-table-wrap';
        table.parentNode.insertBefore(wrap, table);
        wrap.appendChild(table);
      }
      table.querySelectorAll('tbody tr').forEach(function(row){
        Array.from(row.children).forEach(function(cell, i){
          if(!cell.getAttribute('data-label')) cell.setAttribute('data-label', heads[i] || 'Dato');
        });
      });
    });

    // Bootstrap look para formularios sin cambiar nombres ni lógica.
    document.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]):not([type="file"]), textarea, select').forEach(function(el){
      if(el.closest('.no-bootstrap-form')) return;
      if(el.tagName === 'SELECT') el.classList.add('form-select');
      else el.classList.add('form-control');
    });

    // Delay suave de entrada en tarjetas.
    document.querySelectorAll('.card, .panel, .box, .module, .m-card, .topic-card, .resource-card, .topic, .kl-soon-card').forEach(function(card, index){
      card.style.setProperty('--kl-delay', Math.min(index, 8) * 45 + 'ms');
      card.classList.add('kl-reveal');
    });

    // Microinteracción de ondas en botones/enlaces de acción.
    document.addEventListener('click', function(e){
      var target = e.target.closest('.btn, button.btn, a.btn, .btnEdit, .btnDel, .btnAssign, .btnToggle, .btnPerms, .btnReticula, .btnMaterias, .btnDanger, .btn-go');
      if(!target) return;
      var rect = target.getBoundingClientRect();
      var span = document.createElement('span');
      var size = Math.max(rect.width, rect.height);
      span.className = 'kl-ripple';
      span.style.width = span.style.height = size + 'px';
      span.style.left = (e.clientX - rect.left - size/2) + 'px';
      span.style.top = (e.clientY - rect.top - size/2) + 'px';
      target.appendChild(span);
      setTimeout(function(){ span.remove(); }, 650);
    }, {passive:true});

    // Cierra el sidebar móvil después de elegir una opción.
    document.querySelectorAll('#sidebar a').forEach(function(link){
      link.addEventListener('click', function(){
        if(window.innerWidth >= 1000) return;
        var sidebar = document.getElementById('sidebar');
        var overlay = document.getElementById('overlay');
        var menuBtn = document.getElementById('menuBtn');
        sidebar && sidebar.classList.remove('open');
        if(overlay) overlay.style.display = 'none';
        document.body.classList.remove('sidebar-open');
        menuBtn && menuBtn.setAttribute('aria-expanded','false');
      });
    });

    // Loading visual en formularios normales (evita formularios AJAX marcados con data-no-loading).
    document.querySelectorAll('form').forEach(function(form){
      if(form.dataset.noLoading === '1') return;
      form.addEventListener('submit', function(){
        var btn = form.querySelector('button[type="submit"], input[type="submit"]');
        if(!btn || btn.dataset.klLoading === '1') return;
        btn.dataset.klLoading = '1';
        if(btn.tagName === 'BUTTON'){
          btn.dataset.originalText = btn.innerHTML;
          btn.innerHTML = '<i class="fas fa-circle-notch fa-spin" aria-hidden="true"></i><span>Procesando...</span>';
        }
      });
    });

    // Dock inferior para celular: toma las primeras opciones reales del menú lateral.
    var sidebar = document.getElementById('sidebar');
    if(sidebar && !document.querySelector('.kl-mobile-dock')){
      var links = Array.from(sidebar.querySelectorAll('a')).filter(function(a){
        var label = (a.querySelector('.label')?.textContent || a.textContent || '').trim();
        return label && !/cerrar sesión|salir/i.test(label);
      }).slice(0,4);
      if(links.length){
        var dock = document.createElement('nav');
        dock.className = 'kl-mobile-dock';
        dock.setAttribute('aria-label','Accesos rápidos');
        dock.innerHTML = links.map(function(a){
          var icon = a.querySelector('i') ? a.querySelector('i').className : 'fas fa-circle';
          var label = (a.querySelector('.label')?.textContent || a.textContent || 'Opción').trim();
          var href = a.getAttribute('href') || '#';
          var active = a.classList.contains('active') ? ' active' : '';
          return '<a class="'+active+'" href="'+href.replace(/"/g,'&quot;')+'"><i class="'+icon.replace(/"/g,'&quot;')+'"></i><span>'+escapeHtml(label)+'</span></a>';
        }).join('');
        document.body.appendChild(dock);
      }
    }

    // Botón para volver arriba en páginas largas.
    if(!document.querySelector('.kl-scroll-top')){
      var topBtn = document.createElement('button');
      topBtn.type = 'button';
      topBtn.className = 'kl-scroll-top';
      topBtn.setAttribute('aria-label','Volver arriba');
      topBtn.innerHTML = '<i class="fas fa-arrow-up" aria-hidden="true"></i>';
      document.body.appendChild(topBtn);
      topBtn.addEventListener('click', function(){ window.scrollTo({top:0, behavior:'smooth'}); });
      var toggleTop = function(){ topBtn.classList.toggle('is-visible', window.scrollY > 420); };
      toggleTop();
      window.addEventListener('scroll', toggleTop, {passive:true});
    }

    // Tooltips nativos de Bootstrap si Bootstrap ya está disponible.
    if(window.bootstrap && window.bootstrap.Tooltip){
      document.querySelectorAll('[title]:not([data-bs-toggle])').forEach(function(el){
        if(el.dataset.klTooltip === '1') return;
        el.dataset.klTooltip = '1';
        el.setAttribute('data-bs-toggle','tooltip');
        el.setAttribute('data-bs-placement','bottom');
        try{ new window.bootstrap.Tooltip(el); }catch(e){}
      });
    }
  });
})();

// KnowLink Mobile Responsive helpers · 2026-05-24
(function(){
  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }
  function setViewportVars(){
    var vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--kl-vh', vh + 'px');
    document.body && document.body.classList.toggle('kl-is-mobile', window.innerWidth < 1000);
  }
  function closeMobileSidebar(){
    if(window.innerWidth >= 1000) return;
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('overlay');
    var menuBtn = document.getElementById('menuBtn');
    if(sidebar) sidebar.classList.remove('open');
    if(overlay) overlay.style.display = 'none';
    document.body.classList.remove('sidebar-open');
    if(menuBtn) menuBtn.setAttribute('aria-expanded','false');
  }
  ready(function(){
    setViewportVars();
    window.addEventListener('resize', setViewportVars, {passive:true});
    window.addEventListener('orientationchange', function(){ setTimeout(setViewportVars, 250); }, {passive:true});

    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('overlay');
    var menuBtn = document.getElementById('menuBtn');
    if(menuBtn && sidebar){
      menuBtn.addEventListener('click', function(){
        setTimeout(function(){
          var isOpen = sidebar.classList.contains('open');
          document.body.classList.toggle('sidebar-open', isOpen && window.innerWidth < 1000);
          menuBtn.setAttribute('aria-expanded', String(isOpen));
        }, 0);
      }, {passive:true});
    }
    if(overlay){
      overlay.addEventListener('click', function(){
        document.body.classList.remove('sidebar-open');
        if(menuBtn) menuBtn.setAttribute('aria-expanded','false');
      }, {passive:true});
    }
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape') closeMobileSidebar();
    });
    window.addEventListener('resize', function(){
      if(window.innerWidth >= 1000){
        document.body.classList.remove('sidebar-open');
        if(overlay) overlay.style.display = 'none';
      }
    }, {passive:true});

    // Mejora mobile: las tarjetas clicables también se pueden activar con teclado.
    document.querySelectorAll('.m-card, .topic-card, .resource-card, .cont-item').forEach(function(card){
      if(!card.hasAttribute('tabindex')) card.setAttribute('tabindex','0');
      card.setAttribute('role', card.getAttribute('role') || 'button');
    });
  });
})();

// KnowLink Mobile Menu cleanup · usa dock inferior en celular
(function(){
  function ready(fn){
    if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', fn);
    else fn();
  }
  function closeSidebarOnMobile(){
    if(!window.matchMedia || !window.matchMedia('(max-width: 999px)').matches) return;
    var sidebar = document.getElementById('sidebar');
    var overlay = document.getElementById('overlay');
    var menuBtn = document.getElementById('menuBtn');
    if(sidebar) sidebar.classList.remove('open');
    if(overlay) overlay.style.display = 'none';
    document.body && document.body.classList.remove('sidebar-open');
    if(menuBtn){
      menuBtn.setAttribute('aria-hidden','true');
      menuBtn.setAttribute('aria-expanded','false');
      menuBtn.setAttribute('tabindex','-1');
    }
  }
  function restoreMenuOnDesktop(){
    if(!window.matchMedia || window.matchMedia('(max-width: 999px)').matches) return;
    var menuBtn = document.getElementById('menuBtn');
    if(menuBtn){
      menuBtn.removeAttribute('aria-hidden');
      menuBtn.removeAttribute('tabindex');
    }
  }
  ready(function(){
    closeSidebarOnMobile();
    restoreMenuOnDesktop();
    window.addEventListener('resize', function(){
      closeSidebarOnMobile();
      restoreMenuOnDesktop();
    }, {passive:true});
    window.addEventListener('orientationchange', function(){
      setTimeout(closeSidebarOnMobile, 120);
    }, {passive:true});
  });
})();
