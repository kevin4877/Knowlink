<?php
// public/docente/notificaciones.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/auth.php';
require_once __DIR__ . '/../../src/helpers.php';

header('Content-Type: application/json; charset=utf-8');

start_session();
$u = auth_user();
if (!$u || ($u['rol'] ?? '') !== 'docente') {
  http_response_code(403);
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
  exit;
}

$pdo = db();

try {
  // since_id: para calcular cuántas nuevas hay (badge)
  $sinceId   = isset($_GET['since_id']) ? (int)$_GET['since_id'] : 0;
  $docenteId = (int)($u['id'] ?? 0);

  // Conteo de nuevas para el badge
  $countStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM docente_notifs
    WHERE docente_id = :d AND id > :since_id
  ");
  $countStmt->execute([':d'=>$docenteId, ':since_id'=>$sinceId]);
  $totalNew = (int)$countStmt->fetchColumn();

  // Últimas 10 para listar en el menú
  $listStmt = $pdo->prepare("
    SELECT id, tipo, descripcion,
           creado_en, DATE_FORMAT(creado_en, '%Y-%m-%d %H:%i') AS creado_en_fmt
    FROM docente_notifs
    WHERE docente_id = :d
    ORDER BY id DESC
    LIMIT 10
  ");
  $listStmt->execute([':d'=>$docenteId]);
  $items = $listStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

  echo json_encode(['total'=>$totalNew,'items'=>$items], JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
  // Si la tabla no existe o hay cualquier fallo, devolvemos vacío (como admin)
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
}
