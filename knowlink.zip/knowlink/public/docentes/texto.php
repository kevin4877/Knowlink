<?php
// public/docentes/texto.php
// Vista limpia para que el docente revise apuntes de texto.
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'docente') { http_response_code(403); echo 'Acceso denegado'; exit; }

function escx($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$assetId = (int)($_GET['id'] ?? 0);
if ($assetId <= 0) { http_response_code(400); echo 'Apunte inválido.'; exit; }

$pdo = db();
$st = $pdo->prepare("\n  SELECT\n    a.id, a.titulo, a.texto_largo, a.creado_en,\n    c.id AS contenido_id, c.titulo AS contenido_titulo, c.visibilidad, c.docente_id,\n    t.titulo AS tema_titulo,\n    uu.numero AS unidad_numero, uu.titulo AS unidad_titulo,\n    m.clave AS materia_clave, m.nombre AS materia_nombre\n  FROM contenido_activos a\n  JOIN contenidos c ON c.id = a.contenido_id\n  JOIN temas t ON t.id = c.tema_id\n  JOIN unidades uu ON uu.id = t.unidad_id\n  JOIN materias m ON LOWER(m.clave) = LOWER(uu.materia_clave)\n  WHERE a.id = :id AND a.tipo = 'texto'\n  LIMIT 1\n");
$st->execute([':id' => $assetId]);
$A = $st->fetch(PDO::FETCH_ASSOC);

if (!$A) { http_response_code(404); echo 'Apunte no encontrado.'; exit; }
if ((int)$A['docente_id'] !== (int)$yo['id'] && (string)$A['visibilidad'] !== 'publico') {
  http_response_code(403); echo 'No tienes permiso para abrir este apunte.'; exit;
}

$title = 'Apunte · ' . (($A['titulo'] ?? '') ?: ($A['contenido_titulo'] ?? 'Texto'));
$active = 'recursos';
require __DIR__ . '/partials/header.php';
?>
<style>
  .text-reader-wrap{max-width:980px;margin:0 auto}
  .text-reader-head{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;margin-bottom:16px;flex-wrap:wrap}
  .text-reader-title{font-size:24px;font-weight:950;color:#0b2545;line-height:1.18;letter-spacing:-.02em}
  .text-reader-meta{margin-top:8px;color:#64748b;font-size:14px;line-height:1.55}
  .reader-card{background:#fff;border:1px solid #e6eef2;border-radius:24px;box-shadow:0 16px 38px rgba(15,23,42,.08);padding:24px}
  .reader-content{white-space:pre-wrap;color:#1e293b;font-size:16px;line-height:1.8;overflow-wrap:anywhere}
  .btn-reader{display:inline-flex;align-items:center;gap:8px;text-decoration:none;border-radius:14px;padding:11px 15px;border:1px solid #dbeafe;background:#fff;color:#0b2545;font-weight:900}
  .btn-reader:hover{background:#f5f9ff;color:#0284c7}
  html[data-theme="dark"] .text-reader-title{color:#f8fafc!important}
  html[data-theme="dark"] .text-reader-meta{color:#b8c4d6!important}
  html[data-theme="dark"] .reader-card{background:linear-gradient(180deg,rgba(15,31,54,.96),rgba(8,18,34,.98))!important;border-color:rgba(125,211,252,.18)!important;box-shadow:0 18px 46px rgba(0,0,0,.32),inset 0 1px 0 rgba(255,255,255,.04)}
  html[data-theme="dark"] .reader-content{color:#edf6ff!important}
  html[data-theme="dark"] .btn-reader{background:rgba(255,255,255,.06)!important;border-color:rgba(148,163,184,.2)!important;color:#e8f1ff!important}
  @media (max-width:768px){.reader-card{padding:18px;border-radius:20px}.text-reader-title{font-size:20px}.reader-content{font-size:15px}}
</style>

<div class="text-reader-wrap">
  <div class="text-reader-head">
    <div>
      <div class="text-reader-title"><?= escx($A['titulo'] ?: $A['contenido_titulo'] ?: 'Apunte de texto') ?></div>
      <div class="text-reader-meta">
        <?= escx($A['materia_nombre'] ?? '') ?> · Unidad <?= (int)($A['unidad_numero'] ?? 0) ?> — <?= escx($A['unidad_titulo'] ?? '') ?><br>
        Tema: <?= escx($A['tema_titulo'] ?? '') ?>
      </div>
    </div>
    <a class="btn-reader" href="<?= escx(base_url('docentes/temas.php')) ?>"><i class="fas fa-arrow-left"></i> Volver</a>
  </div>

  <article class="reader-card">
    <div class="reader-content"><?= escx((string)($A['texto_largo'] ?? '')) ?></div>
  </article>
</div>

<?php require __DIR__ . '/partials/footer.php'; ?>
