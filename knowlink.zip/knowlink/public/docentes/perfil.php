<?php
// public/docentes/perfil.php
// Entrada del perfil para docentes. Usa el perfil unificado sin duplicar lógica.
declare(strict_types=1);
require __DIR__ . '/../perfil.php';
