<?php
// public/docente/partials/header.php

// esc()
if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}

// Placeholder por defecto
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}

// Polyfill para PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

/**
 * Normaliza cualquier valor de foto_url para que el <img> siempre reciba
 * una URL web válida y (si es posible) absoluta.
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();

    $u = trim(str_replace('\\', '/', $url));
    if ($u === '') return avatar_placeholder();

    // Externa o data URI => tal cual
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) {
      return $u;
    }

    // Acepta rutas guardadas como /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/...
    // o incluso rutas completas de Windows que contengan public/uploads/avatars/...
    while (str_starts_with($u, '../')) { $u = substr($u, 3); }
    if (preg_match('~uploads/avatars/[^?#]+~i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = str_starts_with($u, '/') ? $u : '/' . ltrim($u, '/');
    }

    $src = function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;

    // Evita que el navegador deje en caché una foto anterior en la barra superior.
    if (preg_match('#^/uploads/avatars/#', $path)) {
      $publicRoot = realpath(__DIR__ . '/../../');
      $file = $publicRoot ? ($publicRoot . $path) : null;
      if ($file && is_file($file)) {
        $src .= (strpos($src, '?') === false ? '?' : '&') . 'v=' . filemtime($file);
      }
    }

    return $src;
  }
}

$title  = $title  ?? 'KnowLink · Docente';
$active = $active ?? '';
// Fallback por si la vista no pasó $yo explícitamente
if (!isset($yo) && isset($_SESSION['user'])) { $yo = $_SESSION['user']; }

// Refresca el usuario desde BD para que el avatar superior cambie al actualizar el perfil.
if (function_exists('auth_user')) {
  $freshUser = auth_user();
  if (is_array($freshUser) && (!isset($yo['id']) || (int)$freshUser['id'] === (int)$yo['id'])) {
    $yo = $freshUser;
  }
}
$avatarTopbarSrc = foto_src($yo['foto_url'] ?? ($yo['foto'] ?? null));
?>
<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?= esc($title) ?></title>

<!-- FontAwesome por CDN para íconos -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

<style>
  *{box-sizing:border-box;margin:0;padding:0}
  :root{ --accent:#0055d4; --accent-2:#99acc0; --bg:#f6f8fb; --topbar-h:70px; --sidebar-w:260px; --sidebar-narrow:84px; --muted:#6b7280; --card-bg:#ffffff; }
  html,body{height:100%;font-family:Inter, system-ui, Arial, sans-serif;background:var(--bg);color:#0f172a}
  body{padding-top:var(--topbar-h);overflow-x:hidden}

  /* TOPBAR (igual que Admin) */
  .topbar{position:fixed;top:0;left:0;right:0;height:var(--topbar-h);display:flex;align-items:center;gap:12px;padding:0 18px;background:linear-gradient(90deg,var(--accent-2),var(--accent));color:#fff;z-index:1200;box-shadow:0 6px 18px rgba(31,111,235,0.12)}
  .menu-btn{background:transparent;border:0;color:#fff;font-size:20px;cursor:pointer;padding:8px}
  .brand-small{width:30px;height:30px;margin-left:4px;margin-right:6px;border-radius:6px;background:#ffffff1a;display:inline-flex;align-items:center;justify-content:center;font-weight:900}
  .logo-text{font-weight:800;font-size:18px;white-space:nowrap}

  /* Notifs */
  .notif-area{position:relative}
  .ui-icon{display:inline-flex;align-items:center;gap:8px;cursor:pointer;padding:6px 8px;border-radius:8px;color:#fff;position:relative;transition:background .12s, transform .08s;background:transparent}
  .ui-icon:hover{background:rgba(255,255,255,.06);transform:translateY(-2px)}
  .ui-icon i{font-size:18px;line-height:1;display:inline-block}
  .ui-badge{position:absolute;top:-6px;right:-6px;min-width:18px;height:18px;padding:0 5px;font-size:11px;line-height:18px;text-align:center;border-radius:999px;background:#ef4444;color:#fff;font-weight:700;box-shadow:0 4px 10px rgba(0,0,0,0.12)}
  .notif-menu{position:absolute;right:0;top:calc(100% + 8px);width:320px;background:#fff;color:#0f172a;border-radius:10px;box-shadow:0 14px 40px rgba(2,6,23,.18);border:1px solid #eef2f6;display:none;z-index:1300}
  .notif-menu[aria-hidden="false"]{display:block}
  .notif-head{padding:10px 12px;font-weight:800;border-bottom:1px dashed #eef2f6;background:#fff;position:sticky;top:0;z-index:1}
  .notif-empty{padding:12px;color:#64748b;font-size:14px}
  .notif-item{display:flex;gap:10px;align-items:flex-start;padding:10px 12px;border-bottom:1px dashed #eef2f6}
  .notif-item:last-child{border-bottom:0}
  .notif-item .ico{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:#f1f5ff;color:var(--accent)}
  .notif-item .txt{font-size:14px;line-height:1.35}
  .notif-item .meta{font-size:12px;color:#64748b;margin-top:2px}

  /* Solo la lista scrollea */
  .notif-menu{ max-height: min(70vh, 520px); }
  #notifList{
    max-height: clamp(220px, 50vh, 420px);
    overflow-y: auto;
    overscroll-behavior: contain;
    -webkit-overflow-scrolling: touch;
    padding-right: 4px;
  }
  /* Estética scrollbar */
  #notifList::-webkit-scrollbar{ width: 10px; }
  #notifList::-webkit-scrollbar-thumb{ background: #cbd5e1; border-radius: 8px; }
  #notifList{ scrollbar-width: thin; scrollbar-color: #cbd5e1 transparent; }

  /* User */
  .user-area{position:relative}
  .user-toggle{display:flex;align-items:center;gap:10px;padding:6px;border-radius:8px;cursor:pointer;background:transparent;border:0;color:#fff}
  .user-name{font-weight:600;font-size:14px;color:#fff}
  .profile{width:36px;height:36px;border-radius:50%;object-fit:cover;background:#ffffff1a}
  .user-menu{position:absolute;right:0;top:calc(100% + 8px);width:240px;background:#fff;color:#0f172a;border-radius:10px;box-shadow:0 14px 40px rgba(2,6,23,.18);border:1px solid #eef2f6;display:none;z-index:1300}
  .user-menu[aria-hidden="false"]{display:block}
  .user-menu a{display:flex;gap:10px;align-items:center;padding:10px 12px;text-decoration:none;color:inherit;border-bottom:1px dashed #eef2f6}
  .user-menu a:last-child{border-bottom:0}
  .user-menu a:hover,.user-menu a:focus{background:#f5f8ff;color:var(--accent)}
  .user-menu .meta{padding:10px 12px;font-size:13px;color:#64748b;border-bottom:1px dashed #eef2f6}
  .user-menu .meta strong{color:#0f172a;display:block}

  .user-area.open .user-toggle,
  .notif-area.open .ui-icon{ background: rgba(255,255,255,0.10); box-shadow: 0 0 0 3px rgba(255,255,255,0.28); border-radius: 8px; }
  .user-area .fa-chevron-down { transition: transform .18s ease; }
  .user-area.open .fa-chevron-down { transform: rotate(180deg); }

  /* Sidebar */
  .sidebar{position:fixed;top:var(--topbar-h);left:0;width:var(--sidebar-w);height:calc(100% - var(--topbar-h));background:#fff;color:#222;padding:18px;box-shadow:0 8px 30px rgba(2,6,23,0.06);transition:width .22s ease;z-index:1150;overflow:auto}
  .sidebar.collapsed{width:var(--sidebar-narrow)}
  .sidebar-header{display:flex;align-items:center;gap:10px;margin-bottom:20px}
  .sidebar-header .mini{width:34px;height:34px;border-radius:8px;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;font-weight:900}
  .sidebar-header h2{font-size:18px;font-weight:800;margin:0}
  .sidebar.collapsed .sidebar-header{justify-content:center}
  .sidebar.collapsed .sidebar-header h2{display:none}
  .sidebar.collapsed ul li a .label{ display:none; }
  .sidebar ul{list-style:none;padding:0;margin:0}
  .sidebar ul li{margin:8px 0}
  .sidebar ul li a{display:flex;align-items:center;gap:12px;padding:10px 8px;text-decoration:none;color:inherit;border-radius:8px;font-weight:700;transition: background .12s ease, transform .08s ease, color .12s ease}
  .sidebar ul li a i{width:22px;text-align:center}
  .sidebar ul li a.active{background:linear-gradient(90deg,rgba(0,85,212,.08),rgba(0,85,212,.04));color:var(--accent)}
  .sidebar ul li a:hover,.sidebar ul li a:focus{background:#f5f8ff;color:var(--accent);transform:translateY(-2px)}

  /* Botones */
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800;background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545;}
  .btn.small{padding:6px 10px;border-radius:8px;font-weight:700;}
  .btn-icon{display:inline-flex;align-items:center;gap:8px;}
  a.btn{text-decoration:none;}

  /* Móvil */
  @media (max-width:680px){
    .btn-icon .label{ display:none !important; }
    .btn-icon{ padding:10px; gap:0; }
  }

  /* Content */
  .content-wrap{transition:margin-left .22s ease;margin-left:var(--sidebar-w);padding:28px;max-width:1200px;margin-right:auto;box-sizing:border-box}
  body.sidebar-collapsed .content-wrap,.sidebar.collapsed ~ .content-wrap{margin-left:var(--sidebar-narrow)}
  .main{min-height:calc(100vh - var(--topbar-h))}
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:var(--muted);font-size:14px}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}

  /* Adaptaciones móviles para menús flotantes */
  @media (max-width:999px){
    .sidebar{ transform: translateX(-100%); left:0; transition:transform .18s ease; }
    .sidebar.open{ transform: translateX(0); left:0; }
    .content-wrap{ margin-left:0; padding:16px; }
    body.sidebar-collapsed .content-wrap{ margin-left:0; }
    .logo-text{ display:none; }
    .user-name{ display:none; }
    .menu-btn,.user-toggle,.ui-icon{ padding:10px 12px; }
  }
  @media (max-width:680px){
    .notif-menu,.user-menu{
      position: fixed; top: calc(var(--topbar-h) + 8px); left: 12px; right: 12px;
      width: auto; max-height: 60vh; border-radius: 12px; z-index: 1300;
      overflow: visible;
    }
    #notifList{ max-height: calc(60vh - 44px); }
  }

  a:focus, button:focus{ outline: 3px solid rgba(0,85,212,0.14); outline-offset: 2px; border-radius: 8px; }
</style>

<!-- Bootstrap + capa visual KnowLink -->
<script>
(function(){
  try{
    var saved = localStorage.getItem('knowlink-theme');
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = (saved === 'dark' || saved === 'light') ? saved : (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-bs-theme', theme);
  }catch(e){
    document.documentElement.setAttribute('data-theme', 'light');
    document.documentElement.setAttribute('data-bs-theme', 'light');
  }
})();
</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/css/knowlink-modern.css') : '/assets/css/knowlink-modern.css', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-dock-perfil">
</head>
<body>

  <!-- TOPBAR -->
  <header class="topbar" role="banner">
    <button id="menuBtn" class="menu-btn" aria-label="Abrir o cerrar menú" aria-expanded="true"><i class="fas fa-bars"></i></button>
    <div class="brand-small">KL</div>
    <div class="logo-text">KnowLink · Docente</div>

    <div style="margin-left:auto;display:flex;align-items:center;gap:12px">
      <button id="themeToggle" class="ui-icon theme-toggle" type="button" data-theme-toggle aria-label="Cambiar modo claro u oscuro" title="Cambiar modo claro u oscuro">
        <i class="fas fa-moon" aria-hidden="true"></i><span class="theme-label">Oscuro</span>
      </button>

      <!-- Notificaciones -->
      <div class="notif-area" id="notifArea">
        <button id="notifBtn" class="ui-icon" aria-haspopup="menu" aria-expanded="false" aria-controls="notifMenu" title="Notificaciones" aria-label="Notificaciones">
          <i class="fas fa-bell"></i>
          <span id="notifBadge" class="ui-badge" style="display:none;">0</span>
        </button>
        <div id="notifMenu" class="notif-menu" role="menu" aria-hidden="true" aria-label="Notificaciones">
          <div class="notif-head">Notificaciones</div>
          <div id="notifList"><div class="notif-empty">Sin novedades por ahora.</div></div>
        </div>
      </div>

      <!-- Usuario -->
      <div class="user-area" id="userArea">
        <button id="userDropdownBtn" class="user-toggle" aria-haspopup="menu" aria-expanded="false">
          <img class="profile" src="<?= esc($avatarTopbarSrc) ?>" alt="Perfil">
          <span class="user-name"><?= esc($yo['nombre'] ?? 'Docente') ?></span>
          <i class="fas fa-chevron-down" aria-hidden="true"></i>
        </button>
        <nav id="userMenu" class="user-menu" role="menu" aria-hidden="true" aria-label="Menú de usuario">
          <div class="meta">
            <strong><?= esc(($yo['nombre'] ?? '').' '.($yo['apellidos'] ?? '')) ?></strong>
            <span style="color:#94a3b8;"><?= esc($yo['email'] ?? '') ?></span>
          </div>
          <a role="menuitem" tabindex="-1" href="<?= esc(base_url('docentes/perfil.php')) ?>"><i class="fas fa-user"></i> Mi perfil</a>
          <a role="menuitem" tabindex="-1" href="<?= esc(base_url('logout.php')) ?>"><i class="fas fa-right-from-bracket"></i> Cerrar sesión</a>
        </nav>
      </div>
    </div>
  </header>

  <!-- SIDEBAR -->
  <aside id="sidebar" class="sidebar" role="navigation" aria-label="Menú docente">
    <div class="sidebar-header">
      <div class="mini">KL</div><h2>Panel</h2>
    </div>
    <ul>
      <li><a class="<?= $active==='index'?'active':'' ?>" href="<?= esc(base_url('docentes/index.php')) ?>"><i class="fas fa-home"></i><span class="label">Datos generales</span></a></li>
      <li><a class="<?= $active==='recursos'?'active':'' ?>" href="<?= esc(base_url('docentes/seleccionar_materia.php')) ?>"><i class="fas fa-cloud-arrow-up"></i><span class="label">Subir recursos</span></a></li>
      <li><a class="<?= $active==='grupos'?'active':'' ?>" href="<?= esc(base_url('docentes/grupos.php')) ?>"><i class="fas fa-users"></i><span class="label">Grupos</span></a></li>
      <li><a class="<?= $active==='cursos'?'active':'' ?>" href="<?= esc(base_url('docentes/cursos.php')) ?>"><i class="fas fa-chalkboard-teacher"></i><span class="label">Cursos</span></a></li>
      <li><a href="<?= esc(base_url('logout.php')) ?>"><i class="fas fa-right-from-bracket"></i><span class="label">Cerrar sesión</span></a></li>
    </ul>
  </aside>

  <div class="content-wrap" id="contentWrap">
    <main class="main" role="main" id="mainContent">
