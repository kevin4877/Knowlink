<?php
// docentes/temas.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';
require_once __DIR__ . '/../../src/asset_paths.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'docente') { http_response_code(403); echo "Acceso denegado"; exit; }

header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$pdo = db();

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ================= Helpers ================= */
function json_out($arr, int $code=200){
  http_response_code($code);
  header('Content-Type: application/json; charset=utf-8');
  echo json_encode($arr, JSON_UNESCAPED_UNICODE);
  exit;
}
function ensure_dir(string $dir): bool {
  if (is_dir($dir)) return true;
  return @mkdir($dir, 0775, true);
}
function file_tipo_from_ext(string $ext): string {
  $e = strtolower($ext);
  $map = [
    'pdf'=>'pdf',
    'doc'=>'word','docx'=>'word',
    'ppt'=>'powerpoint','pptx'=>'powerpoint',
    'xls'=>'excel','xlsx'=>'excel','csv'=>'excel',
    'jpg'=>'imagen','jpeg'=>'imagen','png'=>'imagen','gif'=>'imagen','webp'=>'imagen','svg'=>'imagen',
    'mp4'=>'video','mov'=>'video','m4v'=>'video','avi'=>'video','mkv'=>'video','webm'=>'video',
    'txt'=>'texto','md'=>'texto','rtf'=>'texto',
    'url'=>'enlace','link'=>'enlace'
  ];
  return $map[$e] ?? 'otro';
}
function docente_puede_materia(PDO $pdo, int $docente_id, string $materia): bool {
  $st = $pdo->prepare("SELECT 1 FROM docente_permisos_materia WHERE docente_id=:d AND LOWER(materia_clave)=LOWER(:m)");
  $st->execute([':d'=>$docente_id, ':m'=>$materia]);
  return (bool)$st->fetchColumn();
}
function unidad_pertenece_materia(PDO $pdo, int $unidad_id, string $materia): bool {
  $st = $pdo->prepare("SELECT COUNT(*) FROM unidades WHERE id=:u AND LOWER(materia_clave)=LOWER(:m)");
  $st->execute([':u'=>$unidad_id, ':m'=>$materia]);
  return ((int)$st->fetchColumn() > 0);
}
function tema_pertenece_materia(PDO $pdo, int $tema_id, string $materia): bool {
  $sql = "SELECT COUNT(*)
          FROM temas t
          JOIN unidades u ON u.id = t.unidad_id
          WHERE t.id=:t AND LOWER(u.materia_clave)=LOWER(:m)";
  $st = $pdo->prepare($sql);
  $st->execute([':t'=>$tema_id, ':m'=>$materia]);
  return ((int)$st->fetchColumn() > 0);
}
function tema_pertenece_docente(PDO $pdo, int $tema_id, int $docente_id): bool {
  $st = $pdo->prepare("SELECT COUNT(*) FROM contenidos WHERE tema_id=:t AND docente_id=:d");
  $st->execute([':t'=>$tema_id, ':d'=>$docente_id]);
  return ((int)$st->fetchColumn() > 0);
}
function contenido_pertenece(PDO $pdo, int $contenido_id, int $docente_id): bool {
  $st = $pdo->prepare("SELECT COUNT(*) FROM contenidos WHERE id=:c AND docente_id=:d");
  $st->execute([':c'=>$contenido_id, ':d'=>$docente_id]);
  return ((int)$st->fetchColumn() > 0);
}
function contenido_es_publico_o_propio(PDO $pdo, int $contenido_id, int $docente_id): bool {
  $st = $pdo->prepare("SELECT docente_id, visibilidad FROM contenidos WHERE id=:c");
  $st->execute([':c'=>$contenido_id]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if (!$row) return false;
  if ((int)$row['docente_id'] === $docente_id) return true;
  return (string)$row['visibilidad'] === 'publico';
}
function uploads_public_root(): string {
  $base = realpath(__DIR__ . '/../../public/uploads/recursos') ?: (__DIR__ . '/../../public/uploads/recursos');
  return rtrim($base, DIRECTORY_SEPARATOR);
}
function activo_tipo_soporta_ingesta(string $tipo): bool {
  return in_array(strtolower(trim($tipo)), ['pdf','word','texto'], true);
}
function normalizar_public_url_a_ruta_local(string $url): ?string {
  return kl_resolve_asset_path_from_url($url);
}
function registrar_activo_para_ingesta(PDO $pdo, int $activoId): void {
  $sql = "
    SELECT
      a.id AS activo_id,
      a.contenido_id,
      a.tipo,
      a.titulo,
      a.url,
      a.texto_largo,
      c.docente_id,
      c.tema_id,
      t.unidad_id,
      u.materia_clave
    FROM contenido_activos a
    JOIN contenidos c ON c.id = a.contenido_id
    JOIN temas t      ON t.id = c.tema_id
    JOIN unidades u   ON u.id = t.unidad_id
    WHERE a.id = :a
    LIMIT 1
  ";
  $st = $pdo->prepare($sql);
  $st->execute([':a' => $activoId]);
  $row = $st->fetch(PDO::FETCH_ASSOC);

  if (!$row) return;

  $tipo = strtolower(trim((string)($row['tipo'] ?? 'otro')));
  $rutaLocal = null;
  $hashArchivo = null;
  if (!empty($row['url'])) {
    $rutaLocal = normalizar_public_url_a_ruta_local((string)$row['url']);
    if ($rutaLocal && is_file($rutaLocal)) {
      $hashArchivo = hash_file('sha256', $rutaLocal) ?: null;
    }
  }

  $textoCrudo = null;
  $textoLimpio = null;
  $caracteresTotal = null;

  if ($tipo === 'texto') {
    $textoCrudo = trim((string)($row['texto_largo'] ?? ''));
    $textoLimpio = $textoCrudo;
    $caracteresTotal = mb_strlen((string)$textoLimpio, 'UTF-8');
  }

  $estado = activo_tipo_soporta_ingesta($tipo) ? 'pendiente' : 'listo';

  $pdo->prepare("DELETE FROM cola_ingesta_activos WHERE activo_id = :a")
      ->execute([':a' => $activoId]);
  $pdo->prepare("DELETE FROM activo_texto_extraido WHERE activo_id = :a")
      ->execute([':a' => $activoId]);

  $ins = $pdo->prepare("
    INSERT INTO activo_texto_extraido (
      activo_id,
      contenido_id,
      tema_id,
      unidad_id,
      materia_clave,
      docente_id,
      fuente_tipo,
      ruta_origen,
      nombre_archivo,
      hash_archivo,
      idioma,
      texto_crudo,
      texto_limpio,
      paginas_total,
      caracteres_total,
      estado,
      error_detalle,
      extraido_en
    ) VALUES (
      :activo_id,
      :contenido_id,
      :tema_id,
      :unidad_id,
      :materia_clave,
      :docente_id,
      :fuente_tipo,
      :ruta_origen,
      :nombre_archivo,
      :hash_archivo,
      'es',
      :texto_crudo,
      :texto_limpio,
      NULL,
      :caracteres_total,
      :estado,
      NULL,
      NULL
    )
  ");

  $ins->execute([
    ':activo_id'        => (int)$row['activo_id'],
    ':contenido_id'     => (int)$row['contenido_id'],
    ':tema_id'          => (int)$row['tema_id'],
    ':unidad_id'        => (int)$row['unidad_id'],
    ':materia_clave'    => (string)$row['materia_clave'],
    ':docente_id'       => (int)$row['docente_id'],
    ':fuente_tipo'      => $tipo,
    ':ruta_origen'      => $rutaLocal ?: ((string)($row['url'] ?? '') !== '' ? (string)$row['url'] : null),
    ':nombre_archivo'   => (string)($row['titulo'] ?? ''),
    ':hash_archivo'     => $hashArchivo,
    ':texto_crudo'      => $textoCrudo,
    ':texto_limpio'     => $textoLimpio,
    ':caracteres_total' => $caracteresTotal,
    ':estado'           => $estado,
  ]);

  if (activo_tipo_soporta_ingesta($tipo)) {
    $pdo->prepare("
      INSERT INTO cola_ingesta_activos (
        activo_id, prioridad, estado, intentos, disponible_desde
      ) VALUES (
        :activo_id, 5, 'pendiente', 0, CURRENT_TIMESTAMP
      )
    ")->execute([
      ':activo_id' => $activoId
    ]);
  }
}
function limpiar_ingesta_de_activo(PDO $pdo, int $activoId): void {
  $pdo->prepare("DELETE FROM cola_ingesta_activos WHERE activo_id = :a")
      ->execute([':a' => $activoId]);
  $pdo->prepare("DELETE FROM activo_texto_extraido WHERE activo_id = :a")
      ->execute([':a' => $activoId]);
}
function borrar_archivo_de_activo(?string $url): void {
  $url = trim((string)$url);
  if ($url === '') return;
  $ruta = normalizar_public_url_a_ruta_local($url);
  if ($ruta && is_file($ruta)) {
    @unlink($ruta);
  }
}

/* ============= Materia seleccionada (POST o sesión) ============= */
$docId = (int)$yo['id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['materia'])) {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) { http_response_code(400); echo "CSRF inválido"; exit; }
  $materia = (string)$_POST['materia'];
  $_SESSION['docente_materia_actual'] = $materia;
} else {
  $materia = (string)($_SESSION['docente_materia_actual'] ?? '');
}

$materia = trim($materia);
if ($materia === '') { redirect(base_url('docentes/seleccionar_materia.php')); exit; }
$materiaCanonica = resolve_materia_clave($pdo, $materia);
if (!$materiaCanonica) {
  unset($_SESSION['docente_materia_actual']);
  http_response_code(404); echo "Materia no encontrada."; exit;
}
$materia = $materiaCanonica;
$_SESSION['docente_materia_actual'] = $materia;
if (!docente_puede_materia($pdo, $docId, $materia)) {
  unset($_SESSION['docente_materia_actual']);
  http_response_code(403); echo "No tienes permiso sobre la materia seleccionada."; exit;
}

/* ================= AJAX ================= */
$method = strtoupper($_SERVER['REQUEST_METHOD'] ?? 'GET');

if (isset($_GET['ajax']) || ($method === 'POST' && (isset($_POST['ajax']) || stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json')!==false))) {
  $ajax = $_GET['ajax'] ?? ($_POST['ajax'] ?? '');
  $in = [];
  if ($method === 'POST' && stripos($_SERVER['CONTENT_TYPE'] ?? '', 'application/json') !== false) {
    $raw = file_get_contents('php://input');
    $in  = json_decode($raw, true) ?: [];
    $ajax = $in['ajax'] ?? $ajax;
  }

  // Todas excepto uploads requieren CSRF
  if ($ajax !== 'upload_file') {
    $csrf = $in['csrf'] ?? ($_POST['csrf'] ?? $_GET['csrf'] ?? '');
    if (!hash_equals($CSRF, (string)$csrf)) json_out(['ok'=>false,'err'=>'csrf'], 400);
  }

  try {
    /* -------- Unidades -------- */
    if ($ajax === 'list_unidades') {
      $st = $pdo->prepare("SELECT id, numero, titulo, descripcion FROM unidades WHERE LOWER(materia_clave)=LOWER(:m) ORDER BY numero ASC");
      $st->execute([':m'=>$materia]);
      $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      json_out(['ok'=>true, 'items'=>$rows]);
    }

    /* -------- Crear tema (+ notificaciones solo si NO es privado) -------- */
    if ($ajax === 'crear_tema') {
      $unidad  = (int)($in['unidad_id'] ?? 0);
      $titulo  = trim((string)($in['titulo'] ?? ''));
      $desc    = trim((string)($in['descripcion'] ?? ''));
      $vis     = (string)($in['visibilidad'] ?? 'privado');

      if ($unidad<=0 || $titulo==='') json_out(['ok'=>false,'err'=>'param'], 400);
      if (!in_array($vis, ['privado','solo_estudiantes','publico'], true)) $vis = 'privado';
      if (!unidad_pertenece_materia($pdo, $unidad, $materia)) json_out(['ok'=>false,'err'=>'unidad_materia'], 400);

      $pdo->beginTransaction();
      // 1) Tema
      $insT = $pdo->prepare("INSERT INTO temas (unidad_id, titulo, descripcion) VALUES (:u,:t,:d)");
      $insT->execute([':u'=>$unidad, ':t'=>$titulo, ':d'=>$desc ?: null]);
      $temaId = (int)$pdo->lastInsertId();

      // 2) Contenido del docente (ese tema)
      $insC = $pdo->prepare("INSERT INTO contenidos (tema_id, docente_id, visibilidad, titulo, descripcion) VALUES (:tema,:doc,:v,:t,:d)");
      $insC->execute([':tema'=>$temaId, ':doc'=>$docId, ':v'=>$vis, ':t'=>$titulo, ':d'=>$desc ?: null]);
      $contId = (int)$pdo->lastInsertId();

      // 3) Notificaciones a estudiantes EN CURSO SOLO si visibilidad != 'privado'
      if ($vis !== 'privado') {
        $insN = $pdo->prepare("
          INSERT INTO estudiante_notifs (estudiante_id, tipo, materia_clave, unidad_id, tema_id, contenido_id, titulo)
          SELECT e.usuario_id, 'tema_nuevo', :materia, :unidad, :tema, :contenido, :titulo
          FROM estudiantes e
          JOIN reticula_materias rm
            ON rm.reticula_id = e.reticula_id
           AND LOWER(rm.materia_clave) = LOWER(:materia)
          WHERE e.semestre_actual IS NOT NULL
            AND rm.semestre = e.semestre_actual
        ");
        $insN->execute([
          ':materia'   => $materia,
          ':unidad'    => $unidad,
          ':tema'      => $temaId,
          ':contenido' => $contId,
          ':titulo'    => $titulo
        ]);
      }

      $pdo->commit();
      json_out(['ok'=>true, 'tema_id'=>$temaId, 'contenido_id'=>$contId]);
    }

    /* -------- Listar mis temas y públicos de otros -------- */
    if ($ajax === 'list_temas') {
      $unidad  = (int)($in['unidad_id'] ?? ($_GET['unidad_id'] ?? 0));
      if ($unidad<=0) json_out(['ok'=>false,'err'=>'param'], 400);
      if (!unidad_pertenece_materia($pdo, $unidad, $materia)) json_out(['ok'=>false,'err'=>'unidad_materia'], 400);

      // Mis temas
      $sqlMine = "
        SELECT 
          t.id   AS tema_id, t.titulo AS tema_titulo, t.descripcion AS tema_desc,
          c.id   AS contenido_id, c.titulo AS c_titulo, c.descripcion AS c_desc, c.visibilidad,
          (SELECT COUNT(*) FROM contenido_activos a WHERE a.contenido_id=c.id) AS n_activos
        FROM temas t
        JOIN contenidos c ON c.tema_id=t.id AND c.docente_id=:doc
        WHERE t.unidad_id=:u
        ORDER BY t.id DESC
      ";
      $st = $pdo->prepare($sqlMine);
      $st->execute([':doc'=>$docId, ':u'=>$unidad]);
      $mine = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

      // Públicos de otros
      $sqlOthers = "
        SELECT 
          t.id   AS tema_id, t.titulo AS tema_titulo, t.descripcion AS tema_desc,
          c.id   AS contenido_id, c.titulo AS c_titulo, c.descripcion AS c_desc, c.visibilidad,
          u.nombre, u.apellidos,
          (SELECT COUNT(*) FROM contenido_activos a WHERE a.contenido_id=c.id) AS n_activos
        FROM temas t
        JOIN contenidos c ON c.tema_id=t.id AND c.docente_id<>:doc AND c.visibilidad='publico'
        JOIN docentes d ON d.usuario_id = c.docente_id
        JOIN usuarios u ON u.id = d.usuario_id
        WHERE t.unidad_id=:u
        ORDER BY t.id DESC
      ";
      $st2 = $pdo->prepare($sqlOthers);
      $st2->execute([':doc'=>$docId, ':u'=>$unidad]);
      $others = $st2->fetchAll(PDO::FETCH_ASSOC) ?: [];

      json_out(['ok'=>true,'mine'=>$mine,'others_public'=>$others]);
    }

    /* -------- Actualizar meta/visibilidad del tema (solo dueño) -------- */
    if ($ajax === 'update_tema_meta') {
      $tema_id = (int)($in['tema_id'] ?? 0);
      $contenido_id = (int)($in['contenido_id'] ?? 0);
      $titulo = trim((string)($in['titulo'] ?? ''));
      $desc = trim((string)($in['descripcion'] ?? ''));
      $vis = (string)($in['visibilidad'] ?? 'privado');

      if ($tema_id<=0 || $contenido_id<=0 || $titulo==='') json_out(['ok'=>false,'err'=>'param'], 400);
      if (!tema_pertenece_docente($pdo, $tema_id, $docId) || !contenido_pertenece($pdo, $contenido_id, $docId)) {
        json_out(['ok'=>false,'err'=>'permiso'], 403);
      }
      if (!in_array($vis, ['privado','solo_estudiantes','publico'], true)) $vis='privado';

      // Obtener visibilidad anterior y unidad_id del tema (para decidir notificación)
      $stInfo = $pdo->prepare("
        SELECT c.visibilidad AS old_vis, t.unidad_id
        FROM contenidos c
        JOIN temas t ON t.id = c.tema_id
        WHERE c.id=:c AND c.docente_id=:d AND t.id=:t
        LIMIT 1
      ");
      $stInfo->execute([':c'=>$contenido_id, ':d'=>$docId, ':t'=>$tema_id]);
      $rowInfo = $stInfo->fetch(PDO::FETCH_ASSOC);
      if (!$rowInfo) json_out(['ok'=>false,'err'=>'noexists'], 404);
      $old_vis  = (string)($rowInfo['old_vis'] ?? 'privado');
      $unidadId = (int)($rowInfo['unidad_id'] ?? 0);

      // ¿Se debe notificar? (solo si pasa de privado -> {solo_estudiantes|publico})
      $shouldNotify = ($old_vis === 'privado' && in_array($vis, ['solo_estudiantes','publico'], true) && $unidadId>0);

      $pdo->beginTransaction();
      $pdo->prepare("UPDATE temas SET titulo=:t, descripcion=:d WHERE id=:id")->execute([
        ':t'=>$titulo, ':d'=>$desc ?: null, ':id'=>$tema_id
      ]);
      $pdo->prepare("UPDATE contenidos SET titulo=:t, descripcion=:d, visibilidad=:v WHERE id=:c")->execute([
        ':t'=>$titulo, ':d'=>$desc ?: null, ':v'=>$vis, ':c'=>$contenido_id
      ]);

      if ($shouldNotify) {
        // Notificar a estudiantes EN CURSO (misma materia y semestre)
        $insN = $pdo->prepare("
          INSERT INTO estudiante_notifs (estudiante_id, tipo, materia_clave, unidad_id, tema_id, contenido_id, titulo)
          SELECT e.usuario_id, 'tema_nuevo', :materia, :unidad, :tema, :contenido, :titulo
          FROM estudiantes e
          JOIN reticula_materias rm
            ON rm.reticula_id = e.reticula_id
           AND LOWER(rm.materia_clave) = LOWER(:materia)
          WHERE e.semestre_actual IS NOT NULL
            AND rm.semestre = e.semestre_actual
        ");
        $insN->execute([
          ':materia'   => $materia,
          ':unidad'    => $unidadId,
          ':tema'      => $tema_id,
          ':contenido' => $contenido_id,
          ':titulo'    => $titulo
        ]);
      }

      $pdo->commit();

      json_out(['ok'=>true, 'notificado'=> $shouldNotify ? 1 : 0]);
    }

    /* -------- Eliminar tema (solo dueño) -------- */
    if ($ajax === 'delete_tema') {
      $tema_id = (int)($in['tema_id'] ?? 0);
      if ($tema_id<=0) json_out(['ok'=>false,'err'=>'param'], 400);
      if (!tema_pertenece_docente($pdo, $tema_id, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);

      $st = $pdo->prepare("SELECT id FROM contenidos WHERE tema_id=:t AND docente_id=:d");
      $st->execute([':t'=>$tema_id, ':d'=>$docId]);
      $cid = (int)($st->fetchColumn() ?: 0);

      if ($cid>0) {
        $stf = $pdo->prepare("SELECT url FROM contenido_activos WHERE contenido_id=:c");
        $stf->execute([':c'=>$cid]);
        $files = $stf->fetchAll(PDO::FETCH_ASSOC) ?: [];
        foreach($files as $a){
          borrar_archivo_de_activo((string)($a['url'] ?? ''));
        }
        $pdo->prepare("DELETE FROM contenidos WHERE id=:c")->execute([':c'=>$cid]);
      }
      $pdo->prepare("DELETE FROM temas WHERE id=:t")->execute([':t'=>$tema_id]);

      json_out(['ok'=>true]);
    }

    /* -------- Agregar enlace (solo dueño) -------- */
    if ($ajax === 'add_link') {
      $cid = (int)($in['contenido_id'] ?? 0);
      $url = trim((string)($in['url'] ?? ''));
      $tit = trim((string)($in['titulo'] ?? 'Enlace'));
      if ($cid<=0 || $url==='') json_out(['ok'=>false,'err'=>'param'], 400);
      if (!contenido_pertenece($pdo, $cid, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);

      $ins = $pdo->prepare("INSERT INTO contenido_activos (contenido_id, tipo, titulo, url, orden) VALUES (:c,'enlace',:t,:u,1)");
      $ins->execute([':c'=>$cid, ':t'=>$tit, ':u'=>$url]);

      $activoId = (int)$pdo->lastInsertId();
      registrar_activo_para_ingesta($pdo, $activoId);

      json_out(['ok'=>true, 'id'=>$activoId]);
    }

    /* -------- Agregar texto (solo dueño) -------- */
    if ($ajax === 'add_text') {
      $cid = (int)($in['contenido_id'] ?? 0);
      $text = trim((string)($in['texto'] ?? ''));
      $tit = trim((string)($in['titulo'] ?? 'Texto'));
      if ($cid<=0 || $text==='') json_out(['ok'=>false,'err'=>'param'], 400);
      if (!contenido_pertenece($pdo, $cid, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);

      $ins = $pdo->prepare("INSERT INTO contenido_activos (contenido_id, tipo, titulo, texto_largo, orden) VALUES (:c,'texto',:t,:x,1)");
      $ins->execute([':c'=>$cid, ':t'=>$tit, ':x'=>$text]);

      $activoId = (int)$pdo->lastInsertId();
      registrar_activo_para_ingesta($pdo, $activoId);

      json_out(['ok'=>true, 'id'=>$activoId]);
    }

    /* -------- Subir archivo (solo dueño) -------- */
    if ($ajax === 'upload_file') {
      $csrf = $_POST['csrf'] ?? '';
      if (!hash_equals($CSRF, (string)$csrf)) json_out(['ok'=>false,'err'=>'csrf'], 400);

      $cid = (int)($_POST['contenido_id'] ?? 0);
      if ($cid<=0) json_out(['ok'=>false,'err'=>'param'], 400);
      if (!contenido_pertenece($pdo, $cid, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);
      if (empty($_FILES['file']) || ($_FILES['file']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        json_out(['ok'=>false,'err'=>'nofile'], 400);
      }

      $f = $_FILES['file'];
      $name = (string)$f['name'];
      $tmp  = (string)$f['tmp_name'];

      $extOrig  = (string)pathinfo($name, PATHINFO_EXTENSION);
      $extLower = strtolower($extOrig);
      $tipo     = file_tipo_from_ext($extLower);

      $uploadsRoot = uploads_public_root();
      $y = date('Y'); $m = date('m');
      $destDir = rtrim($uploadsRoot, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $y . DIRECTORY_SEPARATOR . $m . DIRECTORY_SEPARATOR;
      if (!ensure_dir($destDir)) json_out(['ok'=>false,'err'=>'mkdir'], 500);

      $origBase = (string)pathinfo($name, PATHINFO_FILENAME);
      $safeBase = preg_replace('/[^a-zA-Z0-9_\-\. ]+/', '_', $origBase);
      $safeBase = trim($safeBase);
      if ($safeBase === '' || $safeBase === '_' ) $safeBase = 'archivo';

      $destName = $safeBase . ($extOrig !== '' ? ('.' . $extOrig) : '');
      $dest     = $destDir . $destName;

      $i = 1;
      while (file_exists($dest)) {
        $destName = $safeBase . '-' . $i . ($extOrig !== '' ? ('.' . $extOrig) : '');
        $dest = $destDir . $destName;
        $i++;
      }

      if (!@move_uploaded_file($tmp, $dest)) json_out(['ok'=>false,'err'=>'move'], 500);

      // URL pública para abrir/descargar
      $publicUrl = 'uploads/recursos/' . $y . '/' . $m . '/' . rawurlencode($destName);

      $st = $pdo->prepare("INSERT INTO contenido_activos (contenido_id, tipo, titulo, url, orden) VALUES (:c,:t,:title,:url,1)");
      $st->execute([
        ':c'=>$cid, ':t'=>$tipo,
        ':title'=> $name,
        ':url'=>$publicUrl
      ]);

      $activoId = (int)$pdo->lastInsertId();
      registrar_activo_para_ingesta($pdo, $activoId);

      json_out([
        'ok'=>true,
        'id'=>$activoId,
        'url'=>$publicUrl,
        'tipo'=>$tipo,
        'titulo'=>$name
      ]);
    }

    /* -------- Listar activos (solo dueño) -------- */
    if ($ajax === 'list_activos') {
      $cid = (int)($in['contenido_id'] ?? $_GET['contenido_id'] ?? 0);
      if ($cid<=0) json_out(['ok'=>false,'err'=>'param'], 400);
      if (!contenido_pertenece($pdo, $cid, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);

      $st = $pdo->prepare("SELECT id, tipo, titulo, url, texto_largo, creado_en FROM contenido_activos WHERE contenido_id=:c ORDER BY id DESC");
      $st->execute([':c'=>$cid]);
      $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      json_out(['ok'=>true,'items'=>$rows]);
    }

    /* -------- Listar activos para VER (público o propio) -------- */
    if ($ajax === 'list_activos_view') {
      $cid = (int)($in['contenido_id'] ?? $_GET['contenido_id'] ?? 0);
      if ($cid<=0) json_out(['ok'=>false,'err'=>'param'], 400);
      if (!contenido_es_publico_o_propio($pdo, $cid, $docId)) json_out(['ok'=>false,'err'=>'permiso'], 403);

      $st = $pdo->prepare("SELECT id, tipo, titulo, url, texto_largo, creado_en FROM contenido_activos WHERE contenido_id=:c ORDER BY id DESC");
      $st->execute([':c'=>$cid]);
      $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      json_out(['ok'=>true,'items'=>$rows]);
    }

    /* -------- Actualizar texto/apunte (solo dueño) -------- */
    if ($ajax === 'update_text') {
      $aid = (int)($in['id'] ?? 0);
      $tit = trim((string)($in['titulo'] ?? 'Texto'));
      $txt = trim((string)($in['texto'] ?? ''));
      if ($aid <= 0 || $txt === '') json_out(['ok'=>false,'err'=>'param'], 400);
      if ($tit === '') $tit = 'Texto';

      $st = $pdo->prepare("
        SELECT a.id, a.tipo, c.docente_id
        FROM contenido_activos a
        JOIN contenidos c ON c.id = a.contenido_id
        WHERE a.id = :id
        LIMIT 1
      ");
      $st->execute([':id'=>$aid]);
      $row = $st->fetch(PDO::FETCH_ASSOC);
      if (!$row || (int)$row['docente_id'] !== $docId || (string)$row['tipo'] !== 'texto') {
        json_out(['ok'=>false,'err'=>'permiso'], 403);
      }

      $pdo->prepare("UPDATE contenido_activos SET titulo = :t, texto_largo = :x WHERE id = :id")
          ->execute([':t'=>$tit, ':x'=>$txt, ':id'=>$aid]);

      registrar_activo_para_ingesta($pdo, $aid);

      json_out(['ok'=>true]);
    }

    /* -------- Eliminar activo (solo dueño) -------- */
    if ($ajax === 'delete_activo') {
      $aid = (int)($in['id'] ?? 0);
      if ($aid<=0) json_out(['ok'=>false,'err'=>'param'], 400);

      $st = $pdo->prepare("SELECT a.id, a.url, c.docente_id
                           FROM contenido_activos a
                           JOIN contenidos c ON c.id=a.contenido_id
                           WHERE a.id=:id LIMIT 1");
      $st->execute([':id'=>$aid]);
      $row = $st->fetch(PDO::FETCH_ASSOC);
      if (!$row || (int)$row['docente_id'] !== $docId) json_out(['ok'=>false,'err'=>'permiso'], 403);

      limpiar_ingesta_de_activo($pdo, $aid);

      borrar_archivo_de_activo((string)($row['url'] ?? ''));

      $pdo->prepare("DELETE FROM contenido_activos WHERE id=:id")->execute([':id'=>$aid]);
      json_out(['ok'=>true]);
    }

    json_out(['ok'=>false,'err'=>'accion'], 400);
  } catch(Throwable $e){
    // error_log($e->getMessage());
    json_out(['ok'=>false,'err'=>'server'], 500);
  }
}

/* ============= VISTA ============= */
$stN = $pdo->prepare("SELECT nombre FROM materias WHERE LOWER(clave)=LOWER(:m) LIMIT 1");
$stN->execute([':m'=>$materia]);
$materiaNombre = (string)($stN->fetchColumn() ?: $materia);

$active   = 'recursos';
$title    = 'KnowLink · Docentes · Temas';
$h1       = 'Temas y recursos';
$subtitle = 'Materia: ' . $materia . ' · ' . $materiaNombre;

require __DIR__ . '/partials/header.php';
?>
<meta name="csrf" content="<?= esc($CSRF) ?>">

<style>
.page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
.page-title{font-size:20px;font-weight:800;color:#0b2545}
.page-sub{color:#6b7280;font-size:14px}
.card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:14px}
.btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
.btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
.btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
.btn.small{padding:6px 10px;border-radius:8px;font-weight:700}

.unis-wrap{display:flex;gap:8px;overflow:auto;padding-bottom:6px}
.chip{
  display:inline-flex; align-items:center; gap:8px;
  padding:8px 12px; border-radius:999px; border:1px solid #e6eef2; background:#f3f6f9; color:#0b2545;
  white-space:nowrap; cursor:pointer; font-weight:700; transition: transform .06s ease, background .12s ease;
}
.chip:hover{ transform: translateY(-1px); background:#eef5ff; border-color:#cfe1ff; }
.chip.active{ background:#0b2545; color:#fff; border-color:#0b2545; }

.form-grid{display:grid;grid-template-columns:1fr;gap:10px}
.input, textarea{
  padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;outline:none;font-size:14px;width:100%;
}
textarea{min-height:96px}
.hint{color:#64748b;font-size:13px}

.section-title{font-size:16px;color:#0b2545;margin-bottom:6px;font-weight:800}
.tlist{display:flex;flex-direction:column;gap:10px}
.tcard{border:1px solid #e6eef2;border-radius:12px;padding:12px;background:#fff}
.thead{display:flex;align-items:center;gap:10px}
.thead h4{margin:0;font-size:16px;color:#0b2545}
.tmeta{margin-left:auto;color:#64748b;font-size:13px}
.tbody{margin-top:8px;color:#334155;font-size:14px}
.res-wrap{margin-top:10px;border-top:1px dashed #e6eef2;padding-top:10px}
.res-tools{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px}
.tab{border:1px solid #e6eef2;background:#f8fbfe;border-radius:8px;padding:6px 10px;cursor:pointer}
.tab.active{background:#0b2545;color:#fff;border-color:#0b2545}
.res-panels > div{display:none}
.res-panels > div.active{display:block}

.drop{border:2px dashed #cfe1ff;border-radius:12px;padding:16px;text-align:center;background:#f5f9ff}
.drop.drag{background:#eef5ff}
.res-list{display:flex;flex-direction:column;gap:8px;margin-top:8px}
.rrow{display:flex;align-items:center;gap:8px;border:1px solid #eef2f6;border-radius:10px;padding:8px}
.rrow .type{font-size:12px;background:#eef5ff;border:1px solid #dbeafe;border-radius:999px;padding:2px 8px;color:#0b2545;font-weight:800}
.rrow .title{flex:1}
.badge{background:#eef5ff;border:1px solid #dbeafe;color:#0b2545;font-size:12px;padding:2px 8px;border-radius:999px;font-weight:800}

.text-snippet{white-space:pre-wrap;border:1px dashed #e6eef2;background:#fbfdff;border-radius:8px;padding:8px;color:#0f172a;max-height:160px;overflow:auto}
.text-editor{display:none;margin-top:8px;border:1px solid #e6eef2;border-radius:12px;background:#fbfdff;padding:10px}
.text-editor.show{display:block}
.text-editor textarea{min-height:140px;resize:vertical}
html[data-theme="dark"] .rrow{background:rgba(15,31,54,.72)!important;border-color:rgba(148,163,184,.18)!important;color:#e8f1ff!important}
html[data-theme="dark"] .rrow .title{color:#f8fafc!important}
html[data-theme="dark"] .text-snippet, html[data-theme="dark"] .text-editor{background:rgba(8,18,34,.72)!important;border-color:rgba(148,163,184,.18)!important;color:#dbeafe!important}
html[data-theme="dark"] .tab{background:rgba(255,255,255,.06)!important;border-color:rgba(148,163,184,.18)!important;color:#e8f1ff!important}
html[data-theme="dark"] .tab.active{background:linear-gradient(135deg,#0ea5e9,#0f766e)!important;color:#fff!important;border-color:transparent!important}
html[data-theme="dark"] .drop{background:rgba(8,18,34,.7)!important;border-color:rgba(125,211,252,.24)!important;color:#cbd5e1!important}

.state{display:none}
.state.show{display:block}
.muted{color:#64748b;font-size:13px}
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost" href="<?= esc(base_url('docentes/seleccionar_materia.php')) ?>">&larr; Cambiar materia</a>
  </div>
</div>

<section class="card">
  <h3 class="section-title"><i class="fas fa-layer-group"></i> Unidades</h3>
  <div id="uList" class="unis-wrap">
    <div class="hint">Cargando unidades…</div>
  </div>
</section>

<!-- Crear tema -->
<section class="card">
  <div id="step-crear" class="state">
    <h3 class="section-title"><i class="fas fa-plus-circle"></i> Crear nuevo tema en <span id="selUnidadName" class="badge">Unidad</span></h3>
    <div class="form-grid">
      <input id="temaTitulo" class="input" type="text" placeholder="Título del tema">
      <textarea id="temaDesc" class="input" placeholder="Descripción (opcional)"></textarea>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <select id="temaVis" class="input" style="max-width:240px;">
          <option value="privado">Privado</option>
          <option value="solo_estudiantes">Solo estudiantes</option>
          <option value="publico">Público</option>
        </select>
        <button id="btnCrearTema" class="btn primary"><i class="fas fa-save"></i> Crear tema</button>
        <div id="crearHint" class="hint"></div>
      </div>
    </div>
  </div>
</section>

<!-- Mis temas / Temas públicos de otros -->
<section class="card">
  <div id="step-temas" class="state">
    <h3 class="section-title"><i class="fas fa-list"></i> Temas de la unidad</h3>
    <div id="mineWrap" style="margin-bottom:12px;">
      <div class="muted" style="margin-bottom:6px;"><i class="fas fa-user"></i> Mis temas</div>
      <div id="mineList" class="tlist"><div class="hint">Selecciona una unidad.</div></div>
    </div>
    <div id="othersWrap">
      <div class="muted" style="margin:10px 0 6px;"><i class="fas fa-users"></i> Temas públicos de otros docentes</div>
      <div id="othersList" class="tlist"><div class="hint">Selecciona una unidad.</div></div>
    </div>
  </div>
</section>

<script>
// ===== Utils =====
const CSRF = document.querySelector('meta[name="csrf"]')?.getAttribute('content') || '';
const FILE_URL_BASE = '<?= esc(base_url('recurso_archivo.php')) ?>';
const TEXT_URL_BASE = '<?= esc(base_url('docentes/texto.php')) ?>';
function fileUrl(id, mode='open'){ return `${FILE_URL_BASE}?id=${encodeURIComponent(id)}&mode=${encodeURIComponent(mode)}`; }
function textUrl(id){ return `${TEXT_URL_BASE}?id=${encodeURIComponent(id)}`; }
function escapeH(s){
  return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
}
async function postJSON(payload){
  const res = await fetch('?ajax='+encodeURIComponent(payload.ajax), {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(Object.assign({csrf:CSRF}, payload))
  });
  return res.json();
}
function el(tag, attrs={}, html=''){
  const e=document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=> e.setAttribute(k,String(v)));
  if (html!=='' && html!=null) e.innerHTML=html;
  return e;
}
function prettyTipo(t){
  const map={pdf:'PDF',word:'Word',imagen:'Imagen',texto:'Texto',enlace:'Enlace',video:'Video',powerpoint:'PowerPoint',excel:'Excel',otro:'Archivo'};
  return map[t]||t;
}

// ===== Estado =====
let unidades = [];
let selUnidad = null;

const uList = document.getElementById('uList');
const stepCrear = document.getElementById('step-crear');
const stepTemas = document.getElementById('step-temas');
const selUnidadName = document.getElementById('selUnidadName');

const temaTitulo = document.getElementById('temaTitulo');
const temaDesc   = document.getElementById('temaDesc');
const temaVis    = document.getElementById('temaVis');
const btnCrear   = document.getElementById('btnCrearTema');
const crearHint  = document.getElementById('crearHint');

const mineList   = document.getElementById('mineList');
const othersList = document.getElementById('othersList');

// Cargar unidades
async function loadUnidades(){
  uList.innerHTML = '<div class="hint">Cargando unidades…</div>';
  try{
    const j = await postJSON({ajax:'list_unidades'});
    if (!j.ok){ uList.innerHTML='<div class="hint" style="color:#b91c1c;">No se pudieron cargar.</div>'; return; }
    unidades = j.items || [];
    if (!unidades.length){ uList.innerHTML='<div class="hint">Esta materia aún no tiene unidades.</div>'; return; }
    renderUnidades();
  }catch(e){
    uList.innerHTML='<div class="hint" style="color:#b91c1c;">Error de red.</div>';
  }
}

function renderUnidades(){
  uList.innerHTML = '';
  unidades.forEach(u=>{
    const chip = el('div', {class:'chip', 'data-id': u.id}, `<i class="fas fa-circle"></i> Unidad ${escapeH(u.numero)} — ${escapeH(u.titulo||'Sin título')}`);
    chip.addEventListener('click', ()=> selectUnidad(u, chip));
    uList.appendChild(chip);
  });
}

async function selectUnidad(u, chipEl){
  selUnidad = { id: u.id, numero: u.numero, titulo: u.titulo||('Unidad '+u.numero) };
  document.querySelectorAll('.chip.active').forEach(c=> c.classList.remove('active'));
  chipEl?.classList.add('active');

  selUnidadName.textContent = `Unidad ${u.numero}`;
  stepCrear.classList.add('show');
  stepTemas.classList.add('show');

  await loadTemas();
}

async function loadTemas(){
  mineList.innerHTML  = '<div class="hint">Cargando mis temas…</div>';
  othersList.innerHTML= '<div class="hint">Cargando temas públicos…</div>';
  try{
    const j = await postJSON({ajax:'list_temas', unidad_id: selUnidad.id});
    if (!j.ok){
      mineList.innerHTML  = '<div class="hint" style="color:#b91c1c;">Error.</div>';
      othersList.innerHTML= '<div class="hint" style="color:#b91c1c;">Error.</div>';
      return;
    }
    renderMine(j.mine || []);
    renderOthers(j.others_public || []);
  }catch(e){
    mineList.innerHTML  = '<div class="hint" style="color:#b91c1c;">Error de red.</div>';
    othersList.innerHTML= '<div class="hint" style="color:#b91c1c;">Error de red.</div>';
  }
}

function renderMine(items){
  if (!items.length){ mineList.innerHTML='<div class="hint">Aún no tienes temas en esta unidad.</div>'; return; }
  mineList.innerHTML='';
  items.forEach(t => { mineList.appendChild(makeMyTemaCard(t)); });
}

function renderOthers(items){
  if (!items.length){ othersList.innerHTML='<div class="hint">No hay temas públicos de otros docentes.</div>'; return; }
  othersList.innerHTML='';
  items.forEach(t => { othersList.appendChild(makeOtherTemaCard(t)); });
}

/* -------- Mis temas (editable) -------- */
function makeMyTemaCard(t){
  const card = el('div', {class:'tcard'});

  const thead = el('div', {class:'thead'});
  const title = el('h4', {}, escapeH(t.c_titulo || t.tema_titulo || 'Tema'));
  const meta  = el('div', {class:'tmeta'}, `<span class="badge">${t.n_activos||0} recurso(s)</span>`);
  thead.append(title, meta);

  const body = el('div', {class:'tbody'}, escapeH(t.c_desc || t.tema_desc || ''));
  const info = el('div', {class:'muted', style:'margin-top:6px;'},
    `Visibilidad del tema: ${escapeH(t.visibilidad || 'privado')}`);

  const tools = el('div', {style:'margin-top:8px;display:flex;gap:6px;flex-wrap:wrap;align-items:center;'});
  const btnEdit = el('button', {class:'btn small ghost'}, '<i class="fas fa-pen"></i> Editar tema');
  const btnDel  = el('button', {class:'btn small ghost'}, '<i class="fas fa-trash"></i> Eliminar tema');
  tools.append(btnEdit, btnDel);

  const cid = t.contenido_id || 0;
  const metaPanel = el('div', {style:'display:none;margin-top:8px;'});
  metaPanel.innerHTML = `
    <div class="form-grid">
      <input class="input" type="text" id="tit-${t.tema_id}" value="${escapeH(t.c_titulo || t.tema_titulo || '')}" placeholder="Título del tema">
      <textarea class="input" id="des-${t.tema_id}" placeholder="Descripción (opcional)">${escapeH(t.c_desc || t.tema_desc || '')}</textarea>
      <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
        <select id="vis-${t.tema_id}" class="input" style="max-width:220px;">
          <option value="privado" ${t.visibilidad==='privado'?'selected':''}>Privado</option>
          <option value="solo_estudiantes" ${t.visibilidad==='solo_estudiantes'?'selected':''}>Solo estudiantes</option>
          <option value="publico" ${t.visibilidad==='publico'?'selected':''}>Público</option>
        </select>
        <button class="btn small primary" id="sv-${t.tema_id}"><i class="fas fa-save"></i> Guardar</button>
      </div>
      <div class="hint" id="h-${t.tema_id}"></div>
    </div>
  `;
  btnEdit.addEventListener('click', ()=>{
    metaPanel.style.display = (metaPanel.style.display==='none' || metaPanel.style.display==='') ? 'block' : 'none';
  });
  metaPanel.querySelector('#sv-'+t.tema_id)?.addEventListener('click', async ()=>{
    const ti  = metaPanel.querySelector('#tit-'+t.tema_id)?.value.trim() || '';
    const de  = metaPanel.querySelector('#des-'+t.tema_id)?.value.trim() || '';
    const vi  = metaPanel.querySelector('#vis-'+t.tema_id)?.value || 'privado';
    const hint = metaPanel.querySelector('#h-'+t.tema_id);
    if (!ti){ hint.textContent='El título es obligatorio.'; return; }
    hint.textContent='Guardando…';
    const j = await postJSON({ajax:'update_tema_meta', tema_id: t.tema_id, contenido_id: cid, titulo: ti, descripcion: de, visibilidad: vi});
    hint.textContent = j.ok ? (j.notificado? 'Guardado y notificado.' : 'Guardado.') : 'Error al guardar.';
    if (j.ok){ title.textContent = ti; body.textContent = de; info.textContent = `Visibilidad del tema: ${vi}`; }
  });

  btnDel.addEventListener('click', async ()=>{
    if(!confirm('Esto eliminará el tema y todos sus recursos. ¿Continuar?')) return;
    const j = await postJSON({ajax:'delete_tema', tema_id: t.tema_id});
    if (j.ok){ card.remove(); if (!mineList.children.length) mineList.innerHTML='<div class="hint">Aún no tienes temas en esta unidad.</div>'; }
  });

  // Recursos (subir/gestionar)
  const resWrap = el('div', {class:'res-wrap'});
  const resTools = el('div', {class:'res-tools'});
  const tabA = el('button', {class:'tab active', 'data-target':'file-'+cid}, '<i class="fas fa-file-arrow-up"></i> Archivo');
  const tabB = el('button', {class:'tab', 'data-target':'url-'+cid}, '<i class="fas fa-link"></i> URL');
  const tabC = el('button', {class:'tab', 'data-target':'txt-'+cid}, '<i class="fas fa-align-left"></i> Texto');
  resTools.append(tabA, tabB, tabC);

  const panels = el('div', {class:'res-panels'});
  const pnA = el('div', {id:'file-'+cid, class:'active'});
  pnA.innerHTML = `
    <div class="drop" id="drop-${cid}">
      Arrastra y suelta archivos aquí, o
      <label class="btn small ghost" style="margin-left:6px;cursor:pointer;">
        seleccionar
        <input type="file" id="file-${cid}" style="display:none;">
      </label>
      <div class="hint">PDF, imágenes, Word, PowerPoint, Excel, videos...</div>
      <div class="hint" id="uphint-${cid}" style="margin-top:6px;"></div>
    </div>
  `;
  const pnB = el('div', {id:'url-'+cid});
  pnB.innerHTML = `
    <div class="form-grid">
      <input type="text" class="input" id="uurl-${cid}" placeholder="https://...">
      <input type="text" class="input" id="utitle-${cid}" placeholder="Título (opcional)">
      <div><button class="btn small primary" id="uadd-${cid}"><i class="fas fa-plus"></i> Agregar enlace</button>
      <span id="uhint-${cid}" class="hint"></span></div>
    </div>
  `;
  const pnC = el('div', {id:'txt-'+cid});
  pnC.innerHTML = `
    <div class="form-grid">
      <input type="text" class="input" id="ttitle-${cid}" placeholder="Título (opcional)">
      <textarea class="input" id="ttext-${cid}" placeholder="Tu apunte…"></textarea>
      <div><button class="btn small primary" id="tadd-${cid}"><i class="fas fa-plus"></i> Agregar texto</button>
      <span id="thint-${cid}" class="hint"></span></div>
    </div>
  `;
  panels.append(pnA, pnB, pnC);

  const resList = el('div', {class:'res-list', id:'rlist-'+cid});
  resWrap.append(resTools, panels, resList);

  [tabA, tabB, tabC].forEach(tab=>{
    tab.addEventListener('click', ()=>{
      tabA.classList.remove('active'); tabB.classList.remove('active'); tabC.classList.remove('active');
      tab.classList.add('active');
      [pnA, pnB, pnC].forEach(p => p.classList.remove('active'));
      const target = tab.getAttribute('data-target');
      document.getElementById(target)?.classList.add('active');
    });
  });

  const drop = pnA.querySelector('#drop-'+cid);
  const fin  = pnA.querySelector('#file-'+cid);
  const uphint = pnA.querySelector('#uphint-'+cid);

  ;['dragenter','dragover'].forEach(ev=>{
    drop.addEventListener(ev, e=>{ e.preventDefault(); e.stopPropagation(); drop.classList.add('drag'); });
  });
  ;['dragleave','dragend','drop'].forEach(ev=>{
    drop.addEventListener(ev, e=>{ e.preventDefault(); e.stopPropagation(); drop.classList.remove('drag'); });
  });
  drop.addEventListener('drop', e=>{
    const files = e.dataTransfer.files;
    if (files && files.length){ uploadFiles(cid, files, uphint); }
  });
  fin.addEventListener('change', e=>{
    const files = fin.files;
    if (files && files.length){ uploadFiles(cid, files, uphint); fin.value=''; }
  });

  pnB.querySelector('#uadd-'+cid)?.addEventListener('click', async ()=>{
    const u = pnB.querySelector('#uurl-'+cid)?.value.trim() || '';
    const ti= pnB.querySelector('#utitle-'+cid)?.value.trim() || 'Enlace';
    const hint = pnB.querySelector('#uhint-'+cid);
    if (!u){ hint.textContent='Escribe una URL válida.'; return; }
    hint.textContent='Agregando…';
    const j = await postJSON({ajax:'add_link', contenido_id: cid, url: u, titulo: ti});
    hint.textContent = j.ok ? 'Agregado.' : 'Error al agregar.';
    if (j.ok){ loadActivos(cid, resList, false); pnB.querySelector('#uurl-'+cid).value=''; pnB.querySelector('#utitle-'+cid).value=''; }
  });

  pnC.querySelector('#tadd-'+cid)?.addEventListener('click', async ()=>{
    const te= pnC.querySelector('#ttext-'+cid)?.value.trim() || '';
    const ti= pnC.querySelector('#ttitle-'+cid)?.value.trim() || 'Texto';
    const hint = pnC.querySelector('#thint-'+cid);
    if (!te){ hint.textContent='Escribe algo.'; return; }
    hint.textContent='Agregando…';
    const j = await postJSON({ajax:'add_text', contenido_id: cid, texto: te, titulo: ti});
    hint.textContent = j.ok ? 'Agregado.' : 'Error al agregar.';
    if (j.ok){ loadActivos(cid, resList, false); pnC.querySelector('#ttext-'+cid).value=''; pnC.querySelector('#ttitle-'+cid).value=''; }
  });

  loadActivos(cid, resList, false);

  card.append(thead, body, info, tools, metaPanel, resWrap);
  return card;
}

/* -------- Temas públicos de otros (solo lectura con Abrir/Descargar) -------- */
function makeOtherTemaCard(t){
  const card = el('div', {class:'tcard', style:'background:#fafcff'});
  const thead = el('div', {class:'thead'});
  const title = el('h4', {}, escapeH(t.c_titulo || t.tema_titulo || 'Tema'));
  const meta  = el('div', {class:'tmeta'}, `<span class="badge">${t.n_activos||0} recurso(s)</span>`);
  thead.append(title, meta);

  const by   = el('div', {class:'muted', style:'margin-top:2px;'}, `Docente: ${escapeH(((t.nombre||'')+' '+(t.apellidos||'')).trim())}`);
  const body = el('div', {class:'tbody'}, escapeH(t.c_desc || t.tema_desc || ''));

  const btn  = el('button', {class:'btn small ghost', style:'margin-top:8px;'}, '<i class="fas fa-folder-open"></i> Ver recursos');
  const rl   = el('div', {class:'res-list', style:'display:none;margin-top:8px;', id:'rlist-p-'+t.contenido_id});

  btn.addEventListener('click', async ()=>{
    rl.style.display = (rl.style.display==='none' || rl.style.display==='') ? 'block' : 'none';
    if (rl.dataset.loaded) return;
    rl.innerHTML = '<div class="hint">Cargando…</div>';
    const j = await postJSON({ajax:'list_activos_view', contenido_id: t.contenido_id});
    if (!j.ok){ rl.innerHTML = '<div class="hint" style="color:#b91c1c;">Error.</div>'; return; }
    renderActivos(rl, j.items || [], true);
    rl.dataset.loaded = '1';
  });

  card.append(thead, by, body, btn, rl);
  return card;
}

/* -------- Render de recursos -------- */
function renderActivos(box, items, readonly){
  if (!items.length){ box.innerHTML='<div class="hint">Sin recursos todavía.</div>'; return; }
  box.innerHTML='';
  items.forEach(a=>{
    const tipo = (a.tipo||'').toLowerCase();
    const url  = (a.url||'').trim();
    const texto = (a.texto_largo||'').trim();
    const titleText = a.titulo || (tipo === 'texto' ? 'Texto' : (url || '(sin título)'));

    const item = el('div', {class:'resource-item'});
    const row = el('div', {class:'rrow'});
    const type = el('span', {class:'type'}, escapeH(prettyTipo(tipo)));
    const title = el('div', {class:'title'}, escapeH(titleText));
    const ops = el('div', {class:'ops', style:'display:flex;gap:6px;flex-wrap:wrap;align-items:center;'});

    if (tipo === 'texto') {
      if (texto) {
        const openBtn = el('a', {class:'btn small', href:textUrl(a.id), target:'_blank', rel:'noopener'}, '<i class="fas fa-up-right-from-square"></i> Abrir');
        ops.appendChild(openBtn);
      }

      if (!readonly) {
        const editBtn = el('button', {class:'btn small ghost', type:'button'}, '<i class="fas fa-pen"></i> Editar');
        ops.appendChild(editBtn);
      }
    } else if (url) {
      if (tipo === 'enlace') {
        const openBtn = el('a', {class:'btn small', href:url, target:'_blank', rel:'noopener'}, '<i class="fas fa-up-right-from-square"></i> Abrir');
        ops.appendChild(openBtn);
      } else {
        const openBtn = el('a', {class:'btn small', href:fileUrl(a.id,'open'), target:'_blank', rel:'noopener'}, '<i class="fas fa-up-right-from-square"></i> Abrir');
        ops.appendChild(openBtn);
        const fileTypes = new Set(['pdf','word','excel','powerpoint','imagen','video','otro']);
        if (fileTypes.has(tipo)){
          const downBtn = el('a', {class:'btn small ghost', href:fileUrl(a.id,'download')}, '<i class="fas fa-download"></i> Descargar');
          ops.appendChild(downBtn);
        }
      }
    }

    if (!readonly){
      const del = el('button', {class:'btn small ghost', type:'button'}, '<i class="fas fa-trash"></i> Quitar');
      del.addEventListener('click', async ()=>{
        if (!confirm('¿Eliminar este recurso?')) return;
        const jr = await postJSON({ajax:'delete_activo', id: a.id});
        if (jr.ok) {
          item.remove();
          if (!box.children.length) box.innerHTML='<div class="hint">Sin recursos todavía.</div>';
        }
      });
      ops.appendChild(del);
    }

    row.append(type, title, ops);
    item.appendChild(row);

    if (tipo === 'texto') {
      const preview = texto.length > 260 ? texto.slice(0,260).trim() + '…' : texto;
      const txt = el('div', {class:'text-snippet'}, escapeH(preview || 'Texto sin contenido.'));
      item.appendChild(txt);

      if (!readonly) {
        const editor = el('div', {class:'text-editor'});
        editor.innerHTML = `
          <div class="form-grid">
            <input type="text" class="input edit-title" value="${escapeH(titleText)}" placeholder="Título del apunte">
            <textarea class="input edit-text" placeholder="Contenido del apunte">${escapeH(texto)}</textarea>
            <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
              <button class="btn small primary save-text" type="button"><i class="fas fa-save"></i> Guardar cambios</button>
              <button class="btn small ghost cancel-text" type="button">Cancelar</button>
              <span class="hint edit-hint"></span>
            </div>
          </div>
        `;
        item.appendChild(editor);

        const editBtn = ops.querySelector('button');
        const cancelBtn = editor.querySelector('.cancel-text');
        const saveBtn = editor.querySelector('.save-text');
        const hint = editor.querySelector('.edit-hint');

        editBtn?.addEventListener('click', ()=> editor.classList.add('show'));
        cancelBtn?.addEventListener('click', ()=> editor.classList.remove('show'));
        saveBtn?.addEventListener('click', async ()=>{
          const newTitle = editor.querySelector('.edit-title')?.value.trim() || 'Texto';
          const newText = editor.querySelector('.edit-text')?.value.trim() || '';
          if (!newText){ hint.textContent = 'Escribe el contenido del apunte.'; return; }
          hint.textContent = 'Guardando…';
          const jr = await postJSON({ajax:'update_text', id:a.id, titulo:newTitle, texto:newText});
          if (jr.ok) {
            hint.textContent = 'Guardado.';
            title.textContent = newTitle;
            const newPreview = newText.length > 260 ? newText.slice(0,260).trim() + '…' : newText;
            txt.textContent = newPreview;
            a.titulo = newTitle;
            a.texto_largo = newText;
            setTimeout(()=>editor.classList.remove('show'), 500);
          } else {
            hint.textContent = 'No se pudo guardar.';
          }
        });
      }
    }

    box.appendChild(item);
  });
}

async function uploadFiles(contenidoId, fileList, hintEl){
  for (let i=0;i<fileList.length;i++){
    const f = fileList[i];
    const fd = new FormData();
    fd.append('ajax','upload_file');
    fd.append('csrf', CSRF);
    fd.append('contenido_id', String(contenidoId));
    fd.append('file', f);
    hintEl.textContent = `Subiendo ${f.name}…`;
    try{
      const res = await fetch('?ajax=upload_file', {method:'POST', body: fd});
      const j = await res.json();
      if (!j.ok){ hintEl.textContent = `Error con ${f.name}`; }
      else { hintEl.textContent = `Subido: ${f.name}`; const box = document.getElementById('rlist-'+contenidoId); loadActivos(contenidoId, box, false); }
    }catch(e){
      hintEl.textContent = `Error de red con ${f.name}`;
    }
  }
  setTimeout(()=>{ hintEl.textContent=''; }, 1500);
}

async function loadActivos(contenidoId, box, readonly){
  if (!box) return;
  box.innerHTML='<div class="hint">Cargando recursos…</div>';
  try{
    const j = await postJSON({ajax: readonly ? 'list_activos_view' : 'list_activos', contenido_id: contenidoId});
    if (!j.ok){ box.innerHTML='<div class="hint" style="color:#b91c1c;">Error.</div>'; return; }
    renderActivos(box, j.items||[], !!readonly);
  }catch(e){ box.innerHTML='<div class="hint" style="color:#b91c1c;">Error.</div>'; }
}

// Crear tema
btnCrear.addEventListener('click', async ()=>{
  if (!selUnidad){ crearHint.textContent='Selecciona una unidad.'; return; }
  const t = (temaTitulo.value||'').trim();
  const d = (temaDesc.value||'').trim();
  const v = (temaVis.value||'privado');
  if (!t){ crearHint.textContent='Escribe un título.'; return; }
  crearHint.textContent='Creando…';
  const j = await postJSON({ajax:'crear_tema', unidad_id: selUnidad.id, titulo: t, descripcion: d, visibilidad: v});
  crearHint.textContent = j.ok ? 'Listo.' : 'Error al crear.';
  if (j.ok){ temaTitulo.value=''; temaDesc.value=''; temaVis.value='privado'; await loadTemas(); }
});

// Init
loadUnidades();
</script>

<?php require __DIR__ . '/partials/footer.php';
