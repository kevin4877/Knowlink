<?php
// public/docente/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'docente') { http_response_code(403); echo "Acceso denegado"; exit; }

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$pdo = db();
$docente_id = (int)($yo['id'] ?? 0);

// ===== Stats seguros con fallback =====
function count_query(PDO $pdo, string $sql, array $params=[]): int {
  try {
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return (int)$st->fetchColumn();
  } catch (Throwable $e) { return 0; }
}

$cntRecursos = count_query($pdo, "SELECT COUNT(*) FROM contenidos WHERE docente_id=:d", [':d'=>$docente_id]);
$cntPerms    = count_query($pdo, "SELECT COUNT(*) FROM docente_permisos_materia WHERE docente_id=:d", [':d'=>$docente_id]);

// grupos: intenta distintas posibles tablas/campos
$cntGrupos = 0;
foreach ([
  ["SELECT COUNT(*) FROM grupos WHERE docente_id=:d", [':d'=>$docente_id]],
  ["SELECT COUNT(*) FROM grupos_docentes WHERE docente_id=:d", [':d'=>$docente_id]],
] as [$q,$p]) {
  $cntGrupos = count_query($pdo, $q, $p);
  if ($cntGrupos>0) break;
}

// cursos: intenta distintas posibles tablas/campos
$cntCursos = 0;
foreach ([
  ["SELECT COUNT(*) FROM cursos WHERE docente_id=:d", [':d'=>$docente_id]],
  ["SELECT COUNT(*) FROM cursos_docentes WHERE docente_id=:d", [':d'=>$docente_id]],
] as [$q,$p]) {
  $cntCursos = count_query($pdo, $q, $p);
  if ($cntCursos>0) break;
}

// Materias asignadas (lista corta)
$materias = [];
try {
  $st = $pdo->prepare("SELECT d.materia_clave AS clave, COALESCE(m.nombre,'') AS nombre
                       FROM docente_permisos_materia d
                       LEFT JOIN materias m ON LOWER(m.clave) = LOWER(d.materia_clave)
                       WHERE d.docente_id = :d
                       ORDER BY d.materia_clave ASC
                       LIMIT 12");
  $st->execute([':d'=>$docente_id]);
  $materias = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) { $materias = []; }

// Recursos recientes (si existe columna titulo/tipo/creado_en)
$recientes = [];
try {
  $st = $pdo->prepare("SELECT id, titulo, tipo, creado_en
                       FROM contenidos
                       WHERE docente_id = :d
                       ORDER BY creado_en DESC
                       LIMIT 8");
  $st->execute([':d'=>$docente_id]);
  $recientes = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch (Throwable $e) { $recientes = []; }

// ===== Vista =====
$active   = 'index';
$title    = 'KnowLink · Docente · Panel';
$h1       = 'Panel del docente';
$subtitle = 'Resumen y accesos rápidos';

require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  /* KPIs */
  .kpi-grid{display:grid;grid-template-columns:repeat(4,minmax(160px,1fr));gap:12px}
  .kpi{background:#fff;border:1px solid #e6eef2;border-radius:14px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,.06)}
  .kpi .label{font-size:12px;color:#64748b}
  .kpi .value{font-size:26px;font-weight:900;color:#0b2545;margin-top:4px}
  .kpi .meta{font-size:12px;color:#94a3b8;margin-top:6px}
  .kpi .icon{margin-left:auto;font-size:22px;opacity:.55}
  .kpi-row{display:flex;align-items:center;gap:12px}
  .kpi.is-primary{background:linear-gradient(180deg,#f8fbff,#ffffff)}
  .kpi.is-green{background:linear-gradient(180deg,#f6fff9,#ffffff)}
  .kpi.is-amber{background:linear-gradient(180deg,#fffaf2,#ffffff)}
  .kpi.is-violet{background:linear-gradient(180deg,#faf7ff,#ffffff)}

  /* Quick actions */
  .qa{display:flex;flex-wrap:wrap;gap:8px}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn.small{padding:8px 12px;border-radius:9px}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  a.btn{text-decoration:none}

  /* Tarjetas listas */
  .grid-2{display:grid;grid-template-columns:2fr 3fr;gap:12px}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);border:1px solid #e6eef2}
  .card h3{font-size:16px;margin-bottom:8px;color:#0b2545}
  .list{display:flex;flex-direction:column;border-top:1px dashed #eef2f6;margin-top:6px}
  .row{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 6px;border-bottom:1px dashed #eef2f6}
  .row:last-child{border-bottom:0}
  .muted{color:#94a3b8}
  .pill{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;border:1px solid #e2ebff;background:#f1f5ff;color:#0055d4;font-size:12px}
  .empty{color:#64748b;padding:8px 4px}

  /* Notificaciones en Home (reusa estilos del header) */
  .notif-mini .item{display:flex;gap:10px;padding:10px 6px;border-bottom:1px dashed #eef2f6}
  .notif-mini .item:last-child{border-bottom:0}
  .notif-mini .ico{width:28px;height:28px;border-radius:8px;display:flex;align-items:center;justify-content:center;background:#f1f5ff;color:#0055d4}
  .notif-mini .title{font-size:14px;color:#0f172a}
  .notif-mini .meta{font-size:12px;color:#94a3b8;margin-top:2px}

  @media (max-width:1100px){ .kpi-grid{grid-template-columns:repeat(2,minmax(160px,1fr));} .grid-2{grid-template-columns:1fr;} }
  @media (max-width:680px){ .kpi-grid{grid-template-columns:1fr;} }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div class="qa">
    <a class="btn ghost btn-icon" href="<?= esc(base_url('docentes/seleccionar_materia.php')) ?>"><i class="fas fa-cloud-arrow-up"></i> <span class="label">Subir recursos</span></a>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('docentes/grupos.php')) ?>"><i class="fas fa-users"></i> <span class="label">Mis grupos</span></a>
    <a class="btn primary btn-icon" href="<?= esc(base_url('docentes/cursos.php')) ?>"><i class="fas fa-chalkboard-teacher"></i> <span class="label">Mis cursos</span></a>
  </div>
</div>

<section class="kpi-grid" aria-label="Indicadores">
  <div class="kpi is-primary">
    <div class="kpi-row">
      <div>
        <div class="label">Recursos subidos</div>
        <div class="value"><?= (int)$cntRecursos ?></div>
        <div class="meta">En toda tu actividad</div>
      </div>
      <i class="fas fa-file-arrow-up icon" aria-hidden="true"></i>
    </div>
  </div>
  <div class="kpi is-green">
    <div class="kpi-row">
      <div>
        <div class="label">Materias habilitadas</div>
        <div class="value"><?= (int)$cntPerms ?></div>
        <div class="meta">Permisos actuales</div>
      </div>
      <i class="fas fa-book icon" aria-hidden="true"></i>
    </div>
  </div>
  <div class="kpi is-amber">
    <div class="kpi-row">
      <div>
        <div class="label">Grupos</div>
        <div class="value"><?= (int)$cntGrupos ?></div>
        <div class="meta">Asignados</div>
      </div>
      <i class="fas fa-users icon" aria-hidden="true"></i>
    </div>
  </div>
  <div class="kpi is-violet">
    <div class="kpi-row">
      <div>
        <div class="label">Cursos</div>
        <div class="value"><?= (int)$cntCursos ?></div>
        <div class="meta">Activos</div>
      </div>
      <i class="fas fa-chalkboard-teacher icon" aria-hidden="true"></i>
    </div>
  </div>
</section>

<div class="grid-2" style="margin-top:12px">
  <!-- Materias -->
  <section class="card" aria-label="Materias">
    <h3><i class="fas fa-book"></i> Mis materias</h3>
    <div class="list">
      <?php if (!$materias): ?>
        <div class="empty">Aún no tienes materias asignadas.</div>
      <?php else: foreach ($materias as $m): ?>
        <div class="row">
          <div><strong><?= esc($m['clave'] ?? '') ?></strong> <span class="muted">· <?= esc($m['nombre'] ?? '') ?></span></div>
          <div class="pill"><i class="fas fa-hashtag"></i> <?= esc($m['clave'] ?? '') ?></div>
        </div>
      <?php endforeach; endif; ?>
    </div>
    <?php if ($materias): ?>
      <div style="margin-top:10px"><span class="muted">¿Falta alguna? </span><a class="btn small ghost" href="<?= esc(base_url('docentes/cursos.php')) ?>"><i class="fas fa-chalkboard"></i> Ver cursos</a></div>
    <?php endif; ?>
  </section>

  <!-- Recursos recientes -->
  <section class="card" aria-label="Recursos recientes">
    <h3><i class="fas fa-file-alt"></i> Recursos recientes</h3>
    <div class="list">
      <?php if (!$recientes): ?>
        <div class="empty">Aún no has subido recursos.</div>
      <?php else: foreach ($recientes as $r): ?>
        <div class="row">
          <div>
            <strong><?= esc($r['titulo'] ?? ('Recurso #'.(int)($r['id'] ?? 0))) ?></strong>
            <?php if (!empty($r['tipo'])): ?>
              <span class="pill"><i class="fas fa-tag"></i> <?= esc($r['tipo']) ?></span>
            <?php endif; ?>
            <?php if (!empty($r['creado_en'])): ?>
              <div class="muted" style="font-size:12px;margin-top:2px;">
                <?= esc(date('d/m/Y H:i', strtotime((string)$r['creado_en']))) ?>
              </div>
            <?php endif; ?>
          </div>
          <a class="btn small ghost" href="<?= esc(base_url('docentes/seleccionar_materia.php')) ?>"><i class="fas fa-eye"></i> Ver</a>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </section>
</div>

<!-- Notificaciones recientes (desde endpoint, mismo render que la campana) -->
<section class="card" aria-label="Notificaciones recientes" style="margin-top:12px">
  <h3><i class="fas fa-bell"></i> Notificaciones recientes</h3>
  <div id="homeNotifs" class="notif-mini">
    <div class="empty">Cargando…</div>
  </div>
  <div style="margin-top:10px">
    <span class="muted">Puedes ver todas desde la campana en la barra superior.</span>
  </div>
</section>

<script>
(function(){
  const NOTIF_URL = <?= json_encode(function_exists('base_url') ? base_url('docentes/notificaciones.php') : '/docentes/notificaciones.php') ?>;
  const box = document.getElementById('homeNotifs');

  function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
  function iconFor(tipo){
    switch(String(tipo||'')){
      case 'perfil':  return 'fa-user-gear';
      case 'permiso': return 'fa-book';
      default:        return 'fa-bell';
    }
  }

  async function loadMiniNotifs(){
    if(!box) return;
    try{
      const res = await fetch(NOTIF_URL + '?limit=6', {cache:'no-store'});
      const data = await res.json();
      const items = data.items || [];
      if (!items.length){
        box.innerHTML = '<div class="empty">No hay notificaciones por ahora.</div>';
        return;
      }
      box.innerHTML = items.map(it=>{
        const icon = iconFor(it.tipo);
        const fecha = escapeHtml(it.creado_en_fmt || it.creado_en || '');
        return `<div class="item">
          <div class="ico"><i class="fas ${icon}"></i></div>
          <div style="flex:1">
            <div class="title">${escapeHtml(it.descripcion||'')}</div>
            <div class="meta">${escapeHtml(it.tipo||'')} · ${fecha}</div>
          </div>
        </div>`;
      }).join('');
    }catch(e){
      box.innerHTML = '<div class="empty">No se pudieron cargar las notificaciones.</div>';
    }
  }

  loadMiniNotifs();
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
