<?php
// public/docentes/subir_tema.php
declare(strict_types=1);

require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'docente') { http_response_code(403); echo 'Acceso denegado'; exit; }

redirect(base_url('docentes/temas.php'));
