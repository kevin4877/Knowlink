<?php
// public/docentes/seleccionar_materia.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'docente') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$pdo = db();

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ================= AJAX ================= */
if (isset($_GET['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');
  $ajax = (string)$_GET['ajax'];
  $docId = (int)$yo['id'];

  try {
    if ($ajax === 'list_materias') {
      $st = $pdo->prepare("
        SELECT m.clave, m.nombre, COALESCE(m.descripcion,'') AS descripcion
        FROM docente_permisos_materia dpm
        JOIN materias m ON LOWER(m.clave) = LOWER(dpm.materia_clave)
        WHERE dpm.docente_id = :d
        ORDER BY m.clave ASC
      ");
      $st->execute([':d'=>$docId]);
      $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
      echo json_encode(['ok'=>true,'items'=>$items], JSON_UNESCAPED_UNICODE);
      exit;
    }
    echo json_encode(['ok'=>false,'err'=>'accion']); exit;
  } catch(Throwable $e){
    echo json_encode(['ok'=>false,'err'=>'server']); exit;
  }
}

/* ============= VISTA ============= */
$active   = 'recursos'; // 🔹 Marca “Subir recursos” en el menú DOCENTES
$title    = 'KnowLink · Docentes · Seleccionar materia';
$h1       = 'Selecciona una materia';
$subtitle = 'Filtra y elige la materia para gestionar unidades y temas.';

require __DIR__ . '/partials/header.php';
?>
<meta name="csrf" content="<?= esc($CSRF) ?>">

<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:14px}
  .tools{display:flex;align-items:flex-end;gap:12px;flex-wrap:wrap}
  .field label{font-size:12px;color:#6b7280;display:block;margin-bottom:6px}
  .field input{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;min-width:260px}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}

  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:12px}
  .m-card{
    background:#fff;border:1px solid #e6eef2;border-radius:12px;overflow:hidden;cursor:pointer;
    display:flex;flex-direction:column;transition:transform .1s ease, box-shadow .12s ease, border-color .12s ease
  }
  .m-card:hover{transform:translateY(-2px);box-shadow:0 16px 36px rgba(2,6,23,0.08);border-color:#dfeaf4}
  .thumb{aspect-ratio:16/9;background:#eef3f6;border-bottom:1px solid #eef2f6}
  .thumb img{width:100%;height:100%;object-fit:cover;display:block}
  .m-body{padding:10px}
  .m-title{font-weight:900;color:#0b2545}
  .m-sub{font-size:13px;color:#6b7280}
  .muted{color:#94a3b8}
  .empty{color:#64748b;padding:12px;border:1px dashed #e6eef2;border-radius:10px;background:#fafcff}
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div class="tools">
    <div class="field">
      <label>Buscar materia (clave o nombre)</label>
      <input id="q" type="text" placeholder="Ej. ACF0901 o 'Cálculo'" autocomplete="off">
    </div>
    <button id="clear" class="btn ghost">Limpiar</button>
  </div>
</div>

<section class="card">
  <div id="count" class="muted" style="margin-bottom:8px;">0 materia(s)</div>
  <div id="grid" class="grid" aria-live="polite">
    <div class="empty">Cargando materias…</div>
  </div>
</section>

<!-- Form (POST) para ir a temas.php sin usar querystring -->
<form id="goForm" method="post" action="<?= esc(base_url('docentes/temas.php')) ?>" style="display:none;">
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <!-- Enviamos ambos por compatibilidad -->
  <input type="hidden" name="materia" id="goMateria">
  <input type="hidden" name="materia_clave" id="goMateriaClave">
</form>

<script>
(function(){
  const grid   = document.getElementById('grid');
  const q      = document.getElementById('q');
  const clearB = document.getElementById('clear');
  const count  = document.getElementById('count');
  const goForm = document.getElementById('goForm');
  const goMat  = document.getElementById('goMateria');
  const goMat2 = document.getElementById('goMateriaClave');

  let materias = [];       // crudo desde AJAX
  let index    = [];       // [[node, haystack], ...] después de render
  let filtro   = '';

  // Quita acentos y baja a minúsculas
  function clean(s){
    return (s||'').toString().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
  }

  // Mini-hash + SVG cover (data URI) similar al diseño anterior
  function coverFor(clave, nombre){
    const siglas = (clave||'MAT').toUpperCase().replace(/[^A-Z0-9]/g,'') || 'MAT';
    // hash simple
    let h=0; for(let i=0;i<siglas.length;i++){ h = (h*31 + siglas.charCodeAt(i)) >>> 0; }
    h = h % 360; const h2 = (h + 30) % 360;
    const title = (nombre || siglas).replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    const svg =
`<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360" role="img" aria-label="${title}">
  <defs><linearGradient id="g${h}" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="hsl(${h},75%,62%)"/><stop offset="1" stop-color="hsl(${h2},82%,64%)"/></linearGradient></defs>
  <rect width="100%" height="100%" fill="url(#g${h})"/>
  <g fill="rgba(255,255,255,0.18)"><circle cx="520" cy="90" r="80"/><circle cx="120" cy="300" r="90"/><rect x="420" y="230" width="120" height="24" rx="12"/></g>
  <text x="50%" y="52%" text-anchor="middle" font-family="Inter, Arial, sans-serif" font-size="92" font-weight="900" fill="#ffffff" opacity="0.96">${siglas}</text>
</svg>`;
    return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg);
  }

  function escapeH(s){
    return String(s ?? '')
      .replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]));
  }

  async function loadMaterias(){
    grid.innerHTML = '<div class="empty">Cargando materias…</div>';
    try{
      const res = await fetch('?ajax=list_materias', {cache:'no-store'});
      const j = await res.json();
      if (!j.ok){ grid.innerHTML = '<div class="empty" style="color:#b91c1c;">No se pudieron cargar.</div>'; setCount(0); return; }
      materias = j.items || [];
      render();
    }catch(e){
      grid.innerHTML = '<div class="empty" style="color:#b91c1c;">Error de red.</div>';
      setCount(0);
    }
  }

  function setCount(n){ if (count) count.textContent = n + ' materia(s)'; }

  function render(){
    const term = clean(filtro);
    // Filtrado sobre el arreglo crudo (clave+nombre+descripcion)
    const rows = materias.filter(m => clean((m.clave||'')+' '+(m.nombre||'')+' '+(m.descripcion||'')).includes(term));
    setCount(rows.length);

    if (!rows.length){
      grid.innerHTML = '<div class="empty">Sin coincidencias.</div>';
      index = [];
      return;
    }

    // Render tarjetas con el DISEÑO bonito
    grid.innerHTML = '';
    const frag = document.createDocumentFragment();

    rows.forEach(m => {
      const clave  = String(m.clave||'');
      const nombre = String(m.nombre||'');
      const desc   = String(m.descripcion||'');
      const card = document.createElement('article');
      card.className = 'm-card';
      card.setAttribute('tabindex','0');
      card.setAttribute('role','button');
      card.setAttribute('aria-label', `${nombre || 'Materia'} ${clave}`);

      // thumb
      const th = document.createElement('div');
      th.className = 'thumb';
      th.innerHTML = `<img alt="Portada de ${escapeH(nombre||clave)}" src="${coverFor(clave, nombre)}">`;

      // body
      const body = document.createElement('div');
      body.className = 'm-body';
      body.innerHTML = `
        <div class="m-title">${escapeH(nombre || 'Materia')}</div>
        <div class="m-sub"><strong>${escapeH(clave)}</strong></div>
      `;

      // form escondido (fallback y submit programático)
      const form = document.createElement('form');
      form.method = 'post';
      form.action = <?= json_encode(function_exists('base_url') ? base_url('docentes/temas.php') : 'temas.php') ?>;
      form.style.display = 'none';
      form.innerHTML = `
        <input type="hidden" name="csrf" value="${escapeH(document.querySelector('meta[name=csrf]')?.content || '')}">
        <input type="hidden" name="materia" value="${escapeH(clave)}">
        <input type="hidden" name="materia_clave" value="${escapeH(clave)}">
      `;

      card.append(th, body, form);
      frag.appendChild(card);
    });

    grid.appendChild(frag);

    // Reindex para búsqueda por accesibilidad (aunque ya filtramos antes de pintar)
    index = Array.from(grid.querySelectorAll('.m-card')).map(card=>{
      const txt = card.textContent || '';
      return [card, clean(txt)];
    });
  }

  function submitFor(card){
    const f = card.querySelector('form');
    if (f) { f.submit(); return; }
    // Respaldo con el form global (por si quisieras)
    const clave = (card.querySelector('.m-sub strong')?.textContent || '').trim();
    if (goMat && goMat2 && clave){
      goMat.value = clave; goMat2.value = clave; goForm.submit();
    }
  }

  // Delegación de eventos para click / Enter / Space
  grid.addEventListener('click', (e)=>{
    const card = e.target.closest('.m-card');
    if (!card) return;
    submitFor(card);
  });
  grid.addEventListener('keydown', (e)=>{
    if (e.key === 'Enter' || e.key === ' ') {
      const card = e.target.closest('.m-card');
      if (!card) return;
      e.preventDefault();
      submitFor(card);
    }
  });

  // Búsqueda en vivo con insensibilidad a acentos
  q.addEventListener('input', ()=>{
    filtro = q.value || '';
    render();
  });
  clearB.addEventListener('click', ()=>{
    q.value = '';
    filtro = '';
    render();
    q.focus();
  });

  // Cargar
  loadMaterias();
})();
</script>

<?php require __DIR__ . '/partials/footer.php';
