<?php
// public/index.php
declare(strict_types=1);

// Seguridad básica en todas las vistas públicas
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-XSS-Protection: 0'); // desuso, pero evita proxies viejos
header('Content-Security-Policy: frame-ancestors \'self\'');

// Dependencias
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/auth.php';

start_session();

// Si no hay usuario, a login
$u = auth_user();
if (!$u) {
  redirect(base_url('login.php'));
}

// Mapa de rutas por rol
$destinos = [
  'administrador' => 'admin/index.php',
  'docente'       => 'docentes/index.php',
  'estudiante'    => 'estudiantes/index.php',
];

// Rol normalizado
$rol = strtolower((string)($u['rol'] ?? ''));

// Si el rol es válido, redirige
if (isset($destinos[$rol])) {
  redirect(base_url($destinos[$rol]));
  exit;
}

// --- Fallback: rol desconocido ---
http_response_code(403);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>KnowLink — Acceso</title>
  <script>
(function(){
  try{
    var saved = localStorage.getItem('knowlink-theme');
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = (saved === 'dark' || saved === 'light') ? saved : (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-bs-theme', theme);
  }catch(e){
    document.documentElement.setAttribute('data-theme', 'light');
    document.documentElement.setAttribute('data-bs-theme', 'light');
  }
})();
</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= htmlspecialchars(base_url('assets/css/knowlink-modern.css'), ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive">
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial;background:#f7fafc;color:#0b2545;display:grid;place-items:center;min-height:100vh;margin:0}
    .card{background:#fff;border-radius:12px;box-shadow:0 10px 30px rgba(2,6,23,.06);padding:22px;max-width:560px}
    h1{margin:0 0 6px 0;font-size:20px}
    p{margin:8px 0;color:#475569}
    .muted{color:#64748b;font-size:14px}
    a.btn{display:inline-block;margin-top:12px;padding:10px 14px;border-radius:10px;text-decoration:none;background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;font-weight:800}
  </style>
</head>
<body>
  <div class="card">
    <h1>Rol no reconocido</h1>
    <p class="muted">Tu cuenta tiene un rol no válido: <strong><?= htmlspecialchars($rol ?: '—', ENT_QUOTES, 'UTF-8') ?></strong>.</p>
    <p>Contacta a un administrador para corregirlo o vuelve a intentar.</p>
    <a class="btn" href="<?= htmlspecialchars(base_url('logout.php'), ENT_QUOTES, 'UTF-8') ?>">Cerrar sesión</a>
  </div>
</body>
</html>
