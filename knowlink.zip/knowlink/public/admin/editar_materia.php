<?php
// public/admin/editar_materia.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// Utils
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,'.rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/', (string)$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) $u = '/' . ltrim($m[0], '/');
    else $u = '/' . ltrim($u, '/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

// DB & CSRF
$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

// Materia a editar. Se toma primero del formulario actual para evitar
// que una sesión anterior guarde unidades en otra materia.
$refMateria = trim((string)($_POST['materia_clave'] ?? ($_GET['materia_clave'] ?? ($_SESSION['edit_materia_clave'] ?? ''))));
$clave = $refMateria !== '' ? resolve_materia_clave($pdo, $refMateria) : null;
if (!$clave) {
  unset($_SESSION['edit_materia_clave']);
  redirect(base_url('admin/gestionar_materias.php?err=Materia+no+seleccionada+o+no+encontrada'));
  exit;
}
$_SESSION['edit_materia_clave'] = $clave;

// Cargar materia usando la clave canónica guardada en materias.
$st = $pdo->prepare("SELECT clave, nombre, descripcion FROM materias WHERE clave=:c LIMIT 1");
$st->execute([':c'=>$clave]);
$materia = $st->fetch(PDO::FETCH_ASSOC);
if (!$materia) {
  unset($_SESSION['edit_materia_clave']);
  redirect(base_url('admin/gestionar_materias.php?err=Materia+no+encontrada'));
  exit;
}
$clave = (string)$materia['clave'];
$_SESSION['edit_materia_clave'] = $clave;

// Helpers unidades
function fetch_unidades(PDO $pdo, string $clave): array {
  $s = $pdo->prepare("SELECT id, numero, titulo, descripcion FROM unidades WHERE LOWER(materia_clave)=LOWER(:c) ORDER BY numero ASC, id ASC");
  $s->execute([':c'=>$clave]);
  return $s->fetchAll(PDO::FETCH_ASSOC) ?: [];
}
$unidades = fetch_unidades($pdo, $clave);

// Estado
$errors = [];
$flash  = null;

// --------- POST router ----------
if ($_SERVER['REQUEST_METHOD']==='POST') {

  // --- ELIMINAR MATERIA COMPLETA ---
  if (isset($_POST['delete_materia'])) {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
      $errors[]='CSRF inválido. Refresca la página.';
    } else {
      try {
        $pdo->beginTransaction();
        $del = $pdo->prepare("DELETE FROM materias WHERE LOWER(clave)=LOWER(:c)");
        $del->execute([':c'=>$clave]);
        $pdo->commit();
        if (isset($_SESSION['edit_materia_clave']) && strcasecmp((string)$_SESSION['edit_materia_clave'], $clave) === 0) {
          unset($_SESSION['edit_materia_clave']);
        }
        redirect(base_url('admin/gestionar_materias.php?ok=del'));
        exit;
      } catch(Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $errors[]='No se pudo eliminar la materia. Revisa dependencias o intenta más tarde.';
      }
    }
    $unidades = fetch_unidades($pdo,$clave);
  }

  // --- ACTUALIZAR DATOS DE MATERIA ---
  elseif (isset($_POST['save_materia'])) {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
      $errors[]='CSRF inválido. Refresca la página.';
    } else {
      $nombre = trim((string)($_POST['nombre'] ?? ''));
      $descripcion = trim((string)($_POST['descripcion'] ?? ''));
      if ($nombre==='' || mb_strlen($nombre)<3) $errors[]='El nombre debe tener al menos 3 caracteres.';
      if (!$errors) {
        try{
          $u = $pdo->prepare("UPDATE materias SET nombre=:n, descripcion=:d WHERE clave=:c");
          $u->execute([':n'=>$nombre, ':d'=>$descripcion, ':c'=>$clave]);
          $flash = ['type'=>'ok','msg'=>'Materia actualizada correctamente.'];
          $materia['nombre']=$nombre; $materia['descripcion']=$descripcion;
        } catch(Throwable $e){
          $errors[]='No se pudo actualizar la materia.';
        }
      }
    }
    // recarga grid
    $unidades = fetch_unidades($pdo,$clave);
  }

  // --- ELIMINAR UNA UNIDAD ---
  elseif (isset($_POST['unit_delete_id'])) {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
      $errors[]='CSRF inválido. Refresca la página.';
    } else {
      $uid = (int)$_POST['unit_delete_id'];
      if ($uid<=0) { $errors[]='Unidad inválida.'; }
      if (!$errors) {
        try{
          $d = $pdo->prepare("DELETE FROM unidades WHERE id=:id AND LOWER(materia_clave)=LOWER(:c)");
          $d->execute([':id'=>$uid, ':c'=>$clave]);
          $flash = ['type'=>'ok','msg'=>'Unidad eliminada.'];
        }catch(Throwable $e){
          $errors[]='No se pudo eliminar la unidad.';
        }
      }
    }
    $unidades = fetch_unidades($pdo,$clave);
  }

  // --- GUARDAR TODAS LAS UNIDADES (LOTE) ---
  elseif (isset($_POST['save_units']) || (($_POST['units_action'] ?? '') === 'save_units')) {
    if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
      $errors[]='CSRF inválido. Refresca la página.';
    } else {
      $ids   = array_values((array)($_POST['units']['id'] ?? []));
      $nums  = array_values((array)($_POST['units']['numero'] ?? []));
      $tits  = array_values((array)($_POST['units']['titulo'] ?? []));
      $descs = array_values((array)($_POST['units']['descripcion'] ?? []));
      $n = max(count($ids), count($nums), count($tits), count($descs));

      $current = fetch_unidades($pdo, $clave);
      $curById = [];
      $curNums = [];
      foreach ($current as $c) {
        $cid = (int)$c['id'];
        $curById[$cid] = $c;
        $curNums[$cid] = (int)$c['numero'];
      }

      $rows = [];
      for ($i=0; $i<$n; $i++) {
        $id     = (int)($ids[$i] ?? 0);
        $numRaw = trim((string)($nums[$i] ?? ''));
        $tit    = trim((string)($tits[$i] ?? ''));
        $des    = trim((string)($descs[$i] ?? ''));

        // Ignora filas nuevas completamente vacías.
        if ($id <= 0 && $numRaw === '' && $tit === '' && $des === '') {
          continue;
        }

        if ($id > 0 && !isset($curById[$id])) {
          $errors[] = 'Una de las unidades ya no existe o no pertenece a esta materia.';
          continue;
        }

        if ($tit === '') {
          $errors[] = 'Escribe el título de la unidad en la fila '.($i+1).'.';
        } elseif (mb_strlen($tit) < 3) {
          $errors[] = 'El título debe tener al menos 3 caracteres en la fila '.($i+1).'.';
        }

        $num = null;
        if ($numRaw !== '') {
          if (!ctype_digit($numRaw)) {
            $errors[] = 'El número de unidad debe ser numérico en la fila '.($i+1).'.';
          } else {
            $num = (int)$numRaw;
            if ($num < 1 || $num > 255) {
              $errors[] = 'El número de unidad debe estar entre 1 y 255 en la fila '.($i+1).'.';
            }
          }
        }

        // En unidades existentes, si dejan el número vacío se conserva el número actual.
        if ($id > 0 && $num === null) {
          $num = $curNums[$id] ?? null;
        }

        $rows[] = [
          'id' => $id,
          'numero' => $num,
          'titulo' => $tit,
          'descripcion' => $des,
          'fila' => $i + 1,
        ];
      }

      // Si el usuario está editando una materia sin unidades y no capturó nada,
      // no marcamos error; simplemente dejamos la materia sin unidades.
      if (!$errors && $rows) {
        // Auto-asigna número solo a nuevas filas que vengan sin número.
        $usedNums = [];
        foreach ($rows as $idx => $r) {
          if ($r['numero'] !== null) {
            $numKey = (int)$r['numero'];
            if (isset($usedNums[$numKey])) {
              $errors[] = 'El número de unidad '.$numKey.' está repetido. Cada unidad debe tener un número diferente.';
            } else {
              $usedNums[$numKey] = true;
            }
          }
        }

        if (!$errors) {
          foreach ($rows as $idx => $r) {
            if ((int)$r['id'] === 0 && $r['numero'] === null) {
              $cand = 1;
              while ($cand <= 255 && isset($usedNums[$cand])) $cand++;
              if ($cand > 255) {
                $errors[] = 'No hay números disponibles para nuevas unidades.';
                break;
              }
              $rows[$idx]['numero'] = $cand;
              $usedNums[$cand] = true;
            }
          }
        }
      }

      if (!$errors) {
        try {
          $pdo->beginTransaction();

          $existingRows = array_values(array_filter($rows, fn($r) => (int)$r['id'] > 0));
          $newRows      = array_values(array_filter($rows, fn($r) => (int)$r['id'] === 0));

          // Para permitir intercambiar números entre unidades existentes sin chocar con
          // la llave única ux_unidades(materia_clave, numero), primero movemos las que
          // cambian a números temporales libres dentro del rango tinyint unsigned.
          $targetNums = [];
          foreach ($existingRows as $r) $targetNums[(int)$r['numero']] = true;
          foreach ($newRows as $r)      $targetNums[(int)$r['numero']] = true;

          $changing = [];
          foreach ($existingRows as $r) {
            $id = (int)$r['id'];
            $old = $curNums[$id] ?? null;
            $newNum = (int)$r['numero'];
            if ($old !== null && $old !== $newNum) $changing[] = $id;
          }

          if ($changing) {
            $blocked = [];
            foreach ($curNums as $v) $blocked[(int)$v] = true;
            foreach ($targetNums as $v => $_) $blocked[(int)$v] = true;

            $tempPool = [];
            for ($t=255; $t>=1; $t--) {
              if (!isset($blocked[$t])) $tempPool[] = $t;
              if (count($tempPool) >= count($changing)) break;
            }
            if (count($tempPool) < count($changing)) {
              throw new RuntimeException('No hay suficientes números temporales para renumerar unidades.');
            }

            $tmpStmt = $pdo->prepare("UPDATE unidades SET numero=:num WHERE id=:id AND LOWER(materia_clave)=LOWER(:c)");
            foreach ($changing as $idx => $id) {
              $tmpStmt->execute([':num'=>$tempPool[$idx], ':id'=>$id, ':c'=>$clave]);
            }
          }

          $upd = $pdo->prepare("UPDATE unidades SET numero=:num, titulo=:tit, descripcion=:des, materia_clave=:c_set WHERE id=:id AND LOWER(materia_clave)=LOWER(:c_where)");
          foreach ($existingRows as $r) {
            $upd->execute([
              ':num' => (int)$r['numero'],
              ':tit' => $r['titulo'],
              ':des' => $r['descripcion'] !== '' ? $r['descripcion'] : null,
              ':id'  => (int)$r['id'],
              ':c_set' => $clave,
              ':c_where' => $clave,
            ]);
          }

          $ins = $pdo->prepare("INSERT INTO unidades (materia_clave, numero, titulo, descripcion) VALUES (:c, :num, :tit, :des)");
          foreach ($newRows as $r) {
            $ins->execute([
              ':c'   => $clave,
              ':num' => (int)$r['numero'],
              ':tit' => $r['titulo'],
              ':des' => $r['descripcion'] !== '' ? $r['descripcion'] : null,
            ]);
          }

          try {
            $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('materia', :ref, :d)")
                ->execute([':ref'=>$clave, ':d'=>'Unidades actualizadas para la materia '.$clave]);
          } catch(Throwable $e) { /* evento opcional */ }

          $pdo->commit();
          $flash = ['type'=>'ok','msg'=>'Unidades guardadas correctamente.'];
        } catch (Throwable $e) {
          if ($pdo->inTransaction()) $pdo->rollBack();
          error_log('[KnowLink] Error al guardar unidades de materia '.$clave.': '.$e->getMessage());
          $errors[] = 'No se pudieron guardar las unidades. Revisa que los números no estén repetidos e intenta nuevamente.';
        }
      }

      $unidades = fetch_unidades($pdo,$clave);
    }
  }

end_after_units:
  // nada
}

// ====== Variables para header/footer ======
$active   = 'materias';
$title    = 'ITZ KnowLink - Administrador · Editar materia';
$h1       = 'Editar materia';
$subtitle = 'Modifica los datos de la materia y sus unidades';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// Header
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px}
  input[type="text"],textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  textarea{min-height:110px;resize:vertical}
  .hint{font-size:12px;color:#6b7280}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn.danger{background:linear-gradient(90deg,#7a0021,#b91c1c);color:#fff}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  a.btn.ghost.btn-icon{text-decoration:none}
  .flash{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:14px}
  .flash.ok{background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46}
  .flash.error{background:#fff1f0;border:1px solid #f5c2c7;color:#7a0021}

  /* tabla unidades */
  .units-table{width:100%;border-collapse:collapse;table-layout:fixed}
  .units-table th,.units-table td{padding:8px;border-bottom:1px dashed #eef3f6;vertical-align:top}
  .units-table th{font-size:13px;color:#6b7280;text-align:left}
  .units-num{width:80px}
  .units-actions{width:160px;text-align:right}
  .units-title input{width:100%}
  .units-desc textarea{width:100%;min-height:70px}
  .actions-row{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
  .actions-row button,.actions-row a{display:inline-flex;align-items:center;gap:8px}
  .add-row{margin-top:10px}
  @media (max-width:820px){
    .units-table thead{display:none}
    .units-table tr{display:block;background:#fff;border:1px solid #eef3f6;border-radius:12px;padding:10px;margin-bottom:10px}
    .units-table td{display:block;border-bottom:0;padding:6px 0}
    .units-actions{text-align:left;width:auto}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div class="actions-row">
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if ($flash): ?>
  <div class="flash <?= $flash['type']==='ok'?'ok':'error' ?>"><?= esc($flash['msg']) ?></div>
<?php endif; ?>
<?php if ($errors): ?>
  <div class="flash error"><strong>Revisa lo siguiente:</strong><ul style="margin-top:6px; padding-left:18px;"><?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?></ul></div>
<?php endif; ?>

<section class="card">
  <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de la materia</h3>
  <form method="post" novalidate>
    <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
    <input type="hidden" name="materia_clave" value="<?= esc($materia['clave']) ?>">
    <div class="form-grid">
      <label class="field">
        <span class="label">Clave</span>
        <input type="text" value="<?= esc($materia['clave']) ?>" disabled>
        <div class="hint">La clave no se edita aquí.</div>
      </label>
      <label class="field" style="grid-column:1/-1;">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" required minlength="3" value="<?= esc($materia['nombre'] ?? '') ?>">
      </label>
      <label class="field" style="grid-column:1/-1;">
        <span class="label">Descripción</span>
        <textarea name="descripcion" placeholder="Opcional..."><?= esc($materia['descripcion'] ?? '') ?></textarea>
      </label>
    </div>
    <div class="actions-row" style="margin-top:12px;">
      <button class="btn primary btn-icon" type="submit" name="save_materia" value="1"><i class="fas fa-save"></i> <span class="label">Guardar cambios</span></button>
    </div>
  </form>
</section>

<section class="card">
  <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Unidades</h3>

  <!-- Un solo formulario para todo el grid -->
  <form method="post" id="formUnits" novalidate>
    <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
    <input type="hidden" name="materia_clave" value="<?= esc($materia['clave']) ?>">
    <input type="hidden" name="materia_nombre" value="<?= esc($materia['nombre']) ?>">
    <input type="hidden" name="units_action" value="save_units">

    <table class="units-table" id="unitsTable">
      <thead>
        <tr>
          <th class="units-num">#</th>
          <th>Título</th>
          <th>Descripción</th>
          <th class="units-actions">Acciones</th>
        </tr>
      </thead>
      <tbody id="unitsBody">
        <?php if (!$unidades): ?>
          <tr class="unit-row">
            <td class="units-num">
              <input type="hidden" name="units[id][]" value="0">
              <input type="text"  name="units[numero][]" inputmode="numeric" pattern="\d*" placeholder="1">
            </td>
            <td class="units-title">
              <input type="text"  name="units[titulo][]" placeholder="Unidad 1">
            </td>
            <td class="units-desc">
              <textarea name="units[descripcion][]" placeholder="Descripción (opcional)"></textarea>
            </td>
            <td class="units-actions">
              <em style="color:#6b7280;font-size:12px;">Nueva</em>
            </td>
          </tr>
        <?php else: ?>
          <?php foreach($unidades as $u): ?>
            <tr class="unit-row">
              <td class="units-num">
                <input type="hidden" name="units[id][]" value="<?= (int)$u['id'] ?>">
                <input type="text"   name="units[numero][]" inputmode="numeric" pattern="\d*" value="<?= (int)$u['numero'] ?>">
              </td>
              <td class="units-title">
                <input type="text"   name="units[titulo][]" value="<?= esc($u['titulo'] ?? '') ?>">
              </td>
              <td class="units-desc">
                <textarea name="units[descripcion][]"><?= esc($u['descripcion'] ?? '') ?></textarea>
              </td>
              <td class="units-actions">
                <button type="submit" class="btn ghost btn-icon" name="unit_delete_id" value="<?= (int)$u['id'] ?>" formnovalidate onclick="return confirm('¿Eliminar esta unidad? También se eliminarán sus temas y recursos relacionados.');">
                  <i class="fas fa-trash"></i> <span class="label">Eliminar</span>
                </button>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php endif; ?>
      </tbody>
    </table>

    <div class="actions-row add-row">
      <button type="button" id="addUnit" class="btn ghost btn-icon">
        <i class="fas fa-plus"></i> <span class="label">Agregar unidad</span>
      </button>
    </div>

    <div class="actions-row" style="margin-top:12px;">
      <button class="btn primary btn-icon" type="submit" name="save_units" value="1">
        <i class="fas fa-save"></i> <span class="label">Guardar cambios de unidades</span>
      </button>
    </div>
  </form>
</section>

<section class="card" id="zona-peligrosa" style="border:1px solid #fecaca;background:#fff7f7;">
  <h3 style="font-size:16px;margin-bottom:8px;color:#7a0021;"><i class="fas fa-triangle-exclamation"></i> Eliminar materia</h3>
  <p style="margin:0 0 12px;color:#7a0021;">
    Esta acción eliminará la materia <strong><?= esc($materia['nombre'] ?? $materia['clave']) ?></strong>, sus unidades y sus relaciones académicas asociadas. No se puede deshacer.
  </p>
  <form method="post" onsubmit="return confirm('¿Seguro que deseas eliminar esta materia? También se eliminarán sus unidades, relaciones con retículas, permisos y contenidos dependientes. Esta acción no se puede deshacer.');">
    <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
    <input type="hidden" name="materia_clave" value="<?= esc($materia['clave']) ?>">
    <button class="btn danger btn-icon" type="submit" name="delete_materia" value="1">
      <i class="fas fa-trash"></i> <span class="label">Eliminar materia definitivamente</span>
    </button>
  </form>
</section>

<script>
(function(){
  'use strict';
  const body = document.getElementById('unitsBody');
  const addBtn = document.getElementById('addUnit');

  function qsa(sel, root=document){ return Array.from(root.querySelectorAll(sel)); }
  function nextNumber(){
    const nums = qsa('input[name="units[numero][]"]', body)
      .map(i => parseInt((i.value || i.placeholder || '0').trim(),10))
      .filter(n => Number.isFinite(n) && n>0);
    return nums.length ? Math.max(...nums) + 1 : 1;
  }

  function makeRow(){
    const n = nextNumber();
    const tr = document.createElement('tr'); tr.className='unit-row';

    const tdNum = document.createElement('td'); tdNum.className='units-num';
    const tdTit = document.createElement('td'); tdTit.className='units-title';
    const tdDes = document.createElement('td'); tdDes.className='units-desc';
    const tdAct = document.createElement('td'); tdAct.className='units-actions';

    const hid = document.createElement('input');
    hid.type='hidden'; hid.name='units[id][]'; hid.value='0';

    const num = document.createElement('input');
    num.type='text'; num.name='units[numero][]'; num.setAttribute('inputmode','numeric'); num.setAttribute('pattern','\\d*');
    num.placeholder = String(n); num.value = String(n);

    const tit = document.createElement('input');
    tit.type='text'; tit.name='units[titulo][]'; tit.placeholder='Unidad ' + n;

    const des = document.createElement('textarea');
    des.name='units[descripcion][]'; des.placeholder='Descripción (opcional)';

    tdNum.appendChild(hid); tdNum.appendChild(num);
    tdTit.appendChild(tit);
    tdDes.appendChild(des);
    tdAct.innerHTML = '<em style="color:#6b7280;font-size:12px;">Nueva</em>';

    tr.appendChild(tdNum); tr.appendChild(tdTit); tr.appendChild(tdDes); tr.appendChild(tdAct);
    return tr;
  }

  addBtn?.addEventListener('click', ()=>{ body.appendChild(makeRow()); });
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
