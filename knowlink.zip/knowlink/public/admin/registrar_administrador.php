<?php
// public/admin/registrar_administrador.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$usuario = auth_user();
if (!$usuario) { redirect(base_url('login.php')); exit; }
if (($usuario['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Cabeceras de seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// === Utilidades
function safeStr($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Polyfill PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

// Placeholder SVG
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="44" cy="32" r="16" fill="#cfd8e3"/><rect x="18" y="54" width="52" height="22" rx="11" fill="#cfd8e3"/></svg>'
    );
  }
}

/**
 * Normaliza a URL web ABSOLUTA para <img src="...">.
 * Acepta /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\', '/', $url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u;
    while (str_starts_with($u, '../')) $u = substr($u, 3);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/'); // /uploads/avatars/...
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

const EMAIL_DOMAIN = '@zitacuaro.tecnm.mx';

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();

/* =============== AJAX: username disponible =============== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'check_username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  $ok=false; $avail=false;
  if ($u !== '' && mb_strlen($u) >= 3) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u");
    $st->execute([':u'=>$u]);
    $avail = ((int)$st->fetchColumn() === 0);
    $ok = true;
  }
  echo json_encode(['ok'=>$ok, 'avail'=>$avail], JSON_UNESCAPED_UNICODE);
  exit;
}

/* =============== POST: registrar administrador =============== */
$errors = [];
$old = [
  'nombre'      => '',
  'apellidos'   => '',
  'email_local' => '',
  'username'    => '',
];
$fotoPreview = foto_src(null);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido. Recarga la página.';
  }

  $old['nombre']      = trim((string)($_POST['nombre'] ?? ''));
  $old['apellidos']   = trim((string)($_POST['apellidos'] ?? ''));
  $old['email_local'] = strtolower(trim((string)($_POST['email_local'] ?? '')));
  $old['username']    = trim((string)($_POST['username'] ?? ''));
  $password           = (string)($_POST['password'] ?? '');
  $password2          = (string)($_POST['password2'] ?? '');

  // Validaciones básicas
  if ($old['nombre'] === '' || mb_strlen($old['nombre']) < 2)     $errors[] = 'Nombre inválido.';
  if ($old['apellidos'] === '' || mb_strlen($old['apellidos'])<2) $errors[] = 'Apellidos inválidos.';

  if ($old['email_local'] === '') {
    $errors[] = 'Usuario del correo institucional requerido.';
  } elseif (!preg_match('/^[a-z0-9._-]{2,64}$/i', $old['email_local'])) {
    $errors[] = 'Usuario de correo inválido. Usa letras, números, ".", "_" o "-".';
  }
  $email = $old['email_local'] . EMAIL_DOMAIN;
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Correo institucional inválido.';
  }

  if ($old['username'] === '' || mb_strlen($old['username']) < 3) $errors[] = 'El usuario debe tener al menos 3 caracteres.';
  if ($password === '' || mb_strlen($password) < 8)               $errors[] = 'La contraseña debe tener al menos 8 caracteres.';
  if ($password !== $password2)                                   $errors[] = 'Las contraseñas no coinciden.';

  // Unicidad
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u");
    $st->execute([':u'=>$old['username']]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'El nombre de usuario ya está en uso.';

    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e");
    $st->execute([':e'=>$email]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'Ese correo ya está registrado.';
  }

  // Subida de foto (opcional). Guardamos SIEMPRE como /uploads/avatars/archivo.ext
  $foto_url = null;       // ruta web limpia que se guardará en DB (p.ej. /uploads/avatars/xxx.webp)
  $saved_abs_path = null; // path absoluto real por si hay que limpiarlo si falla el INSERT

  if (!$errors && isset($_FILES['foto']) && is_array($_FILES['foto']) && ($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['foto'];
    if ($f['error'] !== UPLOAD_ERR_OK) { $errors[]='Error al subir la imagen.'; }
    else {
      if ($f['size'] > 3*1024*1024) $errors[]='La imagen excede 3 MB.';
      // Checa MIME y que sea realmente imagen
      $finfo = finfo_open(FILEINFO_MIME_TYPE);
      $mime  = finfo_file($finfo, $f['tmp_name']); finfo_close($finfo);
      $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
      if (!isset($allowed[$mime])) $errors[]='Formato de imagen no permitido (JPG, PNG, GIF, WEBP).';
      if (!$errors) {
        $gi = @getimagesize($f['tmp_name']);
        if ($gi === false) $errors[] = 'El archivo no es una imagen válida.';
      }
      if (!$errors) {
        $ext = $allowed[$mime];
        $publicRoot = realpath(__DIR__ . '/..'); // .../public
        if (!$publicRoot) { $errors[]='Ruta pública no disponible.'; }
        else {
          $dir = $publicRoot . '/uploads/avatars';
          if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
          $fname   = 'adm_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
          $webPath = '/uploads/avatars/' . $fname;   // <-- RUTA WEB LIMPIA que irá a la DB
          $dest    = $publicRoot . $webPath;         // <-- PATH ABSOLUTO para move_uploaded_file

          if (!move_uploaded_file($f['tmp_name'], $dest)) {
            $errors[] = 'No se pudo guardar la imagen en el servidor.';
          } else {
            $foto_url = $webPath;
            $saved_abs_path = $dest;
            // Actualiza el preview en caso de error posterior
            $fotoPreview = foto_src($foto_url);
          }
        }
      }
    }
  }

  if (!$errors) {
    try {
      $hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>10]);
      $st = $pdo->prepare("
        INSERT INTO usuarios (nombre, apellidos, email, username, password_hash, rol, foto_url, activo, creado_en, actualizado_en)
        VALUES (:n,:a,:e,:u,:ph,'administrador',:f,1,NOW(),NOW())
      ");
      $st->execute([
        ':n'=>$old['nombre'],
        ':a'=>$old['apellidos'],
        ':e'=>$email,
        ':u'=>$old['username'],
        ':ph'=>$hash,
        ':f'=>$foto_url
      ]);

      redirect(base_url('admin/gestionar_administradores.php?created=1'));
      exit;

    } catch(Throwable $e) {
      // Limpieza: si subimos archivo pero falló el INSERT, bórralo
      if ($saved_abs_path && is_file($saved_abs_path)) { @unlink($saved_abs_path); }
      $errors[] = 'No se pudo registrar al administrador. Intenta de nuevo.';
    }
  }
}

/* =========================
   HEADER (parcial existente)
   ========================= */
$active   = 'admins';
$title    = 'ITZ KnowLink - Administrador · Registrar administrador';
$h1       = 'Registrar administrador';
$subtitle = 'Crea un usuario con rol administrativo';

$HEADER_TITLE  = $h1;
$HEADER_SUB    = $subtitle;
$PAGE_TITLE    = $title;
$header_title  = $h1;
$header_sub    = $subtitle;
$page_title    = $title;
$page_h1       = $h1;
$page_h2       = $subtitle;
$PAGE_H1       = $h1;
$PAGE_SUBTITLE = $subtitle;

$MENU_ACTIVE     = $active;
$ACTIVE_MENU     = $active;
$ACTIVE_SECTION  = $active;
$CURRENT_SECTION = $active;

// El header espera $yo
$yo = $usuario;

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
  .page-title{ font-size:20px; font-weight:800; color:#0b2545; }
  .page-sub{ color:#6b7280; font-size:14px; }

  .card{ background:#fff; border-radius:12px; padding:16px; box-shadow:0 10px 30px rgba(2,6,23,0.06); margin-bottom:16px; }
  .form-grid{ display:grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap:12px; margin-top:12px; }
  label.field{ display:flex; flex-direction:column; gap:8px; position:relative; }
  input[type="text"], input[type="email"], input[type="password"], select, textarea {
    width:100%; box-sizing:border-box; padding:10px 12px; border-radius:10px; border:1px solid #e6eef2; outline:none; font-size:14px; background:#fff;
  }
  .hint{ font-size:13px; color:#6b7280; }
  .actions { margin-top:12px; display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
  .btn { padding:10px 14px; border-radius:10px; background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; border:none; cursor:pointer; font-weight:800; }
  .btn.ghost { background:#fff; color:#0b2545; border:1px solid #e6eef2; }
  .btn-icon { display:inline-flex; align-items:center; gap:8px; }
  .btn-icon .label{ display:inline; }

  /* Foto */
  .photo-row { display:flex; gap:12px; align-items:center; }
  .photo-preview { width:88px; height:88px; border-radius:8px; background-size:cover; background-position:center; border:1px dashed #e6eef2; display:flex; align-items:center; justify-content:center; color:#6b7280; }

  /* Email institucional (dominio fijo) */
  .email-row{ display:flex; align-items:stretch; gap:0; max-width:540px; }
  .email-local{ flex:1; border-top-right-radius:0; border-bottom-right-radius:0; border-right:0; }
  .email-addon{ display:flex; align-items:center; padding:0 12px; border:1px solid #e6eef2; background:#f3f6f9; border-left:0;
    border-top-right-radius:10px; border-bottom-right-radius:10px; font-weight:700; color:#0b2545; white-space:nowrap; }

  /* Disponibilidad username */
  .avail { display:none; align-items:center; gap:8px; padding:6px 10px; border-radius:10px; font-weight:800; margin-top:6px; border:1px solid #e6eef2; background:#f3f6f9; color:#0b2545; }
  .avail.good { background:#ecfdf5; border-color:#bbf7d0; color:#065f46; display:inline-flex; }
  .avail.bad  { background:#fff1f0; border-color:#f5c2c7; color:#7a0021; display:inline-flex; }
  .avail.info { display:inline-flex; color:#6b7280; }

  /* Password meter */
  .pw-meter { height:8px; width:100%; background:#eef2f7; border-radius:999px; overflow:hidden; margin-top:6px; }
  .pw-meter > div { height:8px; width:0%; background:#ef4444; transition: width .2s ease; }
  .pw-tip { font-size:12px; color:#6b7280; margin-top:6px; }

  /* Ojo de contraseña (como en las otras vistas) */
  .pwd-wrap{ position:relative; }
  .pwd-wrap input{ padding-right:42px; }
  .toggle-eye{
    position:absolute; right:8px; top:50%; transform:translateY(-50%);
    background:transparent; border:0; cursor:pointer; font-size:16px; color:#6b7280; padding:6px; border-radius:8px;
  }
  .toggle-eye:hover{ background:#f3f6f9; color:#0b2545; }

  /* Ocultar reveladores nativos (evita doble ojo) */
  input[type="password"]::-webkit-textfield-decoration-container,
  input[type="password"]::-webkit-password-reveal-button,
  input[type="password"]::-ms-reveal,
  input[type="password"]::-ms-clear{ display:none !important; appearance:none !important; width:0; height:0; margin:0; padding:0; border:0; pointer-events:none; }
  input[type="password"]{ -moz-appearance:textfield !important; }

  /* Responsive */
  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= safeStr($h1) ?></div>
    <div class="page-sub"><?= safeStr($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= safeStr(base_url('admin/gestionar_administradores.php')) ?>" title="Volver">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="card" role="alert" style="border:1px solid #f5c2c7;background:#fff1f0;color:#7a0021;">
    <ul style="padding-left:18px;"><?php foreach ($errors as $e): ?><li><?= safeStr($e) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" novalidate>
  <input type="hidden" name="csrf" value="<?= safeStr($CSRF) ?>">

  <!-- Foto -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Foto de perfil</h3>
    <p class="hint">Opcional. JPG/PNG/GIF/WEBP (máx. 3 MB).</p>
    <div class="form-grid" style="margin-top:12px;">
      <div class="photo-row">
        <div class="photo-preview" id="preview" style="background-image:url('<?= safeStr($fotoPreview) ?>');"></div>
        <label class="field" style="flex:1;">
          <span class="label">Seleccionar imagen</span>
          <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/gif, image/webp">
          <div class="hint">Deja vacío para no agregar foto.</div>
        </label>
      </div>
    </div>
  </section>

  <!-- Datos personales -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos personales</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" id="nombre" minlength="2" required value="<?= safeStr($old['nombre']) ?>">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" id="apellidos" minlength="2" required value="<?= safeStr($old['apellidos']) ?>">
      </label>

      <!-- Correo institucional con dominio fijo -->
      <label class="field" style="grid-column:1/-1">
        <span class="label">Correo institucional</span>
        <div class="email-row">
          <input type="text" class="email-local" name="email_local" id="email_local" placeholder="nombre.apellido" required value="<?= safeStr($old['email_local']) ?>">
          <div class="email-addon"><?= safeStr(EMAIL_DOMAIN) ?></div>
        </div>
        <div class="hint">Escribe solo el usuario; el dominio es <?= safeStr(EMAIL_DOMAIN) ?>.</div>
      </label>
    </div>
  </section>

  <!-- Acceso -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos de acceso</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" minlength="3" required value="<?= safeStr($old['username']) ?>" autocomplete="off">
        <div id="unameStatus" class="avail info" role="status" aria-live="polite" aria-atomic="true" style="display:none;">
          <i class="fas fa-info-circle"></i> Mínimo 3 caracteres
        </div>
      </label>

      <label class="field" id="fieldPwd">
        <span class="label">Contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="password" placeholder="Escribe la contraseña" required minlength="8" autocomplete="new-password" />
          <button type="button" class="toggle-eye" data-target="password" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
        <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
      </label>

      <label class="field" id="fieldPwd2">
        <span class="label">Confirmar contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="password2" placeholder="Confirma la contraseña" required minlength="8" autocomplete="new-password" />
          <button type="button" class="toggle-eye" data-target="password2" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <small id="pwMatchHint" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
      </label>
    </div>

    <div class="actions">
      <button type="submit" class="btn"><i class="fas fa-user-shield"></i> Registrar administrador</button>
      <a class="btn ghost btn-icon" href="<?= safeStr(base_url('admin/gestionar_administradores.php')) ?>" title="Cancelar">
        <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
      </a>
    </div>
  </section>
</form>

<script>
function pulse(el){ if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'), 450); }
function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&quot;',"'":'&#39;'}[m])); }

/* ===== Imagen preview ===== */
(function(){
  const foto=document.getElementById('foto');
  const preview=document.getElementById('preview');
  const def=<?= json_encode($fotoPreview) ?>;
  foto?.addEventListener('change', e=>{
    const f=e.target.files[0]; if(!f){ preview.style.backgroundImage=`url('${def}')`; return; }
    if(f.size>3*1024*1024){ alert('La imagen excede 3 MB.'); foto.value=''; preview.style.backgroundImage=`url('${def}')`; return; }
    const reader=new FileReader();
    reader.onload=()=> preview.style.backgroundImage=`url('${reader.result}')`;
    reader.readAsDataURL(f);
  });
})();

/* ===== Disponibilidad de usuario ===== */
(function(){
  const unameInput = document.getElementById('username');
  const unameStatus = document.getElementById('unameStatus');
  const submitBtn = document.querySelector('button[type="submit"]');
  let timer=null, last='';

  function show(text, cls){
    unameStatus.style.display='inline-flex';
    unameStatus.classList.remove('good','bad','info');
    if (cls) unameStatus.classList.add(cls);
    unameStatus.innerHTML = text;
  }
  function hide(){ unameStatus.style.display='none'; }

  async function check(u){
    if (!u || u.trim().length < 3){ show('<i class="fas fa-info-circle"></i> Mínimo 3 caracteres','info'); submitBtn && (submitBtn.disabled=false); return; }
    try{
      const res = await fetch(`?ajax=check_username&u=${encodeURIComponent(u)}`, {cache:'no-store'});
      const data = await res.json();
      if (data.ok && data.avail){ show('<i class="fas fa-check-circle"></i> Disponible ✓','good'); submitBtn && (submitBtn.disabled=false); }
      else { show('<i class="fas fa-times-circle"></i> Ya está en uso ✗','bad'); submitBtn && (submitBtn.disabled=true); }
    }catch(e){
      show('<i class="fas fa-info-circle"></i> Intenta de nuevo','info');
    }
  }

  unameInput?.addEventListener('input', ()=>{
    const v = unameInput.value.trim();
    if (v === '') { hide(); submitBtn && (submitBtn.disabled=false); return; }
    clearTimeout(timer);
    timer = setTimeout(()=>{ if (v !== last){ last=v; check(v); } }, 300);
  });

  if (unameInput && unameInput.value.trim().length >= 1) {
    show('<i class="fas fa-info-circle"></i> Mínimo 3 caracteres','info');
    check(unameInput.value.trim());
  }
})();

/* ===== Password meter + match ===== */
(function(){
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');
  const bar=document.getElementById('pwBar');
  const tip=document.getElementById('pwTip');
  const matchHint=document.getElementById('pwMatchHint');

  function scorePassword(pw){
    let score=0; if(!pw) return 0;
    const letters={};
    for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
    const variations={ digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
    let vc=0; for(const k in variations) vc += variations[k] ? 1 : 0;
    score += (vc - 1) * 10; return parseInt(score);
  }
  function updateMeter(){
    const val=p1.value||'';
    const s=Math.min(100, scorePassword(val));
    bar.style.width = (val ? Math.max(8,s) : 0) + '%';
    if (!val){ tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
    if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
    else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
    else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
    else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
    pulse(bar.parentElement);
  }
  function updateMatch(){
    if(!p2.value){ matchHint.style.display='none'; return; }
    matchHint.style.display = (p1.value !== p2.value) ? 'block' : 'none';
    if (matchHint.style.display==='block') pulse(matchHint);
  }
  ['input','change','keyup','blur'].forEach(ev=>{
    p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
    p2?.addEventListener(ev, updateMatch);
  });
  updateMeter(); updateMatch();
})();

/* ===== Ojo de contraseña (como en alumnos/docentes) ===== */
(function(){
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });
})();

/* ===== Validación final (cliente) ===== */
(function(){
  const form=document.querySelector('form');
  const emailLocal=document.getElementById('email_local');
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');

  form?.addEventListener('submit', (e)=>{
    const local = (emailLocal.value||'').trim();
    if (!/^[a-z0-9._-]{2,64}$/i.test(local)) { e.preventDefault(); alert('Usuario de correo inválido.'); emailLocal.focus(); return; }
    if (p1.value.length < 8){ e.preventDefault(); alert('La contraseña debe tener al menos 8 caracteres.'); p1.focus(); return; }
    if (p1.value !== p2.value){ e.preventDefault(); alert('Las contraseñas no coinciden.'); p2.focus(); return; }
  });
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
