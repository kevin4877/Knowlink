<?php
// public/admin/registro_materia.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// Utils locales
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  /**
   * Normaliza rutas de avatar del header a una URL absoluta válida para <img>.
   * Acepta: '/uploads/avatars/...', 'uploads/avatars/...', '../uploads/avatars/...', 'http(s)://...' o 'data:...'
   */
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/', (string)$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) $u = '/' . ltrim($m[0], '/');
    else $u = '/' . ltrim($u, '/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

// DB & CSRF
$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

// Estado de formulario
$errors = [];
$flash  = null;

$values = [
  'clave'       => trim((string)($_POST['clave'] ?? '')),
  'nombre'      => trim((string)($_POST['nombre'] ?? '')),
  'descripcion' => trim((string)($_POST['descripcion'] ?? '')),
];

// POST
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['form'] ?? '') === 'materia') {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido. Refresca la página.';
  }

  // Validaciones básicas
  $clave = $values['clave'];
  $nombre = $values['nombre'];
  $descripcion = $values['descripcion'];

  if ($clave === '') $errors[] = 'La clave es obligatoria.';
  // Aceptamos letras, números, guión y guion bajo. 3-20 chars.
  if ($clave !== '' && !preg_match('/^[A-Za-z0-9_-]{3,20}$/', $clave)) {
    $errors[] = 'La clave debe tener entre 3 y 20 caracteres (letras, números, guión o guion bajo).';
  }
  if ($nombre === '' || mb_strlen($nombre) < 3) {
    $errors[] = 'El nombre debe tener al menos 3 caracteres.';
  }

  // Unicidad de clave
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM materias WHERE clave=:c");
    $st->execute([':c'=>$clave]);
    if ((int)$st->fetchColumn() > 0) {
      $errors[] = 'Ya existe una materia con esa clave.';
    }
  }

  // Insert
  if (!$errors) {
    try {
      $pdo->beginTransaction();

      $ins = $pdo->prepare("INSERT INTO materias (clave, nombre, descripcion) VALUES (:c, :n, :d)");
      $ins->execute([
        ':c' => $clave,
        ':n' => $nombre,
        ':d' => $descripcion !== '' ? $descripcion : null,
      ]);

      // Evento admin (opcional)
      try {
        $ev = $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('materia', :ref, :desc)");
        $ev->execute([
          ':ref'  => $clave,
          ':desc' => 'Nueva materia “'.$nombre.'” creada',
        ]);
      } catch (Throwable $e) {
        // opcional, no rompe el flujo
      }

      $pdo->commit();

      // Abrir en editor sin pasar por URL
      $_SESSION['edit_materia_clave'] = $clave;
      redirect(base_url('admin/editar_materia.php'));
      exit;

    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al registrar la materia.';
    }
  }
}

/* ==========================================================
   Variables para header/footer parciales
   ========================================================== */
$active   = 'materias';
$title    = 'ITZ KnowLink - Administrador · Registrar Materia';
$h1       = 'Registrar materia';
$subtitle = 'Captura la información base de una nueva materia';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// Header
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px}
  input[type="text"],textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  textarea{min-height:110px;resize:vertical}
  .hint{font-size:12px;color:#6b7280}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  a.btn.ghost.btn-icon{text-decoration:none}
  .flash{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:14px}
  .flash.ok{background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46}
  .flash.error{background:#fff1f0;border:1px solid #f5c2c7;color:#7a0021}
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash error">
    <strong>Revisa lo siguiente:</strong>
    <ul style="margin-top:6px; padding-left:18px;">
      <?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?>
    </ul>
  </div>
<?php endif; ?>

<section class="card">
  <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de la materia</h3>
  <form method="post" novalidate>
    <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
    <input type="hidden" name="form" value="materia">

    <div class="form-grid">
      <label class="field">
        <span class="label">Clave</span>
        <input type="text" name="clave" required minlength="3" maxlength="20"
               pattern="[A-Za-z0-9_-]{3,20}"
               placeholder="Ej. ACF0901"
               value="<?= esc($values['clave']) ?>">
        <div class="hint">3–20 caracteres (letras, números, - o _). Debe ser única.</div>
      </label>

      <label class="field" style="grid-column:1/-1;">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" required minlength="3"
               placeholder="Ej. Cálculo Diferencial"
               value="<?= esc($values['nombre']) ?>">
      </label>

      <label class="field" style="grid-column:1/-1;">
        <span class="label">Descripción (opcional)</span>
        <textarea name="descripcion" placeholder="Breve descripción..."><?= esc($values['descripcion']) ?></textarea>
      </label>
    </div>

    <div style="display:flex;gap:8px;align-items:center;margin-top:12px;">
      <button class="btn primary btn-icon" type="submit">
        <i class="fas fa-save"></i> <span class="label">Guardar y continuar</span>
      </button>
      <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>">
        <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
      </a>
    </div>
  </form>
</section>

<?php
require __DIR__ . '/partials/footer.php';
