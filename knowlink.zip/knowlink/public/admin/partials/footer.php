 </main>
  </div>

  <div id="overlay" style="display:none; position:fixed; inset:0; background:rgba(2,6,23,0.36); z-index:1140;"></div>

  <script>
  const ADMIN_NOTIF_URL = <?= json_encode(function_exists('base_url') ? base_url('admin/notificaciones.php') : '/admin/notificaciones.php', JSON_UNESCAPED_SLASHES) ?>;
  (function(){
    function isMobile(){ return window.innerWidth < 1000; }

    // ===== Sidebar + overlay =====
    const menuBtn = document.getElementById('menuBtn');
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('overlay');
    const body = document.body;

    try { if (localStorage.getItem('sidebar-collapsed') === '1') { sidebar.classList.add('collapsed'); body.classList.add('sidebar-collapsed'); } } catch(e){}

    function toggleMenu(){
      if (window.innerWidth >= 1000) {
        sidebar.classList.toggle('collapsed');
        const collapsed = sidebar.classList.contains('collapsed');
        body.classList.toggle('sidebar-collapsed', collapsed);
        try { localStorage.setItem('sidebar-collapsed', collapsed ? '1' : '0'); } catch(e){}
        menuBtn.setAttribute('aria-expanded', String(!collapsed));
      } else {
        sidebar.classList.toggle('open');
        overlay.style.display = sidebar.classList.contains('open') ? 'block' : 'none';
        body.classList.toggle('sidebar-open', sidebar.classList.contains('open'));
        menuBtn.setAttribute('aria-expanded', String(sidebar.classList.contains('open')));
      }
    }
    menuBtn?.addEventListener('click', function(e){ toggleMenu(); e.stopPropagation(); });
    overlay?.addEventListener('click', function(){ sidebar.classList.remove('open'); overlay.style.display='none'; body.classList.remove('sidebar-open'); menuBtn?.setAttribute('aria-expanded','false'); });

    // ===== User menu =====
    const userArea = document.getElementById('userArea');
    const userBtn   = document.getElementById('userDropdownBtn');
    const userMenu  = document.getElementById('userMenu');
    let userHoverTimer, userSticky=false;

    function openUserMenu(sticky=false){ userMenu.setAttribute('aria-hidden','false'); userBtn.setAttribute('aria-expanded','true'); userArea.classList.add('open'); if(sticky) userSticky=true; }
    function closeUserMenu(){ userMenu.setAttribute('aria-hidden','true'); userBtn.setAttribute('aria-expanded','false'); userArea.classList.remove('open'); userSticky=false; }
    function isUserOpen(){ return userMenu.getAttribute('aria-hidden')==='false'; }

    userArea?.addEventListener('mouseenter',()=>{ if(isMobile()) return; clearTimeout(userHoverTimer); if(!userSticky) openUserMenu(false); });
    userArea?.addEventListener('mouseleave',()=>{ if(isMobile()) return; userHoverTimer=setTimeout(()=>{ if(!userSticky) closeUserMenu(); },150); });
    userBtn?.addEventListener('click',(e)=>{ e.stopPropagation(); if(isUserOpen() && userSticky) closeUserMenu(); else openUserMenu(true); });
    document.addEventListener('click',(e)=>{ if(userArea && !userArea.contains(e.target)) closeUserMenu(); });
    document.addEventListener('keydown',(e)=>{ if(e.key==='Escape') closeUserMenu(); });
    userMenu?.setAttribute('aria-hidden','true'); userBtn?.setAttribute('aria-expanded','false');

    // ===== Notificaciones unificadas (con persistencia entre páginas) =====
    const notifArea  = document.getElementById('notifArea');
    const notifBtn   = document.getElementById('notifBtn');
    const notifMenu  = document.getElementById('notifMenu');
    const notifList  = document.getElementById('notifList');
    const notifBadge = document.getElementById('notifBadge');
    let notifHoverTimer, notifSticky=false;

    // Persistimos el último ID visto en localStorage
    function getLastSeen(){ const v = parseInt(localStorage.getItem('notif_last_seen')||'0',10); return Number.isFinite(v) && v>0 ? v : 0; }
    function setLastSeen(id){ try{ localStorage.setItem('notif_last_seen', String(id||0)); }catch(e){} }

    let lastSeenId = getLastSeen();
    let maxFetchedId = lastSeenId;

    function openNotif(sticky=false){
      notifMenu.setAttribute('aria-hidden','false'); notifBtn.setAttribute('aria-expanded','true'); notifArea.classList.add('open');
      if(sticky) notifSticky=true;
      // Al abrir, marcamos como vistas todas las actuales
      if(maxFetchedId > lastSeenId){ setLastSeen(maxFetchedId); lastSeenId = maxFetchedId; updateBadge(0); }
    }
    function closeNotif(){ notifMenu.setAttribute('aria-hidden','true'); notifBtn.setAttribute('aria-expanded','false'); notifArea.classList.remove('open'); notifSticky=false; }
    function isNotifOpen(){ return notifMenu.getAttribute('aria-hidden')==='false'; }

    notifArea?.addEventListener('mouseenter',()=>{ if(isMobile()) return; clearTimeout(notifHoverTimer); if(!notifSticky) openNotif(false); });
    notifArea?.addEventListener('mouseleave',()=>{ if(isMobile()) return; notifHoverTimer=setTimeout(()=>{ if(!notifSticky) closeNotif(); },150); });
    notifBtn?.addEventListener('click',(e)=>{ e.stopPropagation(); if(isNotifOpen() && notifSticky) closeNotif(); else openNotif(true); });
    document.addEventListener('click',(e)=>{ if(notifArea && !notifArea.contains(e.target)) closeNotif(); });
    document.addEventListener('keydown',(e)=>{ if(e.key==='Escape') closeNotif(); });

    function escapeHtml(s){ return (s ?? '').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }
    function renderNotifications(items){
      if(!notifList) return;
      if(!items||!items.length){
        notifList.innerHTML='<div class="notif-empty">Sin novedades por ahora.</div>';
        return;
      }
      notifList.innerHTML = items.map(it=>{
        const icon = it.tipo==='reticula'?'fa-diagram-project':(it.tipo==='materia'?'fa-book':'fa-graduation-cap');
        const id = parseInt(it.id||0,10); if(id>maxFetchedId) maxFetchedId=id;
        return `<div class="notif-item">
          <div class="ico"><i class="fas ${icon}"></i></div>
          <div class="txt">
            <div>${escapeHtml(it.descripcion||'')}</div>
            <div class="meta">${escapeHtml(it.tipo||'')} · ${escapeHtml(it.creado_en_fmt || it.creado_en || '')}</div>
          </div>
        </div>`;
      }).join('');
    }
    function updateBadge(total){
      if(!notifBadge) return;
      if(total>0){ notifBadge.style.display='inline-block'; notifBadge.textContent=(total>99?'99+':String(total)); }
      else{ notifBadge.style.display='none'; }
    }

    async function fetchNotifications(){
      try{
        const res = await fetch(ADMIN_NOTIF_URL + '?since_id=' + encodeURIComponent(lastSeenId), {cache:'no-store'});
        if(!res.ok) return;
        const data = await res.json();
        renderNotifications(data.items||[]);
        const total = parseInt(data.total||0,10)||0;
        // Si el menú está abierto marcamos como visto inmediatamente
        if(isNotifOpen() && maxFetchedId>lastSeenId){ setLastSeen(maxFetchedId); lastSeenId=maxFetchedId; updateBadge(0); }
        else{ updateBadge(total); }
      }catch(e){}
    }
    // carga inicial y cada 10s
    fetchNotifications();
    setInterval(fetchNotifications, 10000);
  })();
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/js/knowlink-theme.js') : '/assets/js/knowlink-theme.js', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive"></script>
</body>
</html>