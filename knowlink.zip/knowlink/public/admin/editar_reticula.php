<?php
// public/admin/editar_reticula.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// ===== Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// ===== Utils
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/', (string)$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) $u = '/' . ltrim($m[0], '/');
    else $u = '/' . ltrim($u, '/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}
// Para inputs date (evita '0000-00-00' rotos)
function input_date(?string $d): string {
  $d = trim((string)$d);
  if ($d === '' || $d === '0000-00-00') return '';
  if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $d)) return '';
  return $d;
}

// ===== DB & CSRF
$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ==========================================================
   HANDSHAKE SEGURO DESDE gestionar_reticulas.php
   - Recibe POST { csrf, go_edit=1, token } generado por mint_edit_token
   - Valida token de sesión y deja $_SESSION['edit_reticula_id']
   ========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['go_edit'])) {
  $postCsrf = (string)($_POST['csrf'] ?? '');
  $token    = (string)($_POST['token'] ?? '');
  if (!hash_equals($CSRF, $postCsrf)) { http_response_code(400); echo "CSRF inválido."; exit; }

  $bag = $_SESSION['edit_reticula_tokens'] ?? [];
  $entry = $bag[$token] ?? null;

  if (!$entry || !is_array($entry)) { http_response_code(400); echo "Token inválido."; exit; }
  if (($entry['exp'] ?? 0) < time()) { unset($_SESSION['edit_reticula_tokens'][$token]); http_response_code(400); echo "Token expirado."; exit; }

  $ridToken = (int)($entry['id'] ?? 0);
  if ($ridToken <= 0) { http_response_code(400); echo "ID inválido."; exit; }

  // Verifica que exista en BD
  $chk = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE id=:id");
  $chk->execute([':id'=>$ridToken]);
  if ((int)$chk->fetchColumn() === 0) { unset($_SESSION['edit_reticula_tokens'][$token]); http_response_code(404); echo "Retícula no encontrada."; exit; }

  // Single-use
  unset($_SESSION['edit_reticula_tokens'][$token]);
  $_SESSION['edit_reticula_id'] = $ridToken;

  // Redirige a sí mismo sin parámetros (no exponemos ID)
  redirect(base_url('admin/editar_reticula.php'));
  exit;
}

/* (Opcional) Compatibilidad con flujos viejos: POST open=reticula & rid */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['open'] ?? '') === 'reticula') {
  $postCsrf = (string)($_POST['csrf'] ?? '');
  $ridPost  = (int)($_POST['rid'] ?? 0);
  if (!hash_equals($CSRF, $postCsrf)) { http_response_code(400); echo "CSRF inválido."; exit; }
  if ($ridPost <= 0) { http_response_code(400); echo "ID inválido."; exit; }
  $chk = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE id=:id");
  $chk->execute([':id'=>$ridPost]);
  if ((int)$chk->fetchColumn() === 0) { http_response_code(404); echo "Retícula no encontrada."; exit; }
  $_SESSION['edit_reticula_id'] = $ridPost;
  redirect(base_url('admin/editar_reticula.php')); exit;
}

/* ==========================================================
   Obtener ID para edición (sesión preferente; GET de respaldo)
   ========================================================== */
$rid = (int)($_SESSION['edit_reticula_id'] ?? 0);
if ($rid <= 0) {
  $rid = (int)($_GET['id'] ?? 0); // respaldo (no recomendado)
  if ($rid > 0) { $_SESSION['edit_reticula_id'] = $rid; }
}
if ($rid <= 0) {
  http_response_code(400);
  echo '<!doctype html><meta charset="utf-8"><title>Falta ID</title>
        <div style="font-family:system-ui,Arial;padding:20px">
          <h2>Falta el identificador de retícula</h2>
          <p>Vuelve al listado y elige “Editar”.</p>
          <p><a href="'.esc(base_url('admin/gestionar_reticulas.php')).'">Regresar al listado</a></p>
        </div>';
  exit;
}

/* ==========================================================
   AJAX: check_clave (unicidad)
   ========================================================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'check_clave') {
  header('Content-Type: application/json; charset=utf-8');
  $clave = trim((string)($_GET['c'] ?? ''));
  $id    = (int)($_GET['id'] ?? $rid);
  $ok=false; $avail=false;
  if ($clave !== '' && mb_strlen($clave) >= 3) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE clave=:c AND id<>:id");
    $st->execute([':c'=>$clave, ':id'=>$id]);
    $avail = ((int)$st->fetchColumn() === 0);
    $ok = true;
  }
  echo json_encode(['ok'=>$ok,'avail'=>$avail], JSON_UNESCAPED_UNICODE);
  exit;
}

/* ==========================================================
   AJAX: delete (verifica dependencias)
   ========================================================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
  header('Content-Type: application/json; charset=utf-8');
  $csrf = (string)($_POST['csrf'] ?? '');
  $id   = (int)($_POST['id'] ?? 0);

  if (!hash_equals($CSRF, $csrf)) { echo json_encode(['ok'=>false,'msg'=>'CSRF inválido']); exit; }
  if ($id !== $rid || $id <= 0)   { echo json_encode(['ok'=>false,'msg'=>'ID inválido']); exit; }

  try {
    $st = $pdo->prepare("SELECT COUNT(*) FROM reticula_materias WHERE reticula_id=:id");
    $st->execute([':id'=>$id]);
    if ((int)$st->fetchColumn() > 0) {
      echo json_encode(['ok'=>false,'msg'=>'No se puede eliminar: hay materias asociadas a esta retícula.']); exit;
    }

    $pdo->beginTransaction();
    $pdo->prepare("DELETE FROM reticulas WHERE id=:id")->execute([':id'=>$id]);

    try{
      $ev = $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('reticula', :ref, :desc)");
      $ev->execute([':ref'=> (string)$id, ':desc'=>'Retícula eliminada']);
    } catch(Throwable $e){}

    $pdo->commit();
    unset($_SESSION['edit_reticula_id']);
    echo json_encode(['ok'=>true]);
  } catch(Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['ok'=>false,'msg'=>'No se pudo eliminar la retícula.']);
  }
  exit;
}

/* ==========================================================
   Cargar retícula
   ========================================================== */
$st = $pdo->prepare("
  SELECT r.id, r.carrera_id, r.clave, r.nombre, r.vigente_desde, r.vigente_hasta,
         c.nombre AS carrera_nombre, c.clave AS carrera_clave
  FROM reticulas r
  LEFT JOIN carreras c ON c.id = r.carrera_id
  WHERE r.id = :id
  LIMIT 1
");
$st->execute([':id'=>$rid]);
$reticula = $st->fetch(PDO::FETCH_ASSOC);
if (!$reticula) { http_response_code(404); echo "Retícula no encontrada."; exit; }

/* ==========================================================
   Cargar carreras
   ========================================================== */
$carreras = [];
try {
  $rs = $pdo->query("SELECT id, clave, nombre FROM carreras ORDER BY nombre ASC");
  $carreras = $rs->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch(Throwable $e){ $carreras = []; }

/* ==========================================================
   POST: guardar cambios
   ========================================================== */
$errors = [];
$flash  = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'reticula') {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido. Refresca la página.';
  }

  $values = [
    'carrera_id'    => (string)($_POST['carrera_id'] ?? ''),
    'clave'         => trim((string)($_POST['clave'] ?? '')),
    'nombre'        => trim((string)($_POST['nombre'] ?? '')),
    'vigente_desde' => trim((string)($_POST['vigente_desde'] ?? '')),
    'vigente_hasta' => trim((string)($_POST['vigente_hasta'] ?? '')),
  ];

  $carrera_id = (int)$values['carrera_id'];
  if ($carrera_id <= 0) $errors[] = 'Selecciona una carrera.';

  if ($values['clave']==='' || mb_strlen($values['clave'])<3) $errors[] = 'La clave debe tener al menos 3 caracteres.';
  if ($values['nombre']==='' || mb_strlen($values['nombre'])<3) $errors[] = 'El nombre debe tener al menos 3 caracteres.';
  if ($values['vigente_desde']==='') $errors[] = '“Vigente desde” es obligatorio.';

  $desde = null; $hasta = null;
  if ($values['vigente_desde']!=='') {
    try { $desde = new DateTime($values['vigente_desde']); }
    catch(Throwable $e){ $errors[]='Fecha “Vigente desde” inválida.'; }
  }
  if ($values['vigente_hasta']!=='') {
    try { $hasta = new DateTime($values['vigente_hasta']); }
    catch(Throwable $e){ $errors[]='Fecha “Vigente hasta” inválida.'; }
  }
  if ($desde && $hasta && $hasta < $desde) $errors[] = '“Vigente hasta” no puede ser anterior a “Vigente desde”.';

  // Carrera existe
  if (!$errors) {
    $stC = $pdo->prepare("SELECT COUNT(*) FROM carreras WHERE id=:id");
    $stC->execute([':id'=>$carrera_id]);
    if ((int)$stC->fetchColumn()===0) $errors[] = 'La carrera seleccionada no existe.';
  }

  // Clave única (excluye la actual)
  if (!$errors) {
    $stU = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE clave=:c AND id<>:id");
    $stU->execute([':c'=>$values['clave'], ':id'=>$rid]);
    if ((int)$stU->fetchColumn()>0) $errors[] = 'Ya existe una retícula con esa clave.';
  }

  if (!$errors) {
    try {
      $pdo->beginTransaction();
      $upd = $pdo->prepare("
        UPDATE reticulas
        SET carrera_id=:car, clave=:cl, nombre=:nm,
            vigente_desde=:vd, vigente_hasta=:vh
        WHERE id=:id
      ");
      $upd->execute([
        ':car'=>$carrera_id,
        ':cl'=>$values['clave'],
        ':nm'=>$values['nombre'],
        ':vd'=>$desde?->format('Y-m-d'),
        ':vh'=>$hasta?->format('Y-m-d'),
        ':id'=>$rid,
      ]);

      try{
        $ev = $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('reticula', :ref, :desc)");
        $ev->execute([':ref'=>$values['clave'], ':desc'=>'Retícula actualizada: '.$values['nombre']]);
      } catch(Throwable $e){}

      $pdo->commit();
      redirect(base_url('admin/gestionar_reticulas.php?ok=upd'));
      exit;
    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al guardar los cambios.';
    }
  }

  // Rehidratar valores en memoria si hubo errores
  if ($errors) {
    $reticula['carrera_id']     = $carrera_id;
    $reticula['clave']          = $values['clave'];
    $reticula['nombre']         = $values['nombre'];
    $reticula['vigente_desde']  = $values['vigente_desde'];
    $reticula['vigente_hasta']  = $values['vigente_hasta'];
  }
}

/* ==========================================================
   Datos para header/menú
   ========================================================== */
$active   = 'reticulas';
$title    = 'ITZ KnowLink - Administrador · Editar Retícula';
$h1       = 'Editar retícula';
$subtitle = 'Actualiza la información base de la retícula';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// Header
require __DIR__ . '/partials/header.php';
?>
<style>
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px}
  input[type="text"],input[type="date"],select{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .hint{font-size:12px;color:#6b7280}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  a.btn.ghost.btn-icon{ text-decoration:none; }
  a.btn.ghost.btn-icon:hover, a.btn.ghost.btn-icon:focus{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }

  .flash{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:14px}
  .flash.ok{background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46}
  .flash.error{background:#fff1f0;border:1px solid #f5c2c7;color:#7a0021}

  .avail{display:inline-flex;gap:10px;align-items:center;padding:6px 10px;border-radius:10px;border:1px solid #e6eef2;background:#f3f6f9;font-weight:700;margin-top:6px}
  .avail.ok{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;color:#065f46}
  .avail.bad{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .danger-zone{ border:1px solid #fecaca; background:#fff1f0; color:#7a0021; }
  .danger-zone h3{ font-size:16px; margin-bottom:6px; }
  .danger-zone p{ font-size:14px; color:#7a0021; }
  .danger-actions{ display:flex; justify-content:flex-end; margin-top:10px; }
  .danger-actions .btn.danger{ background:#fee2e2; color:#991b1b; border:1px solid #fecaca; }
  .danger-actions .btn.danger:hover{ filter:brightness(.98); transform: translateY(-1px); }

  /* Modal */
  .modal{ position:fixed; inset:0; display:none; align-items:center; justify-content:center; z-index:2000; }
  .modal.open{ display:flex; }
  .modal .backdrop{ position:absolute; inset:0; background:rgba(2,6,23,.45); }
  .modal .dialog{
    position:relative; z-index:1; width:min(520px, calc(100% - 32px));
    background:#fff; border-radius:12px; box-shadow:0 18px 44px rgba(2,6,23,.22); padding:16px;
    border:1px solid #e6eef2;
  }
  .modal h4{ font-size:18px; margin-bottom:8px; color:#7a0021; }
  .modal p{ font-size:14px; color:#334155; margin-bottom:10px; }
  .modal .footer{ display:flex; justify-content:flex-end; gap:8px; margin-top:12px; }
</style>

<div class="page-header" style="display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px">
  <div>
    <div class="page-title">Editar retícula</div>
    <div class="page-sub">Actualiza la información base de la retícula</div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($flash)): ?>
  <div class="flash <?= $flash['type']==='ok' ? 'ok':'error' ?>"><?= esc($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
  <div class="flash error"><strong>Revisa lo siguiente:</strong>
    <ul style="margin-top:6px; padding-left:18px;">
      <?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?>
    </ul>
  </div>
<?php endif; ?>

<section class="card">
  <form method="post" novalidate>
    <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
    <input type="hidden" name="form" value="reticula">

    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de la retícula</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Carrera</span>
        <select name="carrera_id" required>
          <option value="">— Selecciona —</option>
          <?php foreach($carreras as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((int)$reticula['carrera_id']===(int)$c['id']?'selected':'') ?>>
              <?= esc($c['nombre'].' ('.$c['clave'].')') ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Obligatorio</div>
      </label>

      <label class="field">
        <span class="label">Clave de retícula</span>
        <input type="text" name="clave" id="clave" required minlength="3" placeholder="Ej. R2025-ICI"
               value="<?= esc($reticula['clave'] ?? '') ?>" autocomplete="off">
        <div id="claveAvail" class="avail" style="display:none;"></div>
        <div class="hint">Debe ser única</div>
      </label>

      <label class="field" style="grid-column:1/-1;">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" required minlength="3" placeholder="Ej. Retícula 2025 Ingeniería Civil"
               value="<?= esc($reticula['nombre'] ?? '') ?>">
      </label>

      <label class="field">
        <span class="label">Vigente desde</span>
        <input type="date" name="vigente_desde" required
               value="<?= esc(input_date($reticula['vigente_desde'] ?? '')) ?>">
        <div class="hint">Obligatorio</div>
      </label>

      <label class="field">
        <span class="label">Vigente hasta (opcional)</span>
        <input type="date" name="vigente_hasta"
               value="<?= esc(input_date($reticula['vigente_hasta'] ?? '')) ?>">
        <div class="hint">Debe ser igual o posterior a “desde”</div>
      </label>
    </div>

    <div style="display:flex;gap:8px;align-items:center;margin-top:12px;flex-wrap:wrap;">
      <button class="btn primary btn-icon" type="submit">
        <i class="fas fa-save"></i> <span class="label">Guardar cambios</span>
      </button>
      <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
        <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
      </a>
    </div>
  </form>
</section>

<!-- Zona peligrosa -->
<section class="card danger-zone" aria-label="Zona peligrosa">
  <h3><i class="fas fa-skull-crossbones"></i> Eliminar retícula</h3>
  <p>Eliminar la retícula <strong><?= esc(($reticula['nombre'] ?? '').' ('.$reticula['clave'].')') ?></strong> es una acción permanente.</p>
  <div class="danger-actions">
    <button id="btnDelete" class="btn danger btn-icon" type="button">
      <i class="fas fa-trash"></i> <span class="label">Eliminar retícula</span>
    </button>
  </div>
</section>

<!-- Modal eliminar -->
<div id="delModal" class="modal" role="dialog" aria-modal="true" aria-labelledby="delTitle" aria-hidden="true">
  <div class="backdrop"></div>
  <div class="dialog">
    <h4 id="delTitle"><i class="fas fa-triangle-exclamation"></i> Confirmar eliminación</h4>
    <p>Esta acción no se puede deshacer. ¿Deseas eliminar definitivamente la retícula?</p>
    <div class="footer">
      <button type="button" class="btn ghost" id="cancelDel">Cancelar</button>
      <button type="button" class="btn danger" id="confirmDel">
        <i class="fas fa-trash"></i> Eliminar definitivamente
      </button>
    </div>
  </div>
</div>

<script>
(function(){
  // Disponibilidad de clave
  const clave   = document.getElementById('clave');
  const box     = document.getElementById('claveAvail');
  const RID     = <?= (int)$rid ?>;

  function show(text, cls, icon){
    box.style.display='inline-flex';
    box.className='avail ' + (cls||'');
    box.innerHTML = (icon ? `<i class="fas ${icon}"></i> ` : '') + text;
  }
  function hide(){ box.style.display='none'; }

  async function checkClave(spin=true){
    const v=(clave.value||'').trim();
    if(!v){ hide(); return; }
    if(v.length<3){ show('Mínimo 3 caracteres','', 'fa-info-circle'); return; }
    if (spin) show('Comprobando…','', 'fa-circle-notch fa-spin');
    try{
      const res = await fetch('?ajax=check_clave&id='+encodeURIComponent(RID)+'&c='+encodeURIComponent(v), {cache:'no-store'});
      const data = await res.json();
      if (data.ok && data.avail){ show('Disponible ✓','ok','fa-check-circle'); }
      else { show('Ya está en uso ✗','bad','fa-times-circle'); }
    }catch(e){ show('Intenta de nuevo','', 'fa-info-circle'); }
  }
  let t=null;
  clave?.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=>checkClave(true), 300); });
  document.addEventListener('DOMContentLoaded', ()=>{ const v=(clave?.value||'').trim(); if(v.length>=3){ checkClave(false); } });

  // Eliminar con modal
  const delBtn   = document.getElementById('btnDelete');
  const modal    = document.getElementById('delModal');
  const btnOK    = document.getElementById('confirmDel');
  const btnCancel= document.getElementById('cancelDel');
  const CSRF     = <?= json_encode($CSRF) ?>;
  const backUrl  = <?= json_encode(base_url('admin/gestionar_reticulas.php'), JSON_UNESCAPED_SLASHES) ?>;

  function openModal(){ modal.classList.add('open'); modal.setAttribute('aria-hidden','false'); btnOK.disabled=false; }
  function closeModal(){ modal.classList.remove('open'); modal.setAttribute('aria-hidden','true'); }

  delBtn?.addEventListener('click', openModal);
  btnCancel?.addEventListener('click', closeModal);
  modal.querySelector('.backdrop')?.addEventListener('click', closeModal);
  document.addEventListener('keydown', (e)=>{ if(e.key==='Escape') closeModal(); });

  btnOK?.addEventListener('click', async ()=>{
    btnOK.disabled = true;
    btnOK.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando…';
    try{
      const form = new URLSearchParams({ ajax:'delete', id:String(RID), csrf:CSRF });
      const res = await fetch('?ajax=delete', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: form
      });
      const data = await res.json();
      if (!data.ok) {
        alert(data.msg || 'No se pudo eliminar.');
        btnOK.disabled = false;
        btnOK.innerHTML = '<i class="fas fa-trash"></i> Eliminar definitivamente';
        return;
      }
      window.location.href = backUrl + '?ok=del';
    }catch(e){
      alert('Error inesperado al eliminar.');
      btnOK.disabled = false;
      btnOK.innerHTML = '<i class="fas fa-trash"></i> Eliminar definitivamente';
    }
  });
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
