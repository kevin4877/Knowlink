<?php
// public/admin/gestionar_docentes.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$usuario = auth_user();
if (!$usuario) { redirect(base_url('login.php')); exit; }
if (($usuario['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Cabeceras de seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Placeholder SVG por defecto
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}

/**
 * foto_src: normaliza a URL web ABSOLUTA para <img src="...">
 * Acepta: /uploads/avatars/... | uploads/avatars/... | ../uploads/avatars/... | http(s)://... | data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || strncmp($u, 'data:', 5) === 0) return $u;
    while (strncmp($u, '../', 3) === 0) { $u = substr($u, 3); }
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/'); // /uploads/avatars/...
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* =================== AJAX: abrir edición sin ?id =================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['ajax'] ?? '') === 'open')) {
  header('Content-Type: application/json; charset=utf-8');
  if (!hash_equals($CSRF, (string)$_POST['csrf'])) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'CSRF inválido.'], JSON_UNESCAPED_UNICODE);
    exit;
  }
  $id = max(0, (int)($_POST['id'] ?? 0));
  if ($id <= 0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'ID inválido.'], JSON_UNESCAPED_UNICODE); exit; }
  $st = $pdo->prepare("SELECT id FROM usuarios WHERE id=:id AND rol='docente' LIMIT 1");
  $st->execute([':id'=>$id]);
  if (!$st->fetchColumn()) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Docente no encontrado.'], JSON_UNESCAPED_UNICODE); exit; }
  $_SESSION['edit_docente_id'] = $id;
  echo json_encode(['ok'=>true], JSON_UNESCAPED_UNICODE);
  exit;
}

/* =================== AJAX: eliminar docente =================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['ajax'] ?? '') === 'delete')) {
  header('Content-Type: application/json; charset=utf-8');
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    http_response_code(400);
    echo json_encode(['ok'=>false,'error'=>'La sesión expiró. Recarga la página e intenta de nuevo.'], JSON_UNESCAPED_UNICODE);
    exit;
  }
  $id = max(0, (int)($_POST['id'] ?? 0));
  if ($id <= 0) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'ID inválido.'], JSON_UNESCAPED_UNICODE); exit; }

  $st = $pdo->prepare("SELECT id, nombre, apellidos FROM usuarios WHERE id=:id AND rol='docente' LIMIT 1");
  $st->execute([':id'=>$id]);
  $docente = $st->fetch(PDO::FETCH_ASSOC);
  if (!$docente) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Docente no encontrado o ya eliminado.'], JSON_UNESCAPED_UNICODE); exit; }

  try {
    $pdo->beginTransaction();

    // Limpieza preventiva para instalaciones donde algunas notificaciones no tienen FK activa.
    $pdo->prepare("DELETE FROM docente_notifs WHERE docente_id=:id")->execute([':id'=>$id]);

    // Primero eliminamos el perfil docente para activar cascadas de permisos/contenidos; luego la cuenta base.
    $pdo->prepare("DELETE FROM docentes WHERE usuario_id=:id")->execute([':id'=>$id]);

    $del = $pdo->prepare("DELETE FROM usuarios WHERE id=:id AND rol='docente'");
    $del->execute([':id'=>$id]);
    if ($del->rowCount() < 1) { throw new RuntimeException('No se eliminó ningún registro.'); }

    if (isset($_SESSION['edit_docente_id']) && (int)$_SESSION['edit_docente_id'] === $id) {
      unset($_SESSION['edit_docente_id']);
    }

    $pdo->commit();
    echo json_encode(['ok'=>true,'msg'=>'Docente eliminado correctamente.'], JSON_UNESCAPED_UNICODE);
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    http_response_code(500);
    echo json_encode(['ok'=>false,'error'=>'No se pudo eliminar el docente. Revisa si tiene información relacionada o intenta más tarde.'], JSON_UNESCAPED_UNICODE);
  }
  exit;
}

/* =================== AJAX: listado/búsqueda =================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'search') {
  header('Content-Type: application/json; charset=utf-8');

  $q        = trim((string)($_GET['q'] ?? ''));
  $materia  = trim((string)($_GET['materia'] ?? ''));
  $page     = max(1, (int)($_GET['page'] ?? 1));
  $perPage  = min(50, max(5, (int)($_GET['perPage'] ?? 20)));
  $off      = ($page - 1) * $perPage;

  $where   = ["u.rol = 'docente'"];
  $params  = [];

  if ($q !== '') {
    $where[] = "(u.nombre LIKE :q OR u.apellidos LIKE :q OR u.username LIKE :q OR u.email LIKE :q)";
    $params[':q'] = '%'.$q.'%';
  }
  if ($materia !== '') {
    $where[] = "EXISTS (
      SELECT 1
      FROM docente_permisos_materia dpm
      LEFT JOIN materias m ON LOWER(m.clave) = LOWER(dpm.materia_clave)
      WHERE dpm.docente_id = u.id
        AND (dpm.materia_clave LIKE :mat OR m.nombre LIKE :mat)
    )";
    $params[':mat'] = '%'.$materia.'%';
  }
  $whereSql = 'WHERE '.implode(' AND ', $where);

  $sqlCount = "SELECT COUNT(*) FROM usuarios u $whereSql";
  $st = $pdo->prepare($sqlCount);
  foreach ($params as $k=>$v) $st->bindValue($k, $v);
  $st->execute();
  $total = (int)$st->fetchColumn();

  $sql = "
    SELECT
      u.id, u.nombre, u.apellidos, u.username, u.email, u.foto_url, u.creado_en,
      COALESCE(p.cnt_perm, 0) AS permisos,
      COALESCE(c.cnt_cont, 0) AS contenidos
    FROM usuarios u
    LEFT JOIN (
      SELECT docente_id, COUNT(*) AS cnt_perm
      FROM docente_permisos_materia
      GROUP BY docente_id
    ) p ON p.docente_id = u.id
    LEFT JOIN (
      SELECT docente_id, COUNT(*) AS cnt_cont
      FROM contenidos
      GROUP BY docente_id
    ) c ON c.docente_id = u.id
    $whereSql
    ORDER BY u.creado_en DESC
    LIMIT :lim OFFSET :off
  ";
  $st = $pdo->prepare($sql);
  foreach ($params as $k=>$v) $st->bindValue($k, $v);
  $st->bindValue(':lim', $perPage, PDO::PARAM_INT);
  $st->bindValue(':off', $off, PDO::PARAM_INT);
  $st->execute();
  $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

  // Normaliza foto a URL absoluta y añade campo "foto"
  foreach ($rows as &$r) {
    $r['foto'] = foto_src($r['foto_url'] ?? null);
  } unset($r);

  echo json_encode(['ok'=>true,'total'=>$total,'page'=>$page,'perPage'=>$perPage,'rows'=>$rows], JSON_UNESCAPED_UNICODE);
  exit;
}

/* =================== Flash (toasts) =================== */
$flash = null;
if (isset($_GET['ok'])) {
  $map = ['1'=>'Docente registrado correctamente.','upd'=>'Docente actualizado correctamente.'];
  $flash = ['type'=>'ok','msg'=>$map[$_GET['ok']] ?? 'Operación realizada.'];
}
if (isset($_GET['err'])) {
  $flash = ['type'=>'err','msg'=>trim((string)$_GET['err']) ?: 'Ocurrió un error.'];
}

/* =================== META para el header (compat layer) =================== */
$PAGE_TITLE   = 'ITZ KnowLink - Administrador · Gestionar Docentes';
$ACTIVE_MENU  = 'docentes';
$HEADER_TITLE = 'Gestionar docentes';
$HEADER_SUB   = 'Busca o edita docentes registrados';

/* Alias por compatibilidad */
$page_title     = $PAGE_TITLE;
$page_h1        = $HEADER_TITLE;
$page_subtitle  = $HEADER_SUB;
$MENU_ACTIVE    = $ACTIVE_MENU;
$menu_active    = $ACTIVE_MENU;
$activeMenu     = $ACTIVE_MENU;
$TITLE          = $HEADER_TITLE;

/* Contexto agrupado */
$VIEW = [
  'title'  => $PAGE_TITLE,
  'h1'     => $HEADER_TITLE,
  'sub'    => $HEADER_SUB,
  'active' => $ACTIVE_MENU,
];

$yo        = $usuario;                      // el header usa $yo
$yo['foto'] = foto_src($yo['foto_url'] ?? null); // asegura avatar normalizado en el header

require __DIR__ . '/partials/header.php';
?>

<!-- ====== CSS DEL DISEÑO ANTERIOR (scopeado) ====== -->
<style>
  aside.sidebar a.active{
    background: linear-gradient(90deg, rgba(0,85,212,.08), rgba(0,85,212,.04));
    color: var(--accent, #0055d4);
  }
  #docentesPage .card{ background:#fff; border-radius:12px; padding:16px; box-shadow:0 10px 30px rgba(2,6,23,.06); margin-bottom:16px; }
  #docentesPage .tools{ display:flex; gap:10px; align-items:center; flex-wrap:wrap; justify-content:space-between; }
  #docentesPage .tools .field{ display:flex; }
  #docentesPage .tools .field input,
  #docentesPage .tools .field select{ padding:10px 12px; border-radius:10px; border:1px solid #e6eef2; background:#fff; font-size:14px; outline:none; min-width:240px; }
  #docentesPage .btn{ padding:10px 14px; border-radius:10px; background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; border:none; cursor:pointer; font-weight:800; }
  #docentesPage .btn.ghost{ background:#fff; color:#0b2545; border:1px solid #e6eef2; }
  #docentesPage a.btn.ghost{ text-decoration:none; }
  #docentesPage .btn-icon .label{ display:inline; margin-left:6px; }
  #docentesPage .table{ width:100%; border-collapse:collapse; table-layout:fixed; }
  #docentesPage .table th, #docentesPage .table td{ padding:10px; border-bottom:1px dashed #eef3f6; text-align:left; font-size:14px; vertical-align:middle; min-width:0; }
  #docentesPage .table th{ font-size:13px; color:#6b7280; }
  #docentesPage col.c-docente{ width:36%; } #docentesPage col.c-correo{ width:28%; } #docentesPage col.c-permisos{ width:9%; } #docentesPage col.c-contenidos{ width:9%; } #docentesPage col.c-actions{ width:18%; }
  #docentesPage .avatar{ width:40px; height:40px; border-radius:999px; object-fit:cover; background:#f3f6f9; flex:0 0 auto; }
  #docentesPage .docente-cell{ display:flex; align-items:center; gap:10px; min-width:0; }
  #docentesPage .docente-cell .nm{ font-weight:800; color:#0b2545; }
  #docentesPage .docente-cell .sub{ font-size:12px; color:#6b7280; }
  #docentesPage .td-email{ white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
  #docentesPage .td-mini{ white-space:nowrap; }
  #docentesPage .chip{ display:inline-flex; align-items:center; gap:6px; padding:3px 6px; border-radius:999px; border:1px solid #e2ebff; background:#f1f5ff; color:#0055d4; font-size:12px; line-height:1; }
  #docentesPage .chip.gray{ background:#f3f4f6; border-color:#e5e7eb; color:#374151; }
  #docentesPage .actions{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; }
  #docentesPage .actions a, #docentesPage .actions button{ display:inline-flex; align-items:center; gap:6px; padding:8px 10px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; font-size:13px; text-decoration:none; color:#0b2545; }
  #docentesPage .actions a:hover, #docentesPage .actions button:hover{ background:#f5f8ff; color:var(--accent,#0055d4); transform: translateY(-1px); }
  #docentesPage .actions .btn-delete{ border-color:#fecaca; color:#b91c1c; background:#fff5f5; }
  #docentesPage .actions .btn-delete:hover{ background:#fee2e2; color:#991b1b; }
  #docentesPage .confirm-overlay{ position:fixed; inset:0; z-index:2400; display:flex; align-items:center; justify-content:center; padding:18px; background:rgba(15,23,42,.46); backdrop-filter:blur(8px); }
  #docentesPage .confirm-overlay[hidden]{ display:none !important; }
  #docentesPage .confirm-card{ width:min(440px,100%); border-radius:20px; padding:20px; background:#fff; color:#0f172a; box-shadow:0 24px 70px rgba(2,6,23,.28); border:1px solid rgba(148,163,184,.22); animation:confirmIn .14s ease-out; }
  @keyframes confirmIn{ from{opacity:0; transform:translateY(10px) scale(.98);} to{opacity:1; transform:translateY(0) scale(1);} }
  #docentesPage .confirm-icon{ width:46px; height:46px; border-radius:16px; display:grid; place-items:center; background:#fee2e2; color:#b91c1c; font-size:20px; margin-bottom:12px; }
  #docentesPage .confirm-title{ font-size:18px; font-weight:900; margin-bottom:6px; }
  #docentesPage .confirm-text{ color:#475569; line-height:1.45; font-size:14px; margin-bottom:16px; }
  #docentesPage .confirm-actions{ display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap; }
  #docentesPage .confirm-actions button{ border:0; border-radius:12px; padding:10px 14px; font-weight:800; cursor:pointer; }
  #docentesPage .confirm-actions .cancel{ background:#f1f5f9; color:#0f172a; }
  #docentesPage .confirm-actions .danger{ background:linear-gradient(135deg,#dc2626,#991b1b); color:#fff; }
  #docentesPage .confirm-actions button:disabled{ opacity:.65; cursor:not-allowed; }

  html[data-theme="dark"] #docentesPage .card{ background:#0f172a; border-color:rgba(148,163,184,.22); color:#e5edf7; }
  html[data-theme="dark"] #docentesPage .tools .field input,
  html[data-theme="dark"] #docentesPage .tools .field select{ background:#111827; border-color:rgba(148,163,184,.24); color:#f8fafc; }
  html[data-theme="dark"] #docentesPage .table th,
  html[data-theme="dark"] #docentesPage .muted{ color:#94a3b8; }
  html[data-theme="dark"] #docentesPage .table th,
  html[data-theme="dark"] #docentesPage .table td{ border-bottom-color:rgba(148,163,184,.18); }
  html[data-theme="dark"] #docentesPage .docente-cell .nm{ color:#f8fafc; }
  html[data-theme="dark"] #docentesPage .docente-cell .sub{ color:#94a3b8; }
  html[data-theme="dark"] #docentesPage .actions a,
  html[data-theme="dark"] #docentesPage .actions button,
  html[data-theme="dark"] #docentesPage .pager button,
  html[data-theme="dark"] #docentesPage .btn.ghost{ background:#111827; color:#e5edf7; border-color:rgba(148,163,184,.24); }
  html[data-theme="dark"] #docentesPage .actions a:hover,
  html[data-theme="dark"] #docentesPage .actions button:hover{ background:#172033; color:#67e8f9; }
  html[data-theme="dark"] #docentesPage .confirm-card{ background:#111827; color:#f8fafc; border-color:rgba(148,163,184,.18); }
  html[data-theme="dark"] #docentesPage .confirm-text{ color:#cbd5e1; }
  html[data-theme="dark"] #docentesPage .confirm-actions .cancel{ background:#1f2937; color:#e5e7eb; }
  html[data-theme="dark"] #docentesPage .actions .btn-delete{ background:rgba(127,29,29,.20); color:#fecaca; border-color:rgba(248,113,113,.35); }
  html[data-theme="dark"] #docentesPage .actions .btn-delete:hover{ background:rgba(127,29,29,.38); color:#fff; }
  #docentesPage .pager{ margin-top:12px; display:flex; gap:10px; align-items:center; }
  #docentesPage .pager button{ padding:8px 12px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; }
  #docentesPage .muted{ color:#6b7280; }
  #docentesPage .center{ text-align:center; }
  #docentesPage .error{ color:#b91c1c; }
  @media (max-width:1200px){ #docentesPage col.c-correo{ width:24%; } #docentesPage col.c-docente{ width:38%; } }
  @media (max-width:1100px){ #docentesPage .actions a .label, #docentesPage .actions button .label{ display:none; } #docentesPage .actions a, #docentesPage .actions button{ padding:8px; } }
  @media (max-width:999px){
    #docentesPage .tools .field input, #docentesPage .tools .field select{ width:100%; min-width:0 !important; }
    #docentesPage .table thead th{ font-size:12px; } #docentesPage .table tbody td{ font-size:13px; }
  }
  /* En celular y tablet la tabla se transforma en tarjetas para que no se corte ni se encime. */
  @media (max-width:900px){
    #docentesPage .page-header{ align-items:flex-start; gap:12px; }
    #docentesPage .page-header > div:last-child{ width:100%; }
    #docentesPage .page-header .btn{ width:100%; justify-content:center; }
    #docentesPage .btn-icon .label{ display:inline; }
    #docentesPage .tools{ display:grid; grid-template-columns:1fr; gap:10px; align-items:stretch; }
    #docentesPage .tools .tools{ display:grid; grid-template-columns:1fr; width:100%; }
    #docentesPage .tools .field, #docentesPage .tools .field input, #docentesPage .tools .field select{ width:100%; min-width:0 !important; }
    #docentesPage .table thead, #docentesPage .table colgroup{ display:none; }
    #docentesPage .table{ border-collapse:separate; border-spacing:0 12px; table-layout:auto; width:100%; }
    #docentesPage .table tbody tr{ display:block; background:#fff; border:1px solid #e6eef2; border-radius:16px; padding:14px; box-shadow:0 12px 28px rgba(2,6,23,.06); }
    #docentesPage .table tbody td{ display:block; width:100%; border-bottom:0; padding:7px 0; }
    #docentesPage .table tbody td + td{ margin-top:4px; }
    #docentesPage .docente-cell{ align-items:flex-start; }
    #docentesPage .docente-cell .nm{ font-size:15px; line-height:1.25; }
    #docentesPage .td-email{ display:block !important; white-space:normal; overflow-wrap:anywhere; word-break:break-word; color:#475569; }
    #docentesPage .td-email::before,
    #docentesPage .td-mini::before{ content:attr(data-label); display:block; font-size:11px; text-transform:uppercase; letter-spacing:.04em; color:#64748b; font-weight:900; margin-bottom:4px; }
    #docentesPage .td-mini{ display:inline-flex; flex-direction:column; align-items:flex-start; gap:4px; margin-right:16px; width:auto; min-width:92px; }
    #docentesPage .chip{ font-size:12px; padding:5px 9px; }
    #docentesPage .table td.actions{ display:grid; grid-template-columns:1fr 1fr; gap:8px; margin-top:10px; padding-top:10px; border-top:1px dashed #e6eef2; }
    #docentesPage .table td.actions a,
    #docentesPage .table td.actions button{ justify-content:center; width:100%; padding:10px; }
    #docentesPage .table td.actions .label{ display:inline !important; }
    #docentesPage .pager{ justify-content:center; flex-wrap:wrap; }
    html[data-theme="dark"] #docentesPage .table tbody tr{ background:#0f172a; border-color:rgba(148,163,184,.22); box-shadow:0 12px 30px rgba(0,0,0,.28); }
    html[data-theme="dark"] #docentesPage .td-email{ color:#cbd5e1; }
    html[data-theme="dark"] #docentesPage .td-email::before,
    html[data-theme="dark"] #docentesPage .td-mini::before{ color:#94a3b8; }
    html[data-theme="dark"] #docentesPage .table td.actions{ border-top-color:rgba(148,163,184,.22); }
  }
  @media (max-width:480px){
    #docentesPage .table td.actions{ grid-template-columns:1fr; }
    #docentesPage .td-mini{ width:48%; margin-right:0; }
  }
</style>

<div id="docentesPage" class="content-inner">
  <div class="page-header">
    <div>
      <div class="page-title"><?= esc($HEADER_TITLE) ?></div>
      <div class="page-sub"><?= esc($HEADER_SUB) ?></div>
    </div>
    <div>
      <a class="btn btn-icon" href="<?= esc(base_url('admin/docente/registro_docente.php')) ?>">
        <i class="fas fa-user-plus"></i><span class="label"> Registrar docente</span>
      </a>
    </div>
  </div>

  <?php if (!empty($flash)): ?>
    <script>
      (function(){
        const f = <?= json_encode($flash, JSON_UNESCAPED_UNICODE) ?>;
        (window.showToast ? window.showToast : function(msg,isErr){ if(isErr){console.error(msg);}else{console.log(msg);} })(f.msg, f.type==='err');
        try{ const u=new URL(location.href); u.searchParams.delete('ok'); u.searchParams.delete('err'); history.replaceState({},'',u); }catch(e){}
      })();
    </script>
  <?php endif; ?>

  <!-- Filtros -->
  <section class="card" aria-label="Filtros de búsqueda">
    <div class="tools">
      <div class="tools" style="gap:8px;">
        <div class="field">
          <input type="text" id="q" placeholder="Buscar por nombre o correo" autocomplete="off" style="min-width:280px;">
        </div>
        <div class="field">
          <input type="text" id="materia" placeholder="Filtrar por materia (clave o nombre)" autocomplete="off" style="min-width:240px;">
        </div>
      </div>
      <div class="tools" style="gap:8px;">
        <div class="field">
          <select id="perPage">
            <option value="10">10 por página</option>
            <option value="20" selected>20 por página</option>
            <option value="30">30 por página</option>
            <option value="50">50 por página</option>
          </select>
        </div>
        <button class="btn ghost btn-icon" id="btnClear" title="Limpiar filtros">
          <i class="fas fa-eraser"></i> <span class="label">Limpiar</span>
        </button>
      </div>
    </div>
  </section>

  <!-- Resultados -->
  <section class="card" aria-label="Resultados">
    <table class="table" id="tbl">
      <colgroup>
        <col class="c-docente"><col class="c-correo"><col class="c-permisos"><col class="c-contenidos"><col class="c-actions">
      </colgroup>
      <thead>
        <tr>
          <th>Docente</th>
          <th class="th-email">Correo</th>
          <th>Perm.</th>
          <th>Cont.</th>
          <th>Acciones</th>
        </tr>
      </thead>
      <tbody id="tbody">
        <tr><td colspan="5" class="muted center">Cargando…</td></tr>
      </tbody>
    </table>

    <div class="pager" id="pager">
      <button id="prev" disabled>&laquo; Anterior</button>
      <span class="muted" id="info">—</span>
      <button id="next" disabled>Siguiente &raquo;</button>
    </div>
  </section>

  <div id="confirmDeleteModal" class="confirm-overlay" hidden aria-hidden="true">
    <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirmDeleteTitle">
      <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
      <div id="confirmDeleteTitle" class="confirm-title">Eliminar docente</div>
      <div id="confirmDeleteText" class="confirm-text">
        Esta acción eliminará al docente seleccionado, sus permisos y los contenidos relacionados. No se puede deshacer.
      </div>
      <div class="confirm-actions">
        <button type="button" class="cancel" id="confirmDeleteCancel">Cancelar</button>
        <button type="button" class="danger" id="confirmDeleteAccept">Sí, eliminar</button>
      </div>
    </div>
  </div>
</div>

<script>
(function(){
  /* ====== ACTIVAR ELEMENTOS DEL HEADER/SIDEBAR (fallback) ====== */
  (function(){
    if (window.setActiveMenu) window.setActiveMenu('docentes');
    if (window.setPageTitles) window.setPageTitles('<?= esc($HEADER_TITLE) ?>','<?= esc($HEADER_SUB) ?>');
    const a = document.querySelector('aside.sidebar a[href$="gestionar_docentes.php"]');
    if (a) a.classList.add('active');
    if (!document.title || document.title.indexOf('Gestionar Docentes') === -1) {
      document.title = '<?= esc($PAGE_TITLE) ?>';
    }
  })();

  const CSRF = <?= json_encode($CSRF) ?>;
  const EDIT_URL = <?= json_encode(base_url('admin/editar_docente.php'), JSON_UNESCAPED_SLASHES) ?>;
  const PLACEHOLDER = <?= json_encode(foto_src(null), JSON_UNESCAPED_SLASHES) ?>;

  const q = document.getElementById('q');
  const materia = document.getElementById('materia');
  const perPage = document.getElementById('perPage');
  const btnClear = document.getElementById('btnClear');
  const tbody = document.getElementById('tbody');
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');
  const info = document.getElementById('info');
  const confirmDeleteModal = document.getElementById('confirmDeleteModal');
  const confirmDeleteText = document.getElementById('confirmDeleteText');
  const confirmDeleteCancel = document.getElementById('confirmDeleteCancel');
  const confirmDeleteAccept = document.getElementById('confirmDeleteAccept');
  let pendingDelete = null;

  let state = { page:1, total:0, perPage: parseInt(perPage.value,10)||20, q:'', materia:'', loading:false };

  function escapeH(str){ return String(str).replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&gt;','"':'&quot;',"'":'&#39;'}[s])); }
  function imgSrc(r){ return (r.foto && r.foto.trim()) ? r.foto : PLACEHOLDER; }
  function chip(n, icon){ n = parseInt(n||0,10); const gray = n<=0; return `<span class="chip ${gray?'gray':''}"><i class="fas ${icon}"></i> ${n>0?n:0}</span>`; }
  const chipPerm = (n)=>chip(n,'fa-key');
  const chipCont = (n)=>chip(n,'fa-file-alt');


  function notify(msg, isErr=false){
    if(window.showToast){ window.showToast(msg, isErr); return; }
    if(isErr) alert(msg); else console.log(msg);
  }

  function openDeleteModal(id, nombre){
    pendingDelete = { id, nombre };
    confirmDeleteText.innerHTML = `¿Seguro que deseas eliminar a <strong>${escapeH(nombre)}</strong>? También se eliminarán sus permisos y contenidos relacionados. Esta acción no se puede deshacer.`;
    confirmDeleteModal.hidden = false;
    confirmDeleteModal.setAttribute('aria-hidden','false');
    setTimeout(()=>confirmDeleteCancel.focus(), 20);
  }

  function closeDeleteModal(){
    pendingDelete = null;
    confirmDeleteModal.hidden = true;
    confirmDeleteModal.setAttribute('aria-hidden','true');
    confirmDeleteAccept.disabled = false;
    confirmDeleteAccept.innerHTML = 'Sí, eliminar';
  }

  async function deleteDocente(){
    if(!pendingDelete?.id) return;
    confirmDeleteAccept.disabled = true;
    confirmDeleteAccept.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
    try{
      const body = new URLSearchParams({ ajax:'delete', csrf:CSRF, id:String(pendingDelete.id) });
      const res = await fetch('', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
      const data = await res.json();
      if(!data.ok) throw new Error(data.error || data.msg || 'No se pudo eliminar el docente.');
      closeDeleteModal();
      notify(data.msg || 'Docente eliminado correctamente.');
      fetchData();
    }catch(err){
      confirmDeleteAccept.disabled = false;
      confirmDeleteAccept.innerHTML = 'Sí, eliminar';
      notify(String(err.message || err), true);
    }
  }

  function buildRow(r){
    const nombre = ((r.nombre||'')+' '+(r.apellidos||'')).trim() || ('Usuario #'+r.id);
    return `<tr>
      <td data-label="Docente">
        <div class="docente-cell">
          <img class="avatar" src="${escapeH(imgSrc(r))}" alt="avatar">
          <div>
            <div class="nm">${escapeH(nombre)}</div>
            <div class="sub">ID ${r.id}</div>
          </div>
        </div>
      </td>
      <td class="td-email" data-label="Correo">${escapeH(r.email||'')}</td>
      <td class="td-mini" data-label="Permisos">${chipPerm(r.permisos)}</td>
      <td class="td-mini" data-label="Contenidos">${chipCont(r.contenidos)}</td>
      <td class="actions" data-label="Acciones">
        <a href="#" class="btn-edit" data-id="${r.id}" role="button"><i class="fas fa-edit"></i> <span class="label">Editar</span></a>
        <button type="button" class="btn-delete" data-id="${r.id}" data-name="${escapeH(nombre)}"><i class="fas fa-trash-alt"></i> <span class="label">Eliminar</span></button>
      </td>
    </tr>`;
  }

  async function fetchData(){
    if(state.loading) return; state.loading=true;
    tbody.innerHTML = `<tr><td colspan="5" class="muted center">Cargando…</td></tr>`;
    try{
      const qs = new URLSearchParams({
        ajax:'search',
        q: state.q, materia: state.materia,
        page: String(state.page||1), perPage: String(state.perPage||20),
      });
      const res = await fetch('?' + qs.toString(), {cache:'no-store'});
      const data = await res.json();
      if(!data.ok) throw new Error('Respuesta inválida');

      state.total = data.total || 0;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length ? rows.map(buildRow).join('') :
        `<tr><td colspan="5" class="muted center">Sin resultados.</td></tr>`;

      const first = Math.min(state.total, ((state.page-1)*state.perPage)+1);
      const last  = Math.min(state.total, state.page*state.perPage);
      info.textContent = state.total ? `${first}–${last} de ${state.total}` : '0 resultados';
      prevBtn.disabled = (state.page<=1);
      nextBtn.disabled = (state.page*state.perPage >= state.total);
    } catch(e){
      tbody.innerHTML = `<tr><td colspan="5" class="error center">Error al cargar datos.</td></tr>`;
      info.textContent = '—'; prevBtn.disabled = true; nextBtn.disabled = true;
      (window.showToast ? window.showToast : console.error)(String(e.message||e), true);
    } finally {
      state.loading=false;
    }
  }

  function debounce(fn,ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
  const onChange = debounce(()=>{ state.page=1; fetchData(); }, 250);

  q.addEventListener('input', ()=>{ state.q = q.value.trim(); onChange(); });
  materia.addEventListener('input', ()=>{ state.materia = materia.value.trim(); onChange(); });
  perPage.addEventListener('change', ()=>{ state.perPage = parseInt(perPage.value,10)||20; state.page=1; fetchData(); });
  prevBtn.addEventListener('click', ()=>{ if(state.page>1){ state.page--; fetchData(); }});
  nextBtn.addEventListener('click', ()=>{ if(state.page*state.perPage < state.total){ state.page++; fetchData(); }});
  btnClear.addEventListener('click', (e)=>{
    e.preventDefault();
    q.value=''; materia.value=''; perPage.value='20';
    state={page:1,total:0,perPage:20,q:'',materia:'',loading:false};
    fetchData();
  });

  confirmDeleteCancel.addEventListener('click', closeDeleteModal);
  confirmDeleteAccept.addEventListener('click', deleteDocente);
  confirmDeleteModal.addEventListener('click', (ev)=>{ if(ev.target === confirmDeleteModal) closeDeleteModal(); });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && !confirmDeleteModal.hidden) closeDeleteModal(); });

  // Abrir edición / eliminar sin ?id
  tbody.addEventListener('click', async (ev)=>{
    const del = ev.target.closest('.btn-delete');
    if(del){
      ev.preventDefault();
      const id = parseInt(del.getAttribute('data-id'),10)||0;
      if(!id) return;
      openDeleteModal(id, del.getAttribute('data-name') || ('Docente #' + id));
      return;
    }

    const a = ev.target.closest('.btn-edit');
    if(!a) return;
    ev.preventDefault();
    const id = a.getAttribute('data-id');
    if(!id) return;

    try{
      const body = new URLSearchParams({ ajax:'open', csrf: CSRF, id: String(id) });
      const res = await fetch('', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body
      });
      const data = await res.json();
      if(!data.ok){ throw new Error(data.error || 'No se pudo abrir la edición'); }
      location.href = EDIT_URL;
    }catch(err){
      (window.showToast ? window.showToast : (m)=>alert(m))(String(err.message||err), true);
    }
  });

  fetchData();
})();
</script>

<?php require __DIR__ . '/partials/footer.php';
