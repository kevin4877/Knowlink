<?php
// public/admin/gestionar_alumnos.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Placeholder por defecto (data URI)
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}

/**
 * foto_src: normaliza a URL web ABSOLUTA lista para <img src="...">
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\', '/', $url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u;
    while (str_starts_with($u, '../')) { $u = substr($u, 3); }
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

// Polyfill PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();

/* ==========================================================
   POST: Ir a editar SIN exponer id en la URL (redirige)
   ========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'go_edit') {
  $csrf = (string)($_POST['csrf'] ?? '');
  if (!hash_equals($CSRF, $csrf)) { redirect(base_url('admin/gestionar_alumnos.php?err=csrf')); exit; }

  $id = (int)($_POST['id'] ?? 0);
  if ($id <= 0) { redirect(base_url('admin/gestionar_alumnos.php?err=id')); exit; }

  $st = $pdo->prepare("SELECT u.id FROM usuarios u WHERE u.id=:id AND u.rol='estudiante' LIMIT 1");
  $st->execute([':id'=>$id]);
  if (!(int)$st->fetchColumn()) { redirect(base_url('admin/gestionar_alumnos.php?err=nf')); exit; }

  $_SESSION['edit_alumno_id'] = $id;
  $_SESSION['edit_alumno_id_ts'] = time();
  redirect(base_url('admin/editar_alumno.php'));
  exit;
}


/* ==========================================================
   POST/AJAX: Eliminar alumno con validación y confirmación
   ========================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
  header('Content-Type: application/json; charset=utf-8');

  $fail = function(string $msg, int $code = 400){
    http_response_code($code);
    echo json_encode(['ok'=>false,'msg'=>$msg], JSON_UNESCAPED_UNICODE);
    exit;
  };
  $ok = function(array $data = []){
    $data['ok'] = true;
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
  };

  $csrf = (string)($_POST['csrf'] ?? '');
  if (!hash_equals($CSRF, $csrf)) { $fail('La sesión expiró. Recarga la página e intenta de nuevo.'); }

  $id = (int)($_POST['id'] ?? 0);
  if ($id <= 0) { $fail('Alumno inválido.'); }

  $st = $pdo->prepare("SELECT u.id, u.nombre, u.apellidos FROM usuarios u JOIN estudiantes e ON e.usuario_id = u.id WHERE u.id=:id AND u.rol='estudiante' LIMIT 1");
  $st->execute([':id'=>$id]);
  $alumno = $st->fetch(PDO::FETCH_ASSOC);
  if (!$alumno) { $fail('El alumno no existe o ya fue eliminado.', 404); }

  try {
    $pdo->beginTransaction();

    // Limpieza preventiva para instalaciones donde algunas tablas no tienen FK activa.
    $pdo->prepare("DELETE FROM estudiante_notifs WHERE estudiante_id=:id")->execute([':id'=>$id]);

    // Primero eliminamos el perfil de estudiante para activar cascadas académicas; luego la cuenta base.
    $pdo->prepare("DELETE FROM estudiantes WHERE usuario_id=:id")->execute([':id'=>$id]);

    $del = $pdo->prepare("DELETE FROM usuarios WHERE id=:id AND rol='estudiante'");
    $del->execute([':id'=>$id]);

    if ($del->rowCount() < 1) {
      throw new RuntimeException('No se eliminó ningún registro.');
    }

    if (isset($_SESSION['edit_alumno_id']) && (int)$_SESSION['edit_alumno_id'] === $id) {
      unset($_SESSION['edit_alumno_id'], $_SESSION['edit_alumno_id_ts']);
    }

    $pdo->commit();
    $ok(['msg'=>'Alumno eliminado correctamente.']);
  } catch (Throwable $e) {
    if ($pdo->inTransaction()) { $pdo->rollBack(); }
    $fail('No se pudo eliminar el alumno. Revisa si tiene información relacionada o intenta más tarde.', 500);
  }
}

/* ==========================================================
   AJAX: Listado/búsqueda (con foto normalizada -> campo "foto")
   ========================================================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'search') {
  header('Content-Type: application/json; charset=utf-8');

  $q       = trim((string)($_GET['q'] ?? ''));
  $carrera = (int)($_GET['carrera'] ?? 0);
  $sem     = (int)($_GET['sem'] ?? 0);
  $page    = max(1, (int)($_GET['page'] ?? 1));
  $perPage = min(50, max(5, (int)($_GET['perPage'] ?? 20)));
  $off     = ($page - 1) * $perPage;

  $where = ["u.rol = 'estudiante'"];
  $params = [];

  if ($q !== '') {
    // Mantenemos búsqueda por username aunque ya no se muestre la columna
    $where[] = "(u.nombre LIKE :q OR u.apellidos LIKE :q OR u.username LIKE :q OR u.email LIKE :q OR e.no_control LIKE :q)";
    $params[':q'] = '%'.$q.'%';
  }
  if ($carrera > 0) { $where[] = "e.carrera_id = :carr"; $params[':carr'] = $carrera; }
  if ($sem > 0)     { $where[] = "e.semestre_actual = :sem"; $params[':sem'] = $sem; }

  $whereSql = 'WHERE '.implode(' AND ', $where);

  // total
  $stmtCnt = $pdo->prepare("
    SELECT COUNT(*)
    FROM usuarios u
    JOIN estudiantes e ON e.usuario_id = u.id
    LEFT JOIN carreras c ON c.id = e.carrera_id
    $whereSql
  ");
  $stmtCnt->execute($params);
  $total = (int)$stmtCnt->fetchColumn();

  // página (seguimos trayendo username/creado_en por compatibilidad, no se muestran)
  $stmt = $pdo->prepare("
    SELECT
      u.id, u.nombre, u.apellidos, u.username, u.email, u.foto_url, u.creado_en,
      e.no_control, e.semestre_actual, e.carrera_id,
      c.nombre AS carrera_nombre
    FROM usuarios u
    JOIN estudiantes e ON e.usuario_id = u.id
    LEFT JOIN carreras c ON c.id = e.carrera_id
    $whereSql
    ORDER BY u.creado_en DESC
    LIMIT :lim OFFSET :off
  ");
  foreach ($params as $k=>$v) $stmt->bindValue($k,$v);
  $stmt->bindValue(':lim', $perPage, PDO::PARAM_INT);
  $stmt->bindValue(':off', $off, PDO::PARAM_INT);
  $stmt->execute();
  $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

  foreach ($rows as &$r) { $r['foto'] = foto_src($r['foto_url'] ?? null); } unset($r);

  echo json_encode([
    'ok'      => true,
    'total'   => $total,
    'page'    => $page,
    'perPage' => $perPage,
    'rows'    => $rows
  ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  exit;
}

/* ==========================================================
   Catálogo de carreras + flash
   ========================================================== */
$carreras = $pdo->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$flash = null;
if (isset($_GET['ok'])) {
  $map = ['1'=>'Alumno registrado correctamente.','upd'=>'Alumno actualizado correctamente.'];
  $flash = ['type'=>'ok','msg'=>$map[$_GET['ok']] ?? 'Operación realizada.'];
}
if (isset($_GET['err'])) {
  $flash = ['type'=>'err','msg'=>trim((string)$_GET['err']) ?: 'Ocurrió un error.'];
}

/* ==========================================================
   VISTA (con parciales)
   ========================================================== */
$title  = 'KnowLink · Administrador · Gestionar Estudiantes';
$active = 'alumnos';
require __DIR__ . '/partials/header.php';
?>
<style>
  .tools { display:flex; gap:10px; align-items:center; flex-wrap:wrap; }
  .tools .field input, .tools .field select { padding:10px 12px; border-radius:10px; border:1px solid #e6eef2; background:#fff; font-size:14px; outline:none; }

  .table { width:100%; border-collapse:separate; border-spacing:0; table-layout:fixed; }
  .table thead th{ font-size:12.5px; color:#6b7280; text-transform:uppercase; letter-spacing:.02em; padding:10px; background:#f8fafc; position:sticky; top:0; z-index:1; }
  .table tbody td{ padding:12px 10px; border-bottom:1px dashed #eef3f6; font-size:14px; vertical-align:middle; word-break:break-word; }
  .avatar { width:40px; height:40px; border-radius:999px; object-fit:cover; background:#f3f6f9; flex:0 0 auto; }
  .chip{ display:inline-flex; align-items:center; gap:6px; padding:6px 10px; border:1px solid #e6eef2; background:#fff; border-radius:999px; font-weight:700; font-size:12.5px; color:#0b2545; }
  .chip i{ font-size:12px; color:#64748b; }
  .actions { white-space:nowrap; }
  .actions a, .actions button { display:inline-flex; align-items:center; gap:6px; padding:8px 10px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; font-size:13px; text-decoration:none; color:#0b2545; }
  .actions a:hover, .actions button:hover { background:#f5f8ff; color:var(--accent); transform: translateY(-1px); }
  .actions .btn-delete{ border-color:#fecaca; color:#b91c1c; background:#fff5f5; }
  .actions .btn-delete:hover{ background:#fee2e2; color:#991b1b; }

  .confirm-overlay{ position:fixed; inset:0; z-index:2400; display:flex; align-items:center; justify-content:center; padding:18px; background:rgba(15,23,42,.46); backdrop-filter:blur(8px); }
  .confirm-overlay[hidden]{ display:none !important; }
  .confirm-card{ width:min(440px,100%); border-radius:20px; padding:20px; background:#fff; color:#0f172a; box-shadow:0 24px 70px rgba(2,6,23,.28); border:1px solid rgba(148,163,184,.22); transform:translateY(0); animation:confirmIn .14s ease-out; }
  @keyframes confirmIn{ from{opacity:0; transform:translateY(10px) scale(.98);} to{opacity:1; transform:translateY(0) scale(1);} }
  .confirm-icon{ width:46px; height:46px; border-radius:16px; display:grid; place-items:center; background:#fee2e2; color:#b91c1c; font-size:20px; margin-bottom:12px; }
  .confirm-title{ font-size:18px; font-weight:900; margin-bottom:6px; }
  .confirm-text{ color:#475569; line-height:1.45; font-size:14px; margin-bottom:16px; }
  .confirm-actions{ display:flex; justify-content:flex-end; gap:10px; flex-wrap:wrap; }
  .confirm-actions button{ border:0; border-radius:12px; padding:10px 14px; font-weight:800; cursor:pointer; }
  .confirm-actions .cancel{ background:#f1f5f9; color:#0f172a; }
  .confirm-actions .danger{ background:linear-gradient(135deg,#dc2626,#991b1b); color:#fff; }
  .confirm-actions button:disabled{ opacity:.65; cursor:not-allowed; }
  html[data-theme="dark"] .confirm-card{ background:#111827; color:#f8fafc; border-color:rgba(148,163,184,.18); }
  html[data-theme="dark"] .confirm-text{ color:#cbd5e1; }
  html[data-theme="dark"] .confirm-actions .cancel{ background:#1f2937; color:#e5e7eb; }
  html[data-theme="dark"] .actions .btn-delete{ background:rgba(127,29,29,.20); color:#fecaca; border-color:rgba(248,113,113,.35); }
  html[data-theme="dark"] .actions .btn-delete:hover{ background:rgba(127,29,29,.38); color:#fff; }
  .pager { margin-top:12px; display:flex; gap:10px; align-items:center; }
  .pager button { padding:8px 12px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; }
  .pager .muted { color:#6b7280; font-size:13px; }

  /* Sin scroll horizontal en móvil/tablet: convertir filas en tarjetas */
  @media (max-width: 980px){
    .table { border-collapse: separate; border-spacing: 0 10px; table-layout:auto; }
    .table thead { display:none; }
    .table tbody tr { display:block; background:#fff; border:1px solid #eef3f6; border-radius:12px; padding:12px; }
    .table tbody td { display:block; border-bottom:0; padding:6px 0; }
    .table tbody td + td { margin-top:4px; }
    .td-inline { display:inline-flex; align-items:center; gap:8px; margin-right:12px; }
    .actions { padding-top:8px; margin-top:8px; border-top:1px dashed #eef3f6; }
    .actions .label { display:inline !important; }
  }

  /* Toast */
  .toast {
    position: fixed; top: calc(var(--topbar-h, 70px) + 12px); right: 16px; z-index: 1400;
    display: none; min-width: 280px; max-width: 420px; padding: 12px 14px; border-radius: 10px;
    box-shadow: 0 18px 40px rgba(2,6,23,0.18); font-size: 14px; line-height: 1.35;
    border: 1px solid transparent; background: #fff; color: #0b2545;
    transform: translateY(-6px); opacity: 0; transition: opacity .18s ease, transform .18s ease;
  }
  .toast.ok { border-color: #bbf7d0; background: #ecfdf5; color: #065f46; }
  .toast.err { border-color: #f5c2c7; background: #fff1f0; color: #7a0021; }
  .toast.show { display: block; opacity: 1; transform: translateY(0); }

  @media (max-width:1100px){
    .actions .label{ display:none; }
    .actions a, .actions button{ padding:8px; }
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title">Gestionar estudiantes</div>
    <div class="page-sub">Busca y edita alumnos registrados</div>
  </div>
  <div>
    <a class="btn primary btn-icon" href="<?= esc(base_url('admin/registrar_alumno.php')) ?>">
      <i class="fas fa-user-plus"></i><span class="label"> Registrar alumno</span>
    </a>
  </div>
</div>

<?php if (!empty($flash)): ?>
  <div id="toast" class="toast <?= esc($flash['type']) ?>">
    <div class="row" style="display:flex; align-items:flex-start; gap:10px;">
      <div class="icon" style="font-size:18px; line-height:1; margin-top:1px;">
        <?php if ($flash['type']==='ok'): ?>
          <i class="fas fa-check-circle" aria-hidden="true"></i>
        <?php else: ?>
          <i class="fas fa-exclamation-triangle" aria-hidden="true"></i>
        <?php endif; ?>
      </div>
      <div class="msg" style="font-weight:700;"><?= esc($flash['msg']) ?></div>
      <button class="close" type="button" aria-label="Cerrar notificación" style="background:transparent;border:0;cursor:pointer;font-size:16px;color:inherit;opacity:.7;padding:4px;">&times;</button>
    </div>
  </div>
<?php endif; ?>

<!-- Filtros -->
<section class="card" aria-label="Filtros de búsqueda">
  <div class="tools" style="justify-content:space-between; gap:12px;">
    <div class="tools" style="gap:8px;">
      <div class="field">
        <input type="text" id="q" placeholder="Buscar por nombre, correo o no. control" style="min-width:280px;">
      </div>
      <div class="field">
        <select id="carrera">
          <option value="0">Todas las carreras</option>
          <?php foreach ($carreras as $c): ?>
            <option value="<?= (int)$c['id'] ?>"><?= esc($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="field">
        <select id="sem">
          <option value="0">Todos los semestres</option>
          <?php for($s=1;$s<=12;$s++): ?>
            <option value="<?= $s ?>">Semestre <?= $s ?></option>
          <?php endfor; ?>
        </select>
      </div>
    </div>
    <div class="tools" style="gap:8px;">
      <div class="field">
        <select id="perPage">
          <option value="10">10 por página</option>
          <option value="20" selected>20 por página</option>
          <option value="30">30 por página</option>
          <option value="50">50 por página</option>
        </select>
      </div>
      <button class="btn ghost" id="btnClear"><i class="fas fa-eraser"></i> Limpiar</button>
    </div>
  </div>
</section>

<!-- Tabla -->
<section class="card" aria-label="Resultados">
  <table class="table" id="tbl">
    <thead>
      <tr>
        <th>Alumno</th>
        <th>No. Control</th>
        <th>Carrera</th>
        <th>Sem</th>
        <th>Correo</th>
        <th style="width:210px;">Acciones</th>
      </tr>
    </thead>
    <tbody id="tbody">
      <tr><td colspan="6" style="text-align:center;color:#6b7280;">Cargando…</td></tr>
    </tbody>
  </table>

  <div class="pager" id="pager">
    <button id="prev" disabled>&laquo; Anterior</button>
    <span class="muted" id="info">—</span>
    <button id="next" disabled>Siguiente &raquo;</button>
  </div>
</section>

<!-- Form oculto para POST de edición -->
<form id="goEditForm" method="post" action="" style="display:none;">
  <input type="hidden" name="action" value="go_edit">
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="id" id="goEditId" value="">
</form>

<div id="confirmDeleteModal" class="confirm-overlay" hidden aria-hidden="true">
  <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirmDeleteTitle">
    <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
    <div id="confirmDeleteTitle" class="confirm-title">Eliminar alumno</div>
    <div id="confirmDeleteText" class="confirm-text">
      Esta acción eliminará al alumno seleccionado y la información académica relacionada. No se puede deshacer.
    </div>
    <div class="confirm-actions">
      <button type="button" class="cancel" id="confirmDeleteCancel">Cancelar</button>
      <button type="button" class="danger" id="confirmDeleteAccept">Sí, eliminar</button>
    </div>
  </div>
</div>

<script>
(function(){
  // ========= Utils =========
  function escapeH(str){ return String(str??'').replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s])); }
  const CSRF = <?= json_encode($CSRF) ?>;
  const notify = (msg, isErr=false)=>{
    if(window.showToast){ window.showToast(msg, isErr); return; }
    if(isErr) alert(msg); else console.log(msg);
  };

  // ========= Tabla/búsqueda =========
  const q = document.getElementById('q');
  const carrera = document.getElementById('carrera');
  const sem = document.getElementById('sem');
  const perPage = document.getElementById('perPage');
  const tbody = document.getElementById('tbody');
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');
  const info = document.getElementById('info');

  const goEditForm = document.getElementById('goEditForm');
  const goEditId   = document.getElementById('goEditId');

  const confirmDeleteModal = document.getElementById('confirmDeleteModal');
  const confirmDeleteText = document.getElementById('confirmDeleteText');
  const confirmDeleteCancel = document.getElementById('confirmDeleteCancel');
  const confirmDeleteAccept = document.getElementById('confirmDeleteAccept');
  let pendingDelete = null;

  let state = { page:1, total:0, perPage: parseInt(perPage.value,10)||20, q:'', carrera:0, sem:0, loading:false };


  function openDeleteModal(id, nombre){
    pendingDelete = { id, nombre };
    confirmDeleteText.innerHTML = `¿Seguro que deseas eliminar a <strong>${escapeH(nombre)}</strong>? También se eliminarán sus datos relacionados como estudiante. Esta acción no se puede deshacer.`;
    confirmDeleteModal.hidden = false;
    confirmDeleteModal.setAttribute('aria-hidden','false');
    setTimeout(()=>confirmDeleteCancel.focus(), 20);
  }

  function closeDeleteModal(){
    pendingDelete = null;
    confirmDeleteModal.hidden = true;
    confirmDeleteModal.setAttribute('aria-hidden','true');
    confirmDeleteAccept.disabled = false;
    confirmDeleteAccept.innerHTML = 'Sí, eliminar';
  }

  async function deleteAlumno(){
    if(!pendingDelete?.id) return;
    confirmDeleteAccept.disabled = true;
    confirmDeleteAccept.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
    try{
      const body = new URLSearchParams({ action:'delete', csrf:CSRF, id:String(pendingDelete.id) });
      const res = await fetch('', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body });
      const data = await res.json();
      if(!data.ok) throw new Error(data.msg || 'No se pudo eliminar el alumno.');
      closeDeleteModal();
      notify(data.msg || 'Alumno eliminado correctamente.');
      fetchData();
    }catch(err){
      confirmDeleteAccept.disabled = false;
      confirmDeleteAccept.innerHTML = 'Sí, eliminar';
      notify(String(err.message || err), true);
    }
  }

  function buildRow(r){
    const foto = (r.foto && String(r.foto).trim()) ? r.foto : <?= json_encode(foto_src(null), JSON_UNESCAPED_SLASHES) ?>;
    const nombre = ((r.nombre||'')+' '+(r.apellidos||'')).trim() || ('Usuario #'+r.id);
    const carrera = r.carrera_nombre || '—';
    const sem = parseInt(r.semestre_actual||0,10)||'—';
    const noctrl = r.no_control || '';

    return `<tr>
      <td>
        <div style="display:flex; align-items:center; gap:10px;">
          <img class="avatar" src="${foto}" alt="avatar">
          <div>
            <div style="font-weight:800;color:#0b2545;">${escapeH(nombre)}</div>
            <div style="font-size:12px;color:#6b7280;">ID ${r.id}</div>
          </div>
        </div>
      </td>
      <td><span class="chip td-inline"><i class="fa-solid fa-hashtag"></i>${escapeH(noctrl)}</span></td>
      <td>${escapeH(carrera)}</td>
      <td>${sem}</td>
      <td>${escapeH(r.email||'')}</td>
      <td class="actions">
        <button type="button" class="btn-edit" data-id="${r.id}"><i class="fas fa-edit"></i> <span class="label">Editar</span></button>
        <button type="button" class="btn-delete" data-id="${r.id}" data-name="${escapeH(nombre)}"><i class="fas fa-trash-alt"></i> <span class="label">Eliminar</span></button>
      </td>
    </tr>`;
  }

  async function fetchData(){
    if(state.loading) return; state.loading=true;
    tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#6b7280;">Cargando…</td></tr>`;
    try{
      const qs = new URLSearchParams({
        ajax:'search',
        q: state.q, carrera: String(state.carrera||0), sem: String(state.sem||0),
        page: String(state.page||1), perPage: String(state.perPage||20),
      });
      const res = await fetch('?' + qs.toString(), {cache:'no-store'});
      const data = await res.json();
      if(!data.ok) throw new Error('Respuesta inválida');
      state.total = data.total || 0;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length ? rows.map(buildRow).join('') :
        `<tr><td colspan="6" style="text-align:center;color:#6b7280;">Sin resultados.</td></tr>`;
      const first = state.total ? Math.min(state.total, ((state.page-1)*state.perPage)+1) : 0;
      const last  = state.total ? Math.min(state.total, state.page*state.perPage) : 0;
      info.textContent = state.total ? `${first}–${last} de ${state.total}` : '0 resultados';
      prevBtn.disabled = (state.page<=1);
      nextBtn.disabled = (state.page*state.perPage >= state.total);
    } catch(e){
      tbody.innerHTML = `<tr><td colspan="6" style="text-align:center;color:#b91c1c;">Error al cargar datos.</td></tr>`;
      info.textContent = '—'; prevBtn.disabled = true; nextBtn.disabled = true;
    } finally {
      state.loading=false; bindActionButtons();
    }
  }

  function bindActionButtons(){
    tbody.querySelectorAll('button.btn-edit[data-id]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = parseInt(btn.getAttribute('data-id'),10)||0; if(!id) return;
        goEditId.value = String(id);
        goEditForm.submit();
      });
    });
    tbody.querySelectorAll('button.btn-delete[data-id]').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const id = parseInt(btn.getAttribute('data-id'),10)||0; if(!id) return;
        const nombre = btn.getAttribute('data-name') || ('Alumno #' + id);
        openDeleteModal(id, nombre);
      });
    });
  }

  function debounce(fn,ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
  const onChange = debounce(()=>{ state.page=1; fetchData(); }, 250);

  document.getElementById('btnClear').addEventListener('click', (e)=>{ e.preventDefault();
    q.value=''; carrera.value='0'; sem.value='0'; perPage.value='20';
    state={page:1,total:0,perPage:20,q:'',carrera:0,sem:0,loading:false};
    fetchData();
  });
  q.addEventListener('input', ()=>{ state.q = q.value.trim(); onChange(); });
  carrera.addEventListener('change', ()=>{ state.carrera = parseInt(carrera.value,10)||0; onChange(); });
  sem.addEventListener('change', ()=>{ state.sem = parseInt(sem.value,10)||0; onChange(); });
  perPage.addEventListener('change', ()=>{ state.perPage = parseInt(perPage.value,10)||20; state.page=1; fetchData(); });

  document.getElementById('prev').addEventListener('click', ()=>{ if(state.page>1){ state.page--; fetchData(); }});
  document.getElementById('next').addEventListener('click', ()=>{ if(state.page*state.perPage < state.total){ state.page++; fetchData(); }});

  confirmDeleteCancel.addEventListener('click', closeDeleteModal);
  confirmDeleteAccept.addEventListener('click', deleteAlumno);
  confirmDeleteModal.addEventListener('click', (ev)=>{ if(ev.target === confirmDeleteModal) closeDeleteModal(); });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && !confirmDeleteModal.hidden) closeDeleteModal(); });

  // ========= Toast (flash) =========
  (function(){
    const toast=document.getElementById('toast');
    if(!toast) return;
    requestAnimationFrame(()=> toast.classList.add('show'));
    const hide=()=>{ toast.classList.remove('show'); setTimeout(()=>toast.remove(),220);
      try{ const u=new URL(location.href); u.searchParams.delete('ok'); u.searchParams.delete('err'); history.replaceState({},'',u);}catch(e){} };
    toast.querySelector('.close')?.addEventListener('click', hide);
    setTimeout(hide, 4500);
  })();

  // Primera carga
  fetchData();
})();
</script>

<?php require __DIR__ . '/partials/footer.php';
