<?php
// public/admin/registro_reticula.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// === Utils locales ===
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Polyfill + normalizadores de foto para que el header muestre bien el avatar
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
/**
 * Normaliza a URL web ABSOLUTA lista para <img src="...">:
 *  - /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/...
 *  - http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\', '/', $url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u; // absoluta o data:
    // Normaliza ../
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    // Extrae segmento uploads/avatars si existe
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/'); // /uploads/avatars/...
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return base_url(ltrim($path, '/'));
  }
}
// Algunos headers usan buildFotoUrl(); lo aliaseamos a foto_src()
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

$pdo = db();

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

// Cargar carreras para el select
$carreas = [];
try {
  $st = $pdo->query("SELECT id, clave, nombre FROM carreras ORDER BY nombre ASC");
  $carreas = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
} catch(Throwable $e) { $carreas = []; }

// Estado del form
$errors = [];
$flash  = null;

$values = [
  'carrera_id'    => (string)($_POST['carrera_id'] ?? ''),
  'clave'         => trim((string)($_POST['clave'] ?? '')),
  'nombre'        => trim((string)($_POST['nombre'] ?? '')),
  'vigente_desde' => trim((string)($_POST['vigente_desde'] ?? '')),
  'vigente_hasta' => trim((string)($_POST['vigente_hasta'] ?? '')),
];

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['form'] ?? '')==='reticula') {
  if (!hash_equals($CSRF, $_POST['csrf'] ?? '')) {
    $errors[] = 'CSRF inválido. Refresca la página.';
  }

  // Validaciones
  $carrera_id = (int)$values['carrera_id'];
  if ($carrera_id <= 0) $errors[] = 'Selecciona una carrera.';

  if ($values['clave']==='' || mb_strlen($values['clave'])<3) $errors[] = 'La clave debe tener al menos 3 caracteres.';
  if ($values['nombre']==='' || mb_strlen($values['nombre'])<3) $errors[] = 'El nombre debe tener al menos 3 caracteres.';
  if ($values['vigente_desde']==='') $errors[] = '“Vigente desde” es obligatorio.';

  $desde = null; $hasta = null;
  if ($values['vigente_desde']!=='') {
    try { $desde = new DateTime($values['vigente_desde']); }
    catch(Throwable $e){ $errors[]='Fecha “Vigente desde” inválida.'; }
  }
  if ($values['vigente_hasta']!=='') {
    try { $hasta = new DateTime($values['vigente_hasta']); }
    catch(Throwable $e){ $errors[]='Fecha “Vigente hasta” inválida.'; }
  }
  if ($desde && $hasta && $hasta < $desde) $errors[] = '“Vigente hasta” no puede ser anterior a “Vigente desde”.';

  // Carrera existe
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM carreras WHERE id=:id");
    $st->execute([':id'=>$carrera_id]);
    if ((int)$st->fetchColumn()===0) $errors[] = 'La carrera seleccionada no existe.';
  }

  // Clave única
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE clave=:c");
    $st->execute([':c'=>$values['clave']]);
    if ((int)$st->fetchColumn()>0) $errors[] = 'Ya existe una retícula con esa clave.';
  }

  // Insert
  if (!$errors) {
    try {
      $pdo->beginTransaction();
      $ins = $pdo->prepare("
        INSERT INTO reticulas (carrera_id, clave, nombre, vigente_desde, vigente_hasta)
        VALUES (:car, :cl, :nm, :vd, :vh)
      ");
      $ins->execute([
        ':car'=>$carrera_id,
        ':cl'=>$values['clave'],
        ':nm'=>$values['nombre'],
        ':vd'=>$desde?->format('Y-m-d'),
        ':vh'=>$hasta?->format('Y-m-d'),
      ]);
      $newId = (int)$pdo->lastInsertId();

      // Evento admin (si existe tabla)
      try{
        $ev = $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('reticula', :ref, :desc)");
        $ev->execute([
          ':ref'=>$values['clave'],
          ':desc'=>'Nueva retícula “'.$values['nombre'].'” creada',
        ]);
      } catch(Throwable $e){ /* opcional */ }

      $pdo->commit();
      redirect(base_url('admin/gestionar_reticulas.php?ok=1'));
      exit;
    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al registrar la retícula.';
    }
  }
}

/* ==========================================================
   Variables para header/footer parciales
   ========================================================== */
$active   = 'reticulas';
$title    = 'ITZ KnowLink - Administrador · Registrar Retícula';
$h1       = 'Registrar retícula';
$subtitle = 'Captura la información base de una nueva retícula';

$HEADER_TITLE  = $h1;
$HEADER_SUB    = $subtitle;
$PAGE_TITLE    = $title;
$header_title  = $h1;
$header_sub    = $subtitle;
$page_title    = $title;
$page_h1       = $h1;
$page_h2       = $subtitle;
$PAGE_H1       = $h1;
$PAGE_SUBTITLE = $subtitle;

$MENU_ACTIVE     = $active;
$ACTIVE_MENU     = $active;
$ACTIVE_SECTION  = $active;
$CURRENT_SECTION = $active;

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// El header usa $yo para el avatar/nombre (ya lo tenemos arriba)
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px}
  input[type="text"],input[type="date"],select{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .hint{font-size:12px;color:#6b7280}

  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  a.btn.ghost.btn-icon{ text-decoration:none; }
  a.btn.ghost.btn-icon:hover, a.btn.ghost.btn-icon:focus{ background:#f5f8ff; color:#0b2545; transform: translateY(-1px); }

  .flash{padding:10px 12px;border-radius:8px;margin-bottom:12px;font-size:14px}
  .flash.error{background:#fff1f0;border:1px solid #f5c2c7;color:#7a0021}

  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="flash error">
    <strong>Revisa lo siguiente:</strong>
    <ul style="margin-top:6px; padding-left:18px;">
      <?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?>
    </ul>
  </div>
<?php endif; ?>

<form method="post" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="form" value="reticula">

  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de la retícula</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Carrera</span>
        <select name="carrera_id" required>
          <option value="">— Selecciona —</option>
          <?php foreach($carreas as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((string)$c['id']===$values['carrera_id']?'selected':'') ?>>
              <?= esc($c['nombre'].' ('.$c['clave'].')') ?>
            </option>
          <?php endforeach; ?>
        </select>
        <div class="hint">Obligatorio</div>
      </label>

      <label class="field">
        <span class="label">Clave de retícula</span>
        <input type="text" name="clave" required minlength="3" placeholder="Ej. R2025-ICI"
               value="<?= esc($values['clave']) ?>">
        <div class="hint">Debe ser única (ej. R2019-ICI)</div>
      </label>

      <label class="field">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" required minlength="3" placeholder="Ej. Retícula 2025 Ingeniería Civil"
               value="<?= esc($values['nombre']) ?>">
      </label>

      <label class="field">
        <span class="label">Vigente desde</span>
        <input type="date" name="vigente_desde" required value="<?= esc($values['vigente_desde']) ?>">
        <div class="hint">Obligatorio</div>
      </label>

      <label class="field">
        <span class="label">Vigente hasta (opcional)</span>
        <input type="date" name="vigente_hasta" value="<?= esc($values['vigente_hasta']) ?>">
        <div class="hint">Debe ser igual o posterior a “desde”</div>
      </label>
    </div>

    <div style="display:flex;gap:8px;align-items:center;margin-top:12px;">
      <button class="btn primary btn-icon" type="submit">
        <i class="fas fa-save"></i> <span class="label">Guardar</span>
      </button>
      <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
        <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
      </a>
    </div>
  </section>
</form>

<?php
require __DIR__ . '/partials/footer.php';
