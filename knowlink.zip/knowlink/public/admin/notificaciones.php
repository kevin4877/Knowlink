<?php
// public/admin/notificaciones.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/auth.php';
require_once __DIR__ . '/../../src/helpers.php';

header('Content-Type: application/json; charset=utf-8');

start_session();
$u = auth_user();
if (!$u || ($u['rol'] ?? '') !== 'administrador') {
  http_response_code(403);
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
  exit;
}

$pdo = db();

// Si la tabla no existe, devolvemos vacío (para no romper UI)
try {
  // since_id: para calcular cuántas nuevas hay (badge)
  $sinceId = isset($_GET['since_id']) ? (int)$_GET['since_id'] : 0;

  // Conteo de nuevas
  $countStmt = $pdo->prepare("
    SELECT COUNT(*) FROM admin_eventos
    WHERE tipo IN ('reticula','materia','carrera')
      AND id > :since_id
  ");
  $countStmt->execute([':since_id' => $sinceId]);
  $totalNew = (int)$countStmt->fetchColumn();

  // Últimas 10 (independiente del since_id, para listar)
  $listStmt = $pdo->query("
    SELECT id, tipo, referencia, descripcion,
           creado_en, DATE_FORMAT(creado_en, '%Y-%m-%d %H:%i') AS creado_en_fmt
    FROM admin_eventos
    WHERE tipo IN ('reticula','materia','carrera')
    ORDER BY id DESC
    LIMIT 10
  ");
  $items = $listStmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

  echo json_encode(['total'=>$totalNew,'items'=>$items], JSON_UNESCAPED_UNICODE);
} catch(Throwable $e) {
  echo json_encode(['total'=>0,'items'=>[]], JSON_UNESCAPED_UNICODE);
}
