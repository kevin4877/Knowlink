<?php
// public/admin/editar_administrador.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Cabeceras seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// Utils
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Polyfill PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

// Placeholder y normalización de foto
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="44" cy="32" r="16" fill="#cfd8e3"/><rect x="18" y="54" width="52" height="22" rx="11" fill="#cfd8e3"/></svg>'
    );
  }
}
/**
 * Devuelve URL absoluta lista para <img src>.
 * Acepta /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\', '/', $url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u;
    // Limpia ../
    while (str_starts_with($u, '../')) $u = substr($u, 3);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/'); // /uploads/avatars/...
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

$pdo = db();

// ====== Cargar administrador
$uid = (int)($_GET['id'] ?? ($_SESSION['edit_admin_id'] ?? 0));
if ($uid <= 0) { http_response_code(400); echo "Falta parámetro id"; exit; }

$sqlAdm = "SELECT u.id, u.nombre, u.apellidos, u.username, u.email, u.foto_url, u.rol, u.activo, u.creado_en, u.actualizado_en
           FROM usuarios u
           WHERE u.id = :id
           LIMIT 1";
$st = $pdo->prepare($sqlAdm);
$st->execute([':id'=>$uid]);
$admin = $st->fetch(PDO::FETCH_ASSOC);
if (!$admin || ($admin['rol'] ?? '') !== 'administrador') {
  http_response_code(404); echo "Administrador no encontrado."; exit;
}

/* =========================================================
   AJAX internos
   ========================================================= */
if (isset($_GET['ajax']) || isset($_POST['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');
  $action = (string)($_GET['ajax'] ?? $_POST['ajax']);

  // Comprobar username (disponibilidad)
  if ($action === 'username') {
    $u = trim((string)($_GET['u'] ?? ''));
    $ok = false; $available = false;
    if ($u !== '' && mb_strlen($u) >= 3) {
      $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u AND id <> :id");
      $st->execute([':u'=>$u, ':id'=>$uid]);
      $available = ((int)$st->fetchColumn() === 0);
      $ok = true;
    }
    echo json_encode(['ok'=>$ok, 'available'=>$available], JSON_UNESCAPED_UNICODE);
    exit;
  }

  // Eliminar administrador (zona peligrosa)
  if ($action === 'delete_admin' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    $id   = (int)($_POST['id'] ?? 0);

    if (!hash_equals($_SESSION['csrf'] ?? '', $csrf)) { echo json_encode(['ok'=>false,'msg'=>'CSRF inválido']); exit; }
    if ($id !== $uid || $id<=0)     { echo json_encode(['ok'=>false,'msg'=>'ID inválido']); exit; }
    if ((int)$yo['id'] === $id)     { echo json_encode(['ok'=>false,'msg'=>'No puedes eliminar tu propia cuenta.']); exit; }

    try {
      // Verificar rol y que quede al menos un admin activo
      $st = $pdo->prepare("SELECT rol, activo FROM usuarios WHERE id=:id LIMIT 1");
      $st->execute([':id'=>$id]);
      $row = $st->fetch(PDO::FETCH_ASSOC);
      if (!$row || ($row['rol'] ?? '') !== 'administrador') {
        echo json_encode(['ok'=>false,'msg'=>'Solo se pueden eliminar administradores.']); exit;
      }
      if ((int)$row['activo'] === 1) {
        $activos = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND id <> ".(int)$id)->fetchColumn();
        if ($activos <= 0) { echo json_encode(['ok'=>false,'msg'=>'Debe quedar al menos un administrador activo.']); exit; }
      }

      $pdo->beginTransaction();
      $pdo->prepare("DELETE FROM usuarios WHERE id=:id AND rol='administrador'")->execute([':id'=>$id]);
      $pdo->commit();
      echo json_encode(['ok'=>true]);
    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      echo json_encode(['ok'=>false,'msg'=>'No se pudo eliminar (posibles dependencias).']);
    }
    exit;
  }

  echo json_encode(['ok'=>false,'err'=>'Acción inválida']); exit;
}

/* =========================================================
   Guardado de datos
   ========================================================= */
$flash = null;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'perfil') {
  if (!hash_equals($_SESSION['csrf'] ?? '', $_POST['csrf'] ?? '')) { $errors[] = 'CSRF inválido. Refresca la página.'; }

  $nombre    = trim((string)($_POST['nombre'] ?? ''));
  $apellidos = trim((string)($_POST['apellidos'] ?? ''));
  $username  = trim((string)($_POST['username'] ?? ''));
  $email     = trim((string)($_POST['email'] ?? ''));
  $pass1     = (string)($_POST['password'] ?? '');
  $pass2     = (string)($_POST['password2'] ?? '');

  if ($nombre==='' || mb_strlen($nombre)<2)       $errors[] = 'Nombre inválido.';
  if ($apellidos==='' || mb_strlen($apellidos)<2) $errors[] = 'Apellidos inválidos.';
  if ($email==='' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Correo inválido.';
  if ($username==='' || mb_strlen($username)<3)   $errors[] = 'Usuario mínimo 3 caracteres.';

  if ($pass1!=='' || $pass2!=='') {
    if ($pass1!==$pass2) $errors[] = 'Las contraseñas no coinciden.';
    if ($pass1!=='' && mb_strlen($pass1)<8) $errors[] = 'La nueva contraseña debe tener al menos 8 caracteres.';
  }

  // Unicidad
  if (!$errors) {
    $qU = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u AND id<>:id");
    $qU->execute([':u'=>$username, ':id'=>$uid]);
    if ((int)$qU->fetchColumn() > 0) $errors[] = 'El username ya está en uso.';

    $qE = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e AND id<>:id");
    $qE->execute([':e'=>$email, ':id'=>$uid]);
    if ((int)$qE->fetchColumn() > 0) $errors[] = 'El correo ya está en uso.';
  }

  // Foto (opcional) — guardar SIEMPRE como /uploads/avatars/archivo.ext
  $foto_url = $admin['foto_url'] ?? null;
  if (!$errors && isset($_FILES['foto']) && is_array($_FILES['foto']) && ($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['foto'];
    if ($f['error'] !== UPLOAD_ERR_OK) { $errors[]='Error al subir la imagen.'; }
    else {
      if ($f['size'] > 3*1024*1024) $errors[]='La imagen excede 3 MB.';
      $finfo = finfo_open(FILEINFO_MIME_TYPE);
      $mime  = finfo_file($finfo, $f['tmp_name']); finfo_close($finfo);
      $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
      if (!isset($allowed[$mime])) $errors[]='Formato de imagen no permitido (JPG, PNG, GIF, WEBP).';

      if (!$errors) {
        $ext        = $allowed[$mime];
        $publicRoot = realpath(__DIR__ . '/..'); // .../public
        if (!$publicRoot) { $errors[]='Ruta pública no disponible.'; }
        else {
          $dir     = $publicRoot . '/uploads/avatars';
          if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
          $fname   = 'u'.$uid.'_'.time().'.'.$ext;
          $webPath = '/uploads/avatars/' . $fname; // ruta web limpia para DB
          $dest    = $publicRoot . $webPath;       // path absoluto real
          if (!move_uploaded_file($f['tmp_name'], $dest)) {
            $errors[] = 'No se pudo guardar la imagen.';
          } else {
            $foto_url = $webPath; // guardamos siempre como /uploads/avatars/...
          }
        }
      }
    }
  }

  if (!$errors) {
    try {
      $pdo->beginTransaction();
      $sqlU = "UPDATE usuarios
               SET nombre=:n, apellidos=:a, username=:u, email=:e, actualizado_en=NOW()"
             . ($foto_url !== null ? ", foto_url=:f " : " ")
             . "WHERE id=:id AND rol='administrador'";
      $stU = $pdo->prepare($sqlU);
      $params = [':n'=>$nombre, ':a'=>$apellidos, ':u'=>$username, ':e'=>$email, ':id'=>$uid];
      if ($foto_url !== null) $params[':f'] = $foto_url;
      $stU->execute($params);

      if ($pass1!=='') {
        $hash = password_hash($pass1, PASSWORD_BCRYPT, ['cost'=>10]);
        $pdo->prepare("UPDATE usuarios SET password_hash=:ph WHERE id=:id")
            ->execute([':ph'=>$hash, ':id'=>$uid]);
      }

      $pdo->commit();
      $flash = ['type'=>'ok','msg'=>'Datos del administrador actualizados correctamente.'];

      // Refrescar datos
      $st = $pdo->prepare($sqlAdm);
      $st->execute([':id'=>$uid]);
      $admin = $st->fetch(PDO::FETCH_ASSOC);
    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al guardar los cambios.';
    }
  }
}

$fotoActual = foto_src($admin['foto_url'] ?? null);

/* =========================
   HEADER (parcial existente)
   ========================= */
$active   = 'admins';
$title    = 'ITZ KnowLink - Administrador · Editar administrador';
$h1       = 'Editar Administrador';
$subtitle = 'Actualizar datos y credenciales de acceso';

/* Variantes típicas que algunos headers leen */
$HEADER_TITLE  = $h1;
$HEADER_SUB    = $subtitle;
$PAGE_TITLE    = $title;
$header_title  = $h1;
$header_sub    = $subtitle;
$page_title    = $title;
$page_h1       = $h1;
$page_h2       = $subtitle;
$PAGE_H1       = $h1;
$PAGE_SUBTITLE = $subtitle;

/* Menú activo en otras variantes */
$MENU_ACTIVE     = $active;
$ACTIVE_MENU     = $active;
$ACTIVE_SECTION  = $active;
$CURRENT_SECTION = $active;

/* El header espera $yo */
if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
  .page-title{ font-size:20px; font-weight:800; color:#0b2545; }
  .page-sub{ color:#6b7280; font-size:14px; }

  .card{ background:#fff; border-radius:12px; padding:16px; box-shadow:0 10px 30px rgba(2,6,23,0.06); margin-bottom:14px; }
  .form-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:12px; margin-top:12px; }
  label.field{ display:flex; flex-direction:column; gap:8px; }
  input[type="text"],input[type="email"],input[type="password"],select{
    width:100%; padding:10px 12px; border-radius:8px; border:1px solid #e6eef2; outline:none; font-size:14px; background:#fbfdfe;
  }
  .hint{ font-size:12px; color:#6b7280; }

  .btn{ padding:10px 14px; border-radius:10px; border:0; cursor:pointer; font-weight:800; }
  .btn.primary{ background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; }
  .btn.ghost{ background:#fff; border:1px solid #e6eef2; color:#0b2545; }
  .btn.danger{ background:#fee2e2; color:#991b1b; border:1px solid #fecaca; }
  .btn.small{ padding:6px 10px; border-radius:8px; font-weight:700; }
  .btn-icon{ display:inline-flex; align-items:center; gap:8px; }
  a.btn.ghost.btn-icon{ text-decoration:none; }
  a.btn.ghost.btn-icon:hover, a.btn.ghost.btn-icon:focus{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }

  .avatar-big{ width:96px; height:96px; border-radius:999px; object-fit:cover; background:#eef3f6; border:4px solid #eef7f8; }
  .avail { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:10px; font-weight:800; margin-top:6px; border:1px solid #e6eef2; background:#f3f6f9; color:#0b2545; }
  .avail.good { background:#ecfdf5; border-color:#bbf7d0; color:#065f46; }
  .avail.bad  { background:#fff1f0; border-color:#f5c2c7; color:#7a0021; }

  /* Ojo de contraseña (mismo estilo que en otras vistas) */
  .pwd-wrap{ position:relative; }
  .pwd-wrap input{ padding-right:42px; }
  .toggle-eye{
    position:absolute; right:8px; top:50%; transform:translateY(-50%);
    background:transparent; border:0; cursor:pointer; font-size:16px; color:#6b7280; padding:6px; border-radius:8px;
  }
  .toggle-eye:hover{ background:#f3f6f9; color:#0b2545; }

  /* Ocultar reveladores nativos (evita doble ojo) */
  input[type="password"]::-webkit-textfield-decoration-container,
  input[type="password"]::-webkit-password-reveal-button,
  input[type="password"]::-ms-reveal,
  input[type="password"]::-ms-clear{ display:none !important; appearance:none !important; width:0; height:0; margin:0; padding:0; border:0; pointer-events:none; }
  input[type="password"]{ -moz-appearance:textfield !important; }

  .actions-bar{ display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-top:12px; }
  .actions-left{ display:flex; gap:8px; flex-wrap:wrap; }
  .actions-right{ display:flex; gap:8px; }

  .danger-zone{ border:1px solid #fecaca; background:#fff1f0; color:#7a0021; }
  .danger-zone h3{ font-size:16px; margin-bottom:6px; }
  .danger-zone p{ font-size:14px; color:#7a0021; }
  .danger-actions{ display:flex; justify-content:flex-end; margin-top:10px; }
  .danger-actions .btn.danger{ border-color:#fca5a5; }
  .danger-actions .btn.danger:hover{ filter:brightness(.98); transform: translateY(-1px); }
  html[data-theme="dark"] .danger-zone{background:rgba(127,29,29,.16) !important;border-color:rgba(248,113,113,.30) !important;color:#fecaca !important;}
  html[data-theme="dark"] .danger-zone h3{color:#fecaca !important;}
  html[data-theme="dark"] .danger-zone p{color:#fca5a5 !important;}
  html[data-theme="dark"] .btn.danger{background:rgba(239,68,68,.16);color:#fecaca;border-color:rgba(248,113,113,.34);}
  html[data-theme="dark"] .btn.danger:hover{background:rgba(239,68,68,.22);}

  /* Confirmación de eliminación: clases propias para no chocar con .modal global/Bootstrap */
  .kl-delete-overlay{
    position:fixed;
    inset:0;
    z-index:6000;
    display:grid;
    place-items:center;
    padding:18px;
    background:rgba(15,23,42,.52);
    backdrop-filter:blur(7px);
    -webkit-backdrop-filter:blur(7px);
  }
  .kl-delete-overlay[hidden]{display:none !important;}
  .kl-delete-dialog{
    width:min(540px,100%);
    border-radius:22px;
    background:#ffffff;
    border:1px solid #e5e7eb;
    box-shadow:0 24px 65px rgba(15,23,42,.24);
    padding:20px;
    color:#0f172a;
    transform:translateY(0);
    animation:klDeleteIn .14s ease-out;
  }
  @keyframes klDeleteIn{from{opacity:0;transform:translateY(8px) scale(.985);}to{opacity:1;transform:translateY(0) scale(1);}}
  .kl-delete-head{display:flex;align-items:flex-start;gap:14px;margin-bottom:12px;}
  .kl-delete-icon{width:50px;height:50px;border-radius:18px;display:grid;place-items:center;background:#fee2e2;color:#b91c1c;font-size:21px;flex:0 0 auto;}
  .kl-delete-title{font-size:18px;font-weight:900;margin:2px 0 4px;color:#7f1d1d;}
  .kl-delete-sub{font-size:14px;line-height:1.45;color:#64748b;}
  .kl-delete-body{margin-top:12px;padding:13px 14px;border-radius:16px;background:#f8fafc;border:1px solid #e2e8f0;font-size:14px;line-height:1.48;color:#334155;}
  .kl-delete-body strong{color:#0f172a;}
  .kl-delete-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:18px;}
  .kl-delete-actions button{border:0;border-radius:14px;padding:10px 15px;font-weight:850;cursor:pointer;display:inline-flex;align-items:center;gap:8px;}
  .kl-delete-actions .cancel{background:#f1f5f9;color:#0f172a;border:1px solid #e2e8f0;}
  .kl-delete-actions .danger{background:linear-gradient(135deg,#dc2626,#991b1b);color:#fff;box-shadow:0 10px 24px rgba(220,38,38,.25);}
  .kl-delete-actions button:disabled{opacity:.65;cursor:not-allowed;}
  html[data-theme="dark"] .kl-delete-overlay{background:rgba(2,6,23,.70);}
  html[data-theme="dark"] .kl-delete-dialog{background:linear-gradient(180deg,#111827,#0f172a);border-color:rgba(148,163,184,.24);color:#f8fafc;box-shadow:0 24px 70px rgba(0,0,0,.55);}
  html[data-theme="dark"] .kl-delete-icon{background:rgba(248,113,113,.14);color:#fca5a5;border:1px solid rgba(248,113,113,.24);}
  html[data-theme="dark"] .kl-delete-title{color:#fecaca;}
  html[data-theme="dark"] .kl-delete-sub{color:#cbd5e1;}
  html[data-theme="dark"] .kl-delete-body{background:rgba(15,23,42,.86);border-color:rgba(148,163,184,.22);color:#dbeafe;}
  html[data-theme="dark"] .kl-delete-body strong{color:#ffffff;}
  html[data-theme="dark"] .kl-delete-actions .cancel{background:#1f2937;color:#e5e7eb;border-color:rgba(148,163,184,.24);}
  html[data-theme="dark"] .kl-delete-actions .danger{background:linear-gradient(135deg,#ef4444,#b91c1c);box-shadow:0 10px 24px rgba(239,68,68,.22);}

  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_administradores.php')) ?>" title="Volver">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if ($flash): ?>
  <div class="flash <?= $flash['type']==='ok' ? 'ok' : 'error' ?>" style="padding:10px 12px;border-radius:8px;margin-bottom:12px;border:1px solid <?= $flash['type']==='ok'?'#bbf7d0':'#f5c2c7' ?>;background:<?= $flash['type']==='ok'?'#ecfdf5':'#fff1f0' ?>;color:<?= $flash['type']==='ok'?'#065f46':'#7a0021' ?>;">
    <?= esc($flash['msg']) ?>
  </div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
  <div class="flash error" style="padding:10px 12px;border-radius:8px;margin-bottom:12px;border:1px solid #f5c2c7;background:#fff1f0;color:#7a0021;">
    <strong>Revisa lo siguiente:</strong>
    <ul><?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?></ul>
  </div>
<?php endif; ?>

<!-- FORM principal -->
<form method="post" enctype="multipart/form-data" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($_SESSION['csrf'] ?? '') ?>">
  <input type="hidden" name="form" value="perfil">

  <!-- BLOQUE 1: Foto -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Foto de perfil</h3>
    <div style="display:flex;align-items:center;gap:16px;">
      <img id="avatar" class="avatar-big" src="<?= esc($fotoActual) ?>" alt="Foto">
      <label class="field" style="max-width:320px;">
        <span class="label">Cambiar foto</span>
        <input type="file" name="foto" id="foto" accept="image/png,image/jpeg,image/gif,image/webp">
        <div class="hint">JPG/PNG/GIF/WEBP — Máx 3MB</div>
      </label>
    </div>
  </section>

  <!-- BLOQUE 2: Datos personales -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos personales</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Nombre(s)</span>
        <input type="text" name="nombre" required minlength="2" value="<?= esc($admin['nombre'] ?? '') ?>">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" required minlength="2" value="<?= esc($admin['apellidos'] ?? '') ?>">
      </label>
      <label class="field">
        <span class="label">Correo</span>
        <input type="email" name="email" required value="<?= esc($admin['email'] ?? '') ?>">
      </label>
    </div>
  </section>

  <!-- BLOQUE 3: Acceso -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de acceso</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" required minlength="3" autocomplete="off" value="<?= esc($admin['username'] ?? '') ?>">
        <div id="unameStatus" class="avail" role="status" aria-live="polite" aria-atomic="true" style="display:none;">
          <i class="fas fa-circle-notch fa-spin"></i> Comprobando…
        </div>
      </label>

      <label class="field">
        <span class="label">Nueva contraseña (opcional)</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="pwd1" minlength="8" placeholder="Dejar vacío para no cambiar" autocomplete="new-password">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="pwd1">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <span class="hint">Mínimo 8 caracteres.</span>
      </label>

      <label class="field">
        <span class="label">Confirmar contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="pwd2" minlength="8" placeholder="Debe coincidir" autocomplete="new-password">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="pwd2">
            <i class="far fa-eye"></i>
          </button>
        </div>
      </label>
    </div>

    <div class="actions-bar">
      <div class="actions-left">
        <button id="saveBtn" class="btn primary" type="submit"><i class="fas fa-save"></i> <span class="label">Guardar cambios</span></button>
        <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_administradores.php')) ?>" title="Cancelar">
          <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
        </a>
      </div>
      <div class="actions-right">
        <a class="btn ghost btn-icon" href="#zona-peligrosa" title="Ir a eliminar">
          <i class="fas fa-triangle-exclamation"></i> <span class="label">Ir a eliminar</span>
        </a>
      </div>
    </div>
  </section>
</form>

<!-- BLOQUE 4: Zona peligrosa (eliminar) -->
<section id="zona-peligrosa" class="card danger-zone" aria-label="Zona peligrosa">
  <h3><i class="fas fa-skull-crossbones"></i>Eliminar administrador</h3>
  <p>Eliminar al administrador <strong><?= esc(($admin['nombre'] ?? '').' '.($admin['apellidos'] ?? '')) ?></strong> es una acción permanente.</p>
  <div class="danger-actions">
    <button id="btnDeleteAdmin" class="btn danger btn-icon" type="button">
      <i class="fas fa-trash"></i> <span class="label">Eliminar administrador</span>
    </button>
  </div>
</section>

<!-- Ventana de confirmación de eliminación -->
<div id="deleteConfirmOverlay" class="kl-delete-overlay" hidden aria-hidden="true">
  <div class="kl-delete-dialog" role="dialog" aria-modal="true" aria-labelledby="deleteConfirmTitle" aria-describedby="deleteConfirmText">
    <div class="kl-delete-head">
      <div class="kl-delete-icon"><i class="fas fa-triangle-exclamation"></i></div>
      <div>
        <div id="deleteConfirmTitle" class="kl-delete-title">Eliminar administrador</div>
        <div class="kl-delete-sub">Confirma la acción antes de eliminar esta cuenta.</div>
      </div>
    </div>
    <div id="deleteConfirmText" class="kl-delete-body">
      Esta acción eliminará definitivamente al administrador
      <strong><?= esc(($admin['nombre'] ?? '').' '.($admin['apellidos'] ?? '')) ?></strong>.
      No se podrá recuperar desde el sistema.
    </div>
    <div class="kl-delete-actions">
      <button type="button" class="cancel" id="cancelDel">Cancelar</button>
      <button type="button" class="danger" id="confirmDel"><i class="fas fa-trash-alt"></i> Sí, eliminar</button>
    </div>
  </div>
</div>

<script>
// Util
function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}

// Foto preview
(function(){
  const foto = document.getElementById('foto');
  const avatar = document.getElementById('avatar');
  foto?.addEventListener('change', (e)=>{
    const f = e.target.files[0];
    if (!f) return;
    if (f.size > 3*1024*1024) { alert('La imagen excede 3 MB'); e.target.value=''; return; }
    const rd = new FileReader();
    rd.onload = ()=> avatar.src = rd.result;
    rd.readAsDataURL(f);
  });
})();

// Disponibilidad de usuario
(function(){
  const unameInput = document.getElementById('username');
  const unameStatus = document.getElementById('unameStatus');
  const saveBtn = document.getElementById('saveBtn');
  let timer=null;

  function setStatus(state, text, icon){
    unameStatus.style.display='inline-flex';
    unameStatus.className = 'avail' + (state ? ' '+state : '');
    unameStatus.innerHTML = `<i class="fas ${icon}"></i> ${text}`;
  }

  async function check(u){
    if (saveBtn) saveBtn.disabled = true;
    if(!u || u.trim().length<3){
      setStatus('', 'Escribe al menos 3 caracteres.', 'fa-info-circle');
      return;
    }
    setStatus('', 'Comprobando…', 'fa-circle-notch fa-spin');
    try{
      const res = await fetch(`?ajax=username&id=<?= (int)$uid ?>&u=${encodeURIComponent(u)}`, {cache:'no-store'});
      const data = await res.json();
      if(data.ok && data.available){
        setStatus('good','Disponible','fa-check-circle');
        if (saveBtn) saveBtn.disabled = false;
      }else{
        setStatus('bad','No disponible','fa-times-circle');
        if (saveBtn) saveBtn.disabled = true;
      }
    }catch(e){
      setStatus('bad','Error al comprobar','fa-exclamation-triangle');
      if (saveBtn) saveBtn.disabled = true;
    }
  }

  unameInput?.addEventListener('input', ()=>{ clearTimeout(timer); timer = setTimeout(()=> check(unameInput.value.trim()), 300); });
  document.addEventListener('DOMContentLoaded', ()=>{ if (unameInput && unameInput.value.trim().length){ unameStatus.style.display='inline-flex'; check(unameInput.value.trim()); } });
})();

// Ojo de contraseña (mismo patrón de otras pantallas)
(function(){
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });
})();

// Eliminar administrador: confirmación propia + POST AJAX
(function(){
  const btnDelete = document.getElementById('btnDeleteAdmin');
  const overlay   = document.getElementById('deleteConfirmOverlay');
  const btnOK     = document.getElementById('confirmDel');
  const btnCancel = document.getElementById('cancelDel');
  const originalOk = '<i class="fas fa-trash-alt"></i> Sí, eliminar';

  if (!btnDelete || !overlay || !btnOK || !btnCancel) return;

  function openDeleteConfirm(){
    overlay.hidden = false;
    overlay.setAttribute('aria-hidden','false');
    btnOK.disabled = false;
    btnOK.innerHTML = originalOk;
    setTimeout(()=>btnCancel.focus(), 0);
  }

  function closeDeleteConfirm(){
    overlay.hidden = true;
    overlay.setAttribute('aria-hidden','true');
    btnOK.disabled = false;
    btnOK.innerHTML = originalOk;
  }

  btnDelete.addEventListener('click', openDeleteConfirm);
  btnCancel.addEventListener('click', closeDeleteConfirm);
  overlay.addEventListener('click', (ev)=>{ if(ev.target === overlay) closeDeleteConfirm(); });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && !overlay.hidden) closeDeleteConfirm(); });

  btnOK.addEventListener('click', async ()=>{
    btnOK.disabled = true;
    btnOK.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
    try{
      const res = await fetch('?ajax=delete_admin', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
          id:'<?= (int)$uid ?>',
          csrf:'<?= esc($_SESSION['csrf'] ?? '') ?>'
        })
      });
      const data = await res.json();
      if (!data.ok) {
        alert(data.msg || 'No se pudo eliminar.');
        btnOK.disabled = false;
        btnOK.innerHTML = originalOk;
        return;
      }
      window.location.href = <?= json_encode(base_url('admin/gestionar_administradores.php?ok=del')) ?>;
    } catch(e){
      alert('Error inesperado al eliminar.');
      btnOK.disabled = false;
      btnOK.innerHTML = originalOk;
    }
  });
})();
</script>

<?php
/* =========================
   FOOTER (parcial existente)
   ========================= */
require __DIR__ . '/partials/footer.php';
