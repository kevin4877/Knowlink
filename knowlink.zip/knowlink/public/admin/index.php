<?php
// public/admin/index.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad básica
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// ==== Utils locales compatibles con el header ====
if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}
/**
 * foto_src: normaliza a URL web ABSOLUTA lista para <img>.
 * Acepta: /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    while (str_starts_with($u, '../')) { $u = substr($u, 3); }
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}
// Polyfill PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

$pdo = db();

/* =========================================
   AJAX: KPIs del tablero
   ========================================= */
if (isset($_GET['ajax']) && $_GET['ajax']==='stats') {
  header('Content-Type: application/json; charset=utf-8');
  try {
    $q = fn($sql) => (int)$pdo->query($sql)->fetchColumn();
    $stats = [
      'estudiantes'     => $q("SELECT COUNT(*) FROM usuarios WHERE rol='estudiante'"),
      'docentes'        => $q("SELECT COUNT(*) FROM usuarios WHERE rol='docente'"),
      'administradores' => $q("SELECT COUNT(*) FROM usuarios WHERE rol='administrador'"),
      'carreras'        => $q("SELECT COUNT(*) FROM carreras"),
      'materias'        => $q("SELECT COUNT(*) FROM materias"),
      'reticulas'       => $q("SELECT COUNT(*) FROM reticulas"),
      'contenidos'      => $q("SELECT COUNT(*) FROM contenidos"),
    ];

    // últimos 5 usuarios (con foto normalizada)
    $st = $pdo->query("
      SELECT id, nombre, apellidos, rol, foto_url,
             DATE_FORMAT(creado_en, '%Y-%m-%d %H:%i:%s') AS creado_en
      FROM usuarios
      ORDER BY creado_en DESC
      LIMIT 5
    ");
    $ultimosUsuarios = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    foreach ($ultimosUsuarios as &$u) {
      $u['foto'] = foto_src($u['foto_url'] ?? null);
    } unset($u);

    echo json_encode(['ok'=>true,'stats'=>$stats,'ultimosUsuarios'=>$ultimosUsuarios], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
  } catch (Throwable $e) {
    echo json_encode(['ok'=>false,'err'=>'No se pudieron obtener las métricas']);
  }
  exit;
}

/* =========================================
   AJAX: Actividad reciente (admin_eventos)
   ========================================= */
if (isset($_GET['ajax']) && $_GET['ajax']==='feed') {
  header('Content-Type: application/json; charset=utf-8');
  try {
    $limit = max(5, min(30, (int)($_GET['limit'] ?? 10)));
    $st = $pdo->prepare("
      SELECT id, tipo, referencia, descripcion,
             DATE_FORMAT(creado_en, '%Y-%m-%d %H:%i:%s') AS creado_en
      FROM admin_eventos
      ORDER BY creado_en DESC
      LIMIT :lim
    ");
    $st->bindValue(':lim', $limit, PDO::PARAM_INT);
    $st->execute();
    $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
    echo json_encode(['ok'=>true,'items'=>$rows], JSON_UNESCAPED_UNICODE);
  } catch (Throwable $e) {
    echo json_encode(['ok'=>false,'err'=>'No se pudo cargar la actividad']);
  }
  exit;
}

// ======== Vista ========
$title  = 'KnowLink · Administrador · Inicio';
$active = 'index';
require __DIR__ . '/partials/header.php';
?>

  <style>
    /* Estilos del tablero (solo esta página) */

    /* Bloques pensados para móvil/tablet. En computadora se ocultan para no duplicar el menú lateral. */
    .admin-mobile-tablet-only{ display:none; }
    @media (max-width: 1024px){
      .admin-mobile-tablet-only{ display:block; }
    }
    .grid-kpi{
      display:grid;
      grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
      gap:12px;
    }
    .kpi{
      background:#fff; border:1px solid #e6eef2; border-radius:12px;
      padding:14px; box-shadow:0 8px 24px rgba(2,6,23,.04);
      display:flex; align-items:center; gap:12px;
    }
    .kpi .ico{
      width:40px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center;
      background:#f1f5ff; color:#0055d4;
    }
    .kpi .txt{ line-height:1.15; }
    .kpi .txt .n{ font-size:20px; font-weight:900; color:#0b2545; }
    .kpi .txt .l{ font-size:12px; color:#6b7280; }

    .quick-actions{ display:flex; flex-wrap:wrap; gap:10px; }

    .academic-actions{
      display:grid;
      grid-template-columns:repeat(3,minmax(0,1fr));
      gap:14px;
    }
    .academic-action{
      position:relative;
      min-height:128px;
      overflow:hidden;
      border-radius:18px;
      padding:18px;
      display:flex;
      flex-direction:column;
      justify-content:space-between;
      text-decoration:none;
      color:#fff;
      isolation:isolate;
      box-shadow:0 16px 36px rgba(15,23,42,.14);
      transition:transform .16s ease, box-shadow .16s ease, filter .16s ease;
    }
    .academic-action::before,
    .academic-action::after{
      content:"";
      position:absolute;
      border-radius:999px;
      background:rgba(255,255,255,.18);
      z-index:-1;
    }
    .academic-action::before{width:130px;height:130px;right:-42px;top:-46px;}
    .academic-action::after{width:76px;height:76px;left:-24px;bottom:-30px;}
    .academic-action:hover{transform:translateY(-3px);box-shadow:0 20px 42px rgba(15,23,42,.20);filter:saturate(1.06);color:#fff;}
    .academic-action .top{display:flex;align-items:center;justify-content:space-between;gap:10px;}
    .academic-action .ico{width:46px;height:46px;border-radius:16px;background:rgba(255,255,255,.20);display:flex;align-items:center;justify-content:center;font-size:20px;}
    .academic-action .go{width:34px;height:34px;border-radius:999px;background:rgba(255,255,255,.18);display:flex;align-items:center;justify-content:center;}
    .academic-action .title{font-size:18px;font-weight:950;line-height:1.15;margin-top:16px;}
    .academic-action .desc{font-size:13px;font-weight:700;opacity:.90;line-height:1.35;margin-top:6px;}
    .academic-action.carreras{background:linear-gradient(135deg,#0f766e,#14b8a6);}
    .academic-action.reticulas{background:linear-gradient(135deg,#1d4ed8,#06b6d4);}
    .academic-action.materias{background:linear-gradient(135deg,#7c3aed,#ec4899);}

    html[data-theme="dark"] .kpi,
    html[data-theme="dark"] .btn.ghost{
      background:#0f172a;
      border-color:rgba(148,163,184,.22);
      color:#e5edf7;
    }
    html[data-theme="dark"] .card h3,
    html[data-theme="dark"] .kpi .txt .n,
    html[data-theme="dark"] .feed .txt .t{
      color:#f8fafc;
    }
    html[data-theme="dark"] .kpi .txt .l,
    html[data-theme="dark"] .feed .txt .m,
    html[data-theme="dark"] .muted{
      color:#94a3b8;
    }

    @media (max-width: 1000px){
      .academic-actions{grid-template-columns:1fr;}
      .academic-action{min-height:112px;padding:16px;}
      .academic-action .title{font-size:17px;margin-top:12px;}
      .admin-home-split{grid-template-columns:1fr !important;}
      .admin-home-split > div:first-child{border-right:0 !important;border-bottom:1px solid #eef2f6;}
      html[data-theme="dark"] .admin-home-split > div:first-child{border-bottom-color:rgba(148,163,184,.18) !important;}
    }

    .btn.primary{ background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; }
    .btn.ghost{ background:#fff; border:1px solid #e6eef2; color:#0b2545; }
    .btn{ padding:10px 14px; border-radius:10px; border:0; cursor:pointer; font-weight:800; display:inline-flex; align-items:center; gap:8px; text-decoration:none; }

    .feed .item{ display:flex; gap:10px; align-items:flex-start; padding:10px 6px; border-bottom:1px dashed #eef2f6; }
    .feed .item:last-child{ border-bottom:0; }
    .feed .ico{ width:28px; height:28px; border-radius:8px; display:flex; align-items:center; justify-content:center; background:#f1f5ff; color:#0055d4; }
    .feed .txt .t{ font-weight:800; color:#0b2545; }
    .feed .txt .m{ font-size:13px; color:#64748b; }

    .list-mini li{ display:flex; justify-content:space-between; gap:10px; padding:8px 0; border-bottom:1px dashed #eef2f6; align-items:center; }
    .list-mini li:last-child{ border-bottom:0; }
    .list-mini .who{ display:flex; align-items:center; gap:10px; }
    .mini-avatar{ width:28px; height:28px; border-radius:50%; object-fit:cover; background:#eef3f6; }
    .muted{ color:#6b7280; }
  </style>

  <div class="page-header admin-mobile-tablet-only">
    <div>
      <div class="page-title">Panel general</div>
      <div class="page-sub">Bienvenido, <?= esc($yo['nombre'] ?? 'Administrador') ?>.</div>
    </div>
  </div>

  <!-- KPIs -->
  <section class="card admin-mobile-tablet-only">
    <h3 style="font-size:16px;margin-bottom:10px;color:#0b2545;">Resumen de la plataforma</h3>
    <div class="grid-kpi" id="kpis">
      <div class="kpi"><div class="ico"><i class="fas fa-user-graduate"></i></div><div class="txt"><div class="n" id="k_estudiantes">—</div><div class="l">Estudiantes</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-chalkboard-teacher"></i></div><div class="txt"><div class="n" id="k_docentes">—</div><div class="l">Docentes</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-user-shield"></i></div><div class="txt"><div class="n" id="k_admins">—</div><div class="l">Administradores</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-graduation-cap"></i></div><div class="txt"><div class="n" id="k_carreras">—</div><div class="l">Carreras</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-book"></i></div><div class="txt"><div class="n" id="k_materias">—</div><div class="l">Materias</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-diagram-project"></i></div><div class="txt"><div class="n" id="k_reticulas">—</div><div class="l">Retículas</div></div></div>
      <div class="kpi"><div class="ico"><i class="fas fa-file-alt"></i></div><div class="txt"><div class="n" id="k_contenidos">—</div><div class="l">Contenidos</div></div></div>
    </div>
  </section>

  <!-- Gestión académica visible en celular y tablet -->
  <section class="card admin-mobile-tablet-only">
    <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:14px;">
      <div>
        <h3 style="font-size:16px;margin-bottom:4px;color:#0b2545;">Gestión académica</h3>
        <div class="muted" style="font-size:13px;">Accesos directos para administrar la estructura académica de KnowLink.</div>
      </div>
    </div>
    <div class="academic-actions">
      <a class="academic-action carreras" href="<?= esc(base_url('admin/gestionar_carreras.php')) ?>">
        <div class="top"><span class="ico"><i class="fas fa-graduation-cap"></i></span><span class="go"><i class="fas fa-arrow-right"></i></span></div>
        <div><div class="title">Gestionar carreras</div><div class="desc">Crear, editar y revisar carreras disponibles.</div></div>
      </a>
      <a class="academic-action reticulas" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
        <div class="top"><span class="ico"><i class="fas fa-diagram-project"></i></span><span class="go"><i class="fas fa-arrow-right"></i></span></div>
        <div><div class="title">Gestionar retículas</div><div class="desc">Organizar semestres y asignar materias a cada plan.</div></div>
      </a>
      <a class="academic-action materias" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>">
        <div class="top"><span class="ico"><i class="fas fa-book"></i></span><span class="go"><i class="fas fa-arrow-right"></i></span></div>
        <div><div class="title">Gestionar materias</div><div class="desc">Crear materias, unidades y revisar contenidos.</div></div>
      </a>
    </div>
  </section>


  <!-- Doble columna: actividad & últimos usuarios -->
  <section class="card" style="padding:0;">
    <div class="admin-home-split" style="display:grid; grid-template-columns: 2fr 1fr; gap:0;">
      <div style="padding:16px; border-right:1px solid #eef2f6;">
        <h3 style="font-size:16px;margin-bottom:10px;color:#0b2545;">Actividad reciente</h3>
        <div id="feed" class="feed">
          <div class="muted">Cargando actividad…</div>
        </div>
        <div style="margin-top:8px;">
          <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>"><i class="fas fa-diagram-project"></i> Ver retículas</a>
          <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>"><i class="fas fa-book"></i> Ver materias</a>
        </div>
      </div>
      <div style="padding:16px;">
        <h3 style="font-size:16px;margin-bottom:10px;color:#0b2545;">Últimos usuarios</h3>
        <ul id="ultimosUsuarios" class="list-mini">
          <li class="muted">Cargando…</li>
        </ul>
      </div>
    </div>
  </section>

  <!-- Ayuda / enlaces -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:10px;color:#0b2545;">Atajos</h3>
    <div class="quick-actions">
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_alumnos.php')) ?>"><i class="fas fa-user-graduate"></i> Gestionar estudiantes</a>
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_docentes.php')) ?>"><i class="fas fa-chalkboard-teacher"></i> Gestionar docentes</a>
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_administradores.php')) ?>"><i class="fas fa-user-shield"></i> Gestionar administradores</a>
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_carreras.php')) ?>"><i class="fas fa-graduation-cap"></i> Gestionar carreras</a>
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>"><i class="fas fa-diagram-project"></i> Gestionar retículas</a>
      <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_materias.php')) ?>"><i class="fas fa-book"></i> Gestionar materias</a>
    </div>
  </section>

  <script>
    const F = new Intl.NumberFormat('es-MX');
    function setText(id, val){ const el=document.getElementById(id); if(el) el.textContent = F.format(val ?? 0); }
    function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

    async function loadStats(){
      try{
        const r = await fetch('?ajax=stats', {cache:'no-store'});
        const data = await r.json();
        if(!data.ok) throw new Error();
        const k = data.stats || {};
        setText('k_estudiantes', k.estudiantes);
        setText('k_docentes', k.docentes);
        setText('k_admins', k.administradores);
        setText('k_carreras', k.carreras);
        setText('k_materias', k.materias);
        setText('k_reticulas', k.reticulas);
        setText('k_contenidos', k.contenidos);

        const ul = document.getElementById('ultimosUsuarios');
        const items = data.ultimosUsuarios || [];
        if (!items.length){ ul.innerHTML = '<li class="muted">Sin datos</li>'; return; }
        ul.innerHTML = items.map(u=>{
          const nombre = escapeHtml(((u.nombre||'') + ' ' + (u.apellidos||'')).trim() || ('Usuario #' + (u.id||'')));
          const rol = escapeHtml(u.rol||'');
          const fecha = escapeHtml(u.creado_en||'');
          const foto = escapeHtml(u.foto || '');
          return `<li>
            <span class="who">
              <img class="mini-avatar" src="${foto}" alt="">
              <span>${nombre} <span class="muted">· ${rol}</span></span>
            </span>
            <span class="muted">${fecha}</span>
          </li>`;
        }).join('');
      }catch(e){
        ['k_estudiantes','k_docentes','k_admins','k_carreras','k_materias','k_reticulas','k_contenidos'].forEach(id=>{ const el=document.getElementById(id); if(el) el.textContent='—'; });
        const ul = document.getElementById('ultimosUsuarios');
        ul.innerHTML = '<li class="muted">Error al cargar.</li>';
      }
    }

    function iconFor(tipo){
      return tipo==='reticula' ? 'fa-diagram-project' : (tipo==='materia' ? 'fa-book' : 'fa-graduation-cap');
    }

    async function loadFeed(){
      const feed = document.getElementById('feed');
      try{
        const r = await fetch('?ajax=feed&limit=10', {cache:'no-store'});
        const data = await r.json();
        const items = data.items || [];
        if (!items.length){
          feed.innerHTML = '<div class="muted">Sin actividad reciente.</div>';
          return;
        }
        feed.innerHTML = items.map(it=>{
          const ico = iconFor(it.tipo||'');
          const desc = escapeHtml(it.descripcion||'');
          const meta = (escapeHtml(it.tipo||'') + (it.creado_en ? ' · '+escapeHtml(it.creado_en) : ''));
          return `<div class="item">
            <div class="ico"><i class="fas ${ico}"></i></div>
            <div class="txt">
              <div class="t">${desc}</div>
              <div class="m">${meta}</div>
            </div>
          </div>`;
        }).join('');
      }catch(e){
        feed.innerHTML = '<div class="muted" style="color:#b91c1c">Error al cargar actividad.</div>';
      }
    }

    // Carga inicial
    loadStats();
    loadFeed();
    // Refrescar feed cada 30s
    setInterval(loadFeed, 30000);
  </script>

<?php
require __DIR__ . '/partials/footer.php';
