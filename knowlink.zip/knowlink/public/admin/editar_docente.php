<?php
// public/admin/editar_docente.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Cabeceras seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// ===== Placeholder + normalizador de rutas de foto (como en alumnos/docentes registro) =====
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('str_starts_with')) { // polyfill PHP < 8
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('foto_src')) {
  /**
   * Normaliza a URL web ABSOLUTA para <img src="...">
   * Acepta: /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
   */
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    while (str_starts_with($u,'../')) $u = substr($u,3);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path,'/')) : $path;
  }
}
function buildFotoUrl(?string $url): string { return foto_src($url); }

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();

/* =========================================================
   Helper de notificaciones para docentes
   ========================================================= */
if (!function_exists('notify_docente')) {
  function notify_docente(PDO $pdo, int $docente_id, string $tipo, string $descripcion): void {
    // Crear tabla si no existe (idempotente)
    $pdo->exec("
      CREATE TABLE IF NOT EXISTS docente_notifs (
        id INT AUTO_INCREMENT PRIMARY KEY,
        docente_id INT NOT NULL,
        tipo VARCHAR(32) NOT NULL,
        descripcion VARCHAR(255) NOT NULL,
        creado_en DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        INDEX idx_docente_fecha (docente_id, creado_en),
        INDEX idx_docente_id (docente_id, id)
      ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");
    // Insertar notificación
    $st = $pdo->prepare("INSERT INTO docente_notifs (docente_id, tipo, descripcion) VALUES (:d,:t,:desc)");
    $st->execute([':d'=>$docente_id, ':t'=>$tipo, ':desc'=>$descripcion]);
  }
}

// ====== Carga docente
$uid = (int)($_GET['id'] ?? ($_SESSION['edit_docente_id'] ?? 0));
if ($uid <= 0) { http_response_code(400); echo "Falta parámetro id"; exit; }

$sqlDoc = "SELECT u.id, u.nombre, u.apellidos, u.username, u.email, u.foto_url, u.rol, u.creado_en
           FROM usuarios u
           WHERE u.id = :id
           LIMIT 1";
$st = $pdo->prepare($sqlDoc);
$st->execute([':id'=>$uid]);
$docente = $st->fetch(PDO::FETCH_ASSOC);
if (!$docente || ($docente['rol'] ?? '') !== 'docente') {
  http_response_code(404); echo "Docente no encontrado."; exit;
}

// Contador de contenidos
$stCnt = $pdo->prepare("SELECT COUNT(*) FROM contenidos WHERE docente_id = :id");
$stCnt->execute([':id'=>$uid]);
$cntCont = (int)$stCnt->fetchColumn();

/* =========================================================
   AJAX internos
   ========================================================= */
if (isset($_GET['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');
  $action = $_GET['ajax'];

  // Comprobar username
  if ($action === 'username') {
    $u = trim((string)($_GET['u'] ?? ''));
    $ok = false; $available = false;
    if ($u !== '' && mb_strlen($u) >= 3) {
      $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u AND id <> :id");
      $st->execute([':u'=>$u, ':id'=>$uid]);
      $available = ((int)$st->fetchColumn() === 0);
      $ok = true;
    }
    echo json_encode(['ok'=>$ok, 'available'=>$available], JSON_UNESCAPED_UNICODE);
    exit;
  }

  // Listar permisos actuales
  if ($action === 'list_perms') {
    $q = $pdo->prepare("SELECT dpm.materia_clave, m.nombre
                        FROM docente_permisos_materia dpm
                        LEFT JOIN materias m ON LOWER(m.clave) = LOWER(dpm.materia_clave)
                        WHERE dpm.docente_id = :d
                        ORDER BY dpm.materia_clave ASC");
    $q->execute([':d'=>$uid]);
    $rows = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
    echo json_encode(['ok'=>true,'items'=>$rows], JSON_UNESCAPED_UNICODE); exit;
  }

  // Buscar materias
  if ($action === 'search_materias') {
    $qstr = trim((string)($_GET['q'] ?? ''));
    if ($qstr === '') { echo json_encode(['ok'=>true,'items'=>[]]); exit; }
    $qs = "%$qstr%";
    $q = $pdo->prepare("SELECT m.clave, m.nombre,
               EXISTS(SELECT 1 FROM docente_permisos_materia p WHERE p.docente_id=:d AND LOWER(p.materia_clave)=LOWER(m.clave)) AS ya
               FROM materias m
               WHERE m.clave LIKE :q OR m.nombre LIKE :q
               ORDER BY (m.clave = :qExact) DESC, m.clave ASC
               LIMIT 20");
    $q->execute([':d'=>$uid, ':q'=>$qs, ':qExact'=>$qstr]);
    $rows = $q->fetchAll(PDO::FETCH_ASSOC) ?: [];
    echo json_encode(['ok'=>true,'items'=>$rows], JSON_UNESCAPED_UNICODE); exit;
  }

  // Agregar permiso
  if ($action === 'add_perm' && $_SERVER['REQUEST_METHOD']==='POST') {
    if (!hash_equals($CSRF, $_POST['csrf'] ?? '')) { echo json_encode(['ok'=>false,'err'=>'CSRF']); exit; }
    $refMateria = trim((string)($_POST['materia_clave'] ?? ''));
    $clave = $refMateria !== '' ? resolve_materia_clave($pdo, $refMateria) : null;
    if (!$clave) { echo json_encode(['ok'=>false,'err'=>'Materia no existe']); exit; }
    try {
      $ins = $pdo->prepare("INSERT IGNORE INTO docente_permisos_materia (docente_id, materia_clave) VALUES (:d,:c)");
      $ins->execute([':d'=>$uid, ':c'=>$clave]);

      // Notificación al docente solo si realmente se insertó
      if ($ins->rowCount() > 0) {
        try { notify_docente($pdo, $uid, 'permiso', "Se te asignó la materia {$clave}."); } catch (Throwable $e) {}
      }

      echo json_encode(['ok'=>true]); exit;
    } catch(Throwable $e) {
      echo json_encode(['ok'=>false,'err'=>'No se pudo agregar']); exit;
    }
  }

  // Eliminar permiso
  if ($action === 'del_perm' && $_SERVER['REQUEST_METHOD']==='POST') {
    if (!hash_equals($CSRF, $_POST['csrf'] ?? '')) { echo json_encode(['ok'=>false,'err'=>'CSRF']); exit; }
    $refMateria = trim((string)($_POST['materia_clave'] ?? ''));
    $clave = $refMateria !== '' ? (resolve_materia_clave($pdo, $refMateria) ?: $refMateria) : '';
    try {
      $del = $pdo->prepare("DELETE FROM docente_permisos_materia WHERE docente_id=:d AND LOWER(materia_clave)=LOWER(:c)");
      $del->execute([':d'=>$uid, ':c'=>$clave]);

      // Notificación al docente solo si realmente se eliminó
      if ($del->rowCount() > 0) {
        try { notify_docente($pdo, $uid, 'permiso', "Se te retiró la materia {$clave}."); } catch (Throwable $e) {}
      }

      echo json_encode(['ok'=>true]); exit;
    } catch(Throwable $e) {
      echo json_encode(['ok'=>false,'err'=>'No se pudo eliminar']); exit;
    }
  }

  echo json_encode(['ok'=>false,'err'=>'Acción inválida']); exit;
}

// ====== AJAX: Eliminar DOCENTE (se mantiene, solo la foto no es editable aquí) ======
if (isset($_POST['ajax']) && $_POST['ajax']==='delete_docente') {
  header('Content-Type: application/json; charset=utf-8');
  $csrf = (string)($_POST['csrf'] ?? '');
  $id   = (int)($_POST['id'] ?? 0);
  if (!hash_equals($CSRF, $csrf)) { echo json_encode(['ok'=>false,'msg'=>'CSRF inválido']); exit; }
  if ($id !== $uid || $id<=0)     { echo json_encode(['ok'=>false,'msg'=>'ID inválido']); exit; }

  try {
    $st = $pdo->prepare("SELECT rol FROM usuarios WHERE id=:id LIMIT 1");
    $st->execute([':id'=>$id]);
    $rol = $st->fetchColumn();
    if ($rol !== 'docente') { echo json_encode(['ok'=>false,'msg'=>'Solo se pueden eliminar docentes.']); exit; }

    $pdo->beginTransaction();
    $pdo->prepare("DELETE FROM usuarios WHERE id=:id")->execute([':id'=>$id]);
    $pdo->commit();
    echo json_encode(['ok'=>true]);
  } catch(Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo json_encode(['ok'=>false,'msg'=>'No se pudo eliminar.']);
  }
  exit;
}

// ====== Guardado de datos (SIN edición de foto) ======
$flash = null;
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form'] ?? '') === 'perfil') {
  if (!hash_equals($CSRF, $_POST['csrf'] ?? '')) { $errors[] = 'CSRF inválido. Refresca la página.'; }

  $nombre    = trim((string)($_POST['nombre'] ?? ''));
  $apellidos = trim((string)($_POST['apellidos'] ?? ''));
  $username  = trim((string)($_POST['username'] ?? ''));
  $email     = trim((string)($_POST['email'] ?? ''));
  $pass1     = (string)($_POST['password'] ?? '');
  $pass2     = (string)($_POST['password2'] ?? '');

  if ($nombre==='' || mb_strlen($nombre)<2)      $errors[] = 'Nombre inválido.';
  if ($apellidos==='' || mb_strlen($apellidos)<2)$errors[] = 'Apellidos inválidos.';
  if ($email==='' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Correo inválido.';
  if ($username==='' || mb_strlen($username)<3)  $errors[] = 'Usuario mínimo 3 caracteres.';

  if ($pass1!=='' || $pass2!=='') {
    if ($pass1!==$pass2) $errors[] = 'Las contraseñas no coinciden.';
    if ($pass1!=='' && mb_strlen($pass1)<8) $errors[] = 'La nueva contraseña debe tener al menos 8 caracteres.';
  }

  // Unicidad
  if (!$errors) {
    $qU = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u AND id<>:id");
    $qU->execute([':u'=>$username, ':id'=>$uid]);
    if ((int)$qU->fetchColumn() > 0) $errors[] = 'El username ya está en uso.';

    $qE = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e AND id<>:id");
    $qE->execute([':e'=>$email, ':id'=>$uid]);
    if ((int)$qE->fetchColumn() > 0) $errors[] = 'El correo ya está en uso.';
  }

  // >>> Importante: aquí NO se procesa subida de foto (deshabilitado en esta vista).

  if (!$errors) {
    try {
      $pdo->beginTransaction();
      // No tocamos foto_url
      $stU = $pdo->prepare("UPDATE usuarios
                            SET nombre=:n, apellidos=:a, username=:u, email=:e, actualizado_en=NOW()
                            WHERE id=:id");
      $stU->execute([':n'=>$nombre, ':a'=>$apellidos, ':u'=>$username, ':e'=>$email, ':id'=>$uid]);

      if ($pass1!=='') {
        $hash = password_hash($pass1, PASSWORD_BCRYPT, ['cost'=>10]);
        $pdo->prepare("UPDATE usuarios SET password_hash=:ph WHERE id=:id")
            ->execute([':ph'=>$hash, ':id'=>$uid]);
      }

      $pdo->commit();
      $flash = ['type'=>'ok','msg'=>'Datos del docente actualizados correctamente.'];

      // Refrescar datos
      $st = $pdo->prepare($sqlDoc);
      $st->execute([':id'=>$uid]);
      $docente = $st->fetch(PDO::FETCH_ASSOC);

      // --- Notificación al docente por cambio de perfil ---
      try {
        notify_docente($pdo, $uid, 'perfil', 'Tu perfil fue actualizado por Administración.');
      } catch (Throwable $e) { /* silencioso */ }

    } catch(Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'Error al guardar los cambios.';
    }
  }
}

$fotoActual = buildFotoUrl($docente['foto_url'] ?? null);

/* =========================
   HEADER (parcial existente)
   ========================= */
$active   = 'docentes';
$title    = 'ITZ KnowLink - Administrador · Editar docente';
$h1       = 'Editar Docente';
$subtitle = 'Actualizar datos y gestionar permisos de materias';

/* Variantes típicas */
$HEADER_TITLE  = $h1;
$HEADER_SUB    = $subtitle;
$PAGE_TITLE    = $title;
$header_title  = $h1;
$header_sub    = $subtitle;
$page_title    = $title;
$page_h1       = $h1;
$page_h2       = $subtitle;
$PAGE_H1       = $h1;
$PAGE_SUBTITLE = $subtitle;

/* Menú activo en otras variantes */
$MENU_ACTIVE     = $active;
$ACTIVE_MENU     = $active;
$ACTIVE_SECTION  = $active;
$CURRENT_SECTION = $active;

/* Constantes si algunos parciales las usan */
if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

/* incluye el header */
require __DIR__ . '/partials/header.php';
?>

<!-- Estilos específicos de esta página -->
<style>
  .page-header{ display:flex; align-items:center; justify-content:space-between; gap:12px; margin-bottom:18px; }
  .page-title{ font-size:20px; font-weight:800; color:#0b2545; }
  .page-sub{ color:#6b7280; font-size:14px; }

  .card{ background:#fff; border-radius:12px; padding:16px; box-shadow:0 10px 30px rgba(2,6,23,0.06); margin-bottom:14px; }
  .form-grid{ display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:12px; margin-top:12px; }
  label.field{ display:flex; flex-direction:column; gap:8px; }
  input[type="text"],input[type="email"],input[type="password"],select{ width:100%; padding:10px 12px; border-radius:8px; border:1px solid #e6eef2; outline:none; font-size:14px; background:#fbfdfe; }
  .btn{ padding:10px 14px; border-radius:10px; border:0; cursor:pointer; font-weight:800; }
  .btn.primary{ background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; }
  .btn.ghost{ background:#fff; border:1px solid #e6eef2; color:#0b2545; }
  .btn.danger{ background:#fee2e2; color:#991b1b; border:1px solid #fecaca; }
  .btn.small{ padding:6px 10px; border-radius:8px; font-weight:700; }
  .btn-icon{ display:inline-flex; align-items:center; gap:8px; }
  a.btn.ghost.btn-icon{ text-decoration:none; }
  a.btn.ghost.btn-icon:hover, a.btn.ghost.btn-icon:focus{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }

  .flash{ padding:10px 12px; border-radius:8px; margin-bottom:12px; font-size:14px; }
  .flash.ok{ background:#ecfdf5; border:1px solid #bbf7d0; color:#065f46; }
  .flash.error{ background:#fff1f0; border:1px solid #f5c2c7; color:#7a0021; }

  .avatar-big{ width:96px; height:96px; border-radius:999px; object-fit:cover; background:#eef3f6; border:4px solid #eef7f8; }
  .tag{ display:inline-flex; align-items:center; gap:6px; padding:4px 8px; border-radius:999px; border:1px solid #e2ebff; background:#f1f5ff; color:#0055d4; font-size:12px; }

  .searchbox{ display:flex; gap:8px; align-items:center; }
  .searchbox input{ flex:1; }
  .results{ margin-top:10px; border:1px solid #e6eef2; border-radius:10px; overflow:hidden; display:none; }
  .res-item{ display:flex; justify-content:space-between; gap:10px; padding:8px 10px; background:#fff; }
  .res-item:nth-child(odd){ background:#f8fafc; }
  .list{ display:flex; flex-direction:column; margin-top:8px; border-top:1px dashed #eef2f6; }
  .row{ display:flex; align-items:center; justify-content:space-between; gap:12px; padding:10px 6px; border-bottom:1px dashed #eef2f6; }
  .row:last-child{ border-bottom:0; }

  .avail { display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:10px; font-weight:800; margin-top:6px; border:1px solid #e6eef2; background:#f3f6f9; color:#0b2545; }
  .avail.good { background:#ecfdf5; border-color:#bbf7d0; color:#065f46; }
  .avail.bad  { background:#fff1f0; border-color:#f5c2c7; color:#7a0021; }

  .pwd-wrap{ position:relative; }
  .pwd-wrap input{ padding-right:42px; }
  .toggle-eye{
    position:absolute; right:8px; top:50%; transform:translateY(-50%);
    background:transparent; border:0; cursor:pointer; font-size:16px; color:#6b7280; padding:6px; border-radius:8px;
  }
  .toggle-eye:hover{ background:#f3f6f9; color:#0b2545; }

  .pw-meter{ height:8px; width:100%; background:#eef2f7; border-radius:999px; overflow:hidden; margin-top:6px; }
  .pw-meter > div{ height:8px; width:0%; background:#ef4444; transition: width .2s ease; }
  .pw-tip{ font-size:12px; color:#6b7280; margin-top:6px; }
  .pulse{ animation: pwpulse .35s ease; }
  @keyframes pwpulse { from{ transform:scale(1.02);} to{ transform:scale(1);} }

  .actions-bar{ display:flex; align-items:center; justify-content:space-between; gap:10px; flex-wrap:wrap; margin-top:12px; }
  .actions-left{ display:flex; gap:8px; flex-wrap:wrap; }
  .actions-right{ display:flex; gap:8px; }

  .danger-zone{ border:1px solid #fecaca; background:#fff1f0; color:#7a0021; }
  .danger-zone h3{ font-size:16px; margin-bottom:6px; }
  .danger-zone p{ font-size:14px; color:#7a0021; }
  .danger-actions{ display:flex; justify-content:flex-end; margin-top:10px; }
  .danger-actions .btn.danger{ border-color:#fca5a5; }
  .danger-actions .btn.danger:hover{ filter:brightness(.98); transform: translateY(-1px); }
  html[data-theme="dark"] .danger-zone{background:rgba(127,29,29,.16) !important;border-color:rgba(248,113,113,.30) !important;color:#fecaca !important;}
  html[data-theme="dark"] .danger-zone h3{color:#fecaca !important;}
  html[data-theme="dark"] .danger-zone p{color:#fca5a5 !important;}
  html[data-theme="dark"] .btn.danger{background:rgba(239,68,68,.16);color:#fecaca;border-color:rgba(248,113,113,.34);}
  html[data-theme="dark"] .btn.danger:hover{background:rgba(239,68,68,.22);}

  /* Confirmación de eliminación: clases propias para no chocar con .modal global/Bootstrap */
  .kl-delete-overlay{
    position:fixed;
    inset:0;
    z-index:6000;
    display:grid;
    place-items:center;
    padding:18px;
    background:rgba(15,23,42,.52);
    backdrop-filter:blur(7px);
    -webkit-backdrop-filter:blur(7px);
  }
  .kl-delete-overlay[hidden]{display:none !important;}
  .kl-delete-dialog{
    width:min(540px,100%);
    border-radius:22px;
    background:#ffffff;
    border:1px solid #e5e7eb;
    box-shadow:0 24px 65px rgba(15,23,42,.24);
    padding:20px;
    color:#0f172a;
    transform:translateY(0);
    animation:klDeleteIn .14s ease-out;
  }
  @keyframes klDeleteIn{from{opacity:0;transform:translateY(8px) scale(.985);}to{opacity:1;transform:translateY(0) scale(1);}}
  .kl-delete-head{display:flex;align-items:flex-start;gap:14px;margin-bottom:12px;}
  .kl-delete-icon{width:50px;height:50px;border-radius:18px;display:grid;place-items:center;background:#fee2e2;color:#b91c1c;font-size:21px;flex:0 0 auto;}
  .kl-delete-title{font-size:18px;font-weight:900;margin:2px 0 4px;color:#7f1d1d;}
  .kl-delete-sub{font-size:14px;line-height:1.45;color:#64748b;}
  .kl-delete-body{margin-top:12px;padding:13px 14px;border-radius:16px;background:#f8fafc;border:1px solid #e2e8f0;font-size:14px;line-height:1.48;color:#334155;}
  .kl-delete-body strong{color:#0f172a;}
  .kl-delete-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:18px;}
  .kl-delete-actions button{border:0;border-radius:14px;padding:10px 15px;font-weight:850;cursor:pointer;display:inline-flex;align-items:center;gap:8px;}
  .kl-delete-actions .cancel{background:#f1f5f9;color:#0f172a;border:1px solid #e2e8f0;}
  .kl-delete-actions .danger{background:linear-gradient(135deg,#dc2626,#991b1b);color:#fff;box-shadow:0 10px 24px rgba(220,38,38,.25);}
  .kl-delete-actions button:disabled{opacity:.65;cursor:not-allowed;}
  html[data-theme="dark"] .kl-delete-overlay{background:rgba(2,6,23,.70);}
  html[data-theme="dark"] .kl-delete-dialog{background:linear-gradient(180deg,#111827,#0f172a);border-color:rgba(148,163,184,.24);color:#f8fafc;box-shadow:0 24px 70px rgba(0,0,0,.55);}
  html[data-theme="dark"] .kl-delete-icon{background:rgba(248,113,113,.14);color:#fca5a5;border:1px solid rgba(248,113,113,.24);}
  html[data-theme="dark"] .kl-delete-title{color:#fecaca;}
  html[data-theme="dark"] .kl-delete-sub{color:#cbd5e1;}
  html[data-theme="dark"] .kl-delete-body{background:rgba(15,23,42,.86);border-color:rgba(148,163,184,.22);color:#dbeafe;}
  html[data-theme="dark"] .kl-delete-body strong{color:#ffffff;}
  html[data-theme="dark"] .kl-delete-actions .cancel{background:#1f2937;color:#e5e7eb;border-color:rgba(148,163,184,.24);}
  html[data-theme="dark"] .kl-delete-actions .danger{background:linear-gradient(135deg,#ef4444,#b91c1c);box-shadow:0 10px 24px rgba(239,68,68,.22);}

  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
    .actions-bar{ flex-direction:column; align-items:stretch; }
    .actions-right{ justify-content:flex-end; }
  }
</style>

<!-- ====== CONTENIDO ESPECÍFICO ====== -->
<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_docentes.php')) ?>" title="Volver">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
    </a>
  </div>
</div>

<?php if ($flash): ?>
  <div class="flash <?= $flash['type']==='ok' ? 'ok' : 'error' ?>"><?= esc($flash['msg']) ?></div>
<?php endif; ?>
<?php if (!empty($errors)): ?>
  <div class="flash error"><strong>Revisa lo siguiente:</strong><ul><?php foreach($errors as $e) echo '<li>'.esc($e).'</li>'; ?></ul></div>
<?php endif; ?>

<!-- Tarjeta de actividad -->
<section class="card" aria-label="Actividad del docente">
  <div style="display:flex; align-items:center; gap:10px; flex-wrap:wrap;">
    <div class="tag"><i class="fas fa-file-alt"></i> Contenidos publicados: <?= (int)$cntCont ?></div>
  </div>
</section>

<!-- FORM principal -->
<form method="post" enctype="multipart/form-data" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="form" value="perfil">

  <!-- BLOQUE 1: Foto (solo lectura aquí) -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Foto de perfil</h3>
    <div style="display:flex;align-items:center;gap:16px;">
      <img class="avatar-big" src="<?= esc($fotoActual) ?>" alt="Foto del docente">
      <div class="hint" style="color:#6b7280;">
        La foto no se puede modificar desde esta pantalla.<br>
        Podrás actualizarla próximamente desde el perfil del docente.
      </div>
    </div>
  </section>

  <!-- BLOQUE 2: Datos personales -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos personales</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Nombre(s)</span>
        <input type="text" name="nombre" required minlength="2" value="<?= esc($docente['nombre'] ?? '') ?>">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" required minlength="2" value="<?= esc($docente['apellidos'] ?? '') ?>">
      </label>
      <label class="field">
        <span class="label">Correo</span>
        <input type="email" name="email" required value="<?= esc($docente['email'] ?? '') ?>">
      </label>
    </div>
  </section>

  <!-- BLOQUE 3: Acceso (con medidor de contraseña) -->
  <section class="card">
    <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Datos de acceso</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" required minlength="3" autocomplete="off" value="<?= esc($docente['username'] ?? '') ?>">
        <div id="unameStatus" class="avail" role="status" aria-live="polite" aria-atomic="true" style="display:none;">
          <i class="fas fa-circle-notch fa-spin"></i> Comprobando…
        </div>
      </label>

      <label class="field">
        <span class="label">Nueva contraseña (opcional)</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="pwd1" minlength="8" placeholder="Dejar vacío para no cambiar" autocomplete="new-password">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="pwd1">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
        <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
      </label>

      <label class="field">
        <span class="label">Confirmar contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="pwd2" minlength="8" placeholder="Debe coincidir" autocomplete="new-password">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="pwd2">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <small id="pwMatchHint" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
      </label>
    </div>

    <div class="actions-bar">
      <div class="actions-left">
        <button id="saveBtn" class="btn primary" type="submit"><i class="fas fa-save"></i> <span class="label">Guardar cambios</span></button>
        <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_docentes.php')) ?>" title="Cancelar">
          <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
        </a>
      </div>
      <div class="actions-right">
        <a class="btn ghost btn-icon" href="#zona-peligrosa" title="Ir a eliminar">
          <i class="fas fa-triangle-exclamation"></i> <span class="label">Ir a eliminar</span>
        </a>
      </div>
    </div>
  </section>
</form>

<!-- BLOQUE 4: Permisos -->
<section class="card">
  <h3 style="font-size:16px;margin-bottom:8px;color:#0b2545;">Permisos por materia</h3>
  <div class="searchbox">
    <input id="qMat" type="text" placeholder="Buscar materia por CLAVE o nombre (ej. ACF0901 o 'Cálculo')" autocomplete="off">
    <button id="btnBuscar" class="btn ghost" type="button"><i class="fas fa-search"></i> Buscar</button>
  </div>
  <div id="results" class="results"></div>

  <div style="margin-top:12px;font-weight:800;color:#0b2545;">Asignadas</div>
  <div id="permsList" class="list" aria-live="polite">
    <div class="row"><div style="color:#6b7280;">Cargando permisos…</div></div>
  </div>
</section>

<!-- BLOQUE 5: Zona peligrosa (eliminar docente) -->
<section id="zona-peligrosa" class="card danger-zone" aria-label="Zona peligrosa">
  <h3><i class="fas fa-skull-crossbones"></i>Eliminar docente</h3>
  <p>Eliminar al docente <strong><?= esc(($docente['nombre'] ?? '').' '.($docente['apellidos'] ?? '')) ?></strong> es una acción permanente.</p>
  <div class="danger-actions">
    <button id="btnDeleteDocente" class="btn danger btn-icon" type="button">
      <i class="fas fa-trash"></i> <span class="label">Eliminar docente</span>
    </button>
  </div>
</section>

<!-- Ventana de confirmación de eliminación -->
<div id="deleteConfirmOverlay" class="kl-delete-overlay" hidden aria-hidden="true">
  <div class="kl-delete-dialog" role="dialog" aria-modal="true" aria-labelledby="deleteConfirmTitle" aria-describedby="deleteConfirmText">
    <div class="kl-delete-head">
      <div class="kl-delete-icon"><i class="fas fa-triangle-exclamation"></i></div>
      <div>
        <div id="deleteConfirmTitle" class="kl-delete-title">Eliminar docente</div>
        <div class="kl-delete-sub">Confirma la acción antes de eliminar este registro.</div>
      </div>
    </div>
    <div id="deleteConfirmText" class="kl-delete-body">
      Esta acción eliminará definitivamente al docente
      <strong><?= esc(($docente['nombre'] ?? '').' '.($docente['apellidos'] ?? '')) ?></strong>
      y sus relaciones asociadas.
    </div>
    <div class="kl-delete-actions">
      <button type="button" class="cancel" id="cancelDel">Cancelar</button>
      <button type="button" class="danger" id="confirmDel"><i class="fas fa-trash-alt"></i> Sí, eliminar</button>
    </div>
  </div>
</div>

<script>
// Util
function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function pulse(el){ if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'), 350); }

// Disponibilidad de usuario
(function(){
  const unameInput = document.getElementById('username');
  const unameStatus = document.getElementById('unameStatus');
  const saveBtn = document.getElementById('saveBtn');
  let timer=null;

  function setStatus(state, text, icon){
    unameStatus.style.display='inline-flex';
    unameStatus.className = 'avail' + (state ? ' '+state : '');
    unameStatus.innerHTML = `<i class="fas ${icon}"></i> ${text}`;
  }

  async function check(u){
    if (saveBtn) saveBtn.disabled = true;
    if(!u || u.trim().length<3){
      setStatus('', 'Escribe al menos 3 caracteres.', 'fa-info-circle');
      return;
    }
    setStatus('', 'Comprobando…', 'fa-circle-notch fa-spin');
    try{
      const res = await fetch(`?ajax=username&u=${encodeURIComponent(u)}`, {cache:'no-store'});
      const data = await res.json();
      if(data.ok && data.available){
        setStatus('good','Disponible','fa-check-circle');
        if (saveBtn) saveBtn.disabled = false;
      }else{
        setStatus('bad','No disponible','fa-times-circle');
        if (saveBtn) saveBtn.disabled = true;
      }
    }catch(e){
      setStatus('bad','Error al comprobar','fa-exclamation-triangle');
      if (saveBtn) saveBtn.disabled = true;
    }
  }

  unameInput?.addEventListener('input', ()=>{ clearTimeout(timer); timer = setTimeout(()=> check(unameInput.value.trim()), 300); });
  document.addEventListener('DOMContentLoaded', ()=>{ if (unameInput && unameInput.value.trim().length){ unameStatus.style.display='inline-flex'; check(unameInput.value.trim()); } });
})();

// Ojo de contraseña
(function(){
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });
})();

// Password meter + match
(function(){
  const p1=document.getElementById('pwd1');
  const p2=document.getElementById('pwd2');
  const bar=document.getElementById('pwBar');
  const tip=document.getElementById('pwTip');
  const matchHint=document.getElementById('pwMatchHint');

  function scorePassword(pw){
    let score=0; if(!pw) return 0;
    const letters={};
    for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
    const variations={ digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
    let vc=0; for(const k in variations) vc += variations[k] ? 1 : 0;
    score += (vc - 1) * 10; return parseInt(score);
  }
  function updateMeter(){
    if(!bar||!tip) return;
    const val=p1.value||'';
    const s=Math.min(100, scorePassword(val));
    bar.style.width = (val ? Math.max(8,s) : 0) + '%';
    if (!val){ tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
    if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
    else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
    else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
    else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
    pulse(bar.parentElement);
  }
  function updateMatch(){
    if(!matchHint) return;
    if(!p2.value){ matchHint.style.display='none'; return; }
    matchHint.style.display = (p1.value !== p2.value) ? 'block' : 'none';
  }
  ['input','change','keyup','blur'].forEach(ev=>{
    p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
    p2?.addEventListener(ev, updateMatch);
  });
  updateMeter(); updateMatch();
})();

// Permisos (AJAX)
(function(){
  const list = document.getElementById('permsList');
  const searchInput = document.getElementById('qMat');
  const btnBuscar = document.getElementById('btnBuscar');
  const results = document.getElementById('results');
  const csrf = '<?= esc($CSRF) ?>';

  async function loadPerms(){
    list.innerHTML = '<div class="row"><div style="color:#6b7280;">Cargando permisos…</div></div>';
    try{
      const res = await fetch('?ajax=list_perms', {cache:'no-store'});
      const data = await res.json();
      const items = data.items||[];
      if (!items.length){
        list.innerHTML = '<div class="row"><div style="color:#6b7280;">Sin materias asignadas.</div></div>';
        return;
      }
      list.innerHTML = items.map(it => {
        const clave = escapeHtml(it.materia_clave||'');
        const nombre = escapeHtml(it.nombre||'');
        return `<div class="row">
          <div><strong>${clave}</strong> · <span style="color:#6b7280">${nombre}</span></div>
          <div><button class="btn small danger" data-del="${clave}"><i class="fas fa-times"></i> Quitar</button></div>
        </div>`;
      }).join('');
    }catch(e){
      list.innerHTML = '<div class="row"><div style="color:#b91c1c;">Error al cargar permisos.</div></div>';
    }
  }

  async function searchMaterias(){
    const q = searchInput.value.trim();
    if (q.length<2){ results.style.display='none'; results.innerHTML=''; return; }
    results.style.display='block';
    results.innerHTML = '<div class="res-item" style="color:#6b7280;">Buscando…</div>';
    try{
      const res = await fetch('?ajax=search_materias&q='+encodeURIComponent(q), {cache:'no-store'});
      const data = await res.json();
      const items = data.items||[];
      if (!items.length){ results.innerHTML = '<div class="res-item" style="color:#6b7280;">Sin coincidencias.</div>'; return; }
      results.innerHTML = items.map(it=>{
        const clave = escapeHtml(it.clave||'');
        const nombre = escapeHtml(it.nombre||'');
        const ya = Number(it.ya||0)===1;
        return `<div class="res-item">
          <div><strong>${clave}</strong> · <span style="color:#6b7280">${nombre}</span></div>
          <div>${ya
            ? '<span class="tag"><i class="fas fa-check"></i> Asignada</span>'
            : `<button class="btn small primary" data-add="${clave}"><i class="fas fa-plus"></i> Agregar</button>`
          }</div>
        </div>`;
      }).join('');
    }catch(e){
      results.innerHTML = '<div class="res-item" style="color:#b91c1c;">Error al buscar materias.</div>';
    }
  }

  results.addEventListener('click', async (e)=>{
    const btn = e.target.closest('[data-add]');
    if (!btn) return;
    const clave = btn.getAttribute('data-add');
    btn.disabled = true;
    try{
      const res = await fetch('?ajax=add_perm', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ csrf, materia_clave: clave })
      });
      const data = await res.json();
      if (!data.ok) alert(data.err||'No se pudo agregar');
      await loadPerms();
      await searchMaterias();
    } finally { btn.disabled=false; }
  });

  list.addEventListener('click', async (e)=>{
    const btn = e.target.closest('[data-del]');
    if (!btn) return;
    const clave = btn.getAttribute('data-del');
    if (!confirm('Quitar permiso para '+clave+'?')) return;
    btn.disabled = true;
    try{
      const res = await fetch('?ajax=del_perm', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({ csrf, materia_clave: clave })
      });
      const data = await res.json();
      if (!data.ok) alert(data.err||'No se pudo eliminar');
      await loadPerms();
      await searchMaterias();
    } finally { btn.disabled=false; }
  });

  let t=null;
  searchInput.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(searchMaterias, 250); });
  btnBuscar.addEventListener('click', searchMaterias);

  loadPerms();
})();

// Eliminar docente: confirmación propia + POST AJAX
(function(){
  const btnDelete = document.getElementById('btnDeleteDocente');
  const overlay   = document.getElementById('deleteConfirmOverlay');
  const btnOK     = document.getElementById('confirmDel');
  const btnCancel = document.getElementById('cancelDel');
  const originalOk = '<i class="fas fa-trash-alt"></i> Sí, eliminar';

  if (!btnDelete || !overlay || !btnOK || !btnCancel) return;

  function openDeleteConfirm(){
    overlay.hidden = false;
    overlay.setAttribute('aria-hidden','false');
    btnOK.disabled = false;
    btnOK.innerHTML = originalOk;
    setTimeout(()=>btnCancel.focus(), 0);
  }

  function closeDeleteConfirm(){
    overlay.hidden = true;
    overlay.setAttribute('aria-hidden','true');
    btnOK.disabled = false;
    btnOK.innerHTML = originalOk;
  }

  btnDelete.addEventListener('click', openDeleteConfirm);
  btnCancel.addEventListener('click', closeDeleteConfirm);
  overlay.addEventListener('click', (ev)=>{ if(ev.target === overlay) closeDeleteConfirm(); });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && !overlay.hidden) closeDeleteConfirm(); });

  btnOK.addEventListener('click', async ()=>{
    btnOK.disabled = true;
    btnOK.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
    try{
      const res = await fetch('', {
        method:'POST',
        headers:{'Content-Type':'application/x-www-form-urlencoded'},
        body: new URLSearchParams({
          ajax:'delete_docente',
          id:'<?= (int)$uid ?>',
          csrf:'<?= esc($CSRF) ?>'
        })
      });
      const data = await res.json();
      if (!data.ok) {
        alert(data.msg || 'No se pudo eliminar.');
        btnOK.disabled = false;
        btnOK.innerHTML = originalOk;
        return;
      }
      window.location.href = <?= json_encode(base_url('admin/gestionar_docentes.php?ok=del')) ?>;
    } catch(e){
      alert('Error inesperado al eliminar.');
      btnOK.disabled = false;
      btnOK.innerHTML = originalOk;
    }
  });
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
