<?php
// public/admin/historial_reticulas.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// Helpers locales
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

if (!function_exists('str_starts_with')) {
  function str_starts_with($h,$n){ return $n!=='' && strpos($h,$n)===0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    if (preg_match('#^(?:https?:)?//#i',$u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#','/',$u);
    if (preg_match('#uploads/avatars/[^?\#]+#i',$u,$m)) $u = '/' . ltrim($m[0],'/');
    else $u = '/' . ltrim($u,'/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

// ---- tokens para acciones seguras ----
function mint_token(string $bucket, int $reticula_id): string {
  if (!isset($_SESSION[$bucket]) || !is_array($_SESSION[$bucket])) {
    $_SESSION[$bucket] = [];
  }
  $t = bin2hex(random_bytes(16));
  $_SESSION[$bucket][$t] = ['id'=>$reticula_id, 'exp'=> time()+300];
  return $t;
}

/* ============================ AJAX (POST JSON) ============================ */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  $ctype = $_SERVER['CONTENT_TYPE'] ?? '';
  if (stripos($ctype, 'application/json') !== false) {
    $raw = file_get_contents('php://input');
    $in  = json_decode($raw, true) ?: [];
    $action = (string)($in['ajax'] ?? '');

    if ($action === 'search') {
      header('Content-Type: application/json; charset=utf-8');

      // CSRF
      if (!hash_equals($_SESSION['csrf'] ?? '', (string)($in['csrf'] ?? ''))) {
        http_response_code(400); echo json_encode(['ok'=>false,'err'=>'csrf']); exit;
      }

      try {
        $q        = trim((string)($in['q'] ?? ''));
        $carrera  = trim((string)($in['carrera'] ?? ''));
        $estado   = (string)($in['estado'] ?? 'historicas'); // historicas|actuales|todas
        $page     = max(1, (int)($in['page'] ?? 1));
        $perPage  = min(50, max(5, (int)($in['perPage'] ?? 20)));
        $off      = ($page - 1) * $perPage;

        $where  = [];
        $params = [];

        if ($q !== '') {
          $where[] = "(r.nombre LIKE :q OR r.clave LIKE :q)";
          $params[':q'] = "%$q%";
        }
        if ($carrera !== '') {
          $where[] = "(c.nombre LIKE :car OR c.clave LIKE :car)";
          $params[':car'] = "%$carrera%";
        }

        if ($estado === 'historicas') {
          $where[] = "(r.vigente_hasta IS NOT NULL AND r.vigente_hasta <> '0000-00-00' AND r.vigente_hasta < CURDATE())";
        } elseif ($estado === 'actuales') {
          $where[] = "(
            r.vigente_hasta IS NULL OR r.vigente_hasta = '0000-00-00' OR r.vigente_hasta >= CURDATE()
          )";
        }

        $whereSql = $where ? ('WHERE '.implode(' AND ',$where)) : '';

        // Total
        $sqlCount = "
          SELECT COUNT(*)
          FROM reticulas r
          LEFT JOIN carreras c ON c.id = r.carrera_id
          $whereSql
        ";
        $st = $pdo->prepare($sqlCount);
        foreach ($params as $k=>$v) $st->bindValue($k,$v);
        $st->execute();
        $total = (int)$st->fetchColumn();

        // Página
        $lim  = (int)$perPage;
        $offi = (int)$off;
        $sql = "
          SELECT
            r.id, r.clave, r.nombre, r.vigente_desde, r.vigente_hasta,
            c.nombre AS carrera_nombre, c.clave AS carrera_clave,
            COALESCE(m.cnt_mats,0) AS materias
          FROM reticulas r
          LEFT JOIN carreras c ON c.id = r.carrera_id
          LEFT JOIN (
            SELECT reticula_id, COUNT(*) AS cnt_mats
            FROM reticula_materias
            GROUP BY reticula_id
          ) m ON m.reticula_id = r.id
          $whereSql
          ORDER BY r.vigente_hasta IS NULL DESC, r.id DESC
          LIMIT $lim OFFSET $offi
        ";
        $st = $pdo->prepare($sql);
        foreach ($params as $k=>$v) $st->bindValue($k, $v);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

        // Tokens por fila (coinciden con editar_reticula.php y reticula_materias.php)
        $out = [];
        foreach ($rows as $r) {
          $rid = (int)$r['id'];
          $out[] = [
            'id'             => $rid,
            'clave'          => $r['clave'],
            'nombre'         => $r['nombre'],
            'carrera_nombre' => $r['carrera_nombre'],
            'carrera_clave'  => $r['carrera_clave'],
            'vigente_desde'  => $r['vigente_desde'],
            'vigente_hasta'  => $r['vigente_hasta'],
            'materias'       => (int)$r['materias'],
            // *** IMPORTANTE: usar el MISMO bucket que gestionar_reticulas ***
            't_edit'         => mint_token('edit_reticula_tokens', $rid),
            't_mat'          => mint_token('reticula_materias_tokens', $rid),
          ];
        }

        echo json_encode([
          'ok'=>true,
          'total'=>$total,
          'page'=>$page,
          'perPage'=>$perPage,
          'rows'=>$out
        ], JSON_UNESCAPED_UNICODE);
      } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok'=>false,'err'=>'db']);
      }
      exit;
    }
  }
}

/* ============================ Vista (HTML) ============================ */

$active   = 'reticulas';
$title    = 'ITZ KnowLink - Administrador · Historial de retículas';
$h1       = 'Historial de retículas';
$subtitle = 'Consulta y edita retículas de años pasados (o muestra todas)';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

require __DIR__ . '/partials/header.php';
?>
<meta name="csrf" content="<?= esc($CSRF) ?>">

<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .field input, .field select{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .btn{padding:10px 14px;border-radius:10px;background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;border:none;cursor:pointer;font-weight:800}
  .btn.ghost{background:#fff;color:#0b2545;border:1px solid #e6eef2}
  .btn-icon .label{display:inline}
  a.btn.ghost{ text-decoration:none; }

  .table { width:100%; border-collapse:collapse; table-layout:fixed; }
  .table th, .table td { padding:10px; border-bottom:1px dashed #eef3f6; text-align:left; font-size:14px; vertical-align:middle; min-width:0; }
  .table th { font-size:13px; color:#6b7280; }
  col.c-reticula{ width:38%; } col.c-carrera{ width:24%; } col.c-fechas{ width:18%; } col.c-materias{ width:8%; } col.c-actions{ width:12%; }
  .td-wrap{ white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
  .reticula-cell .nm { font-weight:800; color:#0b2545; }
  .reticula-cell .sub{ font-size:12px; color:#6b7280; }
  .chip{ display:inline-flex; align-items:center; gap:6px; padding:3px 6px; border-radius:999px; border:1px solid #e2ebff; background:#f1f5ff; color:#0055d4; font-size:12px; line-height:1; }
  .chip.gray{ background:#f3f4f6; border-color:#e5e7eb; color:#374151; }
  .td-mini{ white-space:nowrap; }
  .actions{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; }
  .actions form button{ display:inline-flex; align-items:center; gap:6px; padding:8px 10px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; font-size:13px; color:#0b2545; }
  .actions form button:hover{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }

  .pager{ margin-top:12px; display:flex; gap:10px; align-items:center; }
  .pager button{ padding:8px 12px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; }
  .pager .muted{ color:#6b7280; font-size:13px; }

  @media (max-width:1200px){ .th-carrera, .td-carrera { display:none; } }
  @media (max-width:1050px){ .th-fechas, .td-fechas { display:none; } }
  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
    .table thead{ display:none; }
    .table{ border-collapse: separate; border-spacing:0 10px; table-layout:auto; }
    .table tr{ display:block; background:#fff; border:1px solid #eef3f6; border-radius:12px; padding:12px; }
    .table td{ display:block; border-bottom:0; padding:6px 0; }
    .table td + td{ margin-top:4px; }
    .td-mini{ display:inline-flex; align-items:center; gap:8px; margin-right:12px; padding:4px 0; }
    .table td.actions{
      display:flex; gap:8px; justify-content:flex-start; flex-wrap:wrap;
      margin-top:8px; padding-top:8px; border-top:1px dashed #eef3f6;
    }
    .table td.actions .label{ display:inline !important; }
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title">Historial de retículas</div>
    <div class="page-sub">Consulta, edita y gestiona planes anteriores</div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
      <i class="fas fa-arrow-left"></i> <span class="label">Volver a actuales</span>
    </a>
  </div>
</div>

<section class="card" aria-label="Filtros de búsqueda">
  <div class="tools" style="justify-content:space-between; gap:12px;">
    <div class="tools" style="gap:8px;">
      <div class="field">
        <input type="text" id="q" placeholder="Buscar por nombre o clave de retícula" style="min-width:280px;">
      </div>
      <div class="field">
        <input type="text" id="carrera" placeholder="Filtrar por carrera (clave o nombre)" style="min-width:240px;">
      </div>
      <div class="field">
        <select id="estado">
          <option value="historicas" selected>Históricas</option>
          <option value="actuales">Actuales</option>
          <option value="todas">Todas</option>
        </select>
      </div>
    </div>
    <div class="tools" style="gap:8px;">
      <div class="field">
        <select id="perPage">
          <option value="10">10 por página</option>
          <option value="20" selected>20 por página</option>
          <option value="30">30 por página</option>
          <option value="50">50 por página</option>
        </select>
      </div>
      <button class="btn ghost btn-icon" id="btnClear" title="Limpiar filtros">
        <i class="fas fa-eraser"></i> <span class="label">Limpiar</span>
      </button>
    </div>
  </div>
</section>

<section class="card" aria-label="Resultados">
  <table class="table" id="tbl">
    <colgroup>
      <col class="c-reticula">
      <col class="c-carrera">
      <col class="c-fechas">
      <col class="c-materias">
      <col class="c-actions">
    </colgroup>
    <thead>
      <tr>
        <th>Retícula</th>
        <th class="th-carrera">Carrera</th>
        <th class="th-fechas">Vigencia</th>
        <th>Materias</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody id="tbody">
      <tr><td colspan="5" style="text-align:center;color:#6b7280;">Cargando…</td></tr>
    </tbody>
  </table>

  <div class="pager" id="pager">
    <button id="prev" disabled>&laquo; Anterior</button>
    <span class="muted" id="info">—</span>
    <button id="next" disabled>Siguiente &raquo;</button>
  </div>
</section>

<script>
(function(){
  const CSRF = document.querySelector('meta[name="csrf"]')?.getAttribute('content') || '';

  const q        = document.getElementById('q');
  const carrera  = document.getElementById('carrera');
  const estado   = document.getElementById('estado');
  const perPage  = document.getElementById('perPage');
  const btnClear = document.getElementById('btnClear');
  const tbody    = document.getElementById('tbody');
  const prevBtn  = document.getElementById('prev');
  const nextBtn  = document.getElementById('next');
  const info     = document.getElementById('info');

  const EDIT_URL = <?= json_encode(base_url('admin/editar_reticula.php'), JSON_UNESCAPED_SLASHES) ?>;
  const MAT_URL  = <?= json_encode(base_url('admin/reticula_materias.php'), JSON_UNESCAPED_SLASHES) ?>;

  let state = {
    page: 1,
    total: 0,
    perPage: parseInt(perPage.value,10) || 20,
    q:'',
    carrera:'',
    estado: estado.value,
    loading:false
  };

  function escapeH(str){ return String(str).replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[s])); }

  function fmtDate(d){
    if(!d || d==='0000-00-00') return '—';
    return d;
  }

  function buildRow(r){
    const FEDIT = `
      <form method="post" action="${EDIT_URL}">
        <input type="hidden" name="csrf" value="${escapeH(CSRF)}">
        <input type="hidden" name="token" value="${escapeH(r.t_edit)}">
        <input type="hidden" name="go_edit" value="1">
        <button type="submit" title="Editar"><i class="fas fa-edit"></i> <span class="label">Editar</span></button>
      </form>`;
    const FMAT = `
      <form method="post" action="${MAT_URL}">
        <input type="hidden" name="csrf" value="${escapeH(CSRF)}">
        <input type="hidden" name="token" value="${escapeH(r.t_mat)}">
        <input type="hidden" name="go_rm" value="1">
        <button type="submit" title="Ver materias"><i class="fas fa-layer-group"></i> <span class="label">Ver materias</span></button>
      </form>`;

    const carreraTxt = (r.carrera_nombre || '') ? (r.carrera_nombre + (r.carrera_clave?(' ('+r.carrera_clave+')') : '')) : (r.carrera_clave||'');

    return `<tr>
      <td>
        <div class="reticula-cell">
          <div class="nm">${escapeH(r.nombre || ('Retícula #'+r.id))}</div>
          <div class="sub">${escapeH(r.clave)}</div>
        </div>
      </td>
      <td class="td-carrera td-wrap">${escapeH(carreraTxt)}</td>
      <td class="td-fechas td-mini">
        <span class="chip"><i class="fas fa-play"></i> ${escapeH(fmtDate(r.vigente_desde))}</span>
        <span class="chip gray"><i class="fas fa-flag-checkered"></i> ${escapeH(fmtDate(r.vigente_hasta))}</span>
      </td>
      <td class="td-mini">${Number(r.materias||0) > 0
            ? `<span class="chip"><i class="fas fa-book"></i> ${r.materias}</span>`
            : `<span class="chip gray"><i class="fas fa-book"></i> 0</span>`}
      </td>
      <td class="actions">
        ${FMAT}
        ${FEDIT}
      </td>
    </tr>`;
  }

  async function fetchData(){
    if(state.loading) return; state.loading = true;
    tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#6b7280;">Cargando…</td></tr>`;

    try{
      const res = await fetch('', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({
          ajax:'search',
          csrf: CSRF,
          q: state.q, carrera: state.carrera,
          estado: state.estado,
          page: state.page, perPage: state.perPage
        })
      });
      const data = await res.json();
      if(!data.ok) throw new Error('Respuesta inválida');

      state.total = data.total || 0;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length ? rows.map(buildRow).join('') :
        `<tr><td colspan="5" style="text-align:center;color:#6b7280;">Sin resultados.</td></tr>`;

      const first = state.total ? Math.min(state.total, ((state.page-1)*state.perPage)+1) : 0;
      const last  = state.total ? Math.min(state.total, state.page*state.perPage) : 0;
      info.textContent = state.total ? `${first}–${last} de ${state.total}` : '0 resultados';
      prevBtn.disabled = (state.page<=1);
      nextBtn.disabled = (state.page*state.perPage >= state.total);
    } catch(e){
      tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;color:#b91c1c;">Error al cargar datos.</td></tr>`;
      info.textContent = '—'; prevBtn.disabled = true; nextBtn.disabled = true;
    } finally {
      state.loading = false;
    }
  }

  function debounce(fn,ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
  const onChange = debounce(()=>{ state.page=1; fetchData(); }, 250);

  q.addEventListener('input', ()=>{ state.q=q.value.trim(); onChange(); });
  carrera.addEventListener('input', ()=>{ state.carrera=carrera.value.trim(); onChange(); });
  estado.addEventListener('change', ()=>{ state.estado=estado.value; state.page=1; fetchData(); });
  perPage.addEventListener('change', ()=>{ state.perPage=parseInt(perPage.value,10)||20; state.page=1; fetchData(); });
  prevBtn.addEventListener('click', ()=>{ if(state.page>1){ state.page--; fetchData(); }});
  nextBtn.addEventListener('click', ()=>{ if(state.page*state.perPage<state.total){ state.page++; fetchData(); }});
  btnClear.addEventListener('click', (e)=>{
    e.preventDefault();
    q.value=''; carrera.value=''; estado.value='historicas'; perPage.value='20';
    state={page:1,total:0,perPage:20,q:'',carrera:'',estado:'historicas',loading:false};
    fetchData();
  });

  // Primera carga
  fetchData();
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
