<?php
// public/admin/gestionar_administradores.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Placeholder por defecto (data URI)
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="32" cy="24" r="12" fill="#cfd8e3"/><rect x="14" y="40" width="36" height="16" rx="8" fill="#cfd8e3"/></svg>'
    );
  }
}

/**
 * foto_src: normaliza a URL web ABSOLUTA lista para <img src="...">
 * Acepta: /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\', '/', $url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u, 'data:')) return $u;
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/'); // /uploads/avatars/...
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

// Polyfill PHP < 8
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle) {
    return $needle !== '' && strpos($haystack, $needle) === 0;
  }
}

// CSRF
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();
$miId = (int)($yo['id'] ?? 0);

/* ===================== AJAX ===================== */
if (isset($_GET['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');
  $act = $_GET['ajax'];

  // Listado con búsqueda + paginación (10 por página)
  if ($act === 'list') {
    $q = trim((string)($_GET['q'] ?? ''));
    $page = max(1, (int)($_GET['page'] ?? 1));
    $perPage = 10;
    $off = ($page - 1) * $perPage;

    $where = " WHERE rol = 'administrador' ";
    $params = [];
    if ($q !== '') {
      $where .= " AND (nombre LIKE :q OR apellidos LIKE :q OR email LIKE :q OR username LIKE :q) ";
      $params[':q'] = "%$q%";
    }

    $stmtCnt = $pdo->prepare("SELECT COUNT(*) FROM usuarios $where");
    $stmtCnt->execute($params);
    $total = (int)$stmtCnt->fetchColumn();

    $stmt = $pdo->prepare("
      SELECT id, nombre, apellidos, email, username, foto_url, activo, creado_en, actualizado_en
      FROM usuarios
      $where
      ORDER BY creado_en DESC
      LIMIT :lim OFFSET :off
    ");
    foreach ($params as $k=>$v) $stmt->bindValue($k,$v);
    $stmt->bindValue(':lim', $perPage, PDO::PARAM_INT);
    $stmt->bindValue(':off', $off, PDO::PARAM_INT);
    $stmt->execute();
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC) ?: [];

    // Normaliza foto a URL absoluta y añade campo "foto"
    foreach ($rows as &$r) {
      $r['foto'] = foto_src($r['foto_url'] ?? null);
    } unset($r);

    echo json_encode([
      'ok'=>true,
      'items'=>$rows,
      'total'=>$total,
      'page'=>$page,
      'perPage'=>$perPage,
      'pages'=> max(1, (int)ceil($total / $perPage))
    ], JSON_UNESCAPED_UNICODE);
    exit;
  }

  // Abrir edición SIN exponer ?id en la URL (guarda en sesión)
  if ($act === 'open' && $_SERVER['REQUEST_METHOD']==='POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals($CSRF, $csrf)) { echo json_encode(['ok'=>false,'err'=>'CSRF']); exit; }

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) { echo json_encode(['ok'=>false,'err'=>'ID inválido']); exit; }

    $st = $pdo->prepare("SELECT id FROM usuarios WHERE id=:id AND rol='administrador' LIMIT 1");
    $st->execute([':id'=>$id]);
    if (!$st->fetchColumn()) { echo json_encode(['ok'=>false,'err'=>'No encontrado']); exit; }

    $_SESSION['edit_admin_id'] = $id;
    echo json_encode(['ok'=>true]); exit;
  }

  // Toggle activo/inactivo
  if ($act === 'toggle_active' && $_SERVER['REQUEST_METHOD']==='POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals($CSRF, $csrf)) { echo json_encode(['ok'=>false,'err'=>'CSRF']); exit; }

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) { echo json_encode(['ok'=>false,'err'=>'ID inválido']); exit; }

    if ($id === $miId) { echo json_encode(['ok'=>false,'err'=>'No puedes desactivar tu propia cuenta.']); exit; }

    $st = $pdo->prepare("SELECT id, activo FROM usuarios WHERE id=:id AND rol='administrador' LIMIT 1");
    $st->execute([':id'=>$id]);
    $admin = $st->fetch(PDO::FETCH_ASSOC);
    if (!$admin) { echo json_encode(['ok'=>false,'err'=>'No encontrado']); exit; }

    $nuevo = ((int)$admin['activo'] === 1) ? 0 : 1;

    if ($nuevo === 0) {
      $c = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND id <> ".(int)$id)->fetchColumn();
      if ($c <= 0) {
        echo json_encode(['ok'=>false,'err'=>'Debe existir al menos un administrador activo.']); exit;
      }
    }

    $u = $pdo->prepare("UPDATE usuarios SET activo=:a, actualizado_en=NOW() WHERE id=:id AND rol='administrador'");
    $u->execute([':a'=>$nuevo, ':id'=>$id]);
    echo json_encode(['ok'=>true,'activo'=>$nuevo]); exit;
  }

  // Eliminar administrador con validaciones de seguridad
  if ($act === 'delete' && $_SERVER['REQUEST_METHOD']==='POST') {
    $csrf = (string)($_POST['csrf'] ?? '');
    if (!hash_equals($CSRF, $csrf)) { echo json_encode(['ok'=>false,'err'=>'La sesión expiró. Recarga la página e intenta de nuevo.']); exit; }

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) { echo json_encode(['ok'=>false,'err'=>'ID inválido']); exit; }

    if ($id === $miId) { echo json_encode(['ok'=>false,'err'=>'No puedes eliminar tu propia cuenta mientras estás usando el sistema.']); exit; }

    $st = $pdo->prepare("SELECT id, activo FROM usuarios WHERE id=:id AND rol='administrador' LIMIT 1");
    $st->execute([':id'=>$id]);
    $admin = $st->fetch(PDO::FETCH_ASSOC);
    if (!$admin) { echo json_encode(['ok'=>false,'err'=>'Administrador no encontrado o ya eliminado.']); exit; }

    $otrosAdmins = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND id <> ".(int)$id)->fetchColumn();
    if ($otrosAdmins <= 0) { echo json_encode(['ok'=>false,'err'=>'Debe existir al menos otro administrador registrado.']); exit; }

    $otrosActivos = (int)$pdo->query("SELECT COUNT(*) FROM usuarios WHERE rol='administrador' AND activo=1 AND id <> ".(int)$id)->fetchColumn();
    if ($otrosActivos <= 0) { echo json_encode(['ok'=>false,'err'=>'Debe existir al menos un administrador activo después de eliminar esta cuenta.']); exit; }

    try {
      $pdo->beginTransaction();
      $pdo->prepare("DELETE FROM administradores WHERE usuario_id=:id")->execute([':id'=>$id]);
      $del = $pdo->prepare("DELETE FROM usuarios WHERE id=:id AND rol='administrador'");
      $del->execute([':id'=>$id]);
      if ($del->rowCount() < 1) { throw new RuntimeException('No se eliminó ningún registro.'); }

      if (isset($_SESSION['edit_admin_id']) && (int)$_SESSION['edit_admin_id'] === $id) {
        unset($_SESSION['edit_admin_id']);
      }

      $pdo->commit();
      echo json_encode(['ok'=>true,'msg'=>'Administrador eliminado correctamente.']); exit;
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) { $pdo->rollBack(); }
      echo json_encode(['ok'=>false,'err'=>'No se pudo eliminar el administrador. Revisa si tiene información relacionada o intenta más tarde.']); exit;
    }
  }

  echo json_encode(['ok'=>false,'err'=>'Acción inválida']); exit;
}

/* ===================== UI con parciales ===================== */
$active   = 'admins';
$title    = 'ITZ KnowLink - Administrador · Gestionar administradores';
$h1       = 'Gestionar administradores';
$subtitle = 'Busca, activa/desactiva y edita cuentas de administrador';

$HEADER_TITLE  = $h1;
$HEADER_SUB    = $subtitle;
$PAGE_TITLE    = $title;
$header_title  = $h1;
$header_sub    = $subtitle;
$page_title    = $title;
$page_h1       = $h1;
$page_h2       = $subtitle;
$PAGE_H1       = $h1;
$PAGE_SUBTITLE = $subtitle;

$MENU_ACTIVE     = $active;
$ACTIVE_MENU     = $active;
$ACTIVE_SECTION  = $active;
$CURRENT_SECTION = $active;

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

/* incluye el header */
require __DIR__ . '/partials/header.php';
?>

<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:14px}
  .search-row{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .search-row input[type="text"]{flex:1;min-width:220px;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff}
  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff}
  .btn.ghost{background:#fff;border:1px solid #e6eef2;color:#0b2545}
  .btn.small{padding:6px 10px;border-radius:8px;font-weight:700}
  .btn-icon{display:inline-flex;align-items:center;gap:8px}
  .btn-icon .label{margin-left:6px}
  a.btn.ghost.btn-icon{text-decoration:none}
  a.btn.ghost.btn-icon:hover,a.btn.ghost.btn-icon:focus{background:#f5f8ff;color:#0055d4;transform:translateY(-1px)}

  .list{display:flex;flex-direction:column;margin-top:10px;border:1px solid #e6eef2;border-radius:12px;overflow:hidden}
  .row{
    display:grid;
    grid-template-columns: minmax(200px,1fr) minmax(200px,1fr) minmax(120px,140px) minmax(220px,260px);
    gap:10px; align-items:center; padding:10px 12px;
    border-bottom:1px dashed #eef2f6; background:#fff
  }
  .row:nth-child(odd){background:#f8fafc}
  .row:last-child{border-bottom:0}
  .who{display:flex;align-items:center;gap:10px}
  .avatar{width:42px;height:42px;border-radius:50%;object-fit:cover;background:#eef3f6;border:3px solid #eef7f8}
  .name{font-weight:800;color:#0b2545}
  .sub{font-size:12px;color:#6b7280}
  .tag{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;border:1px solid #e2ebff;background:#f1f5ff;color:#0055d4;font-size:12px;white-space:nowrap}
  .tag.red{background:#fff1f0;border-color:#f5c2c7;color:#7a0021}
  .actions{display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}
  .btn.danger{background:#fff5f5;border:1px solid #fecaca;color:#b91c1c}
  .btn.danger:hover{background:#fee2e2;color:#991b1b}
  .confirm-overlay{position:fixed;inset:0;z-index:2400;display:flex;align-items:center;justify-content:center;padding:18px;background:rgba(15,23,42,.46);backdrop-filter:blur(8px)}
  .confirm-overlay[hidden]{display:none!important}
  .confirm-card{width:min(440px,100%);border-radius:20px;padding:20px;background:#fff;color:#0f172a;box-shadow:0 24px 70px rgba(2,6,23,.28);border:1px solid rgba(148,163,184,.22);animation:confirmIn .14s ease-out}
  @keyframes confirmIn{from{opacity:0;transform:translateY(10px) scale(.98)}to{opacity:1;transform:translateY(0) scale(1)}}
  .confirm-icon{width:46px;height:46px;border-radius:16px;display:grid;place-items:center;background:#fee2e2;color:#b91c1c;font-size:20px;margin-bottom:12px}
  .confirm-title{font-size:18px;font-weight:900;margin-bottom:6px}
  .confirm-text{color:#475569;line-height:1.45;font-size:14px;margin-bottom:16px}
  .confirm-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap}
  .confirm-actions button{border:0;border-radius:12px;padding:10px 14px;font-weight:800;cursor:pointer}
  .confirm-actions .cancel{background:#f1f5f9;color:#0f172a}
  .confirm-actions .danger{background:linear-gradient(135deg,#dc2626,#991b1b);color:#fff}
  .confirm-actions button:disabled{opacity:.65;cursor:not-allowed}
  html[data-theme="dark"] .confirm-card{background:#111827;color:#f8fafc;border-color:rgba(148,163,184,.18)}
  html[data-theme="dark"] .confirm-text{color:#cbd5e1}
  html[data-theme="dark"] .confirm-actions .cancel{background:#1f2937;color:#e5e7eb}
  html[data-theme="dark"] .btn.danger{background:rgba(127,29,29,.20);color:#fecaca;border-color:rgba(248,113,113,.35)}
  html[data-theme="dark"] .btn.danger:hover{background:rgba(127,29,29,.38);color:#fff}

  .email-val{ white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
  @media (max-width:1200px){ .col-email{ display:none; } }
  @media (max-width:1200px){ .row{grid-template-columns:1fr; align-items:flex-start} .actions{justify-content:flex-start} }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div class="search-row">
    <a class="btn primary btn-icon" href="<?= esc(base_url('admin/registrar_administrador.php')) ?>">
      <i class="fas fa-user-plus"></i> <span class="label">Nuevo administrador</span>
    </a>
  </div>
</div>

<section class="card">
  <div class="search-row" style="margin-bottom:10px;">
    <input type="text" id="q" placeholder="Buscar por nombre, apellidos, correo o usuario…" autocomplete="off">
    <button id="btnBuscar" class="btn ghost btn-icon" type="button">
      <i class="fas fa-search"></i> <span class="label">Buscar</span>
    </button>
  </div>

  <div id="list" class="list" aria-live="polite">
    <div class="row"><div class="sub">Cargando administradores…</div></div>
  </div>

  <div class="pager" id="pager" style="display:none;display:flex;gap:8px;align-items:center;justify-content:flex-end;margin-top:10px">
    <button class="btn ghost" id="prev" type="button">&laquo;</button>
    <div id="pgInfo" class="sub"></div>
    <button class="btn ghost" id="next" type="button">&raquo;</button>
  </div>
</section>

<div id="confirmDeleteModal" class="confirm-overlay" hidden aria-hidden="true">
  <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirmDeleteTitle">
    <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
    <div id="confirmDeleteTitle" class="confirm-title">Eliminar administrador</div>
    <div id="confirmDeleteText" class="confirm-text">
      Esta acción eliminará la cuenta de administrador seleccionada. No se puede deshacer.
    </div>
    <div class="confirm-actions">
      <button type="button" class="cancel" id="confirmDeleteCancel">Cancelar</button>
      <button type="button" class="danger" id="confirmDeleteAccept">Sí, eliminar</button>
    </div>
  </div>
</div>

<script>
  const EDIT_URL = <?= json_encode(base_url('admin/editar_administrador.php'), JSON_UNESCAPED_SLASHES) ?>;
  const CSRF = <?= json_encode($CSRF) ?>;
  const MI_ID = <?= json_encode($miId) ?>;
  const PLACEHOLDER = <?= json_encode(foto_src(null)) ?>;

  function escapeHtml(s){ return (s??'').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m])); }

  (function(){
    const list = document.getElementById('list');
    const q = document.getElementById('q');
    const btnBuscar = document.getElementById('btnBuscar');
    const pager = document.getElementById('pager');
    const prev = document.getElementById('prev');
    const next = document.getElementById('next');
    const pgInfo = document.getElementById('pgInfo');
    const confirmDeleteModal = document.getElementById('confirmDeleteModal');
    const confirmDeleteText = document.getElementById('confirmDeleteText');
    const confirmDeleteCancel = document.getElementById('confirmDeleteCancel');
    const confirmDeleteAccept = document.getElementById('confirmDeleteAccept');
    let pendingDelete = null;

    let page = 1, pages = 1, total = 0, perPage = 10, timer = null;


    function notify(msg, isErr=false){
      if(window.showToast){ window.showToast(msg, isErr); return; }
      if(isErr) alert(msg); else console.log(msg);
    }

    function openDeleteModal(id, nombre){
      pendingDelete = { id, nombre };
      confirmDeleteText.innerHTML = `¿Seguro que deseas eliminar a <strong>${escapeHtml(nombre)}</strong>? Esta acción no se puede deshacer.`;
      confirmDeleteModal.hidden = false;
      confirmDeleteModal.setAttribute('aria-hidden','false');
      setTimeout(()=>confirmDeleteCancel.focus(), 20);
    }

    function closeDeleteModal(){
      pendingDelete = null;
      confirmDeleteModal.hidden = true;
      confirmDeleteModal.setAttribute('aria-hidden','true');
      confirmDeleteAccept.disabled = false;
      confirmDeleteAccept.innerHTML = 'Sí, eliminar';
    }

    async function deleteAdministrador(){
      if(!pendingDelete?.id) return;
      confirmDeleteAccept.disabled = true;
      confirmDeleteAccept.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
      try{
        const form = new URLSearchParams({ csrf: CSRF, id: String(pendingDelete.id) });
        const res = await fetch('?ajax=delete', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: form });
        const data = await res.json();
        if(!data.ok){ throw new Error(data.err || data.msg || 'No se pudo eliminar el administrador.'); }
        closeDeleteModal();
        notify(data.msg || 'Administrador eliminado correctamente.');
        fetchList();
      }catch(err){
        confirmDeleteAccept.disabled = false;
        confirmDeleteAccept.innerHTML = 'Sí, eliminar';
        notify(String(err.message || err), true);
      }
    }

    function rowMarkup(u){
      const id = Number(u.id)||0;
      const foto = escapeHtml(u.foto || PLACEHOLDER); // <- ahora viene normalizada desde PHP
      const activo = Number(u.activo||0)===1;
      const tag = activo ? '<span class="tag"><i class="fas fa-check"></i> Activo</span>' : '<span class="tag red"><i class="fas fa-ban"></i> Inactivo</span>';
      const deleteBtn = id === Number(MI_ID) ? '' : `<button class="btn small danger js-delete" type="button" data-id="${id}" data-name="${escapeHtml(((u.nombre||'')+' '+(u.apellidos||'')).trim() || ('Administrador #' + id))}"><i class="fas fa-trash-alt"></i> <span class="label">Eliminar</span></button>`;

      return `<div class="row" data-id="${id}">
        <div class="who">
          <img class="avatar" src="${foto}" alt="">
          <div>
            <div class="name">${escapeHtml(u.nombre||'')} ${escapeHtml(u.apellidos||'')}</div>
            <div class="sub">@${escapeHtml(u.username||'')}</div>
          </div>
        </div>

        <div class="col-email">
          <div class="sub">Correo</div>
          <div class="email-val">${escapeHtml(u.email||'')}</div>
        </div>

        <div>${tag}</div>
        <div class="actions">
          <a href="#" class="btn ghost btn-icon js-edit" data-id="${id}">
            <i class="fas fa-pen"></i> <span class="label">Editar</span>
          </a>
          <button class="btn small ${activo?'':'primary'} js-toggle" type="button">
            <i class="fas ${activo?'fa-eye-slash':'fa-eye'}"></i> <span class="label">${activo?'Desactivar':'Activar'}</span>
          </button>
          ${deleteBtn}
        </div>
      </div>`;
    }

    function render(items){
      if(!items || !items.length){
        list.innerHTML = '<div class="row"><div class="sub">No se encontraron administradores.</div></div>';
        return;
      }
      list.innerHTML = items.map(rowMarkup).join('');
    }

    function renderPager(){
      if (pages <= 1){ pager.style.display='none'; return; }
      pager.style.display='flex';
      prev.disabled = (page<=1);
      next.disabled = (page>=pages);
      pgInfo.textContent = `Página ${page} de ${pages} — ${total} resultado${total===1?'':'s'}`;
    }

    async function fetchList(){
      const term = (q.value||'').trim();
      list.innerHTML = '<div class="row"><div class="sub">Cargando…</div></div>';
      try{
        const res = await fetch(`?ajax=list&q=${encodeURIComponent(term)}&page=${page}`, {cache:'no-store'});
        const data = await res.json();
        if (!data.ok) throw new Error('error');
        total = Number(data.total||0);
        pages = Number(data.pages||1);
        perPage = Number(data.perPage||10);
        page = Math.min(Math.max(1, Number(data.page||1)), pages);
        render(data.items||[]);
        renderPager();
      }catch(e){
        list.innerHTML = '<div class="row"><div style="color:#b91c1c;">Error al cargar la lista.</div></div>';
        pager.style.display='none';
      }
    }

    function debounceSearch(){
      clearTimeout(timer);
      timer = setTimeout(()=>{ page=1; fetchList(); }, 250);
    }

    q.addEventListener('input', debounceSearch);
    btnBuscar.addEventListener('click', ()=>{ page=1; fetchList(); });
    prev.addEventListener('click', ()=>{ if(page>1){ page--; fetchList(); } });
    next.addEventListener('click', ()=>{ if(page<pages){ page++; fetchList(); } });

    confirmDeleteCancel.addEventListener('click', closeDeleteModal);
    confirmDeleteAccept.addEventListener('click', deleteAdministrador);
    confirmDeleteModal.addEventListener('click', (ev)=>{ if(ev.target === confirmDeleteModal) closeDeleteModal(); });
    document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && !confirmDeleteModal.hidden) closeDeleteModal(); });

    // Delegación: EDITAR / ACTIVAR / ELIMINAR
    list.addEventListener('click', async (e)=>{
      const del = e.target.closest('.js-delete');
      if(del){
        e.preventDefault();
        const id = parseInt(del.getAttribute('data-id'),10)||0;
        if(!id) return;
        openDeleteModal(id, del.getAttribute('data-name') || ('Administrador #' + id));
        return;
      }

      const a = e.target.closest('.js-edit');
      if (a){
        e.preventDefault();
        const id = a.getAttribute('data-id');
        if(!id) return;
        try{
          const form = new URLSearchParams({ csrf: CSRF, id: String(id) });
          const res = await fetch('?ajax=open', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: form });
          const data = await res.json();
          if(!data.ok){ alert(data.err || 'No se pudo abrir la edición'); return; }
          location.href = EDIT_URL; // sin parámetros en la ruta
        }catch(err){
          alert('Error de red. Intenta de nuevo.');
        }
        return;
      }

      // Delegación: toggle activo
      const btn = e.target.closest('.js-toggle');
      if (btn){
        const row = e.target.closest('.row');
        const id = Number(row?.getAttribute('data-id')||0);
        if (!id) return;

        btn.disabled = true;
        try{
          const form = new URLSearchParams({ csrf: CSRF, id: String(id) });
          const res = await fetch('?ajax=toggle_active', { method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'}, body: form });
          const data = await res.json();
          if (!data.ok){
            alert(data.err || 'No se pudo actualizar el estado.');
            return;
          }
          fetchList(); // recarga la página actual
        } finally {
          btn.disabled = false;
        }
      }
    });

    // Primera carga
    fetchList();
  })();
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
