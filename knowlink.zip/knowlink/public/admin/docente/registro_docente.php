<?php
// public/admin/docente/registro_docente.php
declare(strict_types=1);

require_once __DIR__ . '/../../../config/db.php';
require_once __DIR__ . '/../../../src/helpers.php';
require_once __DIR__ . '/../../../src/auth.php';

start_session();
$admin = auth_user();
if (!$admin) { redirect(base_url('login.php')); exit; }
if (($admin['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

/* ===== Utilidades de escape ===== */
function safeStr($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

/* ===== Placeholder y normalizador de rutas de foto ===== */
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="44" cy="32" r="16" fill="#cfd8e3"/><rect x="18" y="54" width="52" height="22" rx="11" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('str_starts_with')) { // polyfill PHP < 8
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
/**
 * foto_src: normaliza a URL web ABSOLUTA lista para <img src="...">
 * Acepta: /uploads/avatars/..., uploads/avatars/..., ../uploads/avatars/..., http(s)://..., data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    // absoluta o data:
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    // limpia ../
    while (str_starts_with($u,'../')) $u = substr($u,3);
    // fuerza /uploads/avatars
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path,'/')) : $path;
  }
}
function buildFotoUrl(?string $url): string { return foto_src($url); }

if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();
const EMAIL_DOMAIN = '@zitacuaro.tecnm.mx';

/* =================== AJAX: disponibilidad de username =================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  $ok = false; $available = false;
  if ($u !== '' && mb_strlen($u) >= 3) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u");
    $st->execute([':u'=>$u]);
    $available = ((int)$st->fetchColumn() === 0);
    $ok = true;
  }
  echo json_encode(['ok'=>$ok, 'available'=>$available], JSON_UNESCAPED_UNICODE);
  exit;
}

/* =================== Catálogo de materias (para permisos) =================== */
$materias = $pdo->query("SELECT clave, nombre FROM materias ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

/* =================== Estado del formulario =================== */
$errors = [];
$old = [
  'nombre'       => '',
  'apellidos'    => '',
  'email_local'  => '',
  'username'     => '',
  'password'     => '',
  'password2'    => '',
  'materias'     => [],  // arreglo de claves
];
$fotoPreview = buildFotoUrl(null);

/* =================== POST: crear docente =================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido. Recarga la página.';
  }

  $old['nombre']       = trim((string)($_POST['nombre'] ?? ''));
  $old['apellidos']    = trim((string)($_POST['apellidos'] ?? ''));
  $old['email_local']  = strtolower(trim((string)($_POST['email_local'] ?? '')));
  $old['username']     = trim((string)($_POST['username'] ?? ''));
  $old['password']     = (string)($_POST['password'] ?? '');
  $old['password2']    = (string)($_POST['password2'] ?? '');
  $old['materias']     = array_values(array_unique(array_filter((array)($_POST['materias'] ?? []), 'strlen')));

  // Validaciones
  if ($old['nombre'] === '' || mb_strlen($old['nombre']) < 2)     $errors[] = 'Nombre inválido.';
  if ($old['apellidos'] === '' || mb_strlen($old['apellidos'])<2) $errors[] = 'Apellidos inválidos.';

  // Email institucional (usuario local + dominio fijo)
  if ($old['email_local'] === '') {
    $errors[] = 'Usuario del correo institucional requerido.';
  } elseif (!preg_match('/^[a-z0-9._-]{2,64}$/i', $old['email_local'])) {
    $errors[] = 'Usuario de correo inválido. Usa letras, números, ".", "_" o "-".';
  }
  $email = $old['email_local'] . EMAIL_DOMAIN;
  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $errors[] = 'Correo institucional inválido.';
  }

  if ($old['username'] === '' || mb_strlen($old['username']) < 3) $errors[] = 'El usuario debe tener al menos 3 caracteres.';
  if ($old['password'] === '' || mb_strlen($old['password']) < 8) $errors[] = 'La contraseña debe tener al menos 8 caracteres.';
  if ($old['password'] !== $old['password2'])                     $errors[] = 'Las contraseñas no coinciden.';

  // Unicidad
  if (!$errors) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u");
    $st->execute([':u'=>$old['username']]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'El nombre de usuario ya está en uso.';

    $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e");
    $st->execute([':e'=>$email]);
    if ((int)$st->fetchColumn() > 0) $errors[] = 'Ese correo ya está registrado.';
  }

  // Foto (opcional) — guarda en /public/uploads/avatars y expone /uploads/avatars/...
  $foto_url = null;
  if (!$errors && isset($_FILES['foto']) && is_array($_FILES['foto']) && ($_FILES['foto']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['foto'];
    if ($f['error'] !== UPLOAD_ERR_OK) { $errors[]='Error al subir la imagen.'; }
    else {
      if ($f['size'] > 3 * 1024 * 1024) $errors[]='La imagen excede 3 MB.';
      $finfo = finfo_open(FILEINFO_MIME_TYPE);
      $mime  = finfo_file($finfo, $f['tmp_name']); finfo_close($finfo);
      $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
      if (!isset($allowed[$mime])) $errors[]='Formato de imagen no permitido (JPG, PNG, GIF, WEBP).';
      if (!$errors) {
        $ext   = $allowed[$mime];
        $dir   = __DIR__ . '/../../uploads/avatars'; // desde /admin/docente a /public/uploads/avatars
        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
        $fname = 'doc_' . date('Ymd_His') . '_' . bin2hex(random_bytes(3)) . '.' . $ext;
        $dest  = $dir . '/' . $fname;
        if (!move_uploaded_file($f['tmp_name'], $dest)) { $errors[] = 'No se pudo guardar la imagen.'; }
        else { $foto_url = '/uploads/avatars/' . $fname; }
      }
    }
  }

  if (!$errors) {
    try {
      $pdo->beginTransaction();

      // Crear usuario (rol docente)
      $hash = password_hash($old['password'], PASSWORD_BCRYPT, ['cost'=>10]);
      $stmt = $pdo->prepare("
        INSERT INTO usuarios (nombre, apellidos, email, username, password_hash, rol, foto_url, activo, creado_en, actualizado_en)
        VALUES (:n,:a,:e,:u,:ph,'docente',:f,1,NOW(),NOW())
      ");
      $stmt->execute([
        ':n'=>$old['nombre'],
        ':a'=>$old['apellidos'],
        ':e'=>$email,
        ':u'=>$old['username'],
        ':ph'=>$hash,
        ':f'=>$foto_url
      ]);
      $uid = (int)$pdo->lastInsertId();

      // Alta en docentes
      $pdo->prepare("INSERT INTO docentes (usuario_id) VALUES (:id)")->execute([':id'=>$uid]);

      // Permisos por materia
      if (!empty($old['materias'])) {
        $ins = $pdo->prepare("INSERT INTO docente_permisos_materia (docente_id, materia_clave) VALUES (:d,:m)");
        foreach ($old['materias'] as $clave) {
          $ins->execute([':d'=>$uid, ':m'=>$clave]);
        }
      }

      $pdo->commit();
      redirect(base_url('admin/gestionar_docentes.php?ok=1'));
      exit;
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'No se pudo registrar al docente. Intenta de nuevo.';
    }
  }

  // Rehidratar preview si hubo error
  $fotoPreview = buildFotoUrl($foto_url ?? null);
}

/* =========================
   HEADER (parcial existente)
   ========================= */
$PAGE_TITLE   = 'ITZ KnowLink - Administrador · Registrar docente';
$ACTIVE_MENU  = 'docentes';
$HEADER_TITLE = 'Registrar docente';
$HEADER_SUB   = 'Crea una cuenta de profesor y asigna permisos por materia';

/* Aliases de compatibilidad por si tu header usa otros nombres */
$page_title     = $PAGE_TITLE;
$page_h1        = $HEADER_TITLE;
$page_subtitle  = $HEADER_SUB;
$MENU_ACTIVE    = $ACTIVE_MENU;
$menu_active    = $ACTIVE_MENU;
$activeMenu     = $ACTIVE_MENU;
$TITLE          = $HEADER_TITLE;
$VIEW = ['title'=>$PAGE_TITLE,'h1'=>$HEADER_TITLE,'sub'=>$HEADER_SUB,'active'=>$ACTIVE_MENU];

/* Pasa avatar normalizado al header (compatible con headers que miran foto o foto_url) */
$yo = $admin;
$yo['foto'] = foto_src($yo['foto_url'] ?? null);
$yo['foto_url'] = $yo['foto'];

require __DIR__ . '/../partials/header.php'; // desde /admin/docente a /admin/partials
?>

<!-- ====== CSS del diseño de esta vista (scopeado) ====== -->
<style>
  #regDocentePage .card{ background:#fff; border-radius:12px; padding:16px; box-shadow:0 10px 30px rgba(2,6,23,.06); margin-bottom:16px; }
  #regDocentePage .form-grid{ display:grid; grid-template-columns: repeat(auto-fit, minmax(260px,1fr)); gap:12px; margin-top:12px; }
  #regDocentePage label.field{ display:flex; flex-direction:column; gap:8px; position:relative; }
  #regDocentePage input[type="text"],
  #regDocentePage input[type="email"],
  #regDocentePage input[type="password"],
  #regDocentePage select, #regDocentePage textarea{
    width:100%; box-sizing:border-box; padding:10px 12px; border-radius:8px; border:1px solid #e6eef2; outline:none; font-size:14px; background:#fbfdfe;
  }
  #regDocentePage .hint{ font-size:13px; color:#6b7280; }
  #regDocentePage .actions{ margin-top:12px; display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
  #regDocentePage .btn{ padding:10px 14px; border-radius:10px; background:linear-gradient(90deg,#0b2545,#0fb5bf); color:#fff; border:none; cursor:pointer; font-weight:800; }
  #regDocentePage .btn.ghost{ background:#fff; color:#0b2545; border:1px solid #e6eef2; }
  #regDocentePage .btn-icon{ display:inline-flex; align-items:center; gap:8px; }
  #regDocentePage .btn-icon .label{ display:inline; }

  /* Foto */
  #regDocentePage .photo-row{ display:flex; gap:12px; align-items:center; }
  #regDocentePage .photo-preview{ width:88px; height:88px; border-radius:8px; background-size:cover; background-position:center; border:1px dashed #e6eef2; display:flex; align-items:center; justify-content:center; color:#6b7280; }

  /* Disponibilidad de usuario */
  #regDocentePage .avail{ display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:10px; font-weight:800; margin-top:6px; border:1px solid #e6eef2; background:#f3f6f9; color:#0b2545; }
  #regDocentePage .avail.good{ background:#ecfdf5; border-color:#bbf7d0; color:#065f46; }
  #regDocentePage .avail.bad{ background:#fff1f0; border-color:#f5c2c7; color:#7a0021; }

  /* Password meter + ojo custom */
  #regDocentePage .pw-meter{ height:8px; width:100%; background:#eef2f7; border-radius:999px; overflow:hidden; margin-top:6px; }
  #regDocentePage .pw-meter > div{ height:8px; width:0%; background:#ef4444; transition: width .2s ease; }
  #regDocentePage .pw-tip{ font-size:12px; color:#6b7280; margin-top:6px; }

  #regDocentePage input[type="password"]::-webkit-textfield-decoration-container,
  #regDocentePage input[type="password"]::-webkit-password-reveal-button,
  #regDocentePage input[type="password"]::-ms-reveal,
  #regDocentePage input[type="password"]::-ms-clear{ display:none !important; appearance:none !important; width:0; height:0; margin:0; padding:0; border:0; pointer-events:none; }
  #regDocentePage input[type="password"]{ -moz-appearance:textfield !important; }
  #regDocentePage .pwd-wrap{ position:relative; }
  #regDocentePage .pwd-wrap input{ padding-right:42px; }
  #regDocentePage .toggle-eye{ position:absolute; right:8px; top:50%; transform:translateY(-50%); background:transparent; border:0; cursor:pointer; font-size:16px; color:#6b7280; padding:6px; border-radius:8px; }
  #regDocentePage .toggle-eye:hover{ background:#f3f6f9; color:#0b2545; }

  /* Chips materias */
  #regDocentePage .chipbox{ display:flex; gap:8px; flex-wrap:wrap; max-height:210px; overflow:auto; padding:6px; border:1px dashed #e6eef2; border-radius:10px; background:#fafcff; }
  #regDocentePage .chip{ display:inline-flex; align-items:center; gap:8px; padding:6px 10px; border-radius:999px; border:1px solid #e6eef2; background:#fff; font-size:13px; }
  #regDocentePage .chip input{ transform:translateY(1px); }

  /* Correo institucional con dominio fijo */
  #regDocentePage .email-row{ display:flex; align-items:stretch; gap:0; max-width:540px; }
  #regDocentePage .email-local{ flex:1; border-top-right-radius:0; border-bottom-right-radius:0; border-right:0; }
  #regDocentePage .email-addon{ display:flex; align-items:center; padding:0 12px; border:1px solid #e6eef2; background:#f3f6f9; border-left:0; border-top-right-radius:8px; border-bottom-right-radius:8px; font-weight:700; color:#0b2545; white-space:nowrap; }

  @media (max-width:680px){
    #regDocentePage .btn-icon .label{ display:none; }
    #regDocentePage .btn-icon{ padding:10px; }
  }
</style>

<div id="regDocentePage" class="content-inner">
  <div class="page-header">
    <div>
      <div class="page-title"><?= safeStr($HEADER_TITLE) ?></div>
      <div class="page-sub"><?= safeStr($HEADER_SUB) ?></div>
    </div>
    <div>
      <a class="btn ghost btn-icon" href="<?= safeStr(base_url('admin/gestionar_docentes.php')) ?>" title="Volver">
        <i class="fas fa-arrow-left"></i> <span class="label">Volver</span>
      </a>
    </div>
  </div>

  <?php if (!empty($errors)): ?>
    <div class="card" role="alert" style="border:1px solid #f5c2c7;background:#fff1f0;color:#7a0021;">
      <ul style="padding-left:18px;"><?php foreach ($errors as $e): ?><li><?= safeStr($e) ?></li><?php endforeach; ?></ul>
    </div>
  <?php endif; ?>

  <form method="post" enctype="multipart/form-data" novalidate>
    <input type="hidden" name="csrf" value="<?= safeStr($CSRF) ?>">

    <!-- Foto -->
    <section class="card">
      <h3 style="margin-bottom:6px;">Foto de perfil</h3>
      <p class="hint">Opcional. JPG/PNG/GIF/WEBP (máx. 3 MB).</p>
      <div class="form-grid" style="margin-top:12px;">
        <div class="photo-row">
          <div class="photo-preview" id="preview" style="background-image:url('<?= safeStr($fotoPreview) ?>');"></div>
          <label class="field" style="flex:1;">
            <span class="label">Seleccionar imagen</span>
            <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/gif, image/webp">
          </label>
        </div>
      </div>
    </section>

    <!-- Datos personales -->
    <section class="card">
      <h3 style="margin-bottom:6px;">Datos personales</h3>
      <div class="form-grid">
        <label class="field">
          <span class="label">Nombre</span>
          <input type="text" name="nombre" id="nombre" minlength="2" required value="<?= safeStr($old['nombre']) ?>" placeholder="Escribe el nombre">
        </label>
        <label class="field">
          <span class="label">Apellidos</span>
          <input type="text" name="apellidos" id="apellidos" minlength="2" required value="<?= safeStr($old['apellidos']) ?>" placeholder="Escribe los apellidos">
        </label>

        <!-- Correo institucional con dominio fijo -->
        <label class="field" style="grid-column:1/-1">
          <span class="label">Correo institucional</span>
          <div class="email-row">
            <input type="text" class="email-local" name="email_local" id="email_local" placeholder="Usuario de correo (antes de <?= safeStr(EMAIL_DOMAIN) ?>)" required value="<?= safeStr($old['email_local']) ?>">
            <div class="email-addon"><?= safeStr(EMAIL_DOMAIN) ?></div>
          </div>
        </label>
      </div>
    </section>

    <!-- Acceso -->
    <section class="card">
      <h3 style="margin-bottom:6px;">Datos de acceso</h3>
      <div class="form-grid">
        <label class="field">
          <span class="label">Usuario</span>
          <input type="text" name="username" id="username" minlength="3" required value="<?= safeStr($old['username']) ?>" autocomplete="off" placeholder="Escribe el nombre del usuario">
          <div id="unameStatus" class="avail" role="status" aria-live="polite" aria-atomic="true" style="display:none;">
            <i class="fas fa-circle-notch fa-spin"></i> Comprobando…
          </div>
        </label>

        <label class="field">
          <span class="label">Contraseña</span>
          <div class="pwd-wrap">
            <input type="password" name="password" id="password" placeholder="Escribe la contraseña" required minlength="8" autocomplete="new-password" />
            <button type="button" class="toggle-eye" data-target="password" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
              <i class="far fa-eye"></i>
            </button>
          </div>
          <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
          <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
        </label>

        <label class="field">
          <span class="label">Confirmar contraseña</span>
          <div class="pwd-wrap">
            <input type="password" name="password2" id="password2" placeholder="Confirma la contraseña" required minlength="8" autocomplete="new-password" />
            <button type="button" class="toggle-eye" data-target="password2" aria-label="Mostrar/Ocultar contraseña" title="Mostrar/Ocultar contraseña">
              <i class="far fa-eye"></i>
            </button>
          </div>
          <small id="pwMatchHint" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
        </label>
      </div>
    </section>

    <!-- Permisos por materia -->
    <section class="card">
      <h3 style="margin-bottom:6px;">Permisos: materias en las que puede publicar</h3>
      <div class="form-grid">
        <label class="field full">
          <span class="label">Buscar materia</span>
          <input type="text" id="buscarMateria" placeholder="Escribe para filtrar…">
        </label>
        <div class="full">
          <div id="chips" class="chipbox" role="listbox" aria-label="Materias disponibles">
            <?php foreach ($materias as $m):
              $clave = (string)$m['clave']; $nom = (string)$m['nombre'];
              $checked = in_array($clave, $old['materias'], true) ? 'checked' : '';
            ?>
              <label class="chip" data-text="<?= safeStr(mb_strtolower($clave.' '.$nom)) ?>">
                <input type="checkbox" name="materias[]" value="<?= safeStr($clave) ?>" <?= $checked ?>>
                <span><strong><?= safeStr($clave) ?></strong> — <?= safeStr($nom) ?></span>
              </label>
            <?php endforeach; ?>
          </div>
          <div class="hint" style="margin-top:6px;">Selecciona una o varias (opcional). Puedes modificarlas después.</div>
        </div>
      </div>
    </section>

    <div class="actions">
      <button type="submit" class="btn"><i class="fas fa-user-plus"></i> Registrar docente</button>
      <a class="btn ghost btn-icon" href="<?= safeStr(base_url('admin/gestionar_docentes.php')) ?>" title="Cancelar">
        <i class="fas fa-xmark"></i> <span class="label">Cancelar</span>
      </a>
    </div>
  </form>
</div>

<script>
/* ====== Fallback para marcar menú activo y títulos si el header no los setea ====== */
(function(){
  if (window.setActiveMenu) window.setActiveMenu('docentes');
  if (window.setPageTitles) window.setPageTitles('<?= safeStr($HEADER_TITLE) ?>','<?= safeStr($HEADER_SUB) ?>');
  const a = document.querySelector('aside.sidebar a[href$="gestionar_docentes.php"]');
  if (a) a.classList.add('active');
  if (!document.title || document.title.indexOf('Registrar docente') === -1) {
    document.title = '<?= safeStr($PAGE_TITLE) ?>';
  }
})();

/* ===== Util ===== */
function pulse(el){ if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); setTimeout(()=>el.classList.remove('pulse'), 450); }

/* ===== Imagen preview ===== */
(function(){
  const foto=document.getElementById('foto');
  const preview=document.getElementById('preview');
  const def=<?= json_encode($fotoPreview) ?>;
  foto?.addEventListener('change', e=>{
    const f=e.target.files[0]; if(!f){ preview.style.backgroundImage=`url('${def}')`; return; }
    if(f.size>3*1024*1024){ alert('La imagen excede 3 MB.'); foto.value=''; preview.style.backgroundImage=`url('${def}')`; return; }
    const reader=new FileReader();
    reader.onload=()=> preview.style.backgroundImage=`url('${reader.result}')`;
    reader.readAsDataURL(f);
  });
})();

/* ===== Disponibilidad de usuario ===== */
(function(){
  const unameInput = document.getElementById('username');
  const unameStatus = document.getElementById('unameStatus');
  const submitBtn = document.querySelector('button[type="submit"]');
  let timer=null, ok=false;

  function setStatus(state, text, icon){
    unameStatus.style.display='inline-flex';
    unameStatus.classList.remove('good','bad');
    if(state==='good') unameStatus.classList.add('good');
    if(state==='bad')  unameStatus.classList.add('bad');
    unameStatus.innerHTML = `<i class="fas ${icon}"></i> ${text}`;
  }
  async function check(u){
    if(!u || u.trim().length<3){
      ok=false; setStatus('', 'Escribe al menos 3 caracteres.', 'fa-info-circle');
      submitBtn && (submitBtn.disabled=true); return;
    }
    setStatus('', 'Comprobando…', 'fa-circle-notch fa-spin');
    try{
      const res = await fetch(`?ajax=username&u=${encodeURIComponent(u)}`, {cache:'no-store'});
      const data = await res.json();
      if(data.ok && data.available){ ok=true; setStatus('good','Disponible','fa-check-circle'); submitBtn && (submitBtn.disabled=false); }
      else { ok=false; setStatus('bad','No disponible','fa-times-circle'); submitBtn && (submitBtn.disabled=true); }
    }catch(e){
      ok=false; setStatus('bad','Error al comprobar','fa-exclamation-triangle'); submitBtn && (submitBtn.disabled=true);
    }
  }
  unameInput?.addEventListener('input', ()=>{
    clearTimeout(timer);
    timer=setTimeout(()=> check(unameInput.value.trim()), 300);
  });
  document.addEventListener('DOMContentLoaded', ()=>{
    const v = unameInput?.value.trim() || '';
    if (v.length) check(v);
  });
})();

/* ===== Password meter + match ===== */
(function(){
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');
  const bar=document.getElementById('pwBar');
  const tip=document.getElementById('pwTip');
  const matchHint=document.getElementById('pwMatchHint');

  function scorePassword(pw){
    let score=0; if(!pw) return 0;
    const letters={};
    for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
    const variations={ digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
    let vc=0; for(const k in variations) vc += variations[k] ? 1 : 0;
    score += (vc - 1) * 10; return parseInt(score);
  }
  function updateMeter(){
    const val=p1.value||'';
    const s=Math.min(100, scorePassword(val));
    bar.style.width = (val ? Math.max(8,s) : 0) + '%';
    if (!val){ tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
    if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
    else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
    else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
    else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
    pulse(bar.parentElement);
  }
  function updateMatch(){
    if(!p2.value){ matchHint.style.display='none'; return; }
    matchHint.style.display = (p1.value !== p2.value) ? 'block' : 'none';
    if (matchHint.style.display==='block') pulse(matchHint);
  }
  ['input','change','keyup','blur'].forEach(ev=>{
    p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
    p2?.addEventListener(ev, updateMatch);
  });
  updateMeter(); updateMatch();
})();

/* ===== Ojo de contraseña custom ===== */
(function(){
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });
})();

/* ===== Filtro de materias ===== */
(function(){
  const txt=document.getElementById('buscarMateria');
  const chips=[...document.querySelectorAll('#chips .chip')];
  function applyFilter(){
    const q=(txt.value||'').trim().toLowerCase();
    chips.forEach(ch=>{
      const t=(ch.getAttribute('data-text')||'').toLowerCase();
      ch.style.display = t.includes(q) ? 'inline-flex' : 'none';
    });
  }
  txt?.addEventListener('input', applyFilter);
  applyFilter();
})();

/* ===== Validación final (cliente) ===== */
(function(){
  const form=document.querySelector('#regDocentePage form');
  const emailLocal=document.getElementById('email_local');
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');

  form?.addEventListener('submit', (e)=>{
    const local = (emailLocal.value||'').trim();
    if (!/^[a-z0-9._-]{2,64}$/i.test(local)) { e.preventDefault(); alert('Usuario de correo inválido.'); emailLocal.focus(); return; }
    if (p1.value.length < 8){ e.preventDefault(); alert('La contraseña debe tener al menos 8 caracteres.'); p1.focus(); return; }
    if (p1.value !== p2.value){ e.preventDefault(); alert('Las contraseñas no coinciden.'); p2.focus(); return; }
  });
})();
</script>

<?php require __DIR__ . '/../partials/footer.php'; ?>
