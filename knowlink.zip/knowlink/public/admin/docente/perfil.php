<?php
// public/admin/docente/perfil.php
// Compatibilidad con rutas antiguas: carga el perfil unificado.
declare(strict_types=1);
require __DIR__ . '/../../perfil.php';
