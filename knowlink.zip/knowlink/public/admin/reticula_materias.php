<?php
// public/admin/reticula_materias.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Normalizador de foto (compatibilidad con header)
if (!function_exists('str_starts_with')) {
  function str_starts_with($h,$n){ return $n!=='' && strpos($h,$n)===0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    if (preg_match('#^(?:https?:)?//#i',$u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#','/',$u);
    if (preg_match('#uploads/avatars/[^?\#]+#i',$u,$m)) $u = '/' . ltrim($m[0],'/');
    else $u = '/' . ltrim($u,'/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ------------------------ Helpers de Token ------------------------ */
function resolve_reticula_from_token(string $token): ?int {
  $entry = $_SESSION['reticula_materias_tokens'][$token] ?? null;
  if (!$entry) return null;
  if (!is_array($entry) || ($entry['exp'] ?? 0) < time()) {
    unset($_SESSION['reticula_materias_tokens'][$token]);
    return null;
  }
  // Rolling 5 min
  $_SESSION['reticula_materias_tokens'][$token]['exp'] = time() + 300;
  return (int)$entry['id'];
}

/* =============================== AJAX =============================== */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  $ctype = $_SERVER['CONTENT_TYPE'] ?? '';
  if (stripos($ctype, 'application/json') !== false) {
    $raw = file_get_contents('php://input');
    $in  = json_decode($raw, true) ?: [];
    $action = (string)($in['ajax'] ?? '');

    if (in_array($action, ['list','search_materias','add','update_semestre','delete'], true)) {
      header('Content-Type: application/json; charset=utf-8');

      // Valida CSRF + token
      $csrf  = (string)($in['csrf'] ?? '');
      $token = (string)($in['token'] ?? '');
      if (!hash_equals($_SESSION['csrf'] ?? '', $csrf)) {
        http_response_code(400); echo json_encode(['ok'=>false,'err'=>'csrf']); exit;
      }
      $reticula_id = resolve_reticula_from_token($token);
      if (!$reticula_id) { http_response_code(401); echo json_encode(['ok'=>false,'err'=>'token']); exit; }

      try {
        if ($action === 'list') {
          $sql = "
            SELECT rm.id, rm.materia_clave, rm.semestre, rm.horas_teoria, rm.horas_practica,
                   m.nombre AS materia_nombre
            FROM reticula_materias rm
            JOIN materias m ON LOWER(m.clave) = LOWER(rm.materia_clave)
            WHERE rm.reticula_id = :rid
            ORDER BY rm.semestre ASC, m.nombre ASC
          ";
          $st = $pdo->prepare($sql);
          $st->execute([':rid'=>$reticula_id]);
          $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
          echo json_encode(['ok'=>true, 'rows'=>$rows]); exit;
        }

        if ($action === 'search_materias') {
          $q = trim((string)($in['q'] ?? ''));
          if ($q === '' || mb_strlen($q) < 2) { echo json_encode(['ok'=>true,'items'=>[]]); exit; }

          $st = $pdo->prepare("
            SELECT m.clave, m.nombre,
              EXISTS(SELECT 1 FROM reticula_materias rm WHERE rm.reticula_id=:rid AND LOWER(rm.materia_clave)=LOWER(m.clave)) AS ya
            FROM materias m
            WHERE m.clave LIKE :q OR m.nombre LIKE :q
            ORDER BY m.clave ASC
            LIMIT 20
          ");
          $st->execute([':rid'=>$reticula_id, ':q'=>"%$q%"]);
          $items = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];
          echo json_encode(['ok'=>true, 'items'=>$items]); exit;
        }

        if ($action === 'add') {
          $refMateria = trim((string)($in['materia_clave'] ?? ''));
          $clave = $refMateria !== '' ? resolve_materia_clave($pdo, $refMateria) : null;
          $sem   = (int)($in['semestre'] ?? 0);
          if (!$clave || $sem < 1 || $sem > 9) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'bad_input']); exit; }

          try{
            $ins = $pdo->prepare("INSERT INTO reticula_materias (reticula_id, materia_clave, semestre) VALUES (:rid,:c,:s)");
            $ins->execute([':rid'=>$reticula_id, ':c'=>$clave, ':s'=>$sem]);
          } catch (Throwable $e) {
            http_response_code(409); echo json_encode(['ok'=>false,'err'=>'dup']); exit;
          }

          $st = $pdo->prepare("
            SELECT rm.id, rm.materia_clave, rm.semestre, m.nombre AS materia_nombre
            FROM reticula_materias rm JOIN materias m ON LOWER(m.clave)=LOWER(rm.materia_clave)
            WHERE rm.reticula_id=:rid AND LOWER(rm.materia_clave)=LOWER(:c)
          ");
          $st->execute([':rid'=>$reticula_id, ':c'=>$clave]);
          $row = $st->fetch(PDO::FETCH_ASSOC);

          try {
            $pdo->prepare("INSERT INTO admin_eventos (tipo, referencia, descripcion) VALUES ('materia', :ref, :d)")
                ->execute([':ref'=>$clave, ':d'=>'Materia agregada a retícula ID '.$reticula_id]);
          } catch(Throwable $e){}

          echo json_encode(['ok'=>true, 'row'=>$row]); exit;
        }

        if ($action === 'update_semestre') {
          $rmid = (int)($in['id'] ?? 0);
          $sem  = (int)($in['semestre'] ?? 0);
          if ($rmid<=0 || $sem < 1 || $sem > 9) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'bad_input']); exit; }

          $st = $pdo->prepare("SELECT materia_clave FROM reticula_materias WHERE id=:id AND reticula_id=:rid");
          $st->execute([':id'=>$rmid, ':rid'=>$reticula_id]);
          $clave = $st->fetchColumn();
          if (!$clave) { http_response_code(404); echo json_encode(['ok'=>false,'err'=>'not_found']); exit; }

          $up = $pdo->prepare("UPDATE reticula_materias SET semestre=:s WHERE id=:id");
          $up->execute([':s'=>$sem, ':id'=>$rmid]);

          echo json_encode(['ok'=>true]); exit;
        }

        if ($action === 'delete') {
          $rmid = (int)($in['id'] ?? 0);
          if ($rmid<=0) { http_response_code(400); echo json_encode(['ok'=>false,'err'=>'bad_input']); exit; }
          $del = $pdo->prepare("DELETE FROM reticula_materias WHERE id=:id AND reticula_id=:rid");
          $del->execute([':id'=>$rmid, ':rid'=>$reticula_id]);
          echo json_encode(['ok'=>true]); exit;
        }

      } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok'=>false,'err'=>'db']);
      }
      exit;
    }
  }
}

/* ===================== Entrada inicial por POST (token) ===================== */
$token = '';
$reticula = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['go_rm'])) {
  $token = (string)($_POST['token'] ?? '');
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) { http_response_code(400); echo "CSRF inválido."; exit; }
  $rid = resolve_reticula_from_token($token);
  if (!$rid) { http_response_code(401); echo "Token inválido o expirado."; exit; }

  $_SESSION['reticula_materias_current'] = $token;

  $st = $pdo->prepare("
    SELECT r.id, r.clave, r.nombre, r.vigente_desde, r.vigente_hasta,
           c.nombre AS carrera_nombre, c.clave AS carrera_clave
    FROM reticulas r
    JOIN carreras c ON c.id = r.carrera_id
    WHERE r.id = :id
    LIMIT 1
  ");
  $st->execute([':id'=>$rid]);
  $reticula = $st->fetch(PDO::FETCH_ASSOC);

} else {
  $token = (string)($_SESSION['reticula_materias_current'] ?? '');
  $rid = $token ? resolve_reticula_from_token($token) : 0;
  if ($rid) {
    $st = $pdo->prepare("
      SELECT r.id, r.clave, r.nombre, r.vigente_desde, r.vigente_hasta,
             c.nombre AS carrera_nombre, c.clave AS carrera_clave
      FROM reticulas r
      JOIN carreras c ON c.id = r.carrera_id
      WHERE r.id = :id LIMIT 1
    ");
    $st->execute([':id'=>$rid]);
    $reticula = $st->fetch(PDO::FETCH_ASSOC);
  }
}

if (!$reticula) { http_response_code(400); echo "Acceso inválido."; exit; }

/* ======================= Header / variables de vista ======================= */
$active   = 'reticulas';
$title    = 'ITZ KnowLink - Administrador · Materias de retícula';
$h1       = 'Materias de la retícula';
$subtitle = esc($reticula['clave'].' — '.$reticula['nombre'].' · '.$reticula['carrera_nombre'].' ('.$reticula['carrera_clave'].')');

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

require __DIR__ . '/partials/header.php';
?>
<meta name="csrf" content="<?= esc($CSRF) ?>">
<meta name="token" content="<?= esc($token) ?>">

<style>
  :root{
    --kl-bg:#f7fafc; --kl-card:#ffffff; --kl-muted:#64748b; --kl-ink:#0b2545;
    --kl-accent:#0055d4; --kl-accent-2:#0fb5bf; --kl-soft:#e6eef2;
    --kl-soft-2:#dbe6f0; --kl-soft-3:#eef6ff;
    --kl-danger:#ef4444;
  }

  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:var(--kl-ink)}
  .page-sub{color:var(--kl-muted);font-size:14px}

  .card{background:var(--kl-card);border-radius:14px;padding:16px;box-shadow:0 16px 42px rgba(2,6,23,0.06);margin-bottom:16px;border:1px solid var(--kl-soft)}
  .tools{display:flex;gap:10px;align-items:flex-end;flex-wrap:wrap}
  .field input, .field select{padding:10px 12px;border-radius:10px;border:1px solid var(--kl-soft);background:#fff;font-size:14px;outline:none;min-width:220px}
  .field label{font-size:12px;color:var(--kl-muted);display:block;margin:0 0 6px}

  .btn{padding:10px 14px;border-radius:10px;border:0;cursor:pointer;font-weight:800}
  .btn.primary{background:linear-gradient(90deg,var(--kl-ink),var(--kl-accent-2));color:#fff}
  .btn.ghost{background:#fff;border:1px solid var(--kl-soft);color:var(--kl-ink)}
  .btn.icon{display:inline-flex;align-items:center;gap:8px}

  /* Grid de semestres (claro) */
  .sem-wrap{overflow:auto}
  .sem-grid{
    display:grid;
    grid-template-columns: repeat(9, minmax(260px, 1fr));
    gap:14px;
    min-height: 320px;
  }
  .sem-col{
    background:linear-gradient(180deg,#ffffff,#f9fbff);
    border-radius:14px;padding:12px;color:var(--kl-ink);
    border:1px solid var(--kl-soft);
  }
  .sem-head{font-weight:800;margin-bottom:10px;display:flex;align-items:center;justify-content:space-between}
  .sem-count{font-size:12px;color:#6b7280}
  .dropzone{
    min-height:92px;display:flex;flex-direction:column;gap:10px;
    padding:6px;border-radius:10px;background: lightblue;
    border:1px dashed var(--kl-soft-2); transition:background .12s,border-color .12s, box-shadow .12s;
  }
  .dropzone.empty::after{
    content:'Arrastra materias aquí'; color:#9aa7b6;font-size:12px;
    padding:10px; text-align:center;
  }
  .dropzone.over{
    background:rgba(0,85,212,.08); border-color: rgba(0,85,212,.40);
    box-shadow: inset 0 0 0 2px rgba(0,85,212,.10);
  }

  /* Tarjetas (claras) */
  .mat{
    background:#ffffff; border:1px solid var(--kl-soft); border-radius:12px; padding:10px 10px 8px 10px;
    cursor:grab; box-shadow:0 8px 18px rgba(2,6,23,.06);
    transition: transform .12s ease, box-shadow .12s ease, background .12s ease, border-color .12s ease;
  }
  .mat:hover{ transform: translateY(-2px); box-shadow:0 12px 26px rgba(2,6,23,.12); }
  .mat.drag{ opacity:.85; cursor:grabbing; }
  .mat .clave{font-weight:900;font-size:12px;color:#0b3ea8;background:#eef4ff;border:1px solid #dbeafe;padding:2px 6px;border-radius:999px}
  .mat .nombre{font-size:13px;color:#334155;margin-top:6px}
  .mat .ops{display:flex;gap:8px;margin-top:8px; align-items:center;}
  .mat .chip{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border-radius:999px;border:1px solid #dbeafe;background:#f1f5ff;color:#1e3a8a;font-size:12px}
  .mat .rm{
    margin-left:auto;background:#fff;border:1px solid #e5e7eb;color:#991b1b;border-radius:8px;padding:6px;cursor:pointer;line-height:0;
  }
  .mat .rm:hover{background:#fee2e2;border-color:#fecaca}

  /* Sugerencias: deben quedar sobre la retícula, pero debajo de la barra superior */
  .materia-search-card{
    position:relative;
    z-index:30;
    overflow:visible !important;
  }
  .sem-wrap{
    position:relative;
    z-index:1;
    overflow:auto;
  }
  .sugs{
    position:relative;
    z-index:40;
    overflow:visible !important;
  }
  .sug-box{
    position:absolute;
    top:calc(100% + 8px);
    left:0;
    right:0;
    background:#fff;
    border:1px solid var(--kl-soft);
    border-radius:16px;
    box-shadow:0 24px 58px rgba(2,6,23,.20);
    display:none;
    z-index:80;
    max-height:340px;
    overflow:auto;
    overscroll-behavior:contain;
  }
  .sug-box::before{
    content:'';
    position:absolute;
    left:18px;
    top:-7px;
    width:14px;
    height:14px;
    background:inherit;
    border-left:1px solid var(--kl-soft);
    border-top:1px solid var(--kl-soft);
    transform:rotate(45deg);
  }
  html[data-theme="dark"] .sug-box{
    background:#111827;
    border-color:rgba(148,163,184,.24);
    box-shadow:0 30px 80px rgba(0,0,0,.55);
  }
  .sug-item{padding:10px 12px;display:flex;gap:10px;align-items:center;cursor:pointer;position:relative;z-index:1}
  .sug-item.disabled{opacity:.5;cursor:not-allowed}
  .sug-item:hover{background:#f5f8ff}
  .sug-item .clave{width:92px;font-weight:800;color:var(--kl-ink)}
  .sug-item .nombre{color:#334155;font-size:14px}

  /* Ajustes específicos para modo oscuro en esta pantalla */
  html[data-theme="dark"] .page-title{color:#f8fafc}
  html[data-theme="dark"] .page-sub,
  html[data-theme="dark"] .field label{color:#94a3b8}
  html[data-theme="dark"] .card{
    background:rgba(15,23,42,.92);
    border:1px solid rgba(148,163,184,.18);
    box-shadow:0 18px 45px rgba(0,0,0,.28);
  }
  html[data-theme="dark"] .materia-search-card{
    background:linear-gradient(180deg,rgba(15,23,42,.96),rgba(15,23,42,.90));
    border-color:rgba(148,163,184,.22);
  }
  html[data-theme="dark"] .field input,
  html[data-theme="dark"] .field select{
    background:rgba(2,6,23,.62);
    border-color:rgba(148,163,184,.24);
    color:#e5e7eb;
  }
  html[data-theme="dark"] .field input::placeholder{color:#64748b}
  html[data-theme="dark"] .field select option{background:#0f172a;color:#e5e7eb}
  html[data-theme="dark"] .btn.ghost{
    background:rgba(15,23,42,.78);
    border-color:rgba(148,163,184,.24);
    color:#e5e7eb;
  }
  html[data-theme="dark"] .sem-col{
    background:linear-gradient(180deg,rgba(15,23,42,.96),rgba(30,41,59,.92));
    border-color:rgba(148,163,184,.20);
    color:#e5e7eb;
    box-shadow:inset 0 1px 0 rgba(255,255,255,.03);
  }
  html[data-theme="dark"] .sem-head{color:#f8fafc}
  html[data-theme="dark"] .sem-count{color:#94a3b8}
  html[data-theme="dark"] .dropzone{
    background:rgba(2,6,23,.48);
    border-color:rgba(148,163,184,.26);
  }
  html[data-theme="dark"] .dropzone.empty::after{color:#94a3b8}
  html[data-theme="dark"] .dropzone.over{
    background:rgba(14,165,233,.12);
    border-color:rgba(56,189,248,.48);
    box-shadow:inset 0 0 0 2px rgba(56,189,248,.12);
  }
  html[data-theme="dark"] .mat{
    background:rgba(30,41,59,.96);
    border-color:rgba(148,163,184,.20);
    color:#e5e7eb;
    box-shadow:0 10px 24px rgba(0,0,0,.24);
  }
  html[data-theme="dark"] .mat:hover{box-shadow:0 14px 34px rgba(0,0,0,.34)}
  html[data-theme="dark"] .mat .clave{
    background:rgba(59,130,246,.16);
    border-color:rgba(96,165,250,.24);
    color:#bfdbfe;
  }
  html[data-theme="dark"] .mat .nombre{color:#cbd5e1}
  html[data-theme="dark"] .mat .chip{
    background:rgba(59,130,246,.12);
    border-color:rgba(96,165,250,.22);
    color:#c7d2fe;
  }
  html[data-theme="dark"] .mat .rm{
    background:rgba(15,23,42,.78);
    border-color:rgba(148,163,184,.20);
    color:#fca5a5;
  }
  html[data-theme="dark"] .mat .rm:hover{
    background:rgba(127,29,29,.28);
    border-color:rgba(248,113,113,.32);
  }
  html[data-theme="dark"] .sug-item:hover{background:rgba(59,130,246,.12)}
  html[data-theme="dark"] .sug-item .clave{color:#bfdbfe}
  html[data-theme="dark"] .sug-item .nombre{color:#cbd5e1}
  html[data-theme="dark"] .sug-item.disabled{opacity:.45}
  html[data-theme="dark"] .kl-toast .t{
    background:#0f172a;
    color:#e5e7eb;
    border-color:rgba(148,163,184,.22);
    box-shadow:0 14px 40px rgba(0,0,0,.35);
  }

  /* Toasts (claros) */
  .kl-toast{
    position: fixed; right: 18px; bottom: 18px; display:flex; flex-direction:column; gap:8px; z-index: 2000;
  }
  .kl-toast .t{
    background:#ffffff; color:#0b2545; border:1px solid #e2e8f0; border-radius:12px; padding:10px 12px; min-width: 220px;
    box-shadow:0 14px 40px rgba(2,6,23,.10);
  }

  @media (max-width:999px){
    .sem-grid{ grid-template-columns: repeat(3, minmax(240px, 1fr)); }
  }
  @media (max-width:640px){
    .sem-grid{ grid-template-columns: repeat(2, minmax(220px, 1fr)); }
    .field.sugs{min-width:100% !important;width:100%;}
    .sug-box{max-height:55vh;}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title">Materias por semestre</div>
    <div class="page-sub"><?= $subtitle ?></div>
  </div>
  <div style="display:flex;gap:8px;flex-wrap:wrap">
    <a class="btn ghost" href="<?= esc(base_url('admin/gestionar_reticulas.php')) ?>">
      &larr; Volver a retículas
    </a>
  </div>
</div>

<section class="card materia-search-card">
  <div class="tools" style="justify-content:space-between;">
    <div class="tools" style="gap:14px;align-items:flex-end">
      <div class="field sugs" style="min-width:320px;">
        <label>Buscar materia (clave o nombre)</label>
        <input type="text" id="buscar" placeholder="Ej. ACF0901 o 'Cálculo'" autocomplete="off" style="width:100%">
        <div id="sugBox" class="sug-box" role="listbox" aria-label="Sugerencias"></div>
      </div>
      <div class="field">
        <label>Semestre</label>
        <select id="semAdd">
          <?php for($i=1;$i<=9;$i++): ?>
            <option value="<?= $i ?>">Semestre <?= $i ?></option>
          <?php endfor; ?>
        </select>
      </div>
    </div>
    <div>
      <button class="btn primary icon" id="btnAdd" type="button"><i class="fas fa-plus"></i> <span class="label">Agregar</span></button>
    </div>
  </div>
</section>

<section class="card sem-wrap" aria-label="Cuadrícula de semestres">
  <div id="grid" class="sem-grid" role="grid" aria-label="Semestres">
    <?php for($i=1;$i<=9;$i++): ?>
      <div class="sem-col" data-sem="<?= $i ?>" role="region" aria-labelledby="semh-<?= $i ?>">
        <div class="sem-head">
          <div id="semh-<?= $i ?>">Semestre <?= $i ?></div>
          <div class="sem-count" id="count-<?= $i ?>">0</div>
        </div>
        <div class="dropzone empty" data-sem="<?= $i ?>" aria-label="Semestre <?= $i ?>"></div>
      </div>
    <?php endfor; ?>
  </div>
</section>

<div class="kl-toast" id="toast" aria-live="polite" aria-atomic="true"></div>

<script>
(function(){
  const CSRF  = document.querySelector('meta[name="csrf"]')?.getAttribute('content') || '';
  const TOKEN = document.querySelector('meta[name="token"]')?.getAttribute('content') || '';

  const grid   = document.getElementById('grid');
  const buscar = document.getElementById('buscar');
  const sugBox = document.getElementById('sugBox');
  const btnAdd = document.getElementById('btnAdd');
  const semAdd = document.getElementById('semAdd');
  const toast  = document.getElementById('toast');

  let lastResults = [];
  let chosenClave = '';

  function toastMsg(msg){
    const el = document.createElement('div');
    el.className='t';
    el.textContent = msg;
    toast.appendChild(el);
    setTimeout(()=>{ el.style.opacity='0'; el.style.transition='opacity .25s'; }, 1600);
    setTimeout(()=>{ el.remove(); }, 2000);
  }

  function escapeH(s){ return String(s).replace(/[&<>"']/g, m=>({'&':'&amp;','<':'&lt;','"':'&quot;',"'":'&#039;'}[m])); }

  async function postJSON(payload){
    const res = await fetch('',{
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify(Object.assign({csrf:CSRF, token:TOKEN}, payload))
    });
    return res;
  }

  function updateCounts(){
    for(let i=1;i<=9;i++){
      const zone = grid.querySelector(`.dropzone[data-sem="${i}"]`);
      const cnt  = zone ? zone.querySelectorAll('.mat').length : 0;
      const el   = document.getElementById('count-'+i);
      if (el) el.textContent = cnt + (cnt === 1 ? ' materia' : ' materias');
      if (zone){
        zone.classList.toggle('empty', cnt===0);
      }
    }
  }

  function makeCard(row){
    const div = document.createElement('div');
    div.className = 'mat';
    div.setAttribute('draggable','true');
    div.dataset.id = row.id;

    div.innerHTML = `
      <div class="clave">${escapeH(row.materia_clave)}</div>
      <div class="nombre">${escapeH(row.materia_nombre || '')}</div>
      <div class="ops">
        <span class="chip"><i class="fas fa-layer-group"></i> Sem ${escapeH(row.semestre)}</span>
        <button class="rm" type="button" title="Quitar" aria-label="Quitar"><i class="fas fa-times"></i></button>
      </div>
    `;

    // Drag & drop desde cualquier parte
    div.addEventListener('dragstart', (e)=>{
      div.classList.add('drag');
      e.dataTransfer.setData('text/plain', String(row.id));
      e.dataTransfer.effectAllowed = 'move';
    });
    div.addEventListener('dragend', ()=> div.classList.remove('drag'));

    // Quitar
    div.querySelector('.rm').addEventListener('click', async ()=>{
      if(!confirm('¿Quitar esta materia de la retícula?')) return;
      try{
        const r = await postJSON({ajax:'delete', id: row.id});
        const j = await r.json();
        if (!j.ok) { alert('No se pudo quitar.'); return; }
        div.remove();
        updateCounts();
        toastMsg('Materia quitada.');
      }catch(e){ alert('Error de red.'); }
    });

    return div;
  }

  function attachDropHandlers(){
    grid.querySelectorAll('.dropzone').forEach(zone=>{
      zone.addEventListener('dragenter', (e)=>{ e.preventDefault(); zone.classList.add('over'); });
      zone.addEventListener('dragover',  (e)=>{ e.preventDefault(); e.dataTransfer.dropEffect='move'; });
      zone.addEventListener('dragleave', ()=> zone.classList.remove('over'));
      zone.addEventListener('drop', async (e)=>{
        e.preventDefault(); zone.classList.remove('over');
        const id  = Number(e.dataTransfer.getData('text/plain'));
        const sem = Number(zone.dataset.sem || 0);
        if (!id || !sem) return;
        try{
          const r = await postJSON({ajax:'update_semestre', id, semestre: sem});
          const j = await r.json();
          if (!j.ok) { alert('No se pudo mover.'); return; }
          const card = grid.querySelector(`.mat[data-id="${id}"]`);
          if (card) {
            zone.appendChild(card);
            const chip = card.querySelector('.chip');
            if (chip) chip.innerHTML = `<i class="fas fa-layer-group"></i> Sem ${sem}`;
          }
          updateCounts();
          toastMsg(`Movida a Sem ${sem}.`);
        }catch(e){ alert('Error de red.'); }
      });
    });
  }

  async function loadGrid(){
    try{
      const res = await postJSON({ajax:'list'});
      const data = await res.json();
      if(!data.ok){ alert('No se pudieron cargar las materias.'); return; }

      grid.querySelectorAll('.dropzone').forEach(z=> z.innerHTML='');

      (data.rows||[]).forEach(row=>{
        const zone = grid.querySelector(`.dropzone[data-sem="${row.semestre}"]`) || grid.querySelector('.dropzone[data-sem="1"]');
        zone.appendChild(makeCard(row));
      });

      attachDropHandlers();
      updateCounts();
    }catch(e){ alert('Error de red al cargar.'); }
  }

  /* ----------- Búsqueda con sugerencias ----------- */
  function showSug(items){
    if (!items || !items.length) { sugBox.style.display='none'; sugBox.innerHTML=''; return; }
    sugBox.innerHTML = items.map(it=>{
      const disabled = Number(it.ya||0) ? 'disabled' : '';
      return `<div class="sug-item ${disabled}" role="option" data-clave="${escapeH(it.clave)}" data-ya="${it.ya?1:0}">
        <div class="clave">${escapeH(it.clave)}</div>
        <div class="nombre">${escapeH(it.nombre||'')}</div>
        ${it.ya?'<div style="margin-left:auto;font-size:12px;color:#9ca3af">Ya en retícula</div>':''}
      </div>`;
    }).join('');
    sugBox.style.display='block';

    sugBox.querySelectorAll('.sug-item').forEach(it=>{
      it.addEventListener('click', async ()=>{
        if (Number(it.dataset.ya)) return;
        const clave = it.dataset.clave;
        chosenClave = clave;
        await addMateria(clave, Number(semAdd.value));
        sugBox.style.display='none'; sugBox.innerHTML='';
        buscar.value = ''; chosenClave = '';
      });
    });
  }

  let t=null;
  buscar.addEventListener('input', ()=>{
    chosenClave = '';
    clearTimeout(t);
    const q = buscar.value.trim();
    if (q.length < 2){ sugBox.style.display='none'; sugBox.innerHTML=''; return; }
    t = setTimeout(async ()=>{
      try{
        const r = await postJSON({ajax:'search_materias', q});
        const j = await r.json();
        if (!j.ok) return;
        lastResults = j.items || [];
        showSug(lastResults);
      }catch(e){}
    }, 220);
  });
  document.addEventListener('click', (e)=>{ if(!document.querySelector('.sugs')?.contains(e.target)){ sugBox.style.display='none'; } });

  async function addMateria(clave, sem){
    if (!clave){ alert('Selecciona alguna materia.'); return; }
    try{
      const r = await postJSON({ajax:'add', materia_clave: clave, semestre: sem});
      const j = await r.json();
      if (!j.ok){
        if (j.err==='dup') alert('Esa materia ya está en la retícula.');
        else if (j.err==='no_materia') alert('La clave no existe.');
        else alert('No se pudo agregar.');
        return;
      }
      const zone = grid.querySelector(`.dropzone[data-sem="${sem}"]`);
      if (zone) zone.appendChild(makeCard(Object.assign(j.row||{}, {semestre: sem})));
      attachDropHandlers();
      updateCounts();
      toastMsg('Materia agregada.');
    }catch(e){ alert('Error de red.'); }
  }

  btnAdd.addEventListener('click', async ()=>{
    const typed = buscar.value.trim().toUpperCase();
    const sem   = Number(semAdd.value);
    if (chosenClave){ await addMateria(chosenClave, sem); return; }
    if (!typed){ alert('Escribe la clave o usa una sugerencia.'); return; }
    await addMateria(typed, sem);
  });

  // Carga inicial
  loadGrid();
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
