<?php
// public/admin/registrar_alumnos.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$usuario = auth_user();
if (!$usuario) { redirect(base_url('login.php')); exit; }
if (($usuario['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

/* ========= Helpers locales (como en gestionar_* para normalizar foto) ========= */
if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    // SVG de 88px para preview/placeholder
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="44" cy="32" r="16" fill="#cfd8e3"/><rect x="18" y="54" width="52" height="22" rx="11" fill="#cfd8e3"/></svg>'
    );
  }
}
/** foto_src: normaliza a URL ABSOLUTA para <img src="..."> */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    // Absoluta o data:
    if (preg_match('#^(?:https?:)?//#i', $u) || (isset($u[0]) && strncmp($u, 'data:', 5) === 0)) return $u;
    // Limpia ../
    while (strncmp($u, '../', 3) === 0) { $u = substr($u, 3); }
    // Forzar a /uploads/avatars/...
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();

/* ===================== AJAX: username disponible ===================== */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'check_username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  if ($u === '' || mb_strlen($u) < 3) { echo json_encode(['ok'=>false, 'avail'=>false]); exit; }
  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u");
  $st->execute([':u'=>$u]);
  $taken = (int)$st->fetchColumn() > 0;
  echo json_encode(['ok'=>true, 'avail'=>!$taken], JSON_UNESCAPED_UNICODE);
  exit;
}

/* ================= helpers servidor: semestre y retícula ============== */
function calcular_semestre_desde_no_control(string $no_control): int {
  $no_control = preg_replace('/\D+/', '', $no_control);
  if (strlen($no_control) < 2) return 1;
  $yy = (int)substr($no_control, 0, 2);
  $anio_ingreso = 2000 + $yy;

  $now = new DateTime('now');
  $start = new DateTime($anio_ingreso . '-08-01 00:00:00');
  if ($now < $start) return 1;

  $diff = $start->diff($now);
  $diffMonths = $diff->m + ($diff->y * 12);
  $sem = intdiv($diffMonths, 6) + 1;
  return max(1, min(12, $sem));
}

function obtener_reticula_para_ingreso(PDO $pdo, int $carrera_id, string $no_control): ?int {
  $no_control = preg_replace('/\D+/', '', $no_control);
  if (strlen($no_control) < 2 || $carrera_id <= 0) return null;
  $yy = (int)substr($no_control, 0, 2);
  $anio_ingreso = 2000 + $yy;

  $st = $pdo->prepare("
    SELECT id
    FROM reticulas
    WHERE carrera_id = :c
      AND YEAR(vigente_desde) <= :anio
      AND (vigente_hasta IS NULL OR YEAR(vigente_hasta) >= :anio)
    ORDER BY vigente_desde DESC
    LIMIT 1
  ");
  $st->execute([':c'=>$carrera_id, ':anio'=>$anio_ingreso]);
  $ret = $st->fetchColumn();
  if ($ret) return (int)$ret;

  $st = $pdo->prepare("
    SELECT id FROM reticulas
    WHERE carrera_id = :c AND YEAR(vigente_desde) <= :anio
    ORDER BY vigente_desde DESC
    LIMIT 1
  ");
  $st->execute([':c'=>$carrera_id, ':anio'=>$anio_ingreso]);
  $ret = $st->fetchColumn();
  return $ret ? (int)$ret : null;
}

/* ================= catálogo carreras + POST ================= */
$carreras = $pdo->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];

$errors = [];
$old = ['nombre'=>'','apellidos'=>'','numero_control'=>'','carrera'=>'0','username'=>''];
$defaultAvatar = avatar_placeholder();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $csrf = (string)($_POST['csrf'] ?? '');
  if (!hash_equals($CSRF, $csrf)) $errors[] = 'CSRF inválido.';

  $nombre     = trim((string)($_POST['nombre'] ?? ''));
  $apellidos  = trim((string)($_POST['apellidos'] ?? ''));
  $nc         = preg_replace('/\D+/', '', (string)($_POST['numero_control'] ?? ''));
  $carrera_id = (int)($_POST['carrera'] ?? 0);
  $username   = trim((string)($_POST['username'] ?? ''));
  $password   = (string)($_POST['password'] ?? '');
  $password2  = (string)($_POST['password2'] ?? '');

  $old = ['nombre'=>$nombre,'apellidos'=>$apellidos,'numero_control'=>$nc,'carrera'=>(string)$carrera_id,'username'=>$username];

  if ($nombre === '' || mb_strlen($nombre) < 3) $errors[] = 'Nombre es requerido (mín. 3).';
  if ($apellidos === '' || mb_strlen($apellidos) < 3) $errors[] = 'Apellidos son requeridos (mín. 3).';
  if (!preg_match('/^\d{8}$/', $nc)) $errors[] = 'Número de control inválido (8 dígitos).';
  if ($carrera_id <= 0) $errors[] = 'Selecciona una carrera.';
  if ($username === '' || mb_strlen($username) < 3) $errors[] = 'Usuario inválido (mín. 3).';
  if (mb_strlen($password) < 8) $errors[] = 'Contraseña demasiado corta (mín. 8).';
  if ($password !== $password2) $errors[] = 'Las contraseñas no coinciden.';

  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u");
  $st->execute([':u'=>$username]);
  if ((int)$st->fetchColumn() > 0) $errors[] = 'El nombre de usuario ya está en uso.';

  $st = $pdo->prepare("SELECT COUNT(*) FROM estudiantes WHERE no_control=:n");
  $st->execute([':n'=>$nc]);
  if ((int)$st->fetchColumn() > 0) $errors[] = 'El número de control ya existe.';

  $email = 'L'.$nc.'@zitacuaro.tecnm.mx';

  // ======= Foto (opcional) — guarda en /public/uploads/avatars y deja URL web /uploads/avatars/... =======
  $foto_url = null;
  if (!empty($_FILES['foto']['name'] ?? '')) {
    $f = $_FILES['foto'];
    if ($f['error'] === UPLOAD_ERR_OK) {
      if ($f['size'] > 3*1024*1024) $errors[] = 'La foto excede 3 MB.';
      $finfo = finfo_open(FILEINFO_MIME_TYPE);
      $mime  = finfo_file($finfo, $f['tmp_name']); finfo_close($finfo);
      $allowed = ['image/jpeg'=>'jpg','image/png'=>'png','image/gif'=>'gif','image/webp'=>'webp'];
      if (!isset($allowed[$mime])) $errors[] = 'Formato de imagen no permitido (JPG, PNG, GIF, WEBP).';
      if (!$errors) {
        $ext = $allowed[$mime];
        $dir = __DIR__ . '/../uploads/avatars'; // public/uploads/avatars
        if (!is_dir($dir)) { @mkdir($dir, 0775, true); }
        $fname = 'al_' . date('Ymd_His') . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
        $dest  = $dir . '/' . $fname;
        if (!move_uploaded_file($f['tmp_name'], $dest)) {
          $errors[] = 'No se pudo guardar la foto.';
        } else {
          $foto_url = '/uploads/avatars/' . $fname; // <- ruta web
        }
      }
    } elseif ($f['error'] !== UPLOAD_ERR_NO_FILE) {
      $errors[] = 'Error al subir la foto.';
    }
  }

  if (!$errors) {
    $semestre    = calcular_semestre_desde_no_control($nc);
    $reticula_id = obtener_reticula_para_ingreso($pdo, $carrera_id, $nc);

    try {
      $pdo->beginTransaction();

      $hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>10]);
      $pdo->prepare("INSERT INTO usuarios (nombre, apellidos, email, username, password_hash, rol, foto_url, activo, creado_en, actualizado_en)
                     VALUES (:n,:a,:e,:u,:p,'estudiante',:f,1,NOW(),NOW())")
          ->execute([':n'=>$nombre, ':a'=>$apellidos, ':e'=>$email, ':u'=>$username, ':p'=>$hash, ':f'=>$foto_url]);
      $uid = (int)$pdo->lastInsertId();

      $pdo->prepare("INSERT INTO estudiantes (usuario_id, no_control, reticula_id, carrera_id, semestre_actual)
                     VALUES (:uid,:nc,:ret,:car,:sem)")
          ->execute([':uid'=>$uid, ':nc'=>$nc, ':ret'=>$reticula_id, ':car'=>$carrera_id, ':sem'=>$semestre]);

      $pdo->commit();
      redirect(base_url('admin/gestionar_alumnos.php?ok=1'));
      exit;
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'No se pudo registrar al alumno. Intenta de nuevo.';
    }
  }
}

$fotoPreview = avatar_placeholder();

/* ==================== Variables para el header común ==================== */
$yo = $usuario;                         // el header usa $yo
// Si tu header lee $yo['foto'] (además de foto_url), lo dejamos listo:
$yo['foto'] = foto_src($yo['foto_url'] ?? null);

$title     = 'ITZ KnowLink - Administrador · Registrar alumno';
$pageTitle = 'Registrar alumno';
$pageSub   = 'Crea una cuenta de estudiante con validaciones automáticas';
$active    = 'alumnos';                 // resalta “Gestionar Estudiantes”

require __DIR__ . '/partials/header.php';
?>

<!-- ===== CSS específico de esta página (ligero) ===== -->
<style>
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px;position:relative}
  input[type="text"],input[type="email"],input[type="password"],select,textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,.06);margin-bottom:16px}
  .photo-row{display:flex;gap:12px;align-items:center}
  .photo-preview{width:88px;height:88px;border-radius:8px;background-size:cover;background-position:center;border:1px dashed #e6eef2;display:flex;align-items:center;justify-content:center;color:#6b7280}
  .email-preview{display:inline-flex;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;background:#f3f6f9;border:1px solid #e6eef2;transition:all .18s ease;font-weight:700;color:#0b2545}
  .email-preview .icon{font-size:14px;color:#6b7280}
  .email-preview.valid{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;box-shadow:0 8px 24px rgba(2,6,23,.06);transform:translateY(-2px) scale(1.02)}
  .email-preview.invalid{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}
  .avail{display:inline-flex;gap:10px;align-items:center;padding:6px 10px;border-radius:10px;border:1px solid #e6eef2;background:#f3f6f9;font-weight:700;margin-top:6px}
  .avail.check{color:#6b7280}
  .avail.ok{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;color:#065f46;box-shadow:0 8px 24px rgba(2,6,23,.06)}
  .avail.bad{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}
  .pw-meter{height:8px;width:100%;background:#eef2f7;border-radius:999px;overflow:hidden;margin-top:6px}
  .pw-meter > div{height:8px;width:0%;background:#ef4444;transition:width .2s ease}
  .pw-tip{font-size:12px;color:#6b7280;margin-top:6px}
  .pwd-wrap{position:relative}.pwd-wrap input{padding-right:42px}
  .toggle-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);background:transparent;border:0;cursor:pointer;font-size:16px;color:#6b7280;padding:6px;border-radius:8px}
  .toggle-eye:hover{background:#f3f6f9;color:#0b2545}
</style>

<!-- ===== PAGE HEADER (solo contenido; el layout viene del header común) ===== -->
<div class="page-header">
  <div>
    <div class="page-title"><?= esc($pageTitle) ?></div>
    <div class="page-sub"><?= esc($pageSub) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_alumnos.php')) ?>" aria-label="Volver a gestionar alumnos" title="Volver a gestionar alumnos">
      <i class="fas fa-arrow-left"></i><span class="label"> Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="card" role="alert" style="border:1px solid #f5c2c7;background:#fff1f0;color:#7a0021;">
    <ul style="padding-left:18px;"><?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<form method="post" enctype="multipart/form-data" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">

  <!-- Foto -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Foto de perfil</h3>
    <p class="hint">Opcional. JPG/PNG/GIF/WEBP (máx. 3 MB).</p>
    <div class="form-grid" style="margin-top:12px;">
      <div class="photo-row">
        <div class="photo-preview" id="preview" style="background-image:url('<?= esc($fotoPreview) ?>');"></div>
        <label class="field" style="flex:1;">
          <span class="label">Seleccionar imagen</span>
          <input type="file" id="foto" name="foto" accept="image/png, image/jpeg, image/gif, image/webp">
        </label>
      </div>
    </div>
  </section>

  <!-- Datos personales -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos personales</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" id="nombre" minlength="3" required value="<?= esc($old['nombre']) ?>" placeholder="Escribe el nombre">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" id="apellidos" minlength="3" required value="<?= esc($old['apellidos']) ?>" placeholder="Escribe los apellidos">
      </label>
      <label class="field">
        <span class="label">Carrera</span>
        <select name="carrera" id="carrera" required>
          <option value="0">-- Selecciona --</option>
          <?php foreach ($carreras as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((string)$old['carrera'] === (string)$c['id']) ? 'selected' : '' ?>><?= esc($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field">
        <span class="label">Número de control</span>
        <input type="text" name="numero_control" id="numero_control" inputmode="numeric" pattern="\d{8}" maxlength="8" required value="<?= esc($old['numero_control']) ?>" placeholder="Ingresa el número de control">
      </label>

      <label class="field">
        <span class="label">Semestre</span>
        <input type="text" id="semestre_view" value="" disabled aria-disabled="true" placeholder="0">
      </label>

      <label class="field">
        <span class="label">Correo institucional</span>
        <div style="display:flex; gap:10px; align-items:center;">
          <input type="hidden" id="correoHidden" value="">
          <div id="correoPreview" class="email-preview" role="status" aria-live="polite" title="Correo institucional generado">
            <span class="icon"><i class="fas fa-envelope"></i></span>
            <span id="correoPreviewText" class="email-text">—</span>
          </div>
        </div>
      </label>
    </div>
  </section>

  <!-- Acceso -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos de acceso</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" minlength="3" required value="<?= esc($old['username']) ?>" autocomplete="off" placeholder="Escribe el nombre del usuario">
        <div id="userAvail" class="avail" style="display:none;"></div>
      </label>

      <label class="field" id="fieldPwd">
        <span class="label">Contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="password" minlength="8" autocomplete="new-password" required placeholder="Escribe la contraseña">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="password">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
        <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
      </label>

      <label class="field" id="fieldPwd2">
        <span class="label">Confirmar contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="password2" minlength="8" autocomplete="new-password" required placeholder="Confirma la contraseña">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="password2">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <small id="pwMatch" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
      </label>

      <div class="actions" style="grid-column:1/-1;">
        <button type="submit" class="btn btn-icon">
          <i class="fas fa-save"></i><span class="label"> Guardar alumno</span>
        </button>
        <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_alumnos.php')) ?>">
          <i class="fas fa-xmark"></i><span class="label"> Cancelar</span>
        </a>
      </div>
    </div>
  </section>
</form>

<!-- ===== JS específico de esta página (ligero) ===== -->
<script>
function pulse(el){
  if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse');
  setTimeout(()=>el.classList.remove('pulse'), 450);
}
function escapeHtml(s){
  return (s ?? '').toString().replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

/* Foto preview */
(function(){
  const foto=document.getElementById('foto');
  const preview=document.getElementById('preview');
  const def=<?= json_encode($defaultAvatar) ?>;
  foto?.addEventListener('change', e=>{
    const f=e.target.files[0];
    if(!f){ preview.style.backgroundImage=`url('${def}')`; return; }
    if(f.size>3*1024*1024){ alert('La imagen excede 3 MB.'); foto.value=''; preview.style.backgroundImage=`url('${def}')`; return; }
    const reader=new FileReader();
    reader.onload=()=> preview.style.backgroundImage=`url('${reader.result}')`;
    reader.readAsDataURL(f);
  });
})();

/* Correo + semestre (vista) */
(function(){
  const nc=document.getElementById('numero_control');
  const h=document.getElementById('correoHidden');
  const p=document.getElementById('correoPreview');
  const t=document.getElementById('correoPreviewText');
  const semestreView=document.getElementById('semestre_view');

  function calcSemesterFromYear(year){
    if(!year || isNaN(year)) return '';
    const now=new Date();
    const start=new Date(year,7,1);
    if(now < start) return '1';
    const diffMonths = (now.getFullYear()-start.getFullYear())*12 + (now.getMonth()-start.getMonth());
    let sem = Math.floor(diffMonths/6) + 1;
    sem = Math.max(1, Math.min(12, sem));
    return String(sem);
  }
  function inferYearFromNC(n){
    if(!/^\d{2}/.test(n)) return null;
    const yy=parseInt(n.slice(0,2),10);
    return 2000 + yy;
  }
  function update(){
    let raw=(nc.value||'').replace(/\D/g,'').slice(0,8);
    if(raw!==nc.value) nc.value=raw;

    if(/^\d{8}$/.test(raw)){
      const email='L'+raw+'@zitacuaro.tecnm.mx';
      h.value=email; t.textContent=email;
      p.classList.remove('invalid'); p.classList.add('valid'); pulse(p);
    }else{
      h.value='';
      if(raw.length===0){ t.textContent='—'; p.classList.remove('valid','invalid'); }
      else { t.textContent='L'+raw+'…'; p.classList.remove('valid'); p.classList.add('invalid'); pulse(p); }
    }
    const year = inferYearFromNC(raw);
    const sem  = year ? calcSemesterFromYear(year) : '';
    semestreView.value = sem || '';
  }
  nc?.addEventListener('input', update);
  nc?.addEventListener('paste', ()=>setTimeout(update,0));
  nc?.addEventListener('blur', update);
  update();
})();

/* Usuario disponible */
(function(){
  const u=document.getElementById('username');
  const box=document.getElementById('userAvail');
  let t=null, last='';

  function show(text, cls, icon){
    box.style.display='inline-flex';
    box.className='avail ' + (cls||'');
    box.innerHTML = (icon ? `<i class="fas ${icon}"></i> ` : '') + text;
  }
  function hide(){ box.style.display='none'; }

  async function check({showSpinner=true}={}){
    const v=(u.value||'').trim();
    if(v===last && box.style.display!=='none') return;
    last=v;

    if(v.length===0){ hide(); return; }
    if(v.length<3){ show('Mínimo 3 caracteres','check','fa-info-circle'); return; }
    if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin');
    try{
      const res=await fetch('?ajax=check_username&u='+encodeURIComponent(v), {cache:'no-store'});
      if(!res.ok){ if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin'); return; }
      const data=await res.json();
      if (data.ok && data.avail){ show('Disponible ✓','ok','fa-check-circle'); pulse(box); }
      else { show('Ya está en uso ✗','bad','fa-times-circle'); pulse(box); }
    }catch(e){
      if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin');
    }
  }

  u?.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=> check({showSpinner:true}), 300); });
  document.addEventListener('DOMContentLoaded', ()=>{ const v=(u?.value||'').trim(); if (v.length>=3){ check({showSpinner:false}); } else { hide(); } });
})();

/* Contraseñas: medidor + match + ojo */
(function(){
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');
  const match=document.getElementById('pwMatch');
  const bar=document.getElementById('pwBar');
  const tip=document.getElementById('pwTip');

  function scorePassword(pw){
    let score=0; if(!pw) return 0;
    const letters={};
    for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
    const variations={ digits:/\d/.test(pw), lower:/[a-z]/.test(pw), upper:/[A-Z]/.test(pw), nonWords:/\W/.test(pw) };
    let vc=0; for(const k in variations) vc += variations[k] ? 1 : 0;
    score += (vc - 1) * 10; return parseInt(score);
  }
  function updateMeter(){
    const val=p1.value||'';
    const s=Math.min(100, scorePassword(val));
    bar.style.width = (val ? Math.max(8,s) : 0) + '%';
    if (!val){ tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
    if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
    else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
    else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
    else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
    pulse(bar.parentElement);
  }
  function updateMatch(){
    match.style.display = (p2.value && p1.value !== p2.value) ? 'block' : 'none';
    if (match.style.display==='block') pulse(match);
  }
  ['input','change','keyup','blur'].forEach(ev=>{
    p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
    p2?.addEventListener(ev, updateMatch);
  });
  updateMeter(); updateMatch();

  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });
})();
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
