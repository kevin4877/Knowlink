<?php
// public/admin/editar_alumno.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$admin = auth_user();
if (!$admin) { redirect(base_url('login.php')); exit; }
if (($admin['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

/* ================= Helpers locales ================= */
if (!function_exists('esc')) {
  function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="88" height="88"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="44" cy="32" r="16" fill="#cfd8e3"/><rect x="18" y="54" width="52" height="22" rx="11" fill="#cfd8e3"/></svg>'
    );
  }
}
/**
 * foto_src: normaliza a URL web ABSOLUTA para <img src="...">
 * Acepta: /uploads/avatars/... | uploads/avatars/... | ../uploads/avatars/... | http(s)://... | data:...
 */
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/',$url));
    // Absolutas o data:
    if (preg_match('#^(?:https?:)?//#i', $u) || strncmp($u, 'data:', 5) === 0) return $u;
    // Limpia ../
    while (strncmp($u, '../', 3) === 0) { $u = substr($u, 3); }
    // Forzar /uploads/avatars/...
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) {
      $path = '/' . ltrim($m[0], '/');
    } else {
      $path = '/' . ltrim($u, '/');
    }
    return function_exists('base_url') ? base_url(ltrim($path, '/')) : $path;
  }
}

function safeStr($v){ return esc($v); } // compat

if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

$pdo = db();

/* ================= AJAX: username disponible (excluye propio id) ================= */
if (isset($_GET['ajax']) && $_GET['ajax'] === 'check_username') {
  header('Content-Type: application/json; charset=utf-8');
  $u = trim((string)($_GET['u'] ?? ''));
  $excludeId = (int)($_GET['exclude_id'] ?? 0);
  if ($u === '' || mb_strlen($u) < 3) { echo json_encode(['ok'=>false, 'avail'=>false]); exit; }
  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username = :u AND id <> :id");
  $st->execute([':u'=>$u, ':id'=>$excludeId]);
  $taken = (int)$st->fetchColumn() > 0;
  echo json_encode(['ok'=>true, 'avail'=>!$taken], JSON_UNESCAPED_UNICODE);
  exit;
}

/* ================= Helpers: semestre / retícula ================= */
function year_from_no_control(string $no_control): ?int {
  $no_control = preg_replace('/\D+/', '', $no_control);
  if (strlen($no_control) < 2) return null;
  $yy = (int)substr($no_control, 0, 2);
  $curYY = (int)date('y');
  $year = 2000 + $yy;
  if ($yy > $curYY + 1) { $year = 1900 + $yy; }
  return $year;
}
/** Asumiendo ingreso en agosto. */
function calcular_semestre(int $anio_ingreso, ?DateTime $hoy = null): int {
  $hoy = $hoy ?: new DateTime('now');
  $inicio = new DateTime($anio_ingreso . '-08-01');
  if ($hoy < $inicio) return 1;
  $diffMeses = ((int)$hoy->format('Y') - (int)$inicio->format('Y')) * 12 + ((int)$hoy->format('n') - 8);
  $sem = intdiv($diffMeses, 6) + 1;
  return max(1, min(12, $sem));
}
function pick_reticula_por_anio(PDO $pdo, int $carrera_id, int $anio_ingreso): ?int {
  if ($carrera_id <= 0) return null;
  $st = $pdo->prepare("
    SELECT id
    FROM reticulas
    WHERE carrera_id = :c
      AND YEAR(vigente_desde) <= :y
      AND (vigente_hasta IS NULL OR YEAR(vigente_hasta) >= :y)
    ORDER BY vigente_desde DESC
    LIMIT 1
  ");
  $st->execute([':c'=>$carrera_id, ':y'=>$anio_ingreso]);
  $id = $st->fetchColumn();
  if ($id) return (int)$id;

  $st = $pdo->prepare("SELECT id FROM reticulas WHERE carrera_id=:c ORDER BY vigente_desde DESC LIMIT 1");
  $st->execute([':c'=>$carrera_id]);
  $id = $st->fetchColumn();
  return $id ? (int)$id : null;
}

/* ================= Cargar alumno por ?id o por sesión ================= */
$uid = (int)($_GET['id'] ?? ($_SESSION['edit_alumno_id'] ?? 0));
if ($uid <= 0) { http_response_code(400); echo "Falta id"; exit; }

$st = $pdo->prepare("
  SELECT u.id, u.nombre, u.apellidos, u.email, u.username, u.foto_url, u.activo, u.creado_en, u.actualizado_en,
         e.no_control, e.reticula_id, e.carrera_id, e.semestre_actual
  FROM usuarios u
  LEFT JOIN estudiantes e ON e.usuario_id = u.id
  WHERE u.id = :id AND u.rol = 'estudiante'
  LIMIT 1
");
$st->execute([':id'=>$uid]);
$alumno = $st->fetch(PDO::FETCH_ASSOC);
if (!$alumno) { http_response_code(404); echo "Alumno no encontrado"; exit; }

/* ================= Catálogos académicos ================= */
$carreras = $pdo->query("SELECT id, nombre FROM carreras ORDER BY nombre ASC")->fetchAll(PDO::FETCH_ASSOC) ?: [];
$reticulas = $pdo->query("
  SELECT r.id, r.carrera_id, r.clave, r.nombre, c.nombre AS carrera_nombre
  FROM reticulas r
  JOIN carreras c ON c.id = r.carrera_id
  ORDER BY c.nombre ASC, r.vigente_desde DESC, r.nombre ASC
")->fetchAll(PDO::FETCH_ASSOC) ?: [];

/* ================= Estado formulario ================= */
$errors = [];
$old = [
  'nombre'         => $alumno['nombre'] ?? '',
  'apellidos'      => $alumno['apellidos'] ?? '',
  'numero_control' => $alumno['no_control'] ?? '',
  'carrera'        => (string)($alumno['carrera_id'] ?? '0'),
  'reticula'       => (string)($alumno['reticula_id'] ?? '0'),
  'username'       => $alumno['username'] ?? '',
];
$fotoPreview = foto_src($alumno['foto_url'] ?? null);
$correo_institucional = (preg_match('/^\d{8}$/', (string)$old['numero_control'])) ? ('L'.$old['numero_control'].'@zitacuaro.tecnm.mx') : '';
$semestre_actual_vista = (int)($alumno['semestre_actual'] ?? 0);

/* =================== POST: ELIMINAR =================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['action'] ?? '') === 'delete')) {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) {
    $errors[] = 'CSRF inválido.';
  } else {
    $delId = (int)($_POST['id'] ?? 0);
    if ($delId !== $uid || $delId <= 0) {
      $errors[] = 'Solicitud inválida.';
    } else {
      try {
        // Verifica que sea estudiante
        $chk = $pdo->prepare("SELECT rol FROM usuarios WHERE id=:id LIMIT 1");
        $chk->execute([':id'=>$delId]);
        $rol = (string)$chk->fetchColumn();
        if ($rol !== 'estudiante') {
          $errors[] = 'Solo se pueden eliminar estudiantes.';
        } else {
          $pdo->beginTransaction();
          $pdo->prepare("DELETE FROM usuarios WHERE id=:id")->execute([':id'=>$delId]);
          $pdo->commit();

          if (isset($_SESSION['edit_alumno_id']) && (int)$_SESSION['edit_alumno_id'] === $delId) {
            unset($_SESSION['edit_alumno_id'], $_SESSION['edit_alumno_id_ts']);
          }

          redirect(base_url('admin/gestionar_alumnos.php?ok=del'));
          exit;
        }
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $errors[] = 'No se pudo eliminar el alumno. Verifica dependencias o intenta más tarde.';
      }
    }
  }
}

/* ================= POST: actualizar (SIN editar foto aquí) ================= */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['action'] ?? '') !== 'delete')) {
  if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) $errors[] = 'CSRF inválido.';

  $nombre     = trim((string)($_POST['nombre'] ?? ''));
  $apellidos  = trim((string)($_POST['apellidos'] ?? ''));
  $nc         = preg_replace('/\D+/', '', (string)($_POST['numero_control'] ?? ''));
  $carrera_id = (int)($_POST['carrera'] ?? 0);
  $reticula_manual_id = (int)($_POST['reticula_id'] ?? 0);
  $username   = trim((string)($_POST['username'] ?? ''));
  $password   = (string)($_POST['password'] ?? '');
  $password2  = (string)($_POST['password2'] ?? '');

  $old = [
    'nombre' => $nombre,
    'apellidos' => $apellidos,
    'numero_control' => $nc,
    'carrera' => (string)$carrera_id,
    'reticula' => (string)$reticula_manual_id,
    'username' => $username,
  ];

  if ($nombre === '' || mb_strlen($nombre) < 3) $errors[] = 'Nombre es requerido (mín. 3).';
  if ($apellidos === '' || mb_strlen($apellidos) < 3) $errors[] = 'Apellidos son requeridos (mín. 3).';
  if (!preg_match('/^\d{8}$/', $nc)) $errors[] = 'Número de control inválido (8 dígitos).';
  if ($carrera_id <= 0) $errors[] = 'Selecciona una carrera.';
  if ($reticula_manual_id > 0) {
    $st = $pdo->prepare("SELECT COUNT(*) FROM reticulas WHERE id=:rid AND carrera_id=:cid");
    $st->execute([':rid'=>$reticula_manual_id, ':cid'=>$carrera_id]);
    if ((int)$st->fetchColumn() === 0) {
      $errors[] = 'La retícula seleccionada no pertenece a la carrera elegida.';
    }
  }
  if ($username === '' || mb_strlen($username) < 3) $errors[] = 'Usuario inválido (mín. 3).';

  if ($password !== '' || $password2 !== '') {
    if (mb_strlen($password) < 8) $errors[] = 'Contraseña demasiado corta (mín. 8).';
    if ($password !== $password2) $errors[] = 'Las contraseñas no coinciden.';
  }

  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE username=:u AND id<>:id");
  $st->execute([':u'=>$username, ':id'=>$uid]);
  if ((int)$st->fetchColumn() > 0) $errors[] = 'El nombre de usuario ya está en uso.';

  $email = 'L'.$nc.'@zitacuaro.tecnm.mx';
  $st = $pdo->prepare("SELECT COUNT(*) FROM usuarios WHERE email=:e AND id<>:id");
  $st->execute([':e'=>$email, ':id'=>$uid]);
  if ((int)$st->fetchColumn() > 0) $errors[] = 'El correo institucional ya existe en otro usuario.';

  $st = $pdo->prepare("SELECT COUNT(*) FROM estudiantes WHERE no_control=:n AND usuario_id<>:id");
  $st->execute([':n'=>$nc, ':id'=>$uid]);
  if ((int)$st->fetchColumn() > 0) $errors[] = 'El número de control ya existe en otro alumno.';

  // **IMPORTANTE**: Aquí NO se permite editar la foto. Se mantiene la existente.
  // $alumno['foto_url'] se conserva tal cual; no se procesa $_FILES['foto'].

  if (!$errors) {
    try {
      $pdo->beginTransaction();

      $anio = year_from_no_control($nc);
      if (!$anio) throw new RuntimeException('No se pudo derivar el año de ingreso.');
      $semestre = calcular_semestre($anio, new DateTime('now'));
      $reticula_id = $reticula_manual_id > 0
        ? $reticula_manual_id
        : pick_reticula_por_anio($pdo, $carrera_id, $anio);

      // Update usuarios (sin tocar foto_url)
      $paramsU = [
        ':n'=>$nombre, ':a'=>$apellidos, ':e'=>$email, ':u'=>$username, ':id'=>$uid
      ];
      if ($password !== '') {
        $hash = password_hash($password, PASSWORD_BCRYPT, ['cost'=>10]);
        $sqlU = "UPDATE usuarios SET nombre=:n, apellidos=:a, email=:e, username=:u, password_hash=:ph, actualizado_en=NOW() WHERE id=:id";
        $paramsU[':ph'] = $hash;
      } else {
        $sqlU = "UPDATE usuarios SET nombre=:n, apellidos=:a, email=:e, username=:u, actualizado_en=NOW() WHERE id=:id";
      }
      $pdo->prepare($sqlU)->execute($paramsU);

      // Update estudiante
      $pdo->prepare("UPDATE estudiantes
                     SET no_control=:nc, reticula_id=:rid, carrera_id=:cid, semestre_actual=:sem
                     WHERE usuario_id=:id")
          ->execute([':nc'=>$nc, ':rid'=>$reticula_id, ':cid'=>$carrera_id, ':sem'=>$semestre, ':id'=>$uid]);

      $pdo->commit();
      redirect(base_url('admin/gestionar_alumnos.php?updated=1'));
      exit;
    } catch (Throwable $e) {
      if ($pdo->inTransaction()) $pdo->rollBack();
      $errors[] = 'No se pudo guardar los cambios. Intenta de nuevo.';
    }
  }

  // Recalcular vistas
  $fotoPreview = foto_src($alumno['foto_url'] ?? null);
  $correo_institucional = $email ?? $correo_institucional;
  $semestre_actual_vista = isset($anio) ? calcular_semestre($anio, new DateTime('now')) : $semestre_actual_vista;
}

/* ==================== Variables para el header común ==================== */
$yo        = $admin;                 // el header usa $yo
$yo['foto'] = foto_src($yo['foto_url'] ?? null); // asegura avatar en header
$title     = 'ITZ KnowLink - Administrador · Editar alumno';
$pageTitle = 'Editar alumno';
$pageSub   = 'Actualiza datos personales, acceso y asignación académica';
$active    = 'alumnos'; // resalta “Gestionar Estudiantes”

require __DIR__ . '/partials/header.php';
?>

<!-- ===== CSS específico de esta página ===== -->
<style>
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,.06);margin-bottom:16px}
  .form-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:12px;margin-top:12px}
  label.field{display:flex;flex-direction:column;gap:8px;position:relative}
  input[type="text"],input[type="email"],input[type="password"],select,textarea{width:100%;padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .photo-row{display:flex;gap:12px;align-items:center}
  .photo-preview{width:88px;height:88px;border-radius:8px;background-size:cover;background-position:center;border:1px dashed #e6eef2;display:flex;align-items:center;justify-content:center;color:#6b7280}
  .email-preview{display:inline-flex;align-items:center;gap:10px;padding:8px 12px;border-radius:10px;background:#f3f6f9;border:1px solid #e6eef2;transition:all .18s ease;font-weight:700;color:#0b2545}
  .email-preview .icon{font-size:14px;color:#6b7280}
  .email-preview.valid{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;box-shadow:0 8px 24px rgba(2,6,23,.06);transform:translateY(-2px) scale(1.02)}
  .email-preview.invalid{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}
  .avail{display:inline-flex;gap:10px;align-items:center;padding:6px 10px;border-radius:10px;border:1px solid #e6eef2;background:#f3f6f9;font-weight:700;margin-top:6px}
  .avail.check{color:#6b7280}
  .avail.ok{background:linear-gradient(90deg,#ecfdf5,#bbf7d0);border-color:#bbf7d0;color:#065f46;box-shadow:0 8px 24px rgba(2,6,23,.06)}
  .avail.bad{background:#fff7f0;border-color:#f5c2c7;color:#7a0021}
  .pw-meter{height:8px;width:100%;background:#eef2f7;border-radius:999px;overflow:hidden;margin-top:6px}
  .pw-meter > div{height:8px;width:0%;background:#ef4444;transition:width .2s ease}
  .pw-tip{font-size:12px;color:#6b7280;margin-top:6px}
  .pwd-wrap{position:relative}.pwd-wrap input{padding-right:42px}
  .toggle-eye{position:absolute;right:8px;top:50%;transform:translateY(-50%);background:transparent;border:0;cursor:pointer;font-size:16px;color:#6b7280;padding:6px;border-radius:8px}
  .toggle-eye:hover{background:#f3f6f9;color:#0b2545}
  .btn.danger{ background: linear-gradient(90deg,#7a0021,#b91c1c); color:#fff; border:none; }
  .btn.danger:hover{ filter: brightness(1.05); transform: translateY(-1px); }
  /* Confirmación de eliminación: se usa un nombre propio para evitar conflictos con .modal global/Bootstrap */
  .confirm-overlay{
    position:fixed;
    inset:0;
    z-index:9999;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:18px;
    background:rgba(15,23,42,.52);
    backdrop-filter:blur(8px);
  }
  .confirm-overlay[hidden]{ display:none !important; }
  .confirm-card{
    width:min(460px,100%);
    border-radius:22px;
    padding:22px;
    background:#fff;
    color:#0f172a;
    box-shadow:0 28px 80px rgba(2,6,23,.32);
    border:1px solid rgba(148,163,184,.25);
    animation:confirmIn .16s ease-out;
  }
  @keyframes confirmIn{
    from{opacity:0; transform:translateY(10px) scale(.98);}
    to{opacity:1; transform:translateY(0) scale(1);}
  }
  .confirm-head{display:flex;align-items:flex-start;gap:14px;margin-bottom:12px;}
  .confirm-icon{width:48px;height:48px;border-radius:16px;display:grid;place-items:center;background:#fee2e2;color:#b91c1c;font-size:20px;flex:0 0 auto;}
  .confirm-title{font-size:18px;font-weight:900;margin:2px 0 4px;}
  .confirm-sub{color:#64748b;line-height:1.45;font-size:14px;}
  .confirm-text{background:#f8fafc;border:1px solid #e2e8f0;border-radius:16px;padding:12px 14px;color:#334155;line-height:1.45;font-size:14px;margin-top:12px;}
  .confirm-text strong{color:#0f172a;}
  .confirm-actions{display:flex;justify-content:flex-end;gap:10px;flex-wrap:wrap;margin-top:18px;}
  .confirm-actions button{border:0;border-radius:13px;padding:10px 15px;font-weight:850;cursor:pointer;}
  .confirm-actions .cancel{background:#f1f5f9;color:#0f172a;}
  .confirm-actions .danger{background:linear-gradient(135deg,#dc2626,#991b1b);color:#fff;}
  .confirm-actions button:disabled{opacity:.65;cursor:not-allowed;}
  html[data-theme="dark"] .confirm-card{background:#111827;color:#f8fafc;border-color:rgba(148,163,184,.20);}
  html[data-theme="dark"] .confirm-sub{color:#cbd5e1;}
  html[data-theme="dark"] .confirm-text{background:#0b1220;border-color:rgba(148,163,184,.22);color:#dbeafe;}
  html[data-theme="dark"] .confirm-text strong{color:#fff;}
  html[data-theme="dark"] .confirm-actions .cancel{background:#1f2937;color:#e5e7eb;}
</style>

<!-- ===== PAGE HEADER ===== -->
<div class="page-header">
  <div>
    <div class="page-title"><?= esc($pageTitle) ?></div>
    <div class="page-sub"><?= esc($pageSub) ?></div>
  </div>
  <div>
    <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_alumnos.php')) ?>">
      <i class="fas fa-arrow-left"></i><span class="label"> Volver</span>
    </a>
  </div>
</div>

<?php if (!empty($errors)): ?>
  <div class="card" role="alert" style="border:1px solid #f5c2c7;background:#fff1f0;color:#7a0021;">
    <ul style="padding-left:18px;"><?php foreach ($errors as $e): ?><li><?= esc($e) ?></li><?php endforeach; ?></ul>
  </div>
<?php endif; ?>

<form method="post" novalidate>
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="action" value="update">

  <!-- Foto (solo vista; no editable aquí) -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Foto de perfil</h3>
    <p class="hint">Esta foto no se puede modificar aquí. Próximamente se editará desde el perfil del estudiante.</p>
    <div class="form-grid" style="margin-top:12px;">
      <div class="photo-row">
        <div class="photo-preview" id="preview" style="background-image:url('<?= esc($fotoPreview) ?>');" aria-label="Foto del estudiante"></div>
      </div>
    </div>
  </section>

  <!-- Datos personales -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos personales</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Nombre</span>
        <input type="text" name="nombre" id="nombre" minlength="3" required value="<?= esc($old['nombre']) ?>">
      </label>
      <label class="field">
        <span class="label">Apellidos</span>
        <input type="text" name="apellidos" id="apellidos" minlength="3" required value="<?= esc($old['apellidos']) ?>">
      </label>
      <label class="field">
        <span class="label">Carrera</span>
        <select name="carrera" id="carrera" required>
          <option value="0">-- Selecciona --</option>
          <?php foreach ($carreras as $c): ?>
            <option value="<?= (int)$c['id'] ?>" <?= ((string)$old['carrera']=== (string)$c['id'])?'selected':'' ?>><?= esc($c['nombre']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="field">
        <span class="label">Retícula asignada</span>
        <select name="reticula_id" id="reticula_id" data-current="<?= esc($old['reticula']) ?>">
          <option value="0" data-carrera="0">Asignar automáticamente según carrera y número de control</option>
          <?php foreach ($reticulas as $r): ?>
            <option value="<?= (int)$r['id'] ?>" data-carrera="<?= (int)$r['carrera_id'] ?>" <?= ((string)$old['reticula'] === (string)$r['id']) ? 'selected' : '' ?>>
              <?= esc($r['nombre'].' · '.$r['clave']) ?>
            </option>
          <?php endforeach; ?>
        </select>
        <small class="hint">Úsala solo cuando necesites mover manualmente al estudiante a otra retícula.</small>
      </label>
      <label class="field">
        <span class="label">Número de control</span>
        <input type="text" name="numero_control" id="numero_control" inputmode="numeric" pattern="\d{8}" maxlength="8" required value="<?= esc($old['numero_control']) ?>">
      </label>

      <label class="field">
        <span class="label">Semestre</span>
        <input type="text" id="semestre_view" value="<?= (int)$semestre_actual_vista ?>" disabled aria-disabled="true">
      </label>

      <label class="field">
        <span class="label">Correo institucional</span>
        <div style="display:flex; gap:10px; align-items:center;">
          <input type="hidden" id="correoHidden" value="<?= esc($correo_institucional) ?>">
          <div id="correoPreview" class="email-preview <?= $correo_institucional ? 'valid' : '' ?>" role="status" aria-live="polite" title="Correo institucional">
            <span class="icon"><i class="fas fa-envelope"></i></span>
            <span id="correoPreviewText" class="email-text"><?= esc($correo_institucional ?: '—') ?></span>
          </div>
        </div>
      </label>
    </div>
  </section>

  <!-- Acceso -->
  <section class="card">
    <h3 style="margin-bottom:6px;">Datos de acceso</h3>
    <div class="form-grid">
      <label class="field">
        <span class="label">Usuario</span>
        <input type="text" name="username" id="username" minlength="3" required value="<?= esc($old['username']) ?>" autocomplete="off">
        <div id="userAvail" class="avail" style="display:none;"></div>
      </label>

      <label class="field" id="fieldPwd">
        <span class="label">Nueva contraseña (opcional)</span>
        <div class="pwd-wrap">
          <input type="password" name="password" id="password" minlength="8" autocomplete="new-password" placeholder="Deja vacío para no cambiar">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="password">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <div class="pw-meter" aria-hidden="true"><div id="pwBar"></div></div>
        <div id="pwTip" class="pw-tip">Usa mayúsculas, números y símbolos para mayor seguridad.</div>
      </label>

      <label class="field" id="fieldPwd2">
        <span class="label">Confirmar nueva contraseña</span>
        <div class="pwd-wrap">
          <input type="password" name="password2" id="password2" minlength="8" autocomplete="new-password" placeholder="Repítela si vas a cambiar">
          <button type="button" class="toggle-eye" aria-label="Mostrar/Ocultar contraseña" data-target="password2">
            <i class="far fa-eye"></i>
          </button>
        </div>
        <small id="pwMatch" class="hint" style="display:none;color:#b00020;">Las contraseñas no coinciden.</small>
      </label>

      <div class="actions" style="grid-column:1/-1;">
        <button type="submit" class="btn btn-icon"><i class="fas fa-save"></i><span class="label"> Guardar cambios</span></button>
        <a class="btn ghost btn-icon" href="<?= esc(base_url('admin/gestionar_alumnos.php')) ?>"><i class="fas fa-xmark"></i><span class="label"> Cancelar</span></a>

        <!-- Botón Eliminar (abre modal) -->
        <button type="button" class="btn danger btn-icon" id="btnOpenDelete">
          <i class="fas fa-trash"></i><span class="label"> Eliminar alumno</span>
        </button>
      </div>
    </div>
  </section>
</form>

<!-- Form oculto para eliminar (POST, sin exponer id en URL) -->
<form id="deleteForm" method="post" action="" style="display:none;">
  <input type="hidden" name="csrf" value="<?= esc($CSRF) ?>">
  <input type="hidden" name="action" value="delete">
  <input type="hidden" name="id" value="<?= (int)$uid ?>">
</form>

<!-- Modal de confirmación -->
<div id="confirmDeleteModal" class="confirm-overlay" hidden aria-hidden="true">
  <div class="confirm-card" role="dialog" aria-modal="true" aria-labelledby="confirmDeleteTitle" aria-describedby="confirmDeleteText">
    <div class="confirm-head">
      <div class="confirm-icon"><i class="fas fa-trash-alt"></i></div>
      <div>
        <div id="confirmDeleteTitle" class="confirm-title">Eliminar alumno</div>
        <div class="confirm-sub">Antes de continuar, confirma que deseas eliminar este registro.</div>
      </div>
    </div>

    <div id="confirmDeleteText" class="confirm-text">
      Esta acción eliminará definitivamente al alumno
      <strong><?= esc(trim(($alumno['nombre'] ?? '').' '.($alumno['apellidos'] ?? '')) ?: 'seleccionado') ?></strong>
      con número de control <strong><?= esc($alumno['no_control'] ?? '—') ?></strong>.
      No se puede deshacer.
    </div>

    <div class="confirm-actions">
      <button type="button" class="cancel" id="confirmDeleteCancel">Cancelar</button>
      <button type="button" class="danger" id="confirmDeleteAccept"><i class="fas fa-trash-alt"></i> Sí, eliminar</button>
    </div>
  </div>
</div>

<!-- Script separado para que la confirmación funcione aunque otro bloque JS falle -->
<script>
(function(){
  const openBtn = document.getElementById('btnOpenDelete');
  const modal = document.getElementById('confirmDeleteModal');
  const cancel = document.getElementById('confirmDeleteCancel');
  const accept = document.getElementById('confirmDeleteAccept');
  const form = document.getElementById('deleteForm');

  function openDeleteModal(){
    if(!modal) return;
    modal.hidden = false;
    modal.setAttribute('aria-hidden','false');
    setTimeout(()=>cancel?.focus(), 20);
  }

  function closeDeleteModal(){
    if(!modal) return;
    modal.hidden = true;
    modal.setAttribute('aria-hidden','true');
    if(accept){
      accept.disabled = false;
      accept.innerHTML = '<i class="fas fa-trash-alt"></i> Sí, eliminar';
    }
  }

  openBtn?.addEventListener('click', openDeleteModal);
  cancel?.addEventListener('click', closeDeleteModal);
  modal?.addEventListener('click', (ev)=>{ if(ev.target === modal) closeDeleteModal(); });
  document.addEventListener('keydown', (ev)=>{ if(ev.key === 'Escape' && modal && !modal.hidden) closeDeleteModal(); });
  accept?.addEventListener('click', ()=>{
    if(!form) return;
    accept.disabled = true;
    accept.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> Eliminando';
    form.submit();
  });
})();
</script>

<!-- ===== JS específico de esta página ===== -->
<script>
function pulse(el){
  if(!el) return; el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse');
  setTimeout(()=>el.classList.remove('pulse'), 450);
}

/* Retículas por carrera */
(function(){
  const carrera = document.getElementById('carrera');
  const reticula = document.getElementById('reticula_id');
  if(!carrera || !reticula) return;

  function filtrarReticulas(){
    const carreraId = String(carrera.value || '0');
    const selected = reticula.options[reticula.selectedIndex];
    let selectedVisible = false;

    Array.from(reticula.options).forEach(opt => {
      const optionCarrera = String(opt.getAttribute('data-carrera') || '0');
      const visible = optionCarrera === '0' || optionCarrera === carreraId;
      opt.hidden = !visible;
      opt.disabled = !visible;
      if (opt.selected && visible) selectedVisible = true;
    });

    if(!selectedVisible){
      reticula.value = '0';
    }
  }

  carrera.addEventListener('change', filtrarReticulas);
  filtrarReticulas();
})();

/* Correo + Semestre visible (se recalculan al escribir NC) */
(function(){
  const nc=document.getElementById('numero_control');
  const hCorreo=document.getElementById('correoHidden');
  const pCorreo=document.getElementById('correoPreview');
  const tCorreo=document.getElementById('correoPreviewText');
  const semestreView=document.getElementById('semestre_view');

  function calcSemesterFromYear(year){
    if(!year || isNaN(year)) return '';
    const now=new Date();
    const start=new Date(year,7,1);
    let sem=1;
    if(now >= start){
      const diffMonths=(now.getFullYear()-start.getFullYear())*12 + (now.getMonth()-start.getMonth());
      sem = Math.floor(diffMonths/6) + 1;
    }
    sem = Math.max(1, Math.min(12, sem));
    return String(sem);
  }
  function inferYearFromNoControl(nc8){
    if(!/^\d{2}/.test(nc8)) return null;
    const yy=parseInt(nc8.slice(0,2),10);
    const curYY=parseInt(new Date().getFullYear().toString().slice(-2),10);
    let year=2000+yy;
    if(yy > curYY + 1){ year = 1900 + yy; }
    return year;
  }
  function updateCorreoYSemestre(){
    let raw=(nc.value||'').replace(/\D/g,'').slice(0,8);
    if(raw!==nc.value) nc.value=raw;

    if(/^\d{8}$/.test(raw)){
      const email='L'+raw+'@zitacuaro.tecnm.mx';
      hCorreo.value=email; tCorreo.textContent=email;
      pCorreo.classList.remove('invalid'); pCorreo.classList.add('valid'); pulse(pCorreo);
    }else{
      hCorreo.value='';
      if(raw.length===0){ tCorreo.textContent='—'; pCorreo.classList.remove('valid','invalid'); }
      else { tCorreo.textContent='L'+raw+'…'; pCorreo.classList.remove('valid'); pCorreo.classList.add('invalid'); pulse(pCorreo); }
    }

    const year=inferYearFromNoControl(raw);
    const sem = year ? calcSemesterFromYear(year) : '';
    if(sem){ semestreView.value = sem; } else { semestreView.value = ''; }
  }

  nc?.addEventListener('input', updateCorreoYSemestre);
  nc?.addEventListener('paste', ()=>setTimeout(updateCorreoYSemestre,0));
  nc?.addEventListener('blur', updateCorreoYSemestre);
  updateCorreoYSemestre();
})();

/* Usuario disponible (excluyendo al propio alumno) */
(function(){
  const u=document.getElementById('username');
  const box=document.getElementById('userAvail');
  const userId = <?= (int)$uid ?>;
  let t=null, last='';

  function show(text, cls, icon){
    box.style.display='inline-flex';
    box.className='avail ' + (cls||'');
    box.innerHTML = (icon ? `<i class="fas ${icon}"></i> ` : '') + text;
  }
  function hide(){ box.style.display='none'; }

  async function check({showSpinner=true}={}){
    const v=(u.value||'').trim();
    if(v===last) return; last=v;
    if(v.length===0){ hide(); return; }
    if(v.length<3){ show('Mínimo 3 caracteres','check','fa-info-circle'); return; }
    if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin');
    try{
      const res=await fetch('?ajax=check_username&u='+encodeURIComponent(v)+'&exclude_id='+encodeURIComponent(userId), {cache:'no-store'});
      if(!res.ok){ if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin'); return; }
      const data=await res.json();
      if (data.ok && data.avail){ show('Disponible ✓','ok','fa-check-circle'); pulse(box); }
      else { show('Ya está en uso ✗','bad','fa-times-circle'); pulse(box); }
    }catch(e){
      if (showSpinner) show('Comprobando…','check','fa-circle-notch fa-spin');
    }
  }

  u?.addEventListener('input', ()=>{ clearTimeout(t); t=setTimeout(()=> check({showSpinner:true}), 300); });
  document.addEventListener('DOMContentLoaded', ()=>{ const v=(u?.value||'').trim(); if (v.length>=3){ check({showSpinner:false}); } else { hide(); } });
})();

/* Contraseñas: medidor + match + ojo */
(function(){
  const p1=document.getElementById('password');
  const p2=document.getElementById('password2');
  const match=document.getElementById('pwMatch');
  const bar=document.getElementById('pwBar');
  const tip=document.getElementById('pwTip');

  function scorePassword(pw){
    let score=0; if(!pw) return 0;
    const letters={};
    for(let i=0;i<pw.length;i++){ letters[pw[i]]=(letters[pw[i]]||0)+1; score += 5.0 / letters[pw[i]]; }
    const variations={digits:/\d/.test(pw),lower:/[a-z]/.test(pw),upper:/[A-Z]/.test(pw),nonWords:/\W/.test(pw)}; let vc=0;
    for(const k in variations) vc += variations[k] ? 1 : 0;
    score += (vc - 1) * 10; return parseInt(score);
  }
  function updateMeter(){
    const val=p1.value||'';
    if(!val){ bar.style.width='0%'; tip.textContent='Usa mayúsculas, números y símbolos para mayor seguridad.'; return; }
    const s=Math.min(100, scorePassword(val));
    const w=Math.max(8, s); bar.style.width=w+'%';
    if (s < 30){ bar.style.background = '#ef4444'; tip.textContent='Muy débil — añade longitud y símbolos.'; }
    else if (s < 60){ bar.style.background = '#f59e0b'; tip.textContent='Aceptable — usa mayúsculas y números.'; }
    else if (s < 80){ bar.style.background = '#10b981'; tip.textContent='Buena — casi listo.'; }
    else { bar.style.background = '#0ea5e9'; tip.textContent='Fuerte — excelente.'; }
    pulse(bar.parentElement);
  }
  function updateMatch(){
    if(!p2.value){ match.style.display='none'; return; }
    match.style.display = (p1.value !== p2.value) ? 'block' : 'none';
    if (match.style.display==='block') pulse(match);
  }

  ['input','change','keyup','blur'].forEach(ev=>{
    p1?.addEventListener(ev, ()=>{ updateMeter(); updateMatch(); });
    p2?.addEventListener(ev, updateMatch);
  });

  // toggle-eye
  document.querySelectorAll('.toggle-eye').forEach(btn=>{
    btn.addEventListener('click', ()=>{
      const id = btn.getAttribute('data-target');
      const input = document.getElementById(id);
      if (!input) return;
      if (input.type === 'password') {
        input.type = 'text';
        btn.innerHTML = '<i class="far fa-eye-slash"></i>';
      } else {
        input.type = 'password';
        btn.innerHTML = '<i class="far fa-eye"></i>';
      }
      input.focus();
    });
  });

  updateMeter();
  updateMatch();
})();
</script>

<?php require __DIR__ . '/partials/footer.php'; ?>
