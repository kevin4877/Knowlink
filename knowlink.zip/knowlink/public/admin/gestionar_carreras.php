<?php
// public/admin/gestionar_carreras.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// ===== Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// ===== Utils
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

// Fallbacks avatar (por si el header los usa)
if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,' . rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/', (string)$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) $u = '/' . ltrim($m[0], '/');
    else $u = '/' . ltrim($u, '/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

// ===== DB & CSRF
$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ==========================================================
   AJAX por POST (JSON): search | mint_edit_token
   ========================================================== */
if (strtoupper($_SERVER['REQUEST_METHOD'] ?? '') === 'POST') {
  $ctype = $_SERVER['CONTENT_TYPE'] ?? '';
  if (stripos($ctype, 'application/json') !== false) {
    $raw = file_get_contents('php://input');
    $in  = json_decode($raw, true) ?: [];
    $action = (string)($in['ajax'] ?? '');

    // Respuestas JSON
    if ($action === 'search') {
      header('Content-Type: application/json; charset=utf-8');

      try{
        $q       = trim((string)($in['q'] ?? ''));
        $page    = max(1, (int)($in['page'] ?? 1));
        $perPage = min(50, max(5, (int)($in['perPage'] ?? 20)));
        $off     = ($page - 1) * $perPage;

        $where = ["1=1"];
        $params = [];
        if ($q !== '') {
          $where[] = "(c.nombre LIKE :q OR c.clave LIKE :q)";
          $params[':q'] = "%$q%";
        }
        $whereSql = 'WHERE ' . implode(' AND ', $where);

        // Total
        $sqlCount = "SELECT COUNT(*) FROM carreras c $whereSql";
        $st = $pdo->prepare($sqlCount);
        foreach ($params as $k=>$v) $st->bindValue($k,$v);
        $st->execute();
        $total = (int)$st->fetchColumn();

        // Página con contador de retículas
        $lim  = (int)$perPage; $offi = (int)$off;
        $sql = "
          SELECT
            c.id, c.clave, c.nombre,
            COALESCE(r.cnt,0) AS reticulas
          FROM carreras c
          LEFT JOIN (
            SELECT carrera_id, COUNT(*) AS cnt
            FROM reticulas
            GROUP BY carrera_id
          ) r ON r.carrera_id = c.id
          $whereSql
          ORDER BY c.nombre ASC, c.id DESC
          LIMIT $lim OFFSET $offi
        ";
        $st = $pdo->prepare($sql);
        foreach ($params as $k=>$v) $st->bindValue($k,$v);
        $st->execute();
        $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

        echo json_encode([
          'ok' => true,
          'total' => $total,
          'page' => $page,
          'perPage' => $perPage,
          'rows' => $rows
        ], JSON_UNESCAPED_UNICODE);
      } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok'=>false, 'err'=>'db']);
      }
      exit;
    }

    if ($action === 'mint_edit_token') {
      header('Content-Type: application/json; charset=utf-8');

      try{
        $csrf = (string)($in['csrf'] ?? '');
        if (!hash_equals($CSRF, $csrf)) {
          http_response_code(400);
          echo json_encode(['ok'=>false,'err'=>'csrf']);
          exit;
        }
        $id = (int)($in['id'] ?? 0);
        if ($id <= 0) {
          http_response_code(400);
          echo json_encode(['ok'=>false,'err'=>'bad_id']);
          exit;
        }
        // Verificar que exista
        $st = $pdo->prepare("SELECT id FROM carreras WHERE id=:id");
        $st->execute([':id'=>$id]);
        if (!$st->fetchColumn()) {
          http_response_code(404);
          echo json_encode(['ok'=>false,'err'=>'not_found']);
          exit;
        }
        // Token de un solo uso
        $tok = bin2hex(random_bytes(16));
        $_SESSION['edit_carrera_tokens'][$tok] = [
          'id'  => $id,
          'exp' => time() + 300, // 5 min
        ];

        echo json_encode([
          'ok' => true,
          'token' => $tok,
          'action' => base_url('admin/editar_carrera.php')
        ]);
      } catch (Throwable $e) {
        http_response_code(500);
        echo json_encode(['ok'=>false,'err'=>'srv']);
      }
      exit;
    }
  }
}

/* ==========================================================
   Flash (toasts) — sólo para mensajes de retorno
   ========================================================== */
$flash = null;
if (isset($_GET['ok'])) {
  $map = [
    '1'   => 'Carrera registrada correctamente.',
    'upd' => 'Carrera actualizada correctamente.',
    'del' => 'Carrera eliminada correctamente.'
  ];
  $flash = ['type'=>'ok','msg'=>$map[$_GET['ok']] ?? 'Operación realizada.'];
}
if (isset($_GET['err'])) {
  $flash = ['type'=>'err','msg'=>trim((string)$_GET['err']) ?: 'Ocurrió un error.'];
}

/* ==========================================================
   Variables para header/footer parciales
   ========================================================== */
$active   = 'carreras';
$title    = 'ITZ KnowLink - Administrador · Gestionar Carreras';
$h1       = 'Gestionar carreras';
$subtitle = 'Busca, filtra y edita carreras';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// Header (usa $yo)
require __DIR__ . '/partials/header.php';
?>
<meta name="csrf" content="<?= esc($CSRF) ?>">

<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}

  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .field input, .field select{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .btn{padding:10px 14px;border-radius:10px;background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;border:none;cursor:pointer;font-weight:800}
  .btn.ghost{background:#fff;color:#0b2545;border:1px solid #e6eef2}
  .btn-icon .label{display:inline}
  a.btn.ghost{ text-decoration:none; }

  .table { width:100%; border-collapse:collapse; table-layout:fixed; }
  .table th, .table td { padding:10px; border-bottom:1px dashed #eef3f6; text-align:left; font-size:14px; vertical-align:middle; min-width:0; }
  .table th { font-size:13px; color:#6b7280; }
  col.c-carrera{ width:55%; } col.c-clave{ width:20%; } col.c-reticulas{ width:10%; } col.c-actions{ width:15%; }
  .td-wrap{ white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
  .nm { font-weight:800; color:#0b2545; }
  .sub{ font-size:12px; color:#6b7280; }
  .chip{ display:inline-flex; align-items:center; gap:6px; padding:3px 6px; border-radius:999px; border:1px solid #e2ebff; background:#f1f5ff; color:#0055d4; font-size:12px; line-height:1; }
  .chip.gray{ background:#f3f4f6; border-color:#e5e7eb; color:#374151; }
  .td-mini{ white-space:nowrap; }
  .actions{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; }
  .actions a, .actions button{ display:inline-flex; align-items:center; gap:6px; padding:8px 10px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; font-size:13px; text-decoration:none; color:#0b2545; }
  .actions a:hover, .actions button:hover{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }

  .pager{ margin-top:12px; display:flex; gap:10px; align-items:center; }
  .pager button{ padding:8px 12px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; }
  .pager .muted{ color:#6b7280; font-size:13px; }

  @media (max-width:1100px){ .actions .label{ display:none; } .actions a, .actions button{ padding:8px; } }
  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
    .table thead{ display:none; }
    .table{ border-collapse: separate; border-spacing:0 10px; table-layout:auto; }
    .table tr{ display:block; background:#fff; border:1px solid #eef3f6; border-radius:12px; padding:12px; }
    .table td{ display:block; border-bottom:0; padding:6px 0; }
    .table td + td{ margin-top:4px; }
    .td-mini{ display:inline-flex; align-items:center; gap:8px; margin-right:12px; padding:4px 0; }
    .table td.actions{
      display:flex; gap:8px; justify-content:flex-start; flex-wrap:wrap;
      margin-top:8px; padding-top:8px; border-top:1px dashed #eef3f6;
    }
    .table td.actions .label{ display:inline !important; }
  }

  .toast{ position: fixed; top: 88px; right: 16px; z-index: 1400; display: none; min-width:280px; max-width:420px; padding:12px 14px; border-radius:10px; box-shadow:0 18px 40px rgba(2,6,23,0.18); font-size:14px; line-height:1.35; }
  .toast.ok{ display:block; border:1px solid #bbf7d0; background:#ecfdf5; color:#065f46; }
  .toast.err{ display:block; border:1px solid #f5c2c7; background:#fff1f0; color:#7a0021; }


  /* ===== Ajuste móvil/tablet: listados de administración a todo el ancho ===== */
  @media (max-width:900px){
    .page-header{align-items:flex-start;gap:12px;}
    .page-header > div:last-child{width:100%;display:flex!important;gap:8px;}
    .page-header .btn{width:100%;justify-content:center;}
    .btn-icon .label{display:inline!important;}

    .card,
    section.card{
      width:100%!important;
      max-width:none!important;
      box-sizing:border-box!important;
      padding:12px!important;
      border-radius:18px!important;
      margin-left:0!important;
      margin-right:0!important;
      overflow:visible!important;
    }

    .tools,
    .tools[style],
    .tools .tools,
    .tools .tools[style]{
      display:grid!important;
      grid-template-columns:1fr!important;
      width:100%!important;
      gap:10px!important;
      align-items:stretch!important;
      justify-content:stretch!important;
    }
    .field,
    .field input,
    .field select,
    .tools button,
    .tools .btn{
      width:100%!important;
      min-width:0!important;
      max-width:none!important;
      box-sizing:border-box!important;
    }

    .table thead,
    .table colgroup{display:none!important;}
    .table,
    .table tbody{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      border-collapse:separate!important;
      border-spacing:0 12px!important;
      table-layout:auto!important;
      box-sizing:border-box!important;
    }
    .table tbody tr{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      box-sizing:border-box!important;
      background:#fff!important;
      border:1px solid #e6eef2!important;
      border-radius:16px!important;
      padding:14px!important;
      margin:0 0 12px 0!important;
      box-shadow:0 12px 28px rgba(2,6,23,.06)!important;
    }
    .table tbody td{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      min-width:0!important;
      box-sizing:border-box!important;
      border-bottom:0!important;
      background:transparent!important;
      padding:7px 0!important;
      text-align:left!important;
    }
    .table tbody td + td{margin-top:4px!important;}
    .table tbody td[data-label]::before{
      content:attr(data-label);
      display:block;
      font-size:11px;
      text-transform:uppercase;
      letter-spacing:.04em;
      color:#64748b;
      font-weight:900;
      margin-bottom:4px;
    }
    .materia-cell .nm,
    .reticula-cell .nm,
    .nm{font-size:15px!important;line-height:1.25!important;color:#0b2545;}
    .materia-cell .sub,
    .reticula-cell .sub,
    .sub{font-size:12px!important;line-height:1.35!important;}
    .td-mini{display:flex!important;flex-direction:column!important;align-items:flex-start!important;width:100%!important;white-space:normal!important;gap:4px!important;margin:0!important;}
    .chip{font-size:12px!important;padding:5px 9px!important;}
    .table td.actions{
      display:grid!important;
      grid-template-columns:1fr 1fr!important;
      gap:8px!important;
      width:100%!important;
      margin-top:10px!important;
      padding-top:10px!important;
      border-top:1px dashed #e6eef2!important;
      justify-content:stretch!important;
    }
    .table td.actions a,
    .table td.actions button{
      width:100%!important;
      justify-content:center!important;
      padding:10px!important;
      box-sizing:border-box!important;
    }
    .table td.actions .label{display:inline!important;}
    .pager{justify-content:center!important;flex-wrap:wrap!important;}

    html[data-theme="dark"] .table tbody tr{
      background:#0f172a!important;
      border-color:rgba(148,163,184,.22)!important;
      box-shadow:0 12px 30px rgba(0,0,0,.28)!important;
    }
    html[data-theme="dark"] .table tbody td[data-label]::before{color:#94a3b8!important;}
    html[data-theme="dark"] .materia-cell .nm,
    html[data-theme="dark"] .reticula-cell .nm,
    html[data-theme="dark"] .nm{color:#f8fafc!important;}
    html[data-theme="dark"] .materia-cell .sub,
    html[data-theme="dark"] .reticula-cell .sub,
    html[data-theme="dark"] .sub{color:#94a3b8!important;}
    html[data-theme="dark"] .table td.actions{border-top-color:rgba(148,163,184,.22)!important;}
  }
  @media (max-width:480px){
    .page-header > div:last-child{flex-direction:column!important;}
    .table td.actions{grid-template-columns:1fr!important;}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn btn-icon" href="<?= esc(base_url('admin/registro_carrera.php')) ?>">
      <i class="fas fa-graduation-cap"></i><span class="label"> Registrar carrera</span>
    </a>
  </div>
</div>

<?php if (!empty($flash)): ?>
  <div id="toast" class="toast <?= esc($flash['type']) ?>">
    <div style="display:flex; align-items:flex-start; gap:10px;">
      <div style="font-size:18px; line-height:1; margin-top:1px;">
        <?php if ($flash['type']==='ok'): ?>
          <i class="fas fa-check-circle" aria-hidden="true"></i>
        <?php else: ?>
          <i class="fas fa-exclamation-triangle" aria-hidden="true"></i>
        <?php endif; ?>
      </div>
      <div style="font-weight:700;"><?= esc($flash['msg']) ?></div>
      <button class="close" type="button" aria-label="Cerrar notificación" style="background:transparent;border:0;cursor:pointer;font-size:16px;color:inherit;opacity:.7;padding:4px;margin-left:auto">&times;</button>
    </div>
  </div>
<?php endif; ?>

<!-- Filtros -->
<section class="card" aria-label="Filtros de búsqueda">
  <div class="tools" style="justify-content:space-between; gap:12px;">
    <div class="tools" style="gap:8px;">
      <div class="field">
        <input type="text" id="q" placeholder="Buscar por nombre o clave" style="min-width:280px;">
      </div>
    </div>
    <div class="tools" style="gap:8px;">
      <div class="field">
        <select id="perPage">
          <option value="10">10 por página</option>
          <option value="20" selected>20 por página</option>
          <option value="30">30 por página</option>
          <option value="50">50 por página</option>
        </select>
      </div>
      <button class="btn ghost btn-icon" id="btnClear" title="Limpiar filtros">
        <i class="fas fa-eraser"></i> <span class="label">Limpiar</span>
      </button>
    </div>
  </div>
</section>

<!-- Tabla -->
<section class="card" aria-label="Resultados">
  <table class="table" id="tbl">
    <colgroup>
      <col class="c-carrera">
      <col class="c-clave">
      <col class="c-reticulas">
      <col class="c-actions">
    </colgroup>
    <thead>
      <tr>
        <th>Carrera</th>
        <th>Clave</th>
        <th>Retículas</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody id="tbody">
      <tr><td colspan="4" style="text-align:center;color:#6b7280;">Cargando…</td></tr>
    </tbody>
  </table>

  <div class="pager" id="pager">
    <button id="prev" disabled>&laquo; Anterior</button>
    <span class="muted" id="info">—</span>
    <button id="next" disabled>Siguiente &raquo;</button>
  </div>
</section>

<script>
(function(){
  const CSRF = (document.querySelector('meta[name="csrf"]')?.getAttribute('content')) || '';

  const q        = document.getElementById('q');
  const perPage  = document.getElementById('perPage');
  const btnClear = document.getElementById('btnClear');
  const tbody    = document.getElementById('tbody');
  const prevBtn  = document.getElementById('prev');
  const nextBtn  = document.getElementById('next');
  const info     = document.getElementById('info');

  let state = { page:1, total:0, perPage: parseInt(perPage.value,10)||20, q:'', loading:false };

  function escapeH(str){ return String(str).replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&lt;','"':'&quot;',"'":'&#039;'}[s])); }
  function chip(n){ n = parseInt(n||0,10); return n>0 ? `<span class="chip"><i class="fas fa-diagram-project"></i> ${n}</span>` : `<span class="chip gray"><i class="fas fa-diagram-project"></i> 0</span>`; }

  function buildRow(r){
    const nombre = (r.nombre||'').trim() || ('Carrera #'+r.id);
    const clave  = (r.clave||'').trim();
    const id     = r.id;

    return `<tr>
      <td class="td-wrap" data-label="Carrera">
        <div class="nm">${escapeH(nombre)}</div>
      </td>
      <td class="td-mini" data-label="Clave"><span class="sub">${escapeH(clave)}</span></td>
      <td class="td-mini" data-label="Retículas">${chip(r.reticulas)}</td>
      <td class="actions" data-label="Acciones">
        <button type="button" class="btn-edit" data-id="${id}" title="Editar"><i class="fas fa-edit"></i> <span class="label">Editar</span></button>
      </td>
    </tr>`;
  }

  async function fetchJSON(payload){
    const res = await fetch('', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    return res;
  }

  async function fetchData(){
    if(state.loading) return; state.loading=true;
    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#6b7280;">Cargando…</td></tr>`;
    try{
      const res = await fetchJSON({
        ajax: 'search',
        q: state.q,
        page: state.page,
        perPage: state.perPage
      });
      const data = await res.json();
      if(!data.ok) throw new Error('Respuesta inválida');

      state.total = data.total || 0;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length ? rows.map(buildRow).join('') :
        `<tr><td colspan="4" style="text-align:center;color:#6b7280;">Sin resultados.</td></tr>`;

      const first = state.total ? Math.min(state.total, ((state.page-1)*state.perPage)+1) : 0;
      const last  = state.total ? Math.min(state.total, state.page*state.perPage) : 0;
      info.textContent = state.total ? `${first}–${last} de ${state.total}` : '0 resultados';
      prevBtn.disabled = (state.page<=1);
      nextBtn.disabled = (state.page*state.perPage >= state.total);

      // Enlazar botones Editar (mint token y POST a editar_carrera.php)
      tbody.querySelectorAll('.btn-edit').forEach(btn=>{
        btn.addEventListener('click', async (e)=>{
          const id = e.currentTarget.getAttribute('data-id');
          try{
            const r = await fetchJSON({ ajax:'mint_edit_token', id: Number(id), csrf: CSRF });
            const j = await r.json();
            if(!j.ok){ alert('No se pudo preparar la edición.'); return; }
            // Construir y enviar form oculto
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = j.action;
            form.style.display = 'none';

            const f1 = document.createElement('input');
            f1.name = 'csrf'; f1.value = CSRF; form.appendChild(f1);

            const f2 = document.createElement('input');
            f2.name = 'go_edit'; f2.value = '1'; form.appendChild(f2);

            const f3 = document.createElement('input');
            f3.name = 'token'; f3.value = j.token; form.appendChild(f3);

            document.body.appendChild(form);
            form.submit();
          }catch(err){
            alert('Error de red al preparar la edición.');
          }
        });
      });

    } catch(e){
      tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#b91c1c;">Error al cargar datos.</td></tr>`;
      info.textContent = '—'; prevBtn.disabled = true; nextBtn.disabled = true;
    } finally {
      state.loading=false;
    }
  }

  function debounce(fn,ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a),ms); }; }
  const onChange = debounce(()=>{ state.page=1; fetchData(); }, 250);

  q.addEventListener('input', ()=>{ state.q = q.value.trim(); onChange(); });
  perPage.addEventListener('change', ()=>{ state.perPage = parseInt(perPage.value,10)||20; state.page=1; fetchData(); });
  prevBtn.addEventListener('click', ()=>{ if(state.page>1){ state.page--; fetchData(); }});
  nextBtn.addEventListener('click', ()=>{ if(state.page*state.perPage < state.total){ state.page++; fetchData(); }});
  btnClear.addEventListener('click', (e)=>{ e.preventDefault(); q.value=''; perPage.value='20'; state={page:1,total:0,perPage:20,q:'',loading:false}; fetchData(); });

  // Toast (solo mensajes de retorno)
  (function(){
    const toast=document.getElementById('toast');
    if(!toast) return;
    toast.style.display='block';
    const closeBtn = toast.querySelector('.close');
    function hide(){ toast.remove();
      try{ const u=new URL(location.href); u.searchParams.delete('ok'); u.searchParams.delete('err'); history.replaceState({},'',u);}catch(e){} }
    closeBtn?.addEventListener('click', hide);
    setTimeout(hide, 4500);
  })();

  // Primera carga
  fetchData();
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
