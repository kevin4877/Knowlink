<?php
// public/admin/gestionar_materias.php
declare(strict_types=1);

require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../src/helpers.php';
require_once __DIR__ . '/../../src/auth.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }
if (($yo['rol'] ?? '') !== 'administrador') { http_response_code(403); echo "Acceso denegado"; exit; }

// ===== Seguridad
header('X-Frame-Options: SAMEORIGIN');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: frame-ancestors 'self'");

// ===== Utils
function esc($v){ return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

if (!function_exists('str_starts_with')) {
  function str_starts_with($haystack, $needle){ return $needle !== '' && strpos($haystack, $needle) === 0; }
}
if (!function_exists('avatar_placeholder')) {
  function avatar_placeholder(): string {
    return 'data:image/svg+xml;utf8,'.rawurlencode(
      '<svg xmlns="http://www.w3.org/2000/svg" width="36" height="36"><rect width="100%" height="100%" fill="#eef3f6"/><circle cx="18" cy="12" r="8" fill="#cfd8e3"/><rect x="6" y="24" width="24" height="10" rx="5" fill="#cfd8e3"/></svg>'
    );
  }
}
if (!function_exists('foto_src')) {
  function foto_src(?string $url): string {
    if (!$url) return avatar_placeholder();
    $u = trim(str_replace('\\','/', (string)$url));
    if (preg_match('#^(?:https?:)?//#i', $u) || str_starts_with($u,'data:')) return $u;
    $u = preg_replace('#(^|/)\.\./#', '/', $u);
    if (preg_match('#uploads/avatars/[^?\#]+#i', $u, $m)) $u = '/' . ltrim($m[0], '/');
    else $u = '/' . ltrim($u, '/');
    return base_url(ltrim($u,'/'));
  }
}
if (!function_exists('buildFotoUrl')) {
  function buildFotoUrl(?string $url): string { return foto_src($url); }
}

// ===== DB & CSRF
$pdo = db();
if (empty($_SESSION['csrf'])) { $_SESSION['csrf'] = bin2hex(random_bytes(16)); }
$CSRF = $_SESSION['csrf'];

/* ==========================================================
   AJAX (SIEMPRE POR POST): buscar, abrir edición
   ========================================================== */
if (isset($_POST['ajax'])) {
  header('Content-Type: application/json; charset=utf-8');

  $action = (string)$_POST['ajax'];
  // Helper JSON
  $fail = function($msg='Error'){ echo json_encode(['ok'=>false,'msg'=>$msg], JSON_UNESCAPED_UNICODE); exit; };
  $ok   = function($data=[]){ $data['ok']=true; echo json_encode($data, JSON_UNESCAPED_UNICODE); exit; };

  try {
    if ($action === 'search') {
      // NOTA: aunque sea búsqueda, también aceptamos CSRF porque va por POST
      if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) $fail('CSRF inválido');

      $q       = trim((string)($_POST['q'] ?? ''));
      $page    = max(1, (int)($_POST['page'] ?? 1));
      $perPage = min(50, max(5, (int)($_POST['perPage'] ?? 20)));
      $off     = ($page - 1) * $perPage;

      $where = ['1=1'];
      $params = [];

      if ($q !== '') {
        $where[] = "(m.nombre LIKE :q OR m.clave LIKE :q)";
        $params[':q'] = "%$q%";
      }
      $whereSql = 'WHERE ' . implode(' AND ', $where);

      // Total
      $sqlCount = "SELECT COUNT(*) FROM materias m $whereSql";
      $st = $pdo->prepare($sqlCount);
      foreach($params as $k=>$v) $st->bindValue($k,$v);
      $st->execute();
      $total = (int)$st->fetchColumn();

      // Página (evita placeholders en LIMIT/OFFSET si emulation = false)
      $lim  = (int)$perPage;
      $offi = (int)$off;

      $sql = "
        SELECT
          m.clave, m.nombre, m.descripcion,
          COALESCE(u.cnt_u,0)  AS unidades,
          COALESCE(r.cnt_rm,0) AS en_reticulas
        FROM materias m
        LEFT JOIN (
          SELECT materia_clave, COUNT(*) AS cnt_u
          FROM unidades
          GROUP BY materia_clave
        ) u ON LOWER(u.materia_clave) = LOWER(m.clave)
        LEFT JOIN (
          SELECT materia_clave, COUNT(*) AS cnt_rm
          FROM reticula_materias
          GROUP BY materia_clave
        ) r ON LOWER(r.materia_clave) = LOWER(m.clave)
        $whereSql
        ORDER BY m.nombre ASC, m.clave ASC
        LIMIT $lim OFFSET $offi
      ";
      $st = $pdo->prepare($sql);
      foreach($params as $k=>$v) $st->bindValue($k,$v);
      $st->execute();
      $rows = $st->fetchAll(PDO::FETCH_ASSOC) ?: [];

      $ok(['total'=>$total, 'page'=>$page, 'perPage'=>$perPage, 'rows'=>$rows]);
    }

    if ($action === 'open') {
      if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) $fail('CSRF inválido');
      $refMateria = trim((string)($_POST['clave'] ?? ''));
      if ($refMateria === '') $fail('Clave requerida.');

      $clave = resolve_materia_clave($pdo, $refMateria);
      if (!$clave) $fail('Materia no encontrada.');

      $_SESSION['edit_materia_clave'] = $clave;
      $ok(['redirect' => base_url('admin/editar_materia.php')]);
    }

    if ($action === 'delete') {
      if (!hash_equals($CSRF, (string)($_POST['csrf'] ?? ''))) $fail('CSRF inválido');
      $refMateria = trim((string)($_POST['clave'] ?? ''));
      if ($refMateria === '') $fail('Clave requerida.');

      $clave = resolve_materia_clave($pdo, $refMateria);
      if (!$clave) $fail('Materia no encontrada.');

      $pdo->beginTransaction();
      $del = $pdo->prepare("DELETE FROM materias WHERE LOWER(clave)=LOWER(:c)");
      $del->execute([':c'=>$clave]);
      $pdo->commit();

      if (isset($_SESSION['edit_materia_clave']) && strcasecmp((string)$_SESSION['edit_materia_clave'], $clave) === 0) {
        unset($_SESSION['edit_materia_clave']);
      }

      $ok(['msg'=>'Materia eliminada correctamente.']);
    }

    $fail('Acción inválida');
  } catch (Throwable $e) {
    $fail('Error del servidor');
  }
}

// ==========================================================
// Variables para header/footer
// ==========================================================
$active   = 'materias';
$title    = 'ITZ KnowLink - Administrador · Gestionar Materias';
$h1       = 'Gestionar materias';
$subtitle = 'Busca, filtra y edita materias';

if (!defined('PAGE_TITLE'))   define('PAGE_TITLE',   $title);
if (!defined('HEADER_TITLE')) define('HEADER_TITLE', $h1);
if (!defined('HEADER_SUB'))   define('HEADER_SUB',   $subtitle);
if (!defined('ACTIVE_MENU'))  define('ACTIVE_MENU',  $active);

// Flash por ?ok / ?err (opcional, p.ej. al volver de alta)
$flash = null;
if (isset($_GET['ok'])) {
  $map = ['1'=>'Materia registrada correctamente.', 'upd'=>'Materia actualizada correctamente.', 'del'=>'Materia eliminada correctamente.'];
  $flash = ['type'=>'ok','msg'=>$map[$_GET['ok']] ?? 'Operación realizada.'];
}
if (isset($_GET['err'])) {
  $flash = ['type'=>'err','msg'=>trim((string)$_GET['err']) ?: 'Ocurrió un error.'];
}

// ===== Header
require __DIR__ . '/partials/header.php';
?>
<style>
  .page-header{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
  .page-title{font-size:20px;font-weight:800;color:#0b2545}
  .page-sub{color:#6b7280;font-size:14px}
  .card{background:#fff;border-radius:12px;padding:16px;box-shadow:0 10px 30px rgba(2,6,23,0.06);margin-bottom:16px}
  .tools{display:flex;gap:10px;align-items:center;flex-wrap:wrap}
  .field input, .field select{padding:10px 12px;border-radius:10px;border:1px solid #e6eef2;background:#fff;font-size:14px;outline:none}
  .btn{padding:10px 14px;border-radius:10px;background:linear-gradient(90deg,#0b2545,#0fb5bf);color:#fff;border:none;cursor:pointer;font-weight:800}
  .btn.ghost{background:#fff;color:#0b2545;border:1px solid #e6eef2}
  .btn-icon .label{display:inline}
  a.btn.ghost{ text-decoration:none; }

  .table{ width:100%; border-collapse:collapse; table-layout:fixed; }
  .table th, .table td{ padding:10px; border-bottom:1px dashed #eef3f6; text-align:left; font-size:14px; vertical-align:middle; min-width:0; }
  .table th{ font-size:13px; color:#6b7280; }
  col.c-materia{ width:55%; } col.c-unidades{ width:12%; } col.c-uso{ width:13%; } col.c-actions{ width:20%; }
  .td-wrap{ white-space:normal; overflow-wrap:anywhere; word-break:break-word; }
  .materia-cell .nm{ font-weight:800; color:#0b2545; }
  .materia-cell .sub{ font-size:12px; color:#6b7280; }
  .chip{ display:inline-flex; align-items:center; gap:6px; padding:3px 6px; border-radius:999px; border:1px solid #e2ebff; background:#f1f5ff; color:#0055d4; font-size:12px; line-height:1; }
  .chip.gray{ background:#f3f4f6; border-color:#e5e7eb; color:#374151; }
  .actions{ display:flex; gap:8px; justify-content:flex-end; flex-wrap:wrap; }
  .actions a, .actions button{ display:inline-flex; align-items:center; gap:6px; padding:8px 10px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; font-size:13px; text-decoration:none; color:#0b2545; }
  .actions a:hover, .actions button:hover{ background:#f5f8ff; color:#0055d4; transform: translateY(-1px); }
  .actions button.danger-action{ color:#b91c1c; border-color:#fecaca; }
  .actions button.danger-action:hover{ background:#fff1f2; color:#991b1b; }

  .pager{ margin-top:12px; display:flex; gap:10px; align-items:center; }
  .pager button{ padding:8px 12px; border-radius:8px; border:1px solid #e6eef2; background:#fff; cursor:pointer; font-weight:700; }
  .pager .muted{ color:#6b7280; font-size:13px; }

  .toast{ position: fixed; top: 88px; right: 16px; z-index: 1400; display: none; min-width:280px; max-width:420px; padding:12px 14px; border-radius:10px; box-shadow:0 18px 40px rgba(2,6,23,0.18); font-size:14px; line-height:1.35; }
  .toast.ok{ display:block; border:1px solid #bbf7d0; background:#ecfdf5; color:#065f46; }
  .toast.err{ display:block; border:1px solid #f5c2c7; background:#fff1f0; color:#7a0021; }

  @media (max-width:1100px){ .actions .label{ display:none; } .actions a, .actions button{ padding:8px; } }
  @media (max-width:680px){
    .btn-icon .label{ display:none; }
    .btn-icon{ padding:10px; }
    .table thead{ display:none; }
    .table{ border-collapse: separate; border-spacing:0 10px; table-layout:auto; }
    .table tr{ display:block; background:#fff; border:1px solid #eef3f6; border-radius:12px; padding:12px; }
    .table td{ display:block; border-bottom:0; padding:6px 0; }
    .table td + td{ margin-top:4px; }
    .table td.actions{ display:flex; gap:8px; justify-content:flex-start; flex-wrap:wrap; margin-top:8px; padding-top:8px; border-top:1px dashed #eef3f6; }
    .table td.actions .label{ display:inline !important; }
  }


  /* ===== Ajuste móvil/tablet: listados de administración a todo el ancho ===== */
  @media (max-width:900px){
    .page-header{align-items:flex-start;gap:12px;}
    .page-header > div:last-child{width:100%;display:flex!important;gap:8px;}
    .page-header .btn{width:100%;justify-content:center;}
    .btn-icon .label{display:inline!important;}

    .card,
    section.card{
      width:100%!important;
      max-width:none!important;
      box-sizing:border-box!important;
      padding:12px!important;
      border-radius:18px!important;
      margin-left:0!important;
      margin-right:0!important;
      overflow:visible!important;
    }

    .tools,
    .tools[style],
    .tools .tools,
    .tools .tools[style]{
      display:grid!important;
      grid-template-columns:1fr!important;
      width:100%!important;
      gap:10px!important;
      align-items:stretch!important;
      justify-content:stretch!important;
    }
    .field,
    .field input,
    .field select,
    .tools button,
    .tools .btn{
      width:100%!important;
      min-width:0!important;
      max-width:none!important;
      box-sizing:border-box!important;
    }

    .table thead,
    .table colgroup{display:none!important;}
    .table,
    .table tbody{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      border-collapse:separate!important;
      border-spacing:0 12px!important;
      table-layout:auto!important;
      box-sizing:border-box!important;
    }
    .table tbody tr{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      box-sizing:border-box!important;
      background:#fff!important;
      border:1px solid #e6eef2!important;
      border-radius:16px!important;
      padding:14px!important;
      margin:0 0 12px 0!important;
      box-shadow:0 12px 28px rgba(2,6,23,.06)!important;
    }
    .table tbody td{
      display:block!important;
      width:100%!important;
      max-width:none!important;
      min-width:0!important;
      box-sizing:border-box!important;
      border-bottom:0!important;
      background:transparent!important;
      padding:7px 0!important;
      text-align:left!important;
    }
    .table tbody td + td{margin-top:4px!important;}
    .table tbody td[data-label]::before{
      content:attr(data-label);
      display:block;
      font-size:11px;
      text-transform:uppercase;
      letter-spacing:.04em;
      color:#64748b;
      font-weight:900;
      margin-bottom:4px;
    }
    .materia-cell .nm,
    .reticula-cell .nm,
    .nm{font-size:15px!important;line-height:1.25!important;color:#0b2545;}
    .materia-cell .sub,
    .reticula-cell .sub,
    .sub{font-size:12px!important;line-height:1.35!important;}
    .td-mini{display:flex!important;flex-direction:column!important;align-items:flex-start!important;width:100%!important;white-space:normal!important;gap:4px!important;margin:0!important;}
    .chip{font-size:12px!important;padding:5px 9px!important;}
    .table td.actions{
      display:grid!important;
      grid-template-columns:1fr 1fr!important;
      gap:8px!important;
      width:100%!important;
      margin-top:10px!important;
      padding-top:10px!important;
      border-top:1px dashed #e6eef2!important;
      justify-content:stretch!important;
    }
    .table td.actions a,
    .table td.actions button{
      width:100%!important;
      justify-content:center!important;
      padding:10px!important;
      box-sizing:border-box!important;
    }
    .table td.actions .label{display:inline!important;}
    .pager{justify-content:center!important;flex-wrap:wrap!important;}

    html[data-theme="dark"] .table tbody tr{
      background:#0f172a!important;
      border-color:rgba(148,163,184,.22)!important;
      box-shadow:0 12px 30px rgba(0,0,0,.28)!important;
    }
    html[data-theme="dark"] .table tbody td[data-label]::before{color:#94a3b8!important;}
    html[data-theme="dark"] .materia-cell .nm,
    html[data-theme="dark"] .reticula-cell .nm,
    html[data-theme="dark"] .nm{color:#f8fafc!important;}
    html[data-theme="dark"] .materia-cell .sub,
    html[data-theme="dark"] .reticula-cell .sub,
    html[data-theme="dark"] .sub{color:#94a3b8!important;}
    html[data-theme="dark"] .table td.actions{border-top-color:rgba(148,163,184,.22)!important;}
  }
  @media (max-width:480px){
    .page-header > div:last-child{flex-direction:column!important;}
    .table td.actions{grid-template-columns:1fr!important;}
  }
</style>

<div class="page-header">
  <div>
    <div class="page-title"><?= esc($h1) ?></div>
    <div class="page-sub"><?= esc($subtitle) ?></div>
  </div>
  <div>
    <a class="btn btn-icon" href="<?= esc(base_url('admin/registro_materia.php')) ?>">
      <i class="fas fa-book"></i><span class="label"> Registrar materia</span>
    </a>
  </div>
</div>

<?php if ($flash): ?>
  <div id="toast" class="toast <?= esc($flash['type']) ?>">
    <div style="display:flex; align-items:flex-start; gap:10px;">
      <div style="font-size:18px; line-height:1; margin-top:1px;">
        <?php if ($flash['type']==='ok'): ?>
          <i class="fas fa-check-circle" aria-hidden="true"></i>
        <?php else: ?>
          <i class="fas fa-exclamation-triangle" aria-hidden="true"></i>
        <?php endif; ?>
      </div>
      <div style="font-weight:700;"><?= esc($flash['msg']) ?></div>
      <button class="close" type="button" aria-label="Cerrar" style="background:transparent;border:0;cursor:pointer;font-size:16px;color:inherit;opacity:.7;padding:4px;margin-left:auto">&times;</button>
    </div>
  </div>
<?php endif; ?>

<section class="card" aria-label="Filtros">
  <div class="tools" style="justify-content:space-between; gap:12px;">
    <div class="tools" style="gap:8px;">
      <div class="field">
        <input type="text" id="q" placeholder="Buscar por nombre o clave" style="min-width:280px;">
      </div>
    </div>
    <div class="tools" style="gap:8px;">
      <div class="field">
        <select id="perPage">
          <option value="10">10 por página</option>
          <option value="20" selected>20 por página</option>
          <option value="30">30 por página</option>
          <option value="50">50 por página</option>
        </select>
      </div>
      <button class="btn ghost btn-icon" id="btnClear" title="Limpiar filtros">
        <i class="fas fa-eraser"></i> <span class="label">Limpiar</span>
      </button>
    </div>
  </div>
</section>

<section class="card" aria-label="Resultados">
  <table class="table">
    <colgroup>
      <col class="c-materia">
      <col class="c-unidades">
      <col class="c-uso">
      <col class="c-actions">
    </colgroup>
    <thead>
      <tr>
        <th>Materia</th>
        <th>Unidades</th>
        <th>En retículas</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody id="tbody">
      <tr><td colspan="4" style="text-align:center;color:#6b7280;">Cargando…</td></tr>
    </tbody>
  </table>

  <div class="pager" id="pager">
    <button id="prev" disabled>&laquo; Anterior</button>
    <span class="muted" id="info">—</span>
    <button id="next" disabled>Siguiente &raquo;</button>
  </div>
</section>

<script>
(function(){
  'use strict';
  const CSRF = <?= json_encode($CSRF) ?>;
  const endpoint = location.pathname; // POST al mismo script sin parámetros en URL

  // ====== Estado y helpers ======
  const q = document.getElementById('q');
  const perPage = document.getElementById('perPage');
  const btnClear = document.getElementById('btnClear');
  const tbody = document.getElementById('tbody');
  const prevBtn = document.getElementById('prev');
  const nextBtn = document.getElementById('next');
  const info = document.getElementById('info');

  let state = { page:1, total:0, perPage: parseInt(perPage.value,10)||20, q:'', loading:false };

  function escapeH(str){ return String(str ?? '').replace(/[&<>"']/g, s=>({'&':'&amp;','<':'&lt;','"':'&quot;',"'":'&#039;'}[s])); }
  function chip(n){ n = parseInt(n||0,10); return n>0 ? `<span class="chip"><i class="fas fa-layer-group"></i> ${n}</span>` : `<span class="chip gray"><i class="fas fa-layer-group"></i> 0</span>`; }

  function buildRow(r){
    const nombre = (r.nombre||'').trim() || ('Materia '+r.clave);
    const clave  = (r.clave||'').trim();
    return `<tr>
      <td data-label="Materia">
        <div class="materia-cell">
          <div class="nm">${escapeH(nombre)}</div>
          <div class="sub">${clave ? 'CLAVE '+escapeH(clave) : ''}</div>
        </div>
      </td>
      <td class="td-mini" data-label="Unidades">${chip(r.unidades)}</td>
      <td class="td-mini" data-label="En retículas">${chip(r.en_reticulas)}</td>
      <td class="actions" data-label="Acciones">
        <button type="button" class="btnEdit" data-clave="${escapeH(clave)}"><i class="fas fa-edit"></i> <span class="label">Editar</span></button>
        <button type="button" class="btnDelete danger-action" data-clave="${escapeH(clave)}" data-nombre="${escapeH(nombre)}"><i class="fas fa-trash"></i> <span class="label">Eliminar</span></button>
      </td>
    </tr>`;
  }

  async function postJSON(bodyObj){
    const body = new URLSearchParams(bodyObj);
    const res = await fetch(endpoint, {
      method: 'POST',
      headers: {'Content-Type':'application/x-www-form-urlencoded'},
      body
    });
    // Intentar leer JSON siempre; si falla, lanzar error legible
    const txt = await res.text();
    try { return JSON.parse(txt); }
    catch { throw new Error('Respuesta no válida del servidor'); }
  }

  async function fetchData(){
    if(state.loading) return; state.loading=true;
    tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#6b7280;">Cargando…</td></tr>`;
    try{
      const data = await postJSON({
        ajax:'search',
        csrf: CSRF,
        q: state.q,
        page: String(state.page||1),
        perPage: String(state.perPage||20)
      });
      if(!data.ok) throw new Error(data.msg || 'Error de búsqueda');

      state.total = data.total || 0;
      const rows = data.rows || [];
      tbody.innerHTML = rows.length ? rows.map(buildRow).join('') :
        `<tr><td colspan="4" style="text-align:center;color:#6b7280;">Sin resultados.</td></tr>`;

      const first = state.total ? Math.min(state.total, ((state.page-1)*state.perPage)+1) : 0;
      const last  = state.total ? Math.min(state.total, state.page*state.perPage) : 0;
      info.textContent = state.total ? `${first}–${last} de ${state.total}` : '0 resultados';
      prevBtn.disabled = (state.page<=1);
      nextBtn.disabled = (state.page*state.perPage >= state.total);
    } catch(e){
      tbody.innerHTML = `<tr><td colspan="4" style="text-align:center;color:#b91c1c;">Error al cargar datos.</td></tr>`;
      info.textContent = '—'; prevBtn.disabled = true; nextBtn.disabled = true;
      console.error(e);
    } finally {
      state.loading=false;
    }
  }

  function debounce(fn, ms){ let t; return (...a)=>{ clearTimeout(t); t=setTimeout(()=>fn(...a), ms); }; }
  const onChange = debounce(()=>{ state.page=1; fetchData(); }, 250);

  q.addEventListener('input', ()=>{ state.q = q.value.trim(); onChange(); });
  perPage.addEventListener('change', ()=>{ state.perPage = parseInt(perPage.value,10)||20; state.page=1; fetchData(); });
  prevBtn.addEventListener('click', ()=>{ if(state.page>1){ state.page--; fetchData(); }});
  nextBtn.addEventListener('click', ()=>{ if(state.page*state.perPage < state.total){ state.page++; fetchData(); }});
  btnClear.addEventListener('click', (e)=>{ e.preventDefault(); q.value=''; perPage.value='20';
    state={page:1,total:0,perPage:20,q:'',loading:false}; fetchData(); });

  // Abrir editor / eliminar materia SIN pasar clave por URL (POST seguro)
  tbody.addEventListener('click', async (e)=>{
    const btnEdit = e.target.closest('.btnEdit');
    const btnDelete = e.target.closest('.btnDelete');

    if(btnEdit){
      const clave = btnEdit.getAttribute('data-clave') || '';
      if(!clave) return;
      try{
        const data = await postJSON({ ajax:'open', csrf:CSRF, clave });
        if(!data.ok){ alert(data.msg || 'No se pudo abrir'); return; }
        location.href = data.redirect || '<?= esc(base_url('admin/editar_materia.php')) ?>';
      }catch(err){ alert('Error al abrir la materia'); }
      return;
    }

    if(btnDelete){
      const clave = btnDelete.getAttribute('data-clave') || '';
      const nombre = btnDelete.getAttribute('data-nombre') || 'esta materia';
      if(!clave) return;
      const msg = `¿Eliminar ${nombre}?\n\nTambién se eliminarán sus unidades, relación con retículas, permisos relacionados y contenidos dependientes según las reglas de la base de datos. Esta acción no se puede deshacer.`;
      if(!confirm(msg)) return;
      btnDelete.disabled = true;
      const oldHtml = btnDelete.innerHTML;
      btnDelete.innerHTML = '<i class="fas fa-circle-notch fa-spin"></i> <span class="label">Eliminando</span>';
      try{
        const data = await postJSON({ ajax:'delete', csrf:CSRF, clave });
        if(!data.ok){ alert(data.msg || 'No se pudo eliminar'); btnDelete.disabled=false; btnDelete.innerHTML=oldHtml; return; }
        fetchData();
      }catch(err){
        alert('Error al eliminar la materia');
        btnDelete.disabled=false;
        btnDelete.innerHTML=oldHtml;
      }
    }
  });

  // Toast close & limpiar query params si existen
  (function(){
    const toast = document.getElementById('toast'); if(!toast) return;
    toast.style.display='block';
    const closeBtn = toast.querySelector('.close');
    function hide(){ toast.remove();
      try{ const u=new URL(location.href); u.searchParams.delete('ok'); u.searchParams.delete('err'); history.replaceState({},'',u);}catch(e){}
    }
    closeBtn?.addEventListener('click', hide);
    setTimeout(hide, 4500);
  })();

  // Primera carga
  fetchData();
})();
</script>

<?php
require __DIR__ . '/partials/footer.php';
