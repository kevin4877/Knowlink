<?php
// public/logout.php
declare(strict_types=1);
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/helpers.php';
logout_user();
redirect(base_url('login.php'));
