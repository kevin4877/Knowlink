<?php
// public/recurso_archivo.php
// Sirve archivos de recursos desde una ruta segura y compatible con rutas antiguas.
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/auth.php';
require_once __DIR__ . '/../src/asset_paths.php';

start_session();
$yo = auth_user();
if (!$yo) { redirect(base_url('login.php')); exit; }

$assetId = (int)($_GET['id'] ?? 0);
$mode = ((string)($_GET['mode'] ?? 'open')) === 'download' ? 'download' : 'open';
if ($assetId <= 0) { http_response_code(400); echo 'Recurso inválido.'; exit; }

$pdo = db();
$st = $pdo->prepare("\n  SELECT\n    a.id, a.contenido_id, a.tipo, a.titulo, a.url,\n    c.docente_id, c.visibilidad\n  FROM contenido_activos a\n  JOIN contenidos c ON c.id = a.contenido_id\n  WHERE a.id = :id\n  LIMIT 1\n");
$st->execute([':id' => $assetId]);
$asset = $st->fetch(PDO::FETCH_ASSOC);
if (!$asset) { http_response_code(404); echo 'Recurso no encontrado.'; exit; }

$rol = (string)($yo['rol'] ?? '');
$userId = (int)($yo['id'] ?? 0);
$vis = (string)($asset['visibilidad'] ?? 'privado');
$docenteId = (int)($asset['docente_id'] ?? 0);

$permitido = false;
if ($rol === 'admin') {
  $permitido = true;
} elseif ($rol === 'docente') {
  $permitido = ($docenteId === $userId) || ($vis === 'publico');
} elseif ($rol === 'estudiante') {
  $permitido = in_array($vis, ['publico', 'solo_estudiantes'], true);
}

if (!$permitido) { http_response_code(403); echo 'No tienes permiso para abrir este recurso.'; exit; }

$tipo = strtolower((string)($asset['tipo'] ?? 'otro'));
$url = trim((string)($asset['url'] ?? ''));

if ($tipo === 'enlace') {
  if ($url === '') { http_response_code(404); echo 'El enlace no está disponible.'; exit; }
  header('Location: ' . $url);
  exit;
}

if ($url !== '' && kl_is_http_url($url)) {
  // Recurso externo guardado como archivo: redirige como respaldo.
  header('Location: ' . $url);
  exit;
}

$ruta = kl_resolve_asset_path_from_url($url);
if (!$ruta || !is_file($ruta)) {
  http_response_code(404);
  echo 'El archivo no se encontró en el servidor. Vuelve a subirlo o revisa la ruta guardada.';
  exit;
}

$filename = kl_asset_filename($asset);
$filesize = filesize($ruta);
$mime = 'application/octet-stream';
if (function_exists('finfo_open')) {
  $finfo = finfo_open(FILEINFO_MIME_TYPE);
  if ($finfo) {
    $detected = finfo_file($finfo, $ruta);
    if (is_string($detected) && $detected !== '') $mime = $detected;
    finfo_close($finfo);
  }
}

// Ajustes de MIME útiles para Office si finfo devuelve genérico.
$ext = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
$mimeByExt = [
  'pdf'  => 'application/pdf',
  'doc'  => 'application/msword',
  'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'xls'  => 'application/vnd.ms-excel',
  'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'ppt'  => 'application/vnd.ms-powerpoint',
  'pptx' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation',
  'png'  => 'image/png',
  'jpg'  => 'image/jpeg',
  'jpeg' => 'image/jpeg',
  'webp' => 'image/webp',
  'gif'  => 'image/gif',
  'mp4'  => 'video/mp4',
  'webm' => 'video/webm',
];
if (($mime === 'application/octet-stream' || $mime === 'text/plain') && isset($mimeByExt[$ext])) {
  $mime = $mimeByExt[$ext];
}

header('X-Content-Type-Options: nosniff');
header('Content-Type: ' . $mime);
if ($filesize !== false) header('Content-Length: ' . $filesize);

$disp = $mode === 'download' ? 'attachment' : 'inline';
$asciiName = preg_replace('/[^A-Za-z0-9._ -]/', '_', $filename) ?: 'recurso';
header("Content-Disposition: {$disp}; filename=\"{$asciiName}\"; filename*=UTF-8''" . rawurlencode($filename));
header('Cache-Control: private, max-age=120');

readfile($ruta);
exit;
