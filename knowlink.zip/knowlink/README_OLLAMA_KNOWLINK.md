# Ajuste de Ollama para KnowLink

Esta versión usa por defecto:

```php
define('OLLAMA_BASE_URL', 'http://127.0.0.1:11434/api');
define('OLLAMA_MODEL', 'llama3.2:latest');
```

Tu computadora tiene instalado `llama3.2:latest`, por eso `llama3.2:1b` no funcionaba.

## Pruebas rápidas

```cmd
ollama --version
curl http://localhost:11434/api/tags
ollama list
```

Prueba directa con tu modelo real:

```cmd
curl http://localhost:11434/api/generate -H "Content-Type: application/json" -d "{ \"model\": \"llama3.2:latest\", \"prompt\": \"Genera una pregunta de opción múltiple sobre algoritmos.\", \"stream\": false }"
```

También puedes abrir:

```txt
http://localhost/knowlink/test_ollama.php
```

## Cambios de esta versión

- Se corrigió el modelo por defecto a `llama3.2:latest`.
- Si el modelo configurado no existe, KnowLink intenta detectar modelos instalados con `/api/tags`.
- Para Algoritmos y Lenguajes de Programación, KnowLink intenta usar Ollama primero y solo completa internamente si el modelo tarda o no responde.
- Si Ollama tarda, el sistema completa el examen internamente sin mostrar errores técnicos al estudiante.
