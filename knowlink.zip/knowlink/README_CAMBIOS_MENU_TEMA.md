# Cambios realizados

- Se unificó la estructura del menú y barra superior tomando como base el modo claro.
- En modo oscuro el menú ya no queda pegado al borde: ahora usa el mismo panel flotante, márgenes, esquinas redondeadas y espacios del modo claro.
- El cambio de tema solo modifica paleta, fondos, bordes y sombras.
- Se añadieron transiciones suaves para el cambio claro/oscuro.
- Se agregó una capa de estabilidad visual al login para evitar que cambie la retícula al alternar tema.
- Se actualizó el cache busting del CSS a `20260524-panel-structure`.

Nota: los íconos se cargan mediante CDN de Font Awesome en lugar de archivos locales de fuente.
