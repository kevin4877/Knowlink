# Cambio en generación de exámenes predictivos

Se actualizó la generación para que el examen se base únicamente en:

- Nombre de la materia.
- Nombre de la unidad.

Ya no se consultan temas registrados, chunks, apuntes, archivos subidos ni textos extraídos para crear las preguntas. Esto reduce el tiempo de generación y evita que el sistema dependa del contenido cargado por docentes para formular reactivos.

También se agregó una validación local para operaciones simples y ecuaciones básicas, de modo que si una pregunta contiene un cálculo sencillo, la opción marcada como correcta debe coincidir con el resultado esperado.

En caso de que Ollama devuelva menos preguntas de las solicitadas, el sistema completa internamente el examen de manera silenciosa para que el estudiante no se quede sin evaluación.
