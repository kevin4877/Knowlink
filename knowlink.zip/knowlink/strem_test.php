<?php
@ini_set('output_buffering','off');
@ini_set('zlib.output_compression','0');
if (function_exists('apache_setenv')) { @apache_setenv('no-gzip','1'); }
header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-cache, no-transform');
header('X-Accel-Buffering: no');

// pad de 4KB para forzar flush intermedio
echo str_repeat(' ', 4096)."\n"; @ob_flush(); @flush();

for ($i=1; $i<=5; $i++) {
  echo "tick $i\n";
  @ob_flush(); @flush();
  usleep(500000); // 0.5s
}
echo "done\n";
