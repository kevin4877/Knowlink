-- sql_fix_materias_unidades_claves.sql
-- Ejecuta este archivo una sola vez si tu base tiene claves de materia con mayúsculas/minúsculas mezcladas.
-- No cambia nombres ni elimina datos; solo normaliza las claves relacionadas para que coincidan
-- exactamente con la clave guardada en la tabla materias.

START TRANSACTION;

UPDATE unidades u
JOIN materias m ON LOWER(u.materia_clave) = LOWER(m.clave)
SET u.materia_clave = m.clave;

UPDATE reticula_materias rm
JOIN materias m ON LOWER(rm.materia_clave) = LOWER(m.clave)
SET rm.materia_clave = m.clave;

UPDATE docente_permisos_materia dpm
JOIN materias m ON LOWER(dpm.materia_clave) = LOWER(m.clave)
SET dpm.materia_clave = m.clave;

UPDATE estudiante_notifs en
JOIN materias m ON LOWER(en.materia_clave) = LOWER(m.clave)
SET en.materia_clave = m.clave
WHERE en.materia_clave IS NOT NULL;

UPDATE examenes_predictivos ep
JOIN materias m ON LOWER(ep.materia_clave) = LOWER(m.clave)
SET ep.materia_clave = m.clave;

UPDATE activo_texto_extraido ate
JOIN materias m ON LOWER(ate.materia_clave) = LOWER(m.clave)
SET ate.materia_clave = m.clave;

UPDATE activo_chunks ac
JOIN materias m ON LOWER(ac.materia_clave) = LOWER(m.clave)
SET ac.materia_clave = m.clave;

COMMIT;
