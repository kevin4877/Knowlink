# Cambios en exámenes predictivos e IA

Se ajustó el flujo de generación y calificación de exámenes para hacerlo más estable en pruebas con estudiantes.

## Cambios principales

- Se agregó una ruta optimizada local para **Algoritmos y Lenguajes de Programación**.
- Las preguntas de esa materia ya no dependen de internet, Ollama u OpenAI para generarse.
- La generación respeta dificultad: básico, intermedio y avanzado.
- La generación respeta tipo de examen: teórico, práctico o mixto.
- Si la IA tarda o falla, el sistema completa internamente el examen para no cortar la actividad del estudiante.
- Se redujeron los tiempos máximos de espera de IA para evitar que la pantalla se quede cargando demasiado.
- Se mejoró el manejo de respuestas JSON para que errores de PHP/HTML no aparezcan como “error de red” sin explicación.
- Se agregó reintento automático al calificar el examen.
- La respuesta de calificación ahora devuelve solo lo necesario para reducir peso y evitar fallos.

## Archivos principales modificados

- `public/estudiantes/ver_materia.php`
- `config/config.php`

## Nota

La IA externa puede seguir usándose para otras materias si está configurada, pero KnowLink ya no queda detenido si el proveedor falla o tarda demasiado.
