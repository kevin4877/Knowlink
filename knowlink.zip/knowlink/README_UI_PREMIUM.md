# KnowLink · Versión visual premium

Esta versión mantiene la lógica PHP y la base de datos del proyecto original, pero actualiza la capa visual para que la plataforma se vea más moderna, elegante y lista para publicarse en un portal web.

## Cambios principales

- Login rediseñado con estilo de landing page oscura, líneas diagonales, acentos dorados, tarjeta de acceso limpia y comportamiento responsive.
- Paneles de administrador, docente y estudiante con topbar tipo glass, sidebar elegante, tarjetas con profundidad, botones modernos, tablas más legibles y modo claro/oscuro unificado.
- Mejoras mobile-first para computadora, tablet y celular.
- Tablas convertidas en tarjetas legibles en pantallas pequeñas mediante etiquetas automáticas.
- Microinteracciones: animación de entrada, hover en tarjetas, efecto ripple en botones, cierre automático del menú lateral en móvil y estados de carga en formularios.
- Se conserva la estructura original del proyecto y no se modifican consultas ni reglas de negocio.

## Archivos visuales modificados

- `public/login.php`
- `css/estilosLogin.css`
- `public/assets/css/knowlink-modern.css`
- `public/assets/js/knowlink-theme.js`

## Publicación

1. Copia la carpeta `knowlink` al servidor web.
2. Configura `config/config.php` con los datos reales de MySQL y el `BASE_URL` correcto.
3. Importa `sql.sql` y, si usarás IA, también `sql_migracion_ia.sql`.
4. Asegúrate de que `public/uploads` tenga permisos de escritura.
5. En producción, coloca `COOKIE_SECURE` en `true` si usas HTTPS.
6. Usa como raíz pública del sitio la carpeta `public` cuando sea posible.

## Nota

El diseño usa Bootstrap desde CDN, igual que la versión original. Si el servidor no tendrá internet, descarga Bootstrap localmente y cambia las rutas en los headers/footers.
