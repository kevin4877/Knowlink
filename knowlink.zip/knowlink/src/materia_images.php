<?php
// src/materia_images.php
// Compatibilidad sin carga de imágenes externas.
// Se conserva este archivo para no romper rutas antiguas, pero ya no consulta internet.
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

if (!function_exists('kl_materia_fallback_svg')) {
  function kl_materia_fallback_svg(string $clave, string $nombre = ''): string {
    $titulo = trim($nombre) !== '' ? trim($nombre) : (trim($clave) !== '' ? trim($clave) : 'Materia');
    $codigo = trim($clave);
    $safeTitle = htmlspecialchars(mb_substr($titulo, 0, 80, 'UTF-8'), ENT_QUOTES, 'UTF-8');
    $safeCode = htmlspecialchars(mb_substr($codigo, 0, 24, 'UTF-8'), ENT_QUOTES, 'UTF-8');
    $hash = crc32($titulo . '|' . $codigo);
    $h = $hash % 360;
    $h2 = ($h + 28) % 360;
    return <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="640" height="360" viewBox="0 0 640 360" role="img" aria-label="{$safeTitle}">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="hsl({$h},75%,42%)"/>
      <stop offset="1" stop-color="hsl({$h2},75%,30%)"/>
    </linearGradient>
  </defs>
  <rect width="640" height="360" fill="url(#g)"/>
  <circle cx="90" cy="70" r="70" fill="rgba(255,255,255,.18)"/>
  <circle cx="550" cy="290" r="90" fill="rgba(255,255,255,.12)"/>
  <rect x="36" y="36" width="568" height="288" rx="22" fill="none" stroke="rgba(255,255,255,.20)"/>
  <text x="52" y="82" font-family="Inter, Arial, sans-serif" font-size="22" font-weight="900" fill="rgba(255,255,255,.82)">{$safeCode}</text>
  <foreignObject x="52" y="120" width="536" height="150">
    <div xmlns="http://www.w3.org/1999/xhtml" style="font-family:Inter,Arial,sans-serif;font-size:38px;font-weight:900;line-height:1.08;color:white;text-shadow:0 2px 10px rgba(0,0,0,.28);">{$safeTitle}</div>
  </foreignObject>
</svg>
SVG;
  }
}

if (!function_exists('kl_materia_remote_image')) {
  function kl_materia_remote_image(string $clave, string $nombre = ''): ?string {
    return null;
  }
}

if (!function_exists('materia_portada_url')) {
  function materia_portada_url(string $clave, string $nombre = ''): string {
    $params = http_build_query(['clave' => $clave, 'nombre' => $nombre]);
    return base_url('materia_portada.php?' . $params);
  }
}
