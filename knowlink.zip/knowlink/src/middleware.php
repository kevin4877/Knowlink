<?php
// src/middleware.php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function require_login(): void { auth_require_login(); }
function require_role(string $r): void { auth_require_role($r); }
