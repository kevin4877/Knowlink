<?php
// src/asset_paths.php
// Helpers centralizados para resolver y servir archivos subidos como recursos.
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

if (!function_exists('kl_project_root')) {
  function kl_project_root(): string {
    return rtrim(realpath(__DIR__ . '/..') ?: (__DIR__ . '/..'), DIRECTORY_SEPARATOR);
  }
}

if (!function_exists('kl_public_root')) {
  function kl_public_root(): string {
    return rtrim(realpath(kl_project_root() . '/public') ?: (kl_project_root() . '/public'), DIRECTORY_SEPARATOR);
  }
}

if (!function_exists('kl_norm_slashes')) {
  function kl_norm_slashes(string $path): string {
    return str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $path);
  }
}

if (!function_exists('kl_is_http_url')) {
  function kl_is_http_url(string $url): bool {
    return (bool)preg_match('#^https?://#i', trim($url));
  }
}

if (!function_exists('kl_asset_filename')) {
  function kl_asset_filename(array $asset): string {
    $titulo = trim((string)($asset['titulo'] ?? ''));
    if ($titulo !== '') return basename(str_replace('\\', '/', $titulo));

    $url = trim((string)($asset['url'] ?? ''));
    $path = parse_url($url, PHP_URL_PATH) ?: $url;
    $base = basename(urldecode(str_replace('\\', '/', $path)));
    return $base !== '' ? $base : ('recurso_' . (int)($asset['id'] ?? 0));
  }
}

if (!function_exists('kl_resolve_asset_path_from_url')) {
  /**
   * Convierte rutas antiguas y nuevas de recursos a ruta local real.
   * Soporta ejemplos como:
   * - uploads/recursos/2026/05/archivo.pdf
   * - /uploads/recursos/2026/05/archivo.pdf
   * - /KnowLink/public/uploads/recursos/2026/05/archivo.pdf
   * - C:\xampp\htdocs\knowlink\public\uploads\recursos\...
   */
  function kl_resolve_asset_path_from_url(?string $url): ?string {
    $url = trim((string)$url);
    if ($url === '') return null;

    $projectRoot = kl_project_root();
    $publicRoot  = kl_public_root();
    $allowedDirs = [
      realpath($publicRoot . '/uploads/recursos') ?: ($publicRoot . '/uploads/recursos'),
      realpath($projectRoot . '/uploads/recursos') ?: ($projectRoot . '/uploads/recursos'),
    ];

    $candidatos = [];

    // Ruta absoluta del sistema.
    $direct = str_replace(['\\', '/'], DIRECTORY_SEPARATOR, urldecode($url));
    if (is_file($direct)) $candidatos[] = $direct;

    $path = parse_url($url, PHP_URL_PATH);
    if ($path === null || $path === false || $path === '') $path = $url;
    $path = urldecode(str_replace('\\', '/', (string)$path));

    // Si viene con BASE_URL, quita ese prefijo para resolver relativo a /public.
    $basePath = parse_url(base_url(''), PHP_URL_PATH) ?: '';
    $basePath = '/' . trim($basePath, '/');
    if ($basePath !== '/' && strpos($path, $basePath . '/') === 0) {
      $relative = substr($path, strlen($basePath) + 1);
      $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);
      $candidatos[] = $projectRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);
    }

    // Rutas con /public/uploads/...
    $needlePublic = '/public/uploads/recursos/';
    $posPublic = stripos($path, $needlePublic);
    if ($posPublic !== false) {
      $sub = substr($path, $posPublic + strlen('/public/'));
      $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes(substr($sub, strlen('uploads/')));
      $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($sub);
      $candidatos[] = $projectRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($sub);
    }

    // Rutas con /uploads/recursos/...
    $needleUploads = '/uploads/recursos/';
    $posUploads = stripos($path, $needleUploads);
    if ($posUploads !== false) {
      $sub = substr($path, $posUploads + 1); // uploads/recursos/...
      $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($sub);
      $candidatos[] = $projectRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($sub);
    }

    // Ruta relativa sin slash inicial: uploads/recursos/...
    $relative = ltrim($path, '/');
    if (stripos($relative, 'uploads/recursos/') === 0) {
      $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);
      $candidatos[] = $projectRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);
    }

    // Últimos respaldos.
    $candidatos[] = $publicRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);
    $candidatos[] = $projectRoot . DIRECTORY_SEPARATOR . kl_norm_slashes($relative);

    foreach (array_unique($candidatos) as $candidate) {
      if (!$candidate || !is_file($candidate)) continue;
      $real = realpath($candidate);
      if (!$real) continue;
      foreach ($allowedDirs as $allowed) {
        $allowedReal = realpath($allowed) ?: $allowed;
        $allowedReal = rtrim($allowedReal, DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR;
        if (strpos($real, $allowedReal) === 0) return $real;
      }
    }

    return null;
  }
}

if (!function_exists('kl_asset_stream_url')) {
  function kl_asset_stream_url(int $assetId, string $mode = 'open'): string {
    $mode = $mode === 'download' ? 'download' : 'open';
    return base_url('recurso_archivo.php?id=' . $assetId . '&mode=' . $mode);
  }
}
