<?php
// src/auth.php
declare(strict_types=1);

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/helpers.php';

/**
 * Usa start_session() de helpers.php si existe; si no, define una compatible.
 * (Evita "Cannot redeclare start_session()")
 */
if (!function_exists('start_session')) {
  function start_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
              || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    $params = session_get_cookie_params();
    session_set_cookie_params([
      'lifetime' => 0,
      'path'     => $params['path'] ?? '/',
      'domain'   => $params['domain'] ?? '',
      'secure'   => $secure,
      'httponly' => true,
      'samesite' => 'Lax',
    ]);
    session_start();
  }
}

/** Guarda en sesión sólo lo que la UI necesita */
function set_user_session(array $row): void {
  start_session();
  $foto = isset($row['foto_url']) && $row['foto_url'] !== '' ? (string)$row['foto_url'] : null;
  $_SESSION['user'] = [
    'id'        => (int)($row['id'] ?? 0),
    'nombre'    => (string)($row['nombre'] ?? ''),
    'apellidos' => (string)($row['apellidos'] ?? ''),
    'email'     => (string)($row['email'] ?? ''),
    'username'  => (string)($row['username'] ?? ''),
    'rol'       => (string)($row['rol'] ?? ''),
    'foto_url'  => $foto,
    // Alias de compatibilidad para vistas antiguas que revisan $yo['foto'].
    'foto'      => $foto,
  ];
}

/**
 * Devuelve el usuario autenticado refrescando sus datos desde BD.
 * Esto evita que la barra superior se quede con una foto anterior o vacía
 * después de actualizar el perfil.
 */
function auth_user(): ?array {
  start_session();
  $u = $_SESSION['user'] ?? null;
  if (!$u || !isset($u['id'])) return null;

  try {
    $pdo = db();
    $st  = $pdo->prepare("SELECT id, nombre, apellidos, email, username, rol, foto_url
                          FROM usuarios WHERE id=:id LIMIT 1");
    $st->execute([':id' => (int)$u['id']]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row) {
      set_user_session($row);
      return $_SESSION['user'];
    }
  } catch (Throwable $e) {
    // Si la BD no responde, conserva los datos de sesión disponibles.
    if (isset($u['foto_url']) && !isset($u['foto'])) {
      $u['foto'] = $u['foto_url'];
      $_SESSION['user'] = $u;
    }
  }

  return $_SESSION['user'] ?? $u;
}

/**
 * Autentica por email o username + password.
 * Retorna ['ok'=>bool,'err'=>?string]
 */
function login_user(string $identifier, string $password): array {
  $identifier = trim($identifier);
  if ($identifier === '' || $password === '') {
    return ['ok'=>false, 'err'=>'Credenciales incompletas.'];
  }

  $pdo = db();
  $st  = $pdo->prepare(
    "SELECT id, nombre, apellidos, email, username, rol, foto_url, password_hash, activo
     FROM usuarios
     WHERE email=:id OR username=:id
     LIMIT 1"
  );
  $st->execute([':id'=>$identifier]);
  $row = $st->fetch(PDO::FETCH_ASSOC);
  if (!$row) return ['ok'=>false, 'err'=>'Usuario o contraseña inválidos.'];

  if ((int)($row['activo'] ?? 0) !== 1) {
    return ['ok'=>false, 'err'=>'Tu cuenta está inactiva. Contacta al administrador.'];
  }

  if (!password_verify($password, (string)$row['password_hash'])) {
    return ['ok'=>false, 'err'=>'Usuario o contraseña inválidos.'];
  }

  // Rehash opcional
  if (password_needs_rehash((string)$row['password_hash'], PASSWORD_BCRYPT, ['cost'=>10])) {
    $new = password_hash($password, PASSWORD_BCRYPT, ['cost'=>10]);
    $pdo->prepare("UPDATE usuarios SET password_hash=:ph WHERE id=:id")
        ->execute([':ph'=>$new, ':id'=>(int)$row['id']]);
  }

  // Guardar sesión con todos los campos que el header necesita
  set_user_session($row);

  // Marca último acceso (opcional)
  $pdo->prepare("UPDATE usuarios SET actualizado_en=NOW() WHERE id=:id")
      ->execute([':id'=>(int)$row['id']]);

  return ['ok'=>true, 'err'=>null];
}

/**
 * Wrapper para compatibilidad con tu login (devuelve bool).
 * $remember extiende la cookie de sesión a 30 días.
 */
function auth_login(string $identifier, string $password, bool $remember=false): bool {
  $res = login_user($identifier, $password);
  if (!$res['ok']) return false;

  if ($remember) {
    $p = session_get_cookie_params();
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
              || (($_SERVER['SERVER_PORT'] ?? '') === '443');

    // Extiende la cookie de la sesión actual (simple "remember me")
    setcookie(
      session_name(),
      session_id(),
      [
        'expires'  => time() + 60*60*24*30, // 30 días
        'path'     => $p['path'] ?? '/',
        'domain'   => $p['domain'] ?? '',
        'secure'   => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
      ]
    );
  }

  return true;
}

/** Cierra sesión */
function logout_user(): void {
  start_session();
  $_SESSION = [];
  if (ini_get('session.use_cookies')) {
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time()-42000, $p['path'] ?? '/', $p['domain'] ?? '', $p['secure'] ?? false, $p['httponly'] ?? true);
  }
  session_destroy();
}
