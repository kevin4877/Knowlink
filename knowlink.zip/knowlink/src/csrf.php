<?php
// src/csrf.php
declare(strict_types=1);

require_once __DIR__ . '/helpers.php';

function csrf_token(): string {
  start_session();
  if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
  }
  return $_SESSION['csrf'];
}

function csrf_input(): string {
  $token = htmlspecialchars(csrf_token(), ENT_QUOTES, 'UTF-8');
  return '<input type="hidden" name="csrf" value="'.$token.'">';
}

function csrf_validate(string $tokenFromPost): bool {
  start_session();
  return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $tokenFromPost ?? '');
}
