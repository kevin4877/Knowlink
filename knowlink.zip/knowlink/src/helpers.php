<?php
// src/helpers.php
declare(strict_types=1);

require_once __DIR__ . '/../config/config.php';

function start_session(): void {
  if (session_status() === PHP_SESSION_NONE) {
    session_name(SESSION_NAME);
    session_set_cookie_params([
      'lifetime' => 0,
      'path' => '/',
      'secure' => COOKIE_SECURE,
      'httponly' => true,
      'samesite' => COOKIE_SAMESITE
    ]);
    session_start();
  }
}

function base_url(string $path = ''): string {
  return rtrim(BASE_URL, '/') . '/' . ltrim($path, '/');
}

function flash(string $key, ?string $msg = null) {
  start_session();
  if ($msg === null) {
    if (!empty($_SESSION['flash'][$key])) {
      $m = $_SESSION['flash'][$key];
      unset($_SESSION['flash'][$key]);
      return $m;
    }
    return null;
  } else {
    $_SESSION['flash'][$key] = $msg;
  }
}

function redirect(string $to): void {
  header('Location: ' . $to);
  exit;
}


if (!function_exists('resolve_materia_clave')) {
  /**
   * Devuelve la clave real de la materia tal como está guardada en la tabla materias.
   * Acepta clave o nombre de materia. Esto evita que las unidades se guarden
   * en una materia equivocada cuando la clave llega en mayúsculas/minúsculas
   * distintas o cuando una pantalla trabaja con el nombre de la materia.
   */
  function resolve_materia_clave(PDO $pdo, string $referencia): ?string {
    $referencia = trim($referencia);
    if ($referencia === '') return null;

    // 1) Coincidencia directa por clave.
    $st = $pdo->prepare("SELECT clave FROM materias WHERE clave = :ref LIMIT 1");
    $st->execute([':ref' => $referencia]);
    $clave = $st->fetchColumn();
    if ($clave !== false && $clave !== null && $clave !== '') return (string)$clave;

    // 2) Coincidencia directa por nombre.
    $st = $pdo->prepare("SELECT clave FROM materias WHERE nombre = :ref LIMIT 1");
    $st->execute([':ref' => $referencia]);
    $clave = $st->fetchColumn();
    if ($clave !== false && $clave !== null && $clave !== '') return (string)$clave;

    // 3) Coincidencia flexible por clave o nombre. Solo se usa como respaldo.
    $like = '%' . $referencia . '%';
    $prefix = $referencia . '%';
    $st = $pdo->prepare("\n      SELECT clave\n      FROM materias\n      WHERE clave LIKE :like OR nombre LIKE :like\n      ORDER BY\n        CASE\n          WHEN clave = :ref THEN 0\n          WHEN nombre = :ref THEN 1\n          WHEN clave LIKE :prefix THEN 2\n          WHEN nombre LIKE :prefix THEN 3\n          ELSE 4\n        END,\n        nombre ASC, clave ASC\n      LIMIT 1\n    ");
    $st->execute([':like' => $like, ':prefix' => $prefix, ':ref' => $referencia]);
    $clave = $st->fetchColumn();
    return ($clave !== false && $clave !== null && $clave !== '') ? (string)$clave : null;
  }
}

if (!function_exists('materia_param_canonica')) {
  /**
   * Normaliza una referencia de materia para guardarla en tablas relacionadas.
   * Si no existe una materia con esa clave o nombre, devuelve null.
   */
  function materia_param_canonica(PDO $pdo, string $referencia): ?string {
    return resolve_materia_clave($pdo, $referencia);
  }
}
