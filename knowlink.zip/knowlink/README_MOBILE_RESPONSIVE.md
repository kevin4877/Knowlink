# KnowLink · Ajustes responsivos para celular

Esta versión conserva el diseño de computadora y agrega una capa responsive enfocada en celular.

## Cambios agregados

- Barra superior compacta para celular, con botones táctiles más cómodos.
- Menú lateral tipo drawer en celular, con overlay y cierre automático.
- Dock inferior móvil con accesos rápidos tomados del menú real.
- Tarjetas de materias optimizadas para pantallas pequeñas.
- Encabezados, filtros, buscadores, formularios y botones adaptados a ancho completo.
- Tablas convertidas en tarjetas legibles en celular.
- Modales de exámenes y explicaciones ajustados a pantalla completa móvil.
- Login optimizado para celular sin alterar la versión de escritorio.
- Se actualizó el cache de CSS/JS para cargar la nueva versión.

## Archivos modificados principalmente

- `public/assets/css/knowlink-modern.css`
- `css/estilosLogin.css`
- `public/assets/js/knowlink-theme.js`
- referencias de versión `?v=` en archivos PHP para evitar caché del navegador.

## Nota

La lógica del sistema no fue modificada; los cambios son de presentación, transiciones y comportamiento responsive.
