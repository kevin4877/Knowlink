<?php
// views/_header.php
require_once __DIR__ . '/../src/helpers.php';
require_once __DIR__ . '/../src/auth.php';
auth_try_autologin_from_cookie(); // intenta autologin al cargar cualquier vista
$u = auth_user();
?><!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>KnowLink</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    body{font-family:system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,'Helvetica Neue',Arial,sans-serif;margin:0;background:#0b1020;color:#e8eaf6}
    a{color:#90caf9;text-decoration:none}
    .container{max-width:900px;margin:40px auto;padding:20px;background:#121b35;border-radius:12px;box-shadow:0 10px 30px rgba(0,0,0,.3)}
    .btn{display:inline-block;padding:10px 16px;border-radius:8px;background:#1e88e5;color:#fff}
    .btn.outline{background:transparent;border:1px solid #1e88e5}
    .field{margin:10px 0}
    input{width:100%;padding:10px;border-radius:8px;border:1px solid #2a3d6a;background:#0e1730;color:#e8eaf6}
    .row{display:flex;gap:12px;align-items:center;justify-content:space-between}
    .flash{padding:10px;border-radius:8px;margin:10px 0}
    .flash.error{background:#b00020}
    .flash.ok{background:#2e7d32}
    .topbar{padding:14px 20px;background:#0a142b;border-bottom:1px solid #13224a}
  </style>

<!-- Bootstrap + capa visual KnowLink -->
<script>
(function(){
  try{
    var saved = localStorage.getItem('knowlink-theme');
    var prefersDark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    var theme = (saved === 'dark' || saved === 'light') ? saved : (prefersDark ? 'dark' : 'light');
    document.documentElement.setAttribute('data-theme', theme);
    document.documentElement.setAttribute('data-bs-theme', theme);
  }catch(e){
    document.documentElement.setAttribute('data-theme', 'light');
    document.documentElement.setAttribute('data-bs-theme', 'light');
  }
})();
</script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css">
<link rel="stylesheet" href="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/css/knowlink-modern.css') : '/assets/css/knowlink-modern.css', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive">
</head>
<body>
  <div class="topbar">
    <div class="row">
      <div><strong>KnowLink</strong></div>
      <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">
        <button id="themeToggle" class="ui-icon theme-toggle" type="button" data-theme-toggle aria-label="Cambiar modo claro u oscuro" title="Cambiar modo claro u oscuro"><i class="fas fa-moon" aria-hidden="true"></i><span class="theme-label">Oscuro</span></button>
        <?php if($u): ?>
          Hola, <?=htmlspecialchars($u['nombre'])?> · <a href="<?=base_url('logout.php')?>">Cerrar sesión</a>
        <?php else: ?>
          <a class="btn outline" href="<?=base_url('login.php')?>">Ingresar</a>
        <?php endif; ?>
      </div>
    </div>
  </div>
  <div class="container">
