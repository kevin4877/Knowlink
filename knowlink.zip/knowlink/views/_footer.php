<?php // views/_footer.php ?>
  </div><!-- .container -->

  <link rel="stylesheet" href="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/css/knowlink-modern.css') : '/assets/css/knowlink-modern.css', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive">
    <script src="<?= htmlspecialchars(function_exists('base_url') ? base_url('assets/js/knowlink-theme.js') : '/assets/js/knowlink-theme.js', ENT_QUOTES, 'UTF-8') ?>?v=20260524-mobile-responsive"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
