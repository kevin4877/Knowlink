<?php
// views/_flash.php
$ok = flash('ok'); $err = flash('error');
if ($ok): ?>
  <div class="flash ok"><?=htmlspecialchars($ok)?></div>
<?php endif; if ($err): ?>
  <div class="flash error"><?=htmlspecialchars($err)?></div>
<?php endif; ?>
