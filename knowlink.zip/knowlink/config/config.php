<?php
// config/config.php
declare(strict_types=1);

define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3307');               // ajusta si usas otro puerto
define('DB_NAME', 'KnowLink');
define('DB_USER', 'root');
define('DB_PASS', '');                   // tu contraseña

// Base URL (sin trailing slash). Ej: /KnowLink/public si NO usas vhost.
define('BASE_URL', '/KnowLink/public');

// Cookies de sesión/remember
define('SESSION_NAME', 'kl_session');
define('COOKIE_SECURE', false);          // true si usas HTTPS
define('COOKIE_SAMESITE', 'Lax');        // 'Lax' o 'Strict'
define('REMEMBER_COOKIE', 'kl_remember');
define('REMEMBER_DAYS', 30);



define('LLM_PROVIDER', 'ollama');
define('LLM_FALLBACK_PROVIDER', 'none');
define('OLLAMA_BASE_URL', 'http://127.0.0.1:11434/api');
define('OLLAMA_MODEL', 'llama3.2:latest');
define('OLLAMA_TIMEOUT', 180); // tiempo amplio para que Ollama genere preguntas sin cortar por timeout

define('OPENAI_BASE_URL', 'https://api.openai.com/v1');
define('OPENAI_API_KEY', '');
define('OPENAI_MODEL', 'gpt-4o-mini');
define('OPENAI_TIMEOUT', 120);