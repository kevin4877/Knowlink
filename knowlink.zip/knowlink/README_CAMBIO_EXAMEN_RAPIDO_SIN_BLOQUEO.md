# Cambio: Examen predictivo rápido sin bloqueo de Apache

Se ajustó la generación del examen predictivo para evitar que XAMPP/Apache se quede esperando respuestas largas de Ollama.

## Cambios aplicados

- El examen ya no llama a Ollama/OpenAI durante la generación.
- Ya no lee temas, chunks, archivos subidos, apuntes ni textos extraídos.
- Las preguntas se generan únicamente con:
  - nombre de la materia,
  - nombre de la unidad,
  - dificultad seleccionada,
  - tipo de examen.
- La explicación profunda también se genera localmente para evitar esperas largas.
- Se redujo el tiempo máximo de espera del `fetch` del examen a 20 segundos, aunque normalmente debe responder mucho antes.
- Se mantienen validaciones para que la respuesta correcta exista dentro de las opciones y para evitar preguntas muy incoherentes.

## Motivo

Ollama puede funcionar correctamente desde CMD, pero al usarse dentro de Apache/PHP puede bloquear una petición durante mucho tiempo. Si se abren varias peticiones o se cierra la ventana mientras el servidor sigue esperando, Apache puede sentirse trabado.

Con este cambio, el examen se genera sin depender de servicios externos y el servidor debe responder más rápido.
