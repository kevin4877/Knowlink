# Cambios admin móvil y notificaciones

- Se corrigió la ruta de notificaciones de docentes: `docente/notificaciones.php` -> `docentes/notificaciones.php`.
- Se corrigieron enlaces antiguos `docente/...` dentro del inicio docente.
- La campana de notificaciones del administrador ahora usa `base_url('admin/notificaciones.php')`, evitando rutas relativas frágiles con ngrok.
- En el inicio del administrador se agregó una sección visible de Gestión académica con accesos a Carreras, Retículas y Materias.
- El dock inferior móvil conserva los 4 accesos principales: Inicio, Estudiantes, Docentes y Administradores.
