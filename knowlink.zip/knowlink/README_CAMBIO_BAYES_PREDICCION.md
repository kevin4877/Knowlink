# Cambio: Predicción con Teorema de Bayes

Se actualizó la predicción de aprobación en `public/estudiantes/ver_materia.php`.

## Antes
La probabilidad se calculaba como una mezcla simple entre historial de aprobación y promedio obtenido.

## Ahora
La probabilidad se calcula usando un modelo bayesiano:

- Hipótesis: el estudiante aprobará el próximo examen predictivo.
- Probabilidad previa: tasa estimada de aprobación de la materia, suavizada para evitar valores extremos.
- Evidencias: promedio ponderado, último intento, tendencia reciente y cantidad de intentos.
- Resultado: probabilidad posterior de aprobar el siguiente examen.

El modelo no requiere cambios en la base de datos. Usa las tablas existentes:

- `examenes_predictivos`
- `examen_intentos`

## Fórmula conceptual

P(Aprueba | Evidencia) = P(Evidencia | Aprueba) * P(Aprueba) / P(Evidencia)

En código se usa una versión Naive Bayes por razones de rendimiento y porque permite combinar varias evidencias sin bloquear Apache.
