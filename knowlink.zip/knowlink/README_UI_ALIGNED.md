# KnowLink UI Aligned

Versión ajustada según las capturas comparativas.

Cambios principales:
- Se igualaron los espacios de topbar, menú lateral, contenido y tarjetas entre modo claro y oscuro.
- El modo oscuro conserva el estilo premium anterior, pero con alineación corregida.
- El modo claro tiene un login propio, limpio y luminoso, diferente al login oscuro.
- Se quitaron elementos visibles innecesarios para el estudiante: retícula, clave de retícula y semestre en el panel de materias.
- Se quitó el subtítulo técnico de retícula/clave dentro de la vista de materia del estudiante.
- Se corrigió un duplicado de JavaScript en el login.
- Se mejoró el contraste de textos, inputs, tarjetas y menús en ambos modos.

Para publicar: subir la carpeta `knowlink` al servidor y mantener la estructura actual.
